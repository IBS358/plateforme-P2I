# P2I — Lot 173 — correction des simulations multileviers

Source : copie de travail du Lot 172. Aucun changement du moteur commun ni des BP historiques.

## Correction effectuée

Le script du Lot 172 réduisait `matieres_kg_annuel` sans réduire `cout_production_kg` et tentait de modifier `charges_fixes_annuel` alors que le moteur consomme `charges_fixes`. Les tests de marge du Lot 172 étaient donc insensibles ou partiellement insensibles aux leviers annoncés.

Dans le Lot 173, la réduction du coût matière est répercutée à l'identique dans `cout_production_kg`, tandis que le coût de conversion implicite reste constant. Le facteur de charges fixes est appliqué à `charges_fixes`. Les changements s'appliquent aux trois années dans la variante `all_years` et à A1 seule dans la variante comparative. Le moteur v107 est inchangé.

## Résultats

| UP | Simulations | Marge >=6% A1, trésorerie/bilan conformes | Marge >=6% A1-A3, trésorerie/bilan conformes |
|---|---:|---:|---:|
| Smartphones | 240 | 115 | 115 |
| Tablettes SKD | 240 | 0 | 0 |
| Remorques agricoles historiques | 240 | 4 | 3 |
| Rayonnages légers | 240 | 0 | 0 |

Les 3 scénarios remorques conformes impliquent tous : prix de vente 1 495 USD (+30 %), 120 unités A1 (x2) et coût matière 456 USD (-40 %). Ces hypothèses ne sont pas démontrées industriellement ni commercialement. Elles ne constituent **pas** une configuration BP Découverte validée.

Exemple smartphone exploratoire : 1 125 unités A1, prix 174 USD (+20 %), matières 78,40 USD (-20 %), charges fixes -10 %. Marges nettes A1-A3 : 6,34 %, 12,88 %, 16,10 %. Les prix, volumes et coûts sont à documenter. Aucun résultat n'est transféré dans le BP public.

## Contrôles et limites

- 960 scénarios exécutés, aucune erreur de calcul signalée.
- Contrôles de trésorerie minimale non négative, équilibre bilans et financement 40/60 dans la qualification.
- Comparaison historique : Lot 172 = 45 / 0 / 0 / 0 scénarios A1-A3 ; Lot 173 = 115 / 0 / 3 / 0.
- Les prix et coûts restent des facteurs de simulation, **pas des devis ni des prix de marché vérifiés**.
- Aucun test manuel Microsoft Edge ; aucun nouveau BP Découverte finalisé ; aucune modification de `main`.

Pour reproduire : `node P2I_Edge/LOT173/recalcul_corrige_v107.cjs`.
