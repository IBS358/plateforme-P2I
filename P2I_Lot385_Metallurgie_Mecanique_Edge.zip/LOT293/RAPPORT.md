# Lot 293 — Bandeaux bloc 2
Huit BP intégrés : image d'usine floutée en arrière-plan, grand médaillon principal, quatre petits médaillons de variantes.
Limite importante : les quatre médaillons de plastiques proviennent de quatre granulés colorés distincts de l'illustration IA ; pour les sept autres UP, les quatre petits médaillons sont des recadrages de l'image IA sectorielle et ne démontrent pas visuellement chacun des produits nommés. Une génération d'images distinctes par variante reste nécessaire pour une conformité visuelle complète.
Toutes les variantes sont hors calcul et à qualifier dans le BP Pro. Les 17 rubriques sont conservées. Le logo original n'a pas été modifié ni remplacé.
