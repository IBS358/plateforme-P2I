const fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.resolve(__dirname,'..');let passed=0;
for(const name of ['MACHINES','STOCKAGE']){
 const html=fs.readFileSync(path.join(root,'LOT197',`CHIFFRAGE_${name}.html`),'utf8');
 const scripts=[...html.matchAll(/<script(?:\s+[^>]*)?>([\s\S]*?)<\/script>/g)].map(m=>m[1]).filter(s=>s.trim());
 for(const s of scripts){new vm.Script(s);passed++}
 const code=scripts[scripts.length-1];
 for(const required of ['qty>0&&price>0','Number(r.quantity)>0&&Number(r.price)>0','sourceDocumentee','motifNonApplicable']){
 if(!code.includes(required))throw Error(name+': garde-fou absent '+required);passed++;
 }
 const match=html.match(/<script type="application\/json" id="nomenclature203">([\s\S]*?)<\/script>/);
 if(!match)throw Error(name+': nomenclature manquante');const bom=JSON.parse(match[1]);if(bom.length!==20)throw Error(name+': '+bom.length+' sous-postes au lieu de 20');passed++;
 if(!html.includes('17 rubriques')&&!fs.existsSync(path.join(root,'LOT193',`BP_${name==='MACHINES'?'MACHINES':'STOCKAGE'}_NOUVELLE_CONFIGURATION_17_RUBRIQUES.html`)))throw Error('BP absent');passed++;
}
const index=fs.readFileSync(path.join(root,'LOT192','INDEX_8_BP_ASSEMBLAGE.html'),'utf8');
for(const m of index.matchAll(/href="([^"]+)"/g)){if(m[1].startsWith('http')||m[1].startsWith('#'))continue;const loc=path.resolve(root,'LOT192',decodeURIComponent(m[1].split('#')[0]));if(!fs.existsSync(loc))throw Error('Lien brisé: '+m[1]);passed++;}
console.log(JSON.stringify({tests_passes:passed,modules:2,nomenclatures:40,liens_index:'OK'}));