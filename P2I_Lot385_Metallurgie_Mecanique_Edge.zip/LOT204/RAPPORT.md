# Lot 204 — Garde-fous de complétude des coûts

Base : Lot 203, fichiers historiques conservés.

## Correction
Dans les deux modules de chiffrage des 20 sous-composants, un montant nul ou une quantité nulle ne peut plus être compté comme coût documenté. Les mentions génériques (« à documenter », « test ») ne suffisent plus comme justificatifs. Les exclusions doivent comporter un motif développé. Les imports historiques et les saisies brouillon restent compatibles ; ils ne sont simplement plus considérés comme complets si nuls.

## Limites
Il s’agit de contrôles déclaratifs, pas d’une vérification indépendante des catalogues. Aucun prix ni résultat v107 nouveau. Le rendu manuel Edge n’est pas vérifié.

## Tests
{"tests_passes":37,"modules":2,"nomenclatures":40,"liens_index":"OK"}

