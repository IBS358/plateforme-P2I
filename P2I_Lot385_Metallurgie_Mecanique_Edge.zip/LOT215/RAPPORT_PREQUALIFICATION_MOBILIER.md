# P2I — Lot 215 : préqualification économique du mobilier scolaire

## Source et conservation
Base exacte : Lot 214 (386 entrées). Tous les fichiers antérieurs sont copiés sans modification. Catalogue actif, irrigation et sept BP historiques inchangés.

## Prix et quantités établis dans les lots 210–214
- 3 barres acier de 6 m pour 2 tables-bancs, au prix historique conditionnel de 7 300 FCFA/barre : 10 950 FCFA par unité.
- 1 panneau contreplaqué à 14 500 FCFA pour 2 tables-bancs : 7 250 FCFA par unité.
- Sous-total acier + bois : 18 200 FCFA par unité.
- Prix historique illustratif de 33 000 FCFA/table-banc : **pas un prix de vente P2I validé**.
- Écart maximal avant les autres charges : 14 800 FCFA par unité (44,85 % du prix illustratif).

## Test de contrainte, pas une simulation v107
À un prix de 33 000 FCFA et pour viser une marge nette de 6 % sur CA, le résultat net requis est 1 980 FCFA/unité. Il ne resterait donc que 12 820 FCFA/unité pour **tous** les postes non encore chiffrés (fixations, embouts, peinture, soudure, main-d’œuvre, énergie, transport, personnel indirect, frais fixes, amortissements, intérêts et fiscalité). À 10 %, ce budget tombe à 11 500 FCFA/unité. Il ne s'agit pas d'un budget réalisable démontré, mais d'un plafond arithmétique.

L'outil interactif `PREQUALIFICATION_MOBILIER.html` permet de saisir les coûts documentés ultérieurement, de voir la contribution avant frais fixes et de calculer le plafond des frais fixes à différents volumes. Il ne calcule pas le résultat net v107, le BFR, les impôts ou les amortissements. Les champs manquants sont volontairement vides : **aucun prix inventé**.

## Bloquants réels avant un BP Découverte v107
1. Plan coté et résistance : tube 30×30×1,5 mm, soudures, qualité du panneau, exigences du cahier des charges.
2. Fournitures : visserie, embouts, apprêt, peinture, consommables, emballage et livraison.
3. Gamme opératoire : temps directs, cadence, taux de rebut, énergie, contrôle qualité.
4. CAPEX complet : coupe métal, perçage, gabarits, soudage, ponçage, peinture, bois, sécurité et manutention ; le poste à souder 100 000 FCFA ne suffit pas.
5. Prix commercial comparable (quantité, dimensions, qualité, livraison, TVA) et commandes/volumes soutenables.

## Décision
Ne pas substituer le mobilier scolaire à l'irrigation dans les 96 UP avant d'avoir documenté les points ci-dessus. Ne pas produire de résultat v107 fictif. Le modèle peut être évalué sans relancer des lots de mise en page.
