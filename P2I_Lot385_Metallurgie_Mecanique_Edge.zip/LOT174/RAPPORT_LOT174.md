# P2I — Lot 174 — Qualification exploitable des simulations corrigées

**Base** : Lot 173, copie locale existante. Moteur commun inchangé. Aucune branche GitHub modifiée.

## Résultats vérifiés

- 960 scénarios lus dans les résultats individuels du Lot 173.
- 118 atteignent une marge nette d'au moins 6 % en A1, A2 et A3 avec les contrôles financiers du Lot 173.
- 16 ont en outre une marge A1 comprise entre 6 % et 8 %.
- Répartition : {'smartphones': 115, 'tablettes': 0, 'remorques_agricoles': 3, 'stockage_manutention': 0}.

## Nouveaux fichiers opérationnels

- `QUALIFICATION_4UP.html` : page autonome ouvrable dans Edge sans serveur.
- `SCENARIOS_CONFORMES_MATHEMATIQUEMENT.csv` : 118 scénarios individuels avec prix, coûts et marges.
- `SYNTHESE_QUALIFICATION.json` : synthèse structurée et douze scénarios classés par ampleur d'ajustements.

## Limites bloquantes

Aucune nouvelle nomenclature fournisseur ni prix de vente ivoirien n'a été vérifié. Les quatre BP manquants ne sont pas livrés. Les 118 scénarios sont des simulations et non des configurations industrielles approuvées. Le classement ne démontre pas la faisabilité. Aucun test manuel dans Edge.

## Contrôles

Vérification du nombre de scénarios, des bornes de marges et de la cohérence de la liste CSV avec les indicateurs JSON. ZIP intégral testé par CRC.
