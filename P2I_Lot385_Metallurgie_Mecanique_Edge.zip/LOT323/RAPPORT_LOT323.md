# Lot 323 — recalculs effectifs v107

Quatre scénarios de débouchés multiflux du lot 263 ont été recalculés avec le moteur commun v107, sans changer les CAPEX et coûts du lot 317. Les marges ci-dessous ne sont pas des validations de marché.

- compost: 0.34 % → 21.67 %, trésorerie minimale 43075 USD
- verre: -0.96 % → 3.2 %, trésorerie minimale 30979 USD
- pneus: -6.36 % → 9.06 %, trésorerie minimale 50439 USD
- huiles: 3.25 % → 17.99 %, trésorerie minimale 56897 USD

DEEE : aucune reprise des recettes génériques, car incompatibles avec la ligne de réfrigérateurs. Verre : le mix ancien ne garantit pas une marge cible.
