# Lot 169 — Simulations économiques v107, quatre UP Assemblage & Montage

## Objet
Calcul effectif des seuils de marge nette A1 de 6 % et 8 % à partir des **anciens scénarios historiques Lot152**, sans remplacer les prix historiques par des prix inventés. Les quatre nouvelles configurations industrielles ne sont pas encore établies.

## Méthode
Recherche numérique du seuil de prix A1, avec le moteur commun v107, en gardant constantes les autres variables du scénario historique; recherche séparée au plafond de capacité historique; tests indépendants sur les matières, la conversion et le volume. Chaque simulation conserve les A2/A3 historiques. La capacité théorique n’est pas une prévision commerciale.

| UP | Prix historique USD | Prix seuil 6 % USD | Prix seuil 8 % USD | Prix seuil 6 % au plafond historique USD |
|---|---:|---:|---:|---:|
| smartphones | 145.00 | 214.17 | 220.56 | 170.67 |
| tablettes | 112.00 | 279.25 | 287.59 | 241.80 |
| remorques_agricoles | 1150.00 | 2525.33 | 2600.71 | 1792.55 |
| stockage_manutention | 105.00 | 247.43 | 254.82 | 186.00 |

## Conclusion
Les quatre anciennes configurations ne peuvent pas atteindre 6 % par le seul accroissement de volume dans leur capacité historique, ni par la seule diminution des matières ou de la conversion dans les bornes du modèle. Les prix seuils ne sont pas des prix de marché validés. Ne pas les intégrer aux BP Découverte comme hypothèses commerciales approuvées.

## Travaux restant à réaliser
Reconstituer les quatre nouvelles nomenclatures et capacités, documenter les prix fournisseurs et les prix de vente ivoiriens, recalculer le moteur v107, puis intégrer les BP Découverte complets à 17 rubriques. La configuration de remplacement des tablettes n’est pas validée.

## Tests
- Exécution Node.js du script de simulation v107 : réussie.
- Bilans équilibrés vérifiés pour les simulations à seuil atteignable : réussie.
- CR A1-A3, trésorerie 12 mois et BFR calculés par le moteur : réussie.
- Prix de marché et compatibilités des nouvelles machines : non vérifiés.
- Tests visuels Microsoft Edge : non effectués.
- GitHub main et archives historiques : non modifiés.
