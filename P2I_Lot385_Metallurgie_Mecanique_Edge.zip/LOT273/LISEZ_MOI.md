# P2I Lot 273 — qualification des huit BP

Ce lot ajoute une interface de réconciliation, huit fiches de qualification et les tableaux CSV/JSON. Il ne remplace pas les calculs des BP existants et ne prétend pas valider les marges du lot 270.

**Important :** les cinq écarts d’EBITDA des UP compost, verre, pneus, huiles et DEEE ne sont pas réconciliés par les sources présentes dans l’archive. Les prix, rendements, CAPEX et contrats ne sont pas suffisamment documentés. Les neuf BP historiques hors de cette filière ne sont pas modifiés.

Ouvrir `P2I_Edge/LOT273/OUVRIR_8_BP_LOT273_EDGE.html` dans Microsoft Edge.
