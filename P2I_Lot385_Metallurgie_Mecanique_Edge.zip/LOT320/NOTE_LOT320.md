# Lot 320 — Application de la règle EXW P2I

Le prix catalogue sans incoterm est traité comme **EXW présumé**, sans présenter cette hypothèse comme une condition commerciale publiée. Le transport usine-port est estimé et ventilé **dans** le budget de fret, installation et formation du lot 317.

- Compost : 3 000 USD usine-port sur enveloppe 25 000 USD.
- Huiles : 6 000 USD sur enveloppe 75 000 USD.
- DEEE : 2 000 USD sur enveloppe 35 000 USD.
- Les cinq autres UP conservent le FOB publié dans la source historique.

Montants indicatifs P2I arrondis, non issus de devis. Aucun investissement supplémentaire et aucun recalcul v107 : les frais étaient déjà provisionnés globalement. Les marges des cinq UP sous le seuil de 6 % ne sont pas validées par cette clarification. Les huit BP du lot 320 comprennent une annexe explicite et conservent les 17 rubriques du lot 319.
