# P2I — Lot 157 : reprise exécutable et contrôle financier

## Périmètre réel
Archive de départ : P2I_Edge_96_UP_Lot156_Complet.zip (copie locale). Aucun changement des scénarios actifs Lot155, du moteur v107, du catalogue, des 17 rubriques, des visuels, ni des archives historiques. Aucun changement de GitHub `main`.

Ce lot **n'achève pas** les quatre BP : les hypothèses indispensables de prix rendus, BOM complète, capacité et ventes restent non validées. Il ajoute un test reproductible et une extraction complète des résultats historiques v107, afin de reprendre sur une base contrôlée plutôt que d'accumuler des diagnostics.

## Résultats des recalculs historiques Lot152 (A1)

| UP | Résultat net A1 USD | Marge nette A1 | Qualification |
|---|---:|---:|---|
| Smartphones | -46 831,20 | -35,89 % | Scénario historique, non redressé |
| Tablettes | -130 420,80 | -129,39 % | Scénario historique, non redressé |
| Remorques 750 kg | -70 398,00 | -102,03 % | Non transposable à la remorque 3 tonnes |
| Rayonnages | -85 844,80 | -116,80 % | Scénario historique, non redressé |

Les sorties intégrales figurent dans `RECALCULS_HISTORIQUES_V107_4_UP.json` : entrées, CR trois ans, trésorerie douze mois, BFR trente-six mois, bilans trois ans et contrôles du moteur.

**Attention** : les soldes de trésorerie minimaux positifs proviennent notamment de la réserve initiale modélisée; ils ne prouvent pas la viabilité d'une activité déficitaire.

## Tests exécutés
- `node LOT155/test_lot155_integration.cjs` : réussi, trois scénarios actifs préservés.
- `node LOT156/test_lot156.cjs` : réussi, catalogue 96 UP / 12 filières / 8 UP Assemblage, 17 rubriques et visuels référencés.
- `node LOT157/test_recalculs_historiques.cjs` : réussi, quatre recalculs v107, 3 CR, 12 mois de trésorerie, 36 mois BFR, 3 bilans équilibrés et financement 40/60 pour chacun.

## Non exécuté / non validé
- Aucune nouvelle configuration industrielle, BOM complète ou prix local de vente n'a été validé.
- Aucun nouveau scénario économique alternatif pour les quatre UP n'a été calculé.
- Aucun contrôle graphique, export PDF, clic utilisateur ou parcours Microsoft Edge n'a été effectué.
- La filière Assemblage & Montage n'est **pas clôturée**.

## Suite de production
Établir en une campagne cohérente les quatre BOM complètes et leurs prix rendus, puis intégrer les configurations alternatives documentées au moteur v107. Ne pas modifier artificiellement les marges, ni substituer des prix FOB aux coûts rendus ou aux prix nets de vente.
