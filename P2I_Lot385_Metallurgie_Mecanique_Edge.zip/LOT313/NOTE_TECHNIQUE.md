# Lot 313 — sélection catalogue Verre et Huiles

Six annonces publiques supplémentaires qualifiées. Aucune modification des CAPEX historiques. Les annonces de gammes ne sont pas des prix par modèle. Huiles : la référence 20 t/j n'est pas équivalente à 2,5 t/h sur 4 224 heures annuelles ; ne pas utiliser sans redimensionnement. Verre : le tri optique à 5 t/h ne peut pas suivre 6 t/h sans adaptation. Les 8 BP sont conservés.
