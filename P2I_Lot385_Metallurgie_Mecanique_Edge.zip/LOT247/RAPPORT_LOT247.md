# P2I — Lot 247 : contrôle énergie et sensibilité

Base : archive intégrale du lot 246. Aucun des huit BP n'est déclaré terminé.

## Livré
- Outil HTML hors ligne pour calculer, par UP, la consommation électrique et le coût par tonne vendable.
- Récapitulatif des huit périmètres et références candidates repris du registre du lot 246.
- Conservation intégrale des fichiers du lot 246, sans modification du moteur v107.

## Réserves bloquantes
- Modèles et prix de lignes complètes non qualifiés pour huit UP.
- Puissances réellement absorbées, rendements, débouchés, coûts matière, logistique et BFR non justifiés.
- Les calculs de cet outil sont des sensibilités paramétrables, non des projections financières.
- Aucune recherche fournisseur externe ou validation de prix effectuée dans ce lot.

## Conditions de finalisation
Compléter les preuves commerciales, industrielles et énergétiques, puis exécuter le moteur v107 sur les 8 configurations, vérifier CR/bilan 3 ans et trésorerie 12 mois, tests Edge et export PDF.
