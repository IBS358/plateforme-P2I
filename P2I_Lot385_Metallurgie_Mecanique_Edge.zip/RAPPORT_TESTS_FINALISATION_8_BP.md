# P2I — Rapport concis des contrôles finaux

- **Catalogue/runtime :** les scripts de démarrage et le catalogue ont été chargés en environnement JavaScript; 96 identifiants uniques, 12 filières et huit UP Assemblage & Montage. `tablettes` et `ordinateurs` redirigent vers `machines_conditionnement_pme`; l’entrée Tablettes et les modules financiers historiques restent présents. L’illustration correspondante et son manifeste local sont raccordés.
- **Index et BP :** les huit liens de l’index ouvrent des fichiers existants. Les 8 pages ont 17 rubriques chacune; contrôle des chemins relatifs des ressources et liens : aucune ressource locale manquante (20, 22, 22, 22, 20, 27, 39 et 27 liens respectivement).
- **Préservation :** les données d’entrée et de résultat v107 des machines de conditionnement et des rayonnages sont inchangées; les cinq pages historiques (cuisines, tricycles, vélos, équipements sportifs, smartphones) sont identiques octet par octet à l’archive d’entrée.
- **Moteur financier :** la remorque seule a été recalculée par le moteur commun v107. Tous les scénarios v107 présents comportent 3 années de résultat, 12 mois de trésorerie, 36 périodes de BFR, financement 40/60 et bilans équilibrés à l’arrondi machine. Le déficit remorque est maintenu.
- **Machine :** contrôle arithmétique sans double compte : composants 2 610 + conversion 840 = fabrication 3 450 USD/unité; distribution séparée; CAPEX atelier immobilisé. Résultat conservé, positif sous hypothèses.
- **Navigation/téléchargements :** chemins de l’index vers les pages, matrice, rapport et JSON v107 vérifiés; boutons d’impression/téléchargement existants conservés.

Limite de vérification : pas d’interaction manuelle réelle dans Microsoft Edge dans cet environnement; les contrôles sont statiques et l’exécution des scripts est vérifiée en JavaScript. Aucune validation d’ingénierie mécanique, de conformité ou de demande commerciale n’est revendiquée. L’archive finale a passé `unzip -t` sans erreur.
