# Lot 165 — qualification intégrée des quatre UP restantes

**Version de départ :** copie de travail Lot164, issue du ZIP Lot161. **Aucune modification de GitHub ni de `main`.**

## Fichiers modifiés / créés
- `index.html` : chargement du garde-fou de qualification.
- `runtime/lot165-qualification.js` : statut explicite des quatre configurations non validées; ajout d’un avertissement dans les champs rédactionnels du registre, sans altérer les calculs historiques.
- `LOT165/QUALIFICATION_4UP.html` : page autonome consultable dans Edge.
- `LOT165/DECISIONS_4UP.json` : décisions structurées.
- `LOT165/TESTS_LOT165.json` : contrôles automatiques.

## Limites
Aucun nouveau BP financier n’a été calculé : les nomenclatures, coûts complets, prix et ventes des configurations de remplacement ne sont pas suffisamment documentés. Les quatre BP antérieurs positifs sont conservés sans modification. Le lot n’est **pas** une finalisation des huit BP. Les 17 rubriques historiques sont conservées; aucune validation visuelle Microsoft Edge n’a été effectuée.
