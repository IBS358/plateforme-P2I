# Lot 341 — Visuels contextualisés pour les 54 postes

Les huit BP Découverte du lot 340 sont conservés. Les 54 cartes de postes (7+6+6+7+7+7+7+7) présentent désormais une vue photoréaliste IA d'atelier en complément de leur schéma fonctionnel spécifique.

**Limite explicitée :** la vue IA est réutilisée pour les postes d'une même UP; elle ne représente pas individuellement le modèle exact de chaque machine. Le schéma SVG de chaque poste est distinct. Il ne faut pas présenter les 54 cartes comme 54 photographies de machines différentes.

Aucun recalcul financier; les 17 rubriques, les variantes, les médaillons, les tableaux v107 et les autres fichiers historiques sont préservés. Le verre reste à 3,20 %, le DEEE est conditionnel à la rémunération de la dépollution.

Contrôles : présence des 54 cartes enrichies, vérification des références aux photos et schémas, intégrité ZIP.
