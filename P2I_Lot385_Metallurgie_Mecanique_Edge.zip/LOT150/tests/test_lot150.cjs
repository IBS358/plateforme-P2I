'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const root=path.resolve(__dirname,'../../runtime');
const app=path.resolve(__dirname,'../..');
const c={console,Math,Number,String,Array,Object,Map,Set,JSON,Error,TypeError,Date,Intl,URL,URLSearchParams};
c.window=c;c.location={search:'?unit_id=cuisines_pro_chambres_froides',href:'file:///P2I_Edge/index.html?unit_id=cuisines_pro_chambres_froides'};c.history={replaceState(){}};
vm.createContext(c);
const files=['script-0.js','script-1.js','script-2.js','script-3.js','script-4.js','script-5.js','script-6.js','script-7.js','script-8.js','script-9.js','script-10.js','script-11.js','script-12.js','script-13.js','script-14.js','script-15.js','script-16.js','lot147-data.js','lot149-data.js','lot150-assemblage-data.js','catalogue-up-actif.js','script-17.js','economic-anomaly-guard.js','lot147-render.js','lot149-render.js'];
for(const f of files)vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),c,{filename:f});
new vm.Script(fs.readFileSync(path.join(root,'script-18.js'),'utf8'),{filename:'script-18.js'});
const cat=c.P2I_CATALOGUE_UP_ACTIF,ids=cat.filieres.flatMap(f=>f.up_ids),assembly=cat.filieres.find(f=>f.id==='assemblage').up_ids;
assert.equal(ids.length,96);assert.equal(new Set(ids).size,96);assert.equal(cat.filieres.length,12);
assert.deepEqual(JSON.parse(JSON.stringify(assembly)),['smartphones','tablettes','cuisines_pro_chambres_froides','tricycles_utilitaires','velos','equipements','remorques_agricoles','stockage_manutention']);
const expected=['smartphones','tablettes','tricycles_utilitaires','velos','equipements','remorques_agricoles','stockage_manutention'];
for(const id of expected){const d=c.P2I_BP_DONNEES.unites[id];assert.ok(d,`missing dossier ${id}`);assert.ok(d.processus.length>=5,`process missing ${id}`);assert.ok(d.machines.length>=4,`machines missing ${id}`);assert.equal(d.economie.qualification,'non_calculable_donnees_essentielles_manquantes');const r=c.P2I_BP_DONNEES_ENGINE.calculer(d);assert.equal(r.financier.complet,false);assert.equal(r.resultat_net,null);assert.equal(r.tresorerie,null);}
const text18=fs.readFileSync(path.join(root,'script-18.js'),'utf8');
const short=text18.match(/const SHORT=(\[[^;]+\]);/);assert.ok(short);const rubricCount=(short[1].match(/'[^']*'/g)||[]).length;assert.equal(rubricCount,17);
const adminSource=text18.slice(text18.indexOf('function administrativeOrientation('),text18.indexOf('\nfunction render(){'));
assert.ok(adminSource.startsWith('function administrativeOrientation('),'common administrative component missing');
const adminContext={String};adminContext.window=adminContext;adminContext.esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
vm.createContext(adminContext);vm.runInContext(adminSource+';window.admin=administrativeOrientation;',adminContext);
for(const id of ids){const up=c.P2I_BP_DONNEES.unites[id]||c.P2I_BP_DONNEES_ENGINE?.unites?.[id]||{nom:id,filiereNom:''};const html=adminContext.admin(id,up,up.nom||id);assert.equal((html.match(/class="p2i-admin-card"/g)||[]).length,7,`admin cards missing for ${id}`);assert.ok(html.includes('Fiscalité, emploi et organismes'),`tax/employment card missing for ${id}`);assert.ok(html.includes('Code des investissements'),`investment-code card missing for ${id}`);assert.ok(html.includes('DGI — fiscalité')&&html.includes('CNPS — employeurs'),`official tax/employment sources missing for ${id}`);}
for(const [id,term] of [['smartphones','effacement des données'],['tablettes','ARTCI'],['cuisines_pro_chambres_froides','fluide frigorigène'],['tricycles_utilitaires','mise en circulation'],['velos','cargos électriques'],['equipements','ancrages'],['remorques_agricoles','charge utile'],['stockage_manutention','charges admissibles']]){const up=c.P2I_BP_DONNEES.unites[id];assert.ok(adminContext.admin(id,up,up.nom).includes(term),`activity-specific admin note missing for ${id}`);}
const adminCss=fs.readFileSync(path.join(root,'style-2.css'),'utf8');for(const selector of ['.p2i-admin-cards','.p2i-admin-card','.p2i-admin-card-head'])assert.ok(adminCss.includes(selector),`validated card styling missing ${selector}`);
const kitchen=c.P2I_BP_DONNEES_ENGINE.reference('cuisines_pro_chambres_froides','reference');const k=c.P2I_LOT147.calculate(kitchen);
assert.ok(Math.abs(k.annuel[0].resultat_net-24459.3462)<0.01);assert.equal(k.controles.tresorerie_mois,12);assert.equal(k.controles.bfr_mois,36);assert.equal(k.controles.bilans_equilibres,true);assert.equal(k.controles.financement,'40/60');
const html=fs.readFileSync(path.join(app,'index.html'),'utf8');assert.ok(html.indexOf('lot150-assemblage-data.js')<html.indexOf('catalogue-up-actif.js'));
const migration=c.P2I_BP_DONNEES.migrations_identifiants.lot150.entries;assert.equal(migration.ordinateurs.new_id,'tablettes');assert.equal(migration.motos.new_id,'tricycles_utilitaires');assert.equal(migration.climatiseurs.new_id,'remorques_agricoles');assert.equal(migration.meubles.new_id,'stockage_manutention');
console.log(JSON.stringify({lot:151,passed:true,catalogue:{up:ids.length,unique:new Set(ids).size,filieres:cat.filieres.length},administrative_cards_rendered:ids.length*7,administrative_specificity_checks:8,administrative_visual_model:'existing compact cards and CSS preserved',assembly_ids:assembly,custom_dossiers:expected.length,custom_dossiers_financially_complete:0,rubriques:rubricCount,kitchen_lot149_v107_A1_net_usd:k.annuel[0].resultat_net,kitchen_lot149_margin_A1_pct:k.annuel[0].resultat_net/k.annuel[0].chiffre_affaires*100,kitchen_cash_months:k.controles.tresorerie_mois,kitchen_bfr_months:k.controles.bfr_mois,kitchen_balances_equilibrated:k.controles.bilans_equilibres,kitchen_funding:k.controles.financement,edge_visual_test:false,notes:'Global administrative component is corrected. Seven Assembly financial forecasts and activity-specific images remain incomplete; no unknown values were imputed.'},null,2));
