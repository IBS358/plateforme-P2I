# Lot 150 — intégration Assemblage & Montage

## État de livraison

La copie Lot 149 est conservée. Le catalogue actif est aligné sur huit UP Assemblage : smartphones reconditionnés, tablettes, cuisines/chambres froides, tricycles utilitaires, vélos, équipements sportifs, remorques agricoles et stockage/manutention. Quatre nouveaux identifiants sont introduits avec une table de migration explicite; les dossiers d'origine ordinateurs, motos, climatiseurs et meubles restent dans le référentiel historique. La redirection des anciens liens est explicitée dans `runtime/catalogue-up-actif.js`.

Les sept dossiers de travail ont été intégrés dans le moteur de rendu à 17 rubriques avec produits, flux, postes, nomenclatures descriptives, marchés, risques et sources déjà recensées. Le Lot 149 Cuisine n'a pas été recalculé ni modifié dans ses hypothèses.

**Le Lot 150 n'est pas une clôture financière des sept BP.** Les calculs du moteur économique descriptif retournent `complet:false` et les résultats restent `null`, car le coût d'acquisition du produit/kit, les prix nets et/ou le CAPEX et les cadences effectives manquent encore. Aucun scénario n'a été fabriqué. Les états v107 complets (CR 3 ans, trésorerie 12 mois, BFR, bilan, ROI) ne sont donc pas publiés pour ces sept UP.

Les images spécifiques des sept activités n'étant pas présentes dans la banque média Lot 149, aucune photo d'une autre filière n'a été réaffectée. Les emplacements visuels propres à ces UP restent à intégrer avant de qualifier leurs BP de complets.

## Migrations explicites

| Ancien ID conservé dans l'historique | ID actif | Activité active |
|---|---|---|
| `ordinateurs` | `tablettes` | Assemblage de tablettes éducatives et professionnelles |
| `motos` | `tricycles_utilitaires` | Assemblage de tricycles utilitaires |
| `climatiseurs` | `remorques_agricoles` | Fabrication de remorques agricoles et utilitaires légères |
| `meubles` | `stockage_manutention` | Équipements de stockage et manutention légère |
| `electromenager` | `cuisines_pro_chambres_froides` | Migration Lot 149 conservée |

Les anciens dossiers restent dans `runtime/script-16.js`; les quatre anciens liens redirigent vers les nouveaux identifiants, tandis que `migrations_identifiants.lot150` garde la correspondance et sa justification.

## Références techniques déjà conservées

| UP | Repères techniques inscrits | Réserve majeure |
|---|---|---|
| Smartphones reconditionnés | TBK-801, TBK-2206, diagnostic, effacement, réparation, tests et grading | Prix d'achat de lots, taux réparable, pièces, garantie et cadence |
| Tablettes | Offre Smartlink 10,1 pouces à 154,47 USD FOB affichée comme kit non assemblé; postes ESD/tests | Packing list du kit, licences, prix net et cadence |
| Tricycles | Jolmolangma JLM31001/JLM31003, 1 000 W, 48/60 V, batterie annoncée 45 Ah | Pas de charge utile confirmée; prix 380–410 USD non attribué à ces modèles |
| Vélos | Robot Quattro Holland Mechanics et BOM mécanique 26 pouces | Prix/capacité machine et coût de kits absents |
| Équipements sportifs | QD-1325 (listing 4 500–19 700 USD, options non appariées) et MIG250DC-1 (265–288 USD FOB) | Postes auxiliaires, BOM coté et prix net hors pose |
| Remorques | QD-1325, presse WC67Y 100T/3200 (11 700–12 700 USD FOB), MIG250DC-1 | Tare/PTAC/charge utile et BOM massique non libérés; atelier partagé avec sport |
| Stockage/manutention | Profileuse montants Raintech 59 000–67 500 USD FOB | Prix limité aux montants; lignes traverses/plateaux et charges admissibles absentes |

Ces prix sont des annonces ou plages précédemment recensées, pas des prix rendus Côte d'Ivoire ni des CAPEX complets. Les comparateurs commerciaux locaux ne sont pas convertis en prix usine.

## Vérifications de ce lot

Reproductibles via `tests/test_lot150.cjs` : nombre et unicité des 96 IDs, 12 filières, huit identifiants Assemblage attendus, présence des sept dossiers, structure à 17 rubriques, maintien des inconnues financières, calcul v107 du scénario Cuisine Lot 149 et clé de financement 40/60. La syntaxe Node des scripts et l'intégrité du ZIP ont aussi été contrôlées.

**Non vérifiés dans Microsoft Edge :** le rendu graphique réel, les clics de navigation, l'affichage des images spécifiques (non intégrées), l'export PDF et le téléchargement. Le ZIP s'ouvre localement avec `P2I_Edge/index.html`, mais une validation visuelle Edge reste nécessaire.
