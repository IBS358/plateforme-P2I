# P2I — Lot 253 : dimensionnement industriel (étude exploratoire)

## Portée
Reprise intégrale du ZIP Lot 252. Aucune modification des BP historiques, des neuf UP déjà traitées, du moteur v107 ou des autres filières. Ajout d'un tableau de sensibilité pour le plastique et d'un registre de capacités de travail pour les huit UP de Recyclage & Valorisation.

## Méthode
Capacités plastique : 500, 1 000 et 2 000 kg/h ; taux d'utilisation 50, 70, 85 et 95 %. Calculs fondés sur les hypothèses du scénario exploratoire Lot 251, **pas sur des prix industriels nouveaux**. Extrapolation CAPEX = CAPEX_500 × (capacité/500)^0,75 ; charges fixes = charges_500 × (capacité/500)^0,65. Ces exposants sont des hypothèses d'analyse non documentées. Les consommations spécifiques, rendements et prix unitaires restent constants par hypothèse, ce qui peut être irréaliste.

## Limites
Le prix 550 FCFA/kg ne valide pas le marché des paillettes lavées. Les 1 000 et 2 000 kg/h ne disposent pas de devis ni de catalogue qualifié. Les sept autres UP n'ont pas de scénario financier inventé. Aucun compte v107, bilan, BFR, TVA, IS ou trésorerie mensuelle n'a été calculé. Aucune UP supplémentaire n'est déclarée achevée.

## Prochain verrou industriel
Pour chaque capacité candidate, obtenir prix catalogue correspondant à une ligne complète, puissance installée, énergie spécifique, rendement et coût de maintenance ; puis vérifier le gisement et les ventes réalistes en Côte d'Ivoire avant le calcul v107.
