'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const app=path.resolve(__dirname,'../..'),root=path.join(app,'runtime');
const c={console,Math,Number,String,Array,Object,Map,Set,JSON,Error,TypeError,Date,Intl,URL,URLSearchParams};c.window=c;c.location={search:'?unit_id=smartphones',href:'file:///P2I_Edge/index.html?unit_id=smartphones'};c.history={replaceState(){}};vm.createContext(c);
const files=['script-0.js','script-1.js','script-2.js','script-3.js','script-4.js','script-5.js','script-6.js','script-7.js','script-8.js','script-9.js','script-10.js','script-11.js','script-12.js','script-13.js','script-14.js','script-15.js','script-16.js','lot147-data.js','lot149-data.js','lot150-assemblage-data.js','lot152-assemblage-finances.js','catalogue-up-actif.js','script-17.js','lot152-assemblage-visuels.js','economic-anomaly-guard.js','lot147-render.js','lot149-render.js'];
for(const f of files)vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),c,{filename:f});
new vm.Script(fs.readFileSync(path.join(root,'script-18.js'),'utf8'),{filename:'script-18.js'});
const cat=c.P2I_CATALOGUE_UP_ACTIF,ids=cat.filieres.flatMap(f=>f.up_ids),assembly=cat.filieres.find(f=>f.id==='assemblage').up_ids;
assert.equal(ids.length,96);assert.equal(new Set(ids).size,96);assert.equal(cat.filieres.length,12);
assert.deepEqual(JSON.parse(JSON.stringify(assembly)),['smartphones','tablettes','cuisines_pro_chambres_froides','tricycles_utilitaires','velos','equipements','remorques_agricoles','stockage_manutention']);
const expected=['smartphones','tablettes','tricycles_utilitaires','velos','equipements','remorques_agricoles','stockage_manutention'];
const reports=[];
for(const id of expected){
 const d=c.P2I_BP_DONNEES.unites[id],x=c.P2I_LOT152_FINANCES.units[id],v=c.P2I_BP_LOT81_VISUALS;
 assert.ok(d&&x,`dossier or calculation absent: ${id}`);
 assert.equal(x.result.version,'107');assert.equal(x.result.annuel.length,3);assert.equal(x.result.tresorerie.length,12);assert.equal(x.result.bfr.length,36);
 assert.equal(x.result.controles.bilans_equilibres,true);assert.equal(x.result.controles.financement,'40/60');assert.ok(x.result.bilans.every(b=>Math.abs(b.ecart)<.02));
 assert.ok(x.result.annuel.every(a=>a.chiffre_affaires>0));assert.equal(d.variantes.reference.reference.up_id,id);
 assert.ok(fs.existsSync(path.join(app,v.atlas['lot152-'+id].image)));
 assert.ok(v.processus[id].steps.length>=6);assert.ok(Object.keys(v.processus[id].images_by_step).length===v.processus[id].steps.length);
 assert.equal(v.variantes_commerciales[id].reference.length,2);
 reports.push({id,name:d.nom,revenue:x.result.annuel.map(a=>a.chiffre_affaires),net:x.result.annuel.map(a=>a.resultat_net),margin_a1:x.result.annuel[0].resultat_net/x.result.annuel[0].chiffre_affaires,min_cash_a1:Math.min(...x.result.tresorerie.map(r=>r.solde_final)),capex:x.input.investissement,initial_reserve:x.result.reserve_initiale,balance_ok:x.result.controles.bilans_equilibres,financial_status:'indicative_not_validated'});
}
const html=fs.readFileSync(path.join(app,'index.html'),'utf8');assert.ok(html.indexOf('lot152-assemblage-finances.js')<html.indexOf('script-18.js'));assert.ok(html.indexOf('script-17.js')<html.indexOf('lot152-assemblage-visuels.js'));assert.ok(html.indexOf('lot152-assemblage-visuels.js')<html.indexOf('script-18.js'));
const n=fs.readFileSync(path.join(root,'script-18.js'),'utf8').match(/const SHORT=(\[[^;]+\]);/);assert.ok(n);assert.equal((n[1].match(/'[^']*'/g)||[]).length,17);
const output={lot:152,passed:true,catalogue:{up:ids.length,unique:new Set(ids).size,filieres:cat.filieres.length},assemblage_ids:assembly,calculated_units:reports.length,all_scenarios:{engine:'v107',years:3,treasury_months:12,bfr_months:36,balances_equilibrated:true,funding:'40/60'},visuals:{format:'UP-specific P2I vector atlases',units:reports.length,steps_per_unit:'6',variants_per_unit:2,ai_or_supplier_photographs:false,description:'Purpose-built vector illustrations; not documentary machine photos.'},financial_results:reports,scope:'No admin component, kitchen scenario, prior validated scenarios, or main branch changed.'};
fs.writeFileSync(path.join(app,'LOT152/results/v107-simulations.json'),JSON.stringify(output,null,2));
console.log(JSON.stringify(output,null,2));
