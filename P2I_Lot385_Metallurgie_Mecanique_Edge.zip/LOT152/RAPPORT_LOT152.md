# Lot 152 — Assemblage & Montage : BP et calculs v107

Date : 16 novembre 2026. Base : copie complète du Lot 151. Le Lot 151 et les archives antérieures restent intacts; la branche `main` n’a pas été modifiée.

## Résultat du lot

Les sept dossiers d’Assemblage ont reçu une configuration financière centrale indicative, des entrées raccordées au moteur commun v107, un registre d’hypothèses et sources, ainsi que des visuels vectoriels propres à chaque UP. Chaque scénario comporte un compte de résultat sur trois ans, 12 mois de trésorerie, 36 mois de BFR, trois bilans équilibrés et le financement 40/60 du CAPEX. Les hypothèses de chiffre d’affaires et certains coûts de production/équipements sont des estimations P2I; aucun résultat n’est qualifié de validation économique.

| UP | CA A1 (USD) | Résultat net A1 (USD) | Marge A1 | Trésorerie minimale fin de mois (USD) | Réserve de lancement calculée v107 (USD) |
|---|---:|---:|---:|---:|---:|
| Reconditionnement industriel de smartphones | 130 500 | -46 831 | -35.89% | 4 200 | 66 286 |
| Assemblage de tablettes éducatives et professionnelles | 100 800 | -130 421 | -129.39% | 2 800 | 166 173 |
| Assemblage de tricycles utilitaires | 148 000 | 3 400 | 2.30% | 5 389 | 17 405 |
| Assemblage de vélos économiques  scolaires et utilitaires | 176 250 | -4 579 | -2.60% | 5 800 | 27 702 |
| Fabrication et installation d’équipements sportifs de proximité | 112 500 | -14 181 | -12.61% | 4 200 | 28 253 |
| Fabrication de remorques agricoles et utilitaires légères | 69 000 | -70 398 | -102.03% | 5 500 | 84 518 |
| Fabrication d’équipements de stockage et de manutention légère | 73 500 | -85 845 | -116.80% | 11 800 | 107 883 |

La trésorerie mensuelle affichée est positive dans les scénarios après la réserve initiale calculée par v107. Cette réserve varie de 17 405 USD à 166 173 USD, financée séparément par l’apport dans le modèle; il faut l’inclure dans le besoin de fonds à mobiliser. Les pertes A1 des six autres dossiers ne sont pas masquées.

## Hypothèses structurantes et recommandations

- **Smartphones :** coût du lot de téléphones ancré à une offre publique de 77 USD pour 1 000+ appareils G7 grade A+, mais contenu/rendement des lots hétérogènes non garanti. Le scénario est déficitaire; à revoir autour d’une grille réelle de modèles/grades et des taux de panne, sans extrapoler l’offre G7 à toute la gamme.
- **Tablettes :** le kit Smartlink à 154,47 USD FOB dépasse le prix net P2I simulé à 112 USD avant les auxiliaires; le déficit est structurel dans cette configuration. Pas de rentabilité à annoncer avant une autre offre SKD qualifiée ou le choix d’un autre segment d’appareil.
- **Tricycles :** seul résultat A1 positif (+3 400 USD, 2,30 %). Le tarif FOB du JLM31001 est public (420–460 USD; 52 CKD par conteneur 40HQ); le scénario dépend encore de charges rendues et d’un prix de vente P2I estimés. Ce résultat n’est donc pas une validation commerciale.
- **Vélos :** la valeur FOB 55,80 USD porte sur un vélo fini, pas un kit CKD. Elle n’a pas été utilisée comme prix fournisseur du kit; le coût matière de 112 USD demeure une estimation P2I de BOM. Résultat A1 légèrement négatif.
- **Sports / remorques :** atelier de découpe, pliage et soudage mutualisé modélisé une seule fois dans le registre CAPEX de 54 000 USD, ventilé à 24 000 USD pour Sports et 30 000 USD pour Remorques; budgets dédiés respectifs 18 000 et 25 000 USD. L’allocation est une hypothèse P2I, pas une offre de machines. Les deux dossiers sont déficitaires en A1; charge admissible de remorque non spécifiée.
- **Stockage :** la profileuse Raintech documentée ne constitue qu’une partie de la ligne; la fabrication de traverses et plateaux, et la capacité de charge, sont à compléter. Le prix de vente et plusieurs coûts sont estimatifs; perte A1 significative.

## Présentation et visuels

Chaque dossier conserve les 17 rubriques. Le bloc 2 reçoit le produit principal et deux variantes commerciales illustrées; le bloc 17 reçoit six postes numérotés et illustrés par UP. Ces sept planches sont des **illustrations vectorielles P2I** de produits et d’opérations, pas des photographies documentaires de machines, ni des visuels fournisseurs. Elles ne comportent pas de personnes; aucun portrait artificiel ni logo P2I recréé.

## Contrôles exécutés

- Test Node `LOT152/tests/test_lot152.cjs` : réussi; 96 identifiants uniques, 12 filières, sélection Assemblage conservée, 17 rubriques déclarées, sept scénarios v107 calculés, 12 mois de trésorerie, 36 mois de BFR, bilans équilibrés et répartition 40/60.
- Vérification des chemins locaux des sept planches SVG, des six correspondances poste-image et des deux variantes par UP : réussie.
- Les archives Lot 151 sont conservées et le catalogue actif compte toujours 96 UP / 12 filières.
- **Microsoft Edge réel : non vérifié.** Le navigateur Chromium local n’a pas pu démarrer dans l’environnement d’exécution; le contrôle visuel final reste à effectuer en ouvrant `P2I_Edge/index.html` dans Edge. Aucun clic d’export PDF n’est déclaré testé.

## Principales réserves

Ces calculs démontrent le fonctionnement du moteur pour les nouveaux dossiers, mais la plupart des lignes ne sont pas financièrement défendables pour décision d’investissement sans confirmation des hypothèses P2I, notamment les coûts rendus, salaires, ventes, capex auxiliaires et nomenclatures. Les scénarios tablettes, smartphones, remorques et stockage appellent un repositionnement ou une nouvelle configuration économique; les marges négatives restent visibles.
