# Lot 265 — UP Verre : redimensionnement avant validation

Source : P2I_Edge/LOT264/finances/verre.json (archive Lot 264). Conservation intégrale des 644 entrées du lot 264.

## Diagnostic A1 existant
- CA : 792,304,128 FCFA ; EBITDA : 191,720,384 FCFA ; résultat net : -48 279 616 FCFA ; DSCR 0,88.
- CAPEX hypothétique : 1,5 milliard FCFA, amorti en 10 ans ; dette 60 %, taux indicatif 10 %, amortissement du principal en 7 ans.
- Le tableau de trésorerie initial suppose des ventes et encaissements uniformes ; il n'est pas un BFR détaillé.

## Changement industriel retenu pour étude (non encore validé)
Conserver le tri, nettoyage/dépollution, broyage, criblage, séparation des indésirables et conditionnement. Ne pas intégrer de four de fusion. Commercialiser le calcin par couleur et, seulement après qualification commerciale, les fractions de granulats/sable de verre. **Aucun revenu de coproduit n'est ajouté sans justification.**

## Sensibilité investissement + productivité
Les 24 cas du CSV font varier **indépendamment** le CAPEX entre 0,5 et 1,5 milliard FCFA et l'amélioration de l'EBITDA entre 0 et 120 M FCFA. Une baisse de CAPEX n'est **pas** une offre catalogue ni la preuve qu'une ligne de 6 t/h peut être achetée à ce montant. Une amélioration d'EBITDA n'est **pas** un contrat de vente.

La cible de marge nette 6 % est calculée avec un impôt illustratif de 25 % sur bénéfice positif ; ceci n'est pas une vérification fiscale du régime CI. Les charges d'exploitation, les ventes et le rendement sont maintenus constants pour isoler l'effet financier. Le taux d'utilisation, le BFR réel, les bilans équilibrés et le moteur v107 restent à traiter.

## Garde-fous de décision
1. Obtenir prix catalogue de ligne complète 5–8 t/h, équipements de dépollution, séparation, conditionnement, eau et poussières, avec débits garantis.
2. Vérifier 15 000 t/an environ de calcin vendable, collecte ~17 700 t/an, et contrats de vente à la qualité requise.
3. Documenter les prix par fraction de sortie, les refus et le coût de leur traitement ; ne pas cumuler deux ventes pour la même tonne.
4. Recalculer le BFR et la trésorerie mensuelle, l'amortissement, le bilan et la dette via v107.
5. Si aucun scénario vérifié n'atteint RN/CA ≥ 6 % et DSCR ≥ 1,2, garder l'UP en statut non qualifié, ne pas forcer les chiffres.
