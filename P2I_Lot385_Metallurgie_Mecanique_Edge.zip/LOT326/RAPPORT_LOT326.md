# Lot 326 — Consolidation des huit BP Recyclage & Valorisation

Source : lot 325 conservé intégralement.

Sept UP : résultats déjà obtenus et conservés, verre 3,20 % accepté.

DEEE : scénario de référence **conditionnel** de 300 USD/t de prestation de dépollution, selon le moteur v107 du lot 325 : CA A1 838 075 USD, RN A1 151 264 USD, marge A1 18,05 %. Apport 40 % / dette 60 %, 12 mois de trésorerie, bilans équilibrés selon contrôles.

Sans prestation : −108,07 %. Aucun tarif commercial ou contrat n'est démontré. Le scénario conditionnel ne constitue pas une validation commerciale. Le BP Pro devra confirmer l'existence de contrats et la faisabilité technique et réglementaire.

Corrections : annexe DEEE insérée dans le corps du HTML (au lieu d'être placée après </html>), accès consolidé aux huit BP, conservation intégrale des lots antérieurs. Aucun recalcul nouveau, aucun prix inventé.
