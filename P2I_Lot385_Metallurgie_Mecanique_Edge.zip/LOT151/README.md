# P2I — Lot 151

## Objet de la mise à jour

Cette version reprend le Lot 150 et applique une correction centralisée à l'encart administratif de la rubrique 1. Le modèle visuel approuvé — cartes compactes, grille adaptative, texte lisible et absence de tableau à défilement horizontal — est conservé. Le moteur `administrativeOrientation()` reste commun et est appelé par le rendu de la rubrique 1; les données réglementaires sont contextualisées par filière, par UP BTP et, désormais, par les huit UP Assemblage & Montage.

Les cartes distinguent les formalités générales de création, les démarches sectorielles conditionnelles, les incitations du Code des investissements soumises à instruction, l'implantation/travaux conditionnels, la qualification environnementale, les obligations fiscales/sociales et les sources officielles. Aucune autorisation, exonération ou éligibilité n'est déclarée acquise.

## Résultat de vérification par UP Assemblage & Montage

| UP | Calcul financier v107 | Visuels dédiés présents | Encart administratif |
|---|---|---|---|
| Cuisines professionnelles & chambres froides | Oui, scénario Lot 149 repris : résultat net A1 24 459,35 USD; marge 9,19 %. Non recalculé dans ce lot. | Oui, les visuels produit/atelier déjà intégrés sont conservés. | Corrigé via le composant commun; adaptation spécifique cuisines et fluide frigorigène. |
| Smartphones reconditionnés | Non; données essentielles manquantes, aucun résultat fabriqué. | Non; images spécifiques à intégrer. | Corrigé; adaptation spécifique données, provenance et déchets électroniques. |
| Tablettes éducatives et professionnelles | Non; coûts kits et ventes essentiels à documenter. | Non; images spécifiques à intégrer. | Corrigé; adaptation conformité radio/électrique à qualifier. |
| Tricycles utilitaires | Non; coût kit, charge/capacité et prix net non qualifiés. | Non; images spécifiques à intégrer. | Corrigé; adaptation homologation/circulation à confirmer selon catégorie. |
| Vélos économiques, scolaires et utilitaires | Non; coûts kits/composants et prix nets non qualifiés. | Non; images spécifiques à intégrer. | Corrigé; adaptation sécurité des vélos et variante électrique. |
| Équipements sportifs | Non; nomenclature et prix nets complets absents. | Non; images spécifiques à intégrer. | Corrigé; adaptation fabrication versus travaux d'installation. |
| Remorques agricoles et utilitaires légères | Non; conception/charge utile et BOM de référence restent à qualifier. | Non; images spécifiques à intégrer. | Corrigé; adaptation homologation, charge et circulation à confirmer. |
| Stockage et manutention légère | Non; nomenclature complète, charges admissibles et coûts manquants. | Non; images spécifiques à intégrer. | Corrigé; adaptation charges, stabilité et sécurité d'utilisation. |

**État de clôture :** cette version corrige et vérifie la présentation administrative transversale, mais ne clôt pas les sept BP financiers/visuels. Le dossier Cuisine reste l'unique scénario Assemblage doté d'un calcul complet dans la base de travail actuelle. Les inconnues des sept autres dossiers ne sont pas remplacées par zéro ni par des estimations non sourcées.

## Contrôles exécutés

Le test Node `LOT150/tests/test_lot150.cjs` a été étendu puis exécuté. Il contrôle : 96 identifiants uniques, 12 filières, 17 rubriques, rendu de 7 cartes administratives pour chacune des 96 UP (672 cartes au total), présence des points fiscalité/CNPS/Code des investissements, adaptation administrative des huit UP Assemblage, conservation des styles de cartes, migrations d'identifiants et non-régression du scénario Cuisine v107 (financement 40/60, bilans équilibrés, 12 mois de trésorerie).

Le contrôle d'interface graphique réel, les clics et l'export PDF dans Microsoft Edge restent à faire sur le poste utilisateur. Ce ZIP est prévu pour ouverture locale en extrayant l'archive puis `P2I_Edge/index.html`.
