# P2I — Lot 156 : réévaluation des quatre BP Assemblage & Montage restants

## Décision de livraison

La plateforme intègre les huit UP d'Assemblage & Montage et conserve les trois scénarios Lot 155 recalculés (Tricycles, Vélos, Équipements sportifs) ainsi que le BP Cuisines & Chambres froides. Le Lot 156 met à jour dans la rubrique 14 des quatre autres BP les comparaisons locales et fournisseurs réellement vérifiées.

**Aucun des quatre dossiers ci-dessous n'est déclaré économiquement finalisé.** Aucun nouveau calcul v107 n'a été produit pour eux : une donnée d'entrée essentielle reste non démontrée pour chaque configuration. Les résultats v107 historiques sont préservés, mais ne sont pas transformés en nouvelle référence.

## Résultats et statut des quatre UP

| UP | Configuration conservée pour étude | Calcul réalisé dans ce lot | Blocage | Piste concrète à instruire |
|---|---|---|---|---|
| Smartphones | Atelier multimarque : réception/grade, diagnostic, effacement, réparation, tests, nettoyage, classement et emballage. | Comparaison indicative de coût FOB et de prix local sur iPhone 13 128 Go; pas de calcul v107 nouveau. Écart brut 35 540–39 110 FCFA avant tout coût de fret, fiscalité, réparation, garantie et distribution. | Les prix ne sont pas établis par grade identique; volume annuel de téléphones entrants et taux réparables manquent. L'offre 262–268 USD FOB n'étaye pas l'ancien coût moyen à 77–78,50 USD. | Approvisionnement régional/local en lots multimarques gradés ou prestation B2B sur appareils apportés par les entreprises clientes; dimensionner uniquement après prix d'entrée, rendement et volume d'approvisionnement documentés. |
| Tablettes | Ligne de montage/test SKD pour tablettes 10,1 pouces 4/128 Go. | Comparaison directe : le kit Smartlink à 154,47 USD FOB = 91 909,65 FCFA au taux de planification 595; tablette Itel complète équivalente affichée à 81 900 FCFA. Surcoût du kit de 10 009,65 FCFA avant fret/assemblage. | Le kit sélectionné ne peut soutenir la vente locale observée; aucune offre publique équivalente à coût SKD inférieur n'a été vérifiée. Ancienne contribution négative conservée. | Chercher un kit institutionnel dont le contenu, la garantie et le prix sont documentés. À défaut, étudier une fabrication d'armoires/chariots de charge sécurisés pour écoles et bureaux, activité distincte à contrôler contre le catalogue avant substitution. |
| Remorques | Fabrication locale des structures, avec achat d'organes roulants complets compatibles. Comparateur : Zeyi 7CX-3E, 3 t, mono-essieu, remorque complète. | Comparaison du produit fini à 1 850–1 950 USD FOB et constat d'incohérence de masse à vide (1 050 kg sur une page, 1 260 kg sur une autre). Le sous-total local déjà relevé (acier 614,04 USD + essieux seuls 758 USD pour deux) est 1 372,04 USD avant nombreux postes. Aucun calcul v107 nouveau. | Pas de train roulant complet coté, BOM structurelle détaillée, charge/attelage/freinage vérifiés, temps d'atelier, coût rendu, ni prix net local. FOB remorque entière ≠ coût du kit ni prix de vente local. | Conserver la fabrication locale d'une remorque fixe; comparer une charge plus modérée tracteur/motoculteur et le 3 t, après validation mécanique des organes roulants et du châssis. Aucun PTAC ou charge utile n'est déclaré sûr dans ce lot. |
| Rayonnages & manutention | Baie modulaire 1 800 × 900 × 400 mm, cinq niveaux; variante industrielle à charge supérieure à étudier sur cellule métal partagée. | WADFOW au même format affiché à 55 900 FCFA au détail. L'ancien prix net 105 USD vaut 62 475 FCFA au taux 595, soit 6 575 FCFA de plus que ce prix de détail. Aux anciens coûts P2I estimatifs (84 USD production + 8 USD distribution), le prix de détail ne laisserait que 1 160 FCFA/unité avant frais fixes. | Prix de détail, masse et charge admissible de la baie P2I, BOM, prix d'achat acier et allocation réelle des machines partagées manquent. Une offre de ligne de profilage 45–55 kUSD ne prouve pas qu'elle couvre perforation, finitions et outillage. | Standardiser une gamme de rayonnages lourds, établis et chariots sur une cellule de métallerie partagée avec allocation par heures-machine; comparer coût local et prix rendu import avant d'investir dans une ligne dédiée. |

## Historique financier conservé

Les résultats des Lots 152–154 restent archivés. Repères historiques A1 : Smartphones −46 831,20 USD (−35,89 %) au Lot 152 et −21 631,20 USD (−8,29 %) au scénario Lot 153; Tablettes −130 420,80 USD (−129,39 %); Remorques 750 kg −70 398 USD (−102,03 %), configuration non transposable au 3 t; Stockage −85 844,80 USD (−116,80 %), avec une autre sensibilité affichée à −91 052,80 USD (−133,33 %). Ils ne sont pas recalculés ou remplacés dans ce lot.

## Préservation et contrôles

- Aucun résultat, prix ou scénario des trois BP Lot 155 n'a été modifié.
- Aucun identifiant, filière, UP ni archive historique n'est modifié; la filière Assemblage & Montage conserve huit UP et le catalogue 96 UP/12 filières.
- Les quatre notes Lot 156 apparaissent dans la rubrique 14 de leur BP. Les contenus de la rubrique 17 et les visuels existants sont conservés.
- La conversion comparative est explicitement fondée sur l'hypothèse de planification P2I de 595 FCFA/USD; elle ne représente pas un taux de douane ou un coût rendu.
- Les résultats techniques et les limites précises figurent dans `CALCULS_CIBLES_4_UP.csv` et `SOURCES_LOT156.md`.

**Limite importante :** ce ZIP ne contient pas quatre BP financièrement achevés; il rend visibles les données qui les empêchent de l'être et les options de conception à instruire, sans transformer une réserve en validation. Aucun rendu graphique réel, clic d'export ou parcours complet n'a été vérifié dans Microsoft Edge.
