P2I — LOT 156

Le ZIP conserve les huit BP Assemblage & Montage et les 96 UP. Les trois scénarios indicatifs Lot155 (Tricycles, Vélos, Équipements sportifs) et le BP Cuisines/Chambres froides restent actifs sans modification.

La rubrique 14 des quatre autres BP a été mise à jour avec les comparaisons et décisions de conception du Lot156. Aucun nouveau scénario v107 n'est calculé pour ces quatre UP : les données d'entrée indispensables sont encore incompatibles ou absentes. Elles ne sont pas présentées comme finalisées.

Voir RAPPORT_LOT156_FINALISATION.md, MATRICE_4_UP.csv, CALCULS_CIBLES_4_UP.csv et SOURCES_LOT156.md.
