# Lot 156 — sources ciblées et portée

Sources consultées le 16 novembre 2026. Les annonces et prix de vente peuvent changer; les pages sont des comparateurs et ne remplacent pas des spécifications d'achat vérifiées.

| Dossier | Source | Donnée utilisée | Limite |
|---|---|---|---|
| Smartphones | https://www.made-in-china.com/price/prodetail_Secondhand-Consumer-Electronics_cEOrUdRGXuhw.html | Offre iPhone 13 d'occasion/reconditionné : 262–268 USD FOB, MOQ 2. | Grade et conformité du lot, coût du fret, douane, réparations et fourniture annuelle non documentés. |
| Smartphones | https://reprisemarket.com/produit/iphone-13-128-go | iPhone 13 128 Go « presque neuf » affiché à 195 000 FCFA au détail, testé sur 30 points et garanti six mois. | Prix consommateur local, pas prix de gros ni prix encaissé par un reconditionneur. |
| Smartphones | https://www.telecom.gouv.ci/uploads/publications/178066624486.pdf | Filières locales de collecte/réparation/reconditionnement; les 9 tonnes 2024 couvrent plusieurs catégories d'équipements. | Ne fournit pas un volume annuel accessible de smartphones par grade. |
| Tablettes | https://fr.made-in-china.com/video-channel/sysmartlink_jAqrHNFcLvYu_SKD-CKD-Computer-Provider-Mediatek-Mtk6771-Powered-10-1-Inch-Android-Tablet-Unassembled-4GB-128GB-Hardware-Kids-Tablet-PC.html | Kit Smartlink explicitement non assemblé, 10,1 po, 4/128 Go, 154,47 USD FOB, MOQ 300. | Prix FOB, frais rendus et contenu exact de la nomenclature à confirmer. |
| Tablettes | https://jeven.ci/products/tablette-itel-pad-one-10-1-8mp-5mp-4g-4go-128go?variant=44195433808029 | Itel Pad One complète 10,1 po 4/128 Go affichée à 81 900 FCFA. | Prix détail local; marque distincte du kit Smartlink. Sert à comparer le segment, pas à fixer un prix de gros. |
| Remorques | https://zeyimachinery.en.made-in-china.com/product/MxSrBGnPVHpu/China-Hot-Selling-3-Ton-Farm-Utility-Trailer-Mobile-Single-Axle-Mini-Dump-Farm-Tractor-Trailer.html | Modèle 7CX-3E : 3 t, dimensions et caractéristiques publiées; page produit indique 1 260 kg à vide. | Fiche produit ne constitue pas une conception locale ni preuve de conformité du projet P2I. |
| Remorques | https://www.made-in-china.com/video-channel/zeyimachinery_KQxYANlOYiUc_Agriculture-Machinery-Farm-Trailers-Dump-and-Tipping-Tractor-Trailer.html | Même 7CX-3E : prix FOB 1 950 USD pour 1–4, 1 850 USD à partir de 5; autre emplacement de la page indique 1 050 kg à vide. | Contradiction interne sur la masse à vide; prix du produit fini uniquement. |
| Rayonnages | https://www.jumia.ci/slp/etageres-en-metal-pour-garage/ | WADFOW WTS1A94, baie acier cinq niveaux 1 800×900×400 mm à 55 900 FCFA affiché. | Prix détail local; charge admissible, épaisseur d'acier et provenance non établies sur l'annonce consultée. |
| Rayonnages | https://www.made-in-china.com/factory/upright-roll-forming-machine.html | Offres catalogue de lignes rack uprights/beams/shelf panels à 45 000–55 000 USD selon annonce. | Périmètre de chaque ligne et inclusion du poinçonnage, finition, outillage et auxiliaires à vérifier; prix catalogue machine, pas CAPEX rendu CI. |

## Taux de conversion comparatif

Les calculs comparatifs de ce dossier utilisent **595 FCFA/USD**, taux de planification qui apparaît dans le BP Cuisines/Chambres froides Lot 147. Il est appliqué uniquement à titre de repère P2I; ce n'est pas un cours de change courant, une conversion douanière ou un coût rendu. Aucun taux n'a été utilisé pour déclarer une marge v107.
