# P2I — Lot 217 — Étude multigamme mobilier scolaire et professionnel

## Décision
**Candidat non validé et non activé.** Ce lot répond à la demande de dimensionner plus largement l'atelier et d'intégrer le mobilier professionnel aux calculs. Il ne prouve pas la rentabilité et ne doit pas être publié comme BP Découverte.

## Produits intégrés au calcul
1. Table-banc biplace : prix 33 000 FCFA, coût variable 25 200 FCFA (18 200 FCFA matières conditionnelles + 7 000 FCFA autres coûts hypothétiques).
2. Bureau professionnel simple : prix 110 000 FCFA et coût variable 71 000 FCFA **entièrement hypothétiques**.
3. Armoire métallique : prix 160 000 FCFA et coût variable 108 000 FCFA **entièrement hypothétiques**.

**Attention** : les bureaux et armoires n'ont pas encore de nomenclature technique, de références fournisseurs ni de prix commerciaux sourcés. Leur contribution au CA ne peut pas être retenue dans un BP publié.

## Volumes hypothétiques A1 / A2 / A3
| Plan | Tables-bancs | Bureaux | Armoires |
|---|---|---|---|
| Prudent | 400 / 850 / 1300 | 40 / 100 / 150 | 20 / 50 / 75 |
| Progressif | 600 / 1400 / 2100 | 80 / 180 / 280 | 40 / 90 / 140 |
| Ambitieux | 800 / 2400 / 3600 | 100 / 300 / 480 | 50 / 150 / 240 |

Les volumes sont des **tests de capacité et de débouchés**, pas des commandes ou prévisions étayées. Les capacités machine et le calendrier de production ne sont pas encore vérifiés.

## Autres hypothèses de stress test
CAPEX 45 000 USD, dont machines 30 000 USD ; personnel A1 24 000 USD ; charges fixes A1 15 000 USD ; croissance personnel 8 %/an, fixes 5 %/an, coûts variables 3 %/an. **Ces montants sont hypothétiques et non sourcés.** Prix ±10 % ; change 595 FCFA/USD ; apport 40 %, dette 60 %, intérêt 8 %, durée 60 mois ; TVA 18 %, IS 25 %. Les prix de vente sont constants hors facteur de sensibilité.

## Résultats du moteur commun v107 — résultat net USD
| Plan | Prix relatif | A1 | A2 | A3 |
|---|---:|---:|---:|---:|
| Prudent | 90 % | -40 264 | -37 209 | -37 209 |
| Prudent | 100 % | -36 769 | -29 302 | -25 209 |
| Prudent | 110 % | -33 273 | -21 394 | -13 209 |
| Progressif | 90 % | -36 179 | -29 541 | -26 831 |
| Progressif | 100 % | -30 297 | -16 028 | -6 243 |
| Progressif | 110 % | -24 415 | -2 515 | +10 759 |
| Ambitieux | 90 % | -33 580 | -17 142 | -10 104 |
| Ambitieux | 100 % | -25 950 | +4 312 | +18 893 |
| Ambitieux | 110 % | -18 320 | +21 480 | +45 363 |

**9/9 scénarios perdent de l'argent en A1.** Une hausse des volumes à partir de A2 peut produire un résultat positif dans quelques cas, mais les résultats dépendent d'hypothèses non documentées. Un résultat positif n'est pas une validation.

## Contrôles techniques
Le script `LOT217_RUN.cjs` charge les 12 scripts historiques du moteur commun. Il produit 9 scénarios, les résultats A1-A3, 12 mois de trésorerie, 36 mois de BFR et les écarts de bilan. Le JSON et le CSV sont des sorties effectivement calculées. La trésorerie positive liée au coussin initial ne constitue pas une validation de solvabilité.

## Conditions à satisfaire avant activation et visuels définitifs
- Chiffrer la nomenclature complète et les prix sourcés des bureaux et armoires, avec machines communes et postes spécifiques.
- Recalculer CAPEX, masse salariale, frais fixes, emballage, livraison et service après-vente à partir de sources.
- Vérifier les capacités et l'organisation de l'atelier aux volumes A2-A3, ainsi que le BFR nécessaire pour les marchés institutionnels.
- Rechercher un scénario A1 réaliste et soutenable, sans ajuster artificiellement les prix ou les volumes pour afficher une marge positive.
- Une fois seulement validé, migrer l'UP dans les 96 UP, produire les 17 rubriques et les visuels P2I des blocs 2 et 17.

## Préservation
Tous les fichiers historiques de l'archive 216 sont conservés. Aucun fichier existant du catalogue actif ni des sept BP précédents n'a été modifié. `main` n'a pas été touchée.
