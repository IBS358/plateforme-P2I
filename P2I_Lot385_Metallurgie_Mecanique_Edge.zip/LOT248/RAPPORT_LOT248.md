# P2I — Lot 248 : audit global cumulatif des 96 UP

Base : archive complete du lot 247, conservee sans alteration.

## Comptage de la matrice source
- 96 lignes, 96 identifiants uniques.
- Les statuts ci-dessous sont repris de la matrice, sans certification nouvelle.

### etat
- PARTIEL_CALCULABLE : 31
- PARTIEL_NON_CALCULABLE : 65

### BP_termine_verifie_ce_lot
- NON : 96

### scenario_financier_calculable
- NON : 65
- OUI : 31

### structure_17_rubriques_presentes
- OUI : 96

### filiere
- Agro-alimentaire & Boissons : 8
- Assemblage & Montage : 8
- BTP & Matériaux de Construction : 8
- Chimie, Cosmétiques & Détergents : 8
- Médical & Pharmaceutique : 8
- Métallurgie & Mécanique : 8
- Plastique & Caoutchouc : 8
- Recyclage & Valorisation : 8
- Services Industriels : 8
- Textile, Habillement & Cuir : 8
- Électronique & Électricité : 8
- Énergie, Eau & Environnement : 8

## Recyclage
- 8 dossiers et 33 postes historiques conserves (registre lot245).
- Les 8 BP demeurent non calculables selon le registre historique : aucune simulation v107 nouvelle validee.

## Conditions avant livraison finale
- Qualifier les lignes et leurs prix catalogues, capacites, puissances, matieres et marches.
- Recalculer et controler les etats financiers et la tresorerie mensuelle.
- Tester les 96 BP sous Edge, leurs 17 rubriques, PDF et navigation.
- Ne pas confondre audit de matrice et validation de 96 BP.