# Lot 327 — Contrôle éditorial et enrichissement bloc 17

Conservation intégrale du lot 326. Huit BP sont copiés vers LOT327 avec une grille des postes tirée des tableaux originaux, une navigation propre et une mention explicite des limites photographiques. Aucun résultat financier n’a été recalculé ni déclaré validé.

| UP | Postes décrits | Images existantes | 17 sections |
|---|---:|---:|---|
| plastique | 7 | 3 | oui |
| papier-carton | 6 | 3 | oui |
| metaux | 6 | 3 | oui |
| compost | 7 | 3 | oui |
| verre | 7 | 3 | oui |
| pneus | 7 | 3 | oui |
| huiles | 7 | 3 | oui |
| deee | 7 | 3 | oui |

**Limites :** photos spécifiques des machines/postes absentes ; certaines rubriques historiques contiennent des données provisoires ; le modèle DEEE est conditionnel à un tarif de prestation non vérifié. Les cartes ne sont pas des photographies.
