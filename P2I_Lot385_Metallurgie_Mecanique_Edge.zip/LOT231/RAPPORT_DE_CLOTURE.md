# P2I — Lot 231 — Bilan de fin de lot Assemblage & Montage

## Réalisé
- Source exacte : ZIP lot 230. Tous les fichiers antérieurs conservés, hormis la mise à jour du BP Mobilier pour clarifier la gamme et son statut.
- BP mobilier 17 rubriques, visuel IA existant, armoires basses et caissons hors calcul.
- Calculs v107 lot229 préservés : CA A1 139,9 M FCFA ; marge nette A1 3,11 %, A2 7,80 %, A3 8,13 % sous hypothèses.
- Navigation vers index huit BP et audit des liens.

## Limites qui empêchent une validation définitive
- Prix, coûts complets et capacités de fabrication des trois gammes non corroborés par devis/cahier des charges.
- Crédit client modélisé séparément, non injecté dans le moteur v107. Besoin total de financement et trésorerie consolidée non validés.
- Le catalogue actif des 96 UP conserve irrigation ; migration non effectuée afin de ne pas casser les dépendances.
- Les variantes innovantes, armoires basses et caissons restent hors calcul.
- Visuel principal IA existant ; galerie photographique poste par poste non complète.

**Statut : BP Découverte provisoire consultable, pas BP définitif validé.**
