# P2I — Lot 116 : recalcul économique médical

**Base :** copie consolidée du Lot 115, elle-même issue du Lot 113 complet intégré au Lot 114. Les archives Lot 77/78 et Lot 114 restent conservées. Aucun changement GitHub ni modification de `main`.

## Travail financier effectué

Le moteur partagé `P2I_BP_SIMULATION_COMMUNE` est réutilisé. Les scénarios ci-dessous affichent compte de résultat/bilan sur trois ans et trésorerie sur douze mois, avec financement 40 % apport / 60 % dette. Aucun prix ni volume n’a été augmenté pour obtenir une marge cible.

| UP | Investissement modélisé | CA A1 → A3 | Résultat net A1 → A3 | Marge nette A1 | État |
|---|---:|---:|---:|---:|---|
| Kits médicaux et premiers secours | 33 090 USD | 450 000 → 630 000 USD | 69 354 → 98 259 USD | 15,4 % | Recalcul disponible ; hypothèses de nomenclature, prix, volumes et débouchés non validées. |
| Mobilier médical — divan fixe | 154 065 USD | 420 000 → 630 000 USD | 82 932 → 153 874 USD | 19,7 % | Recalcul conditionnel : enveloppe fonctionnelle P2I des 7 postes 78 000 USD non catalogue ; coûts et ventes de l’étude historique conservés. |
| Béquilles et cannes — paire anglaise | 112 170 USD | 375 000 → 525 000 USD | 73 690 → 119 155 USD | 19,7 % | Recalcul conditionnel : enveloppe fonctionnelle P2I des 7 postes 58 000 USD non catalogue ; coûts et ventes de l’étude historique conservés. |

Les budgets de 78 000 et 58 000 USD proviennent des estimations fonctionnelles historiques de `machines-data.js`, pas de prix fournisseurs. Pour les postes ajoutés au budget machine, fret incrémental de 10 % et assurance de 1 % sont des provisions P2I à remplacer par des offres. Les prix usine et volumes utilisés restent des hypothèses de Lot 77/78, non des ventes contractées. Les bénéfices simulés ne sont donc pas des validations de rentabilité.

## Données qui empêchent encore les cinq autres calculs combinés

- **Alèses :** pas de prix exact du modèle BERICH, la cadence « 200–300 m » n’a pas d’unité de temps, pas de coût matière/nomenclature ni de prix de vente comparable.
- **Sparadraps, pansements et compresses :** étude combinée nécessaire avec deux produits, deux prix, deux coûts matière et deux cadences. Les anciens calculs séparés ne sont pas additionnés ; bandelettes hors calcul.
- **Fauteuils roulants :** arbitrage fabrication ou achat du châssis et coût des composants manquent. L’ancien modèle achetait un châssis et ne finance donc pas les 7 postes actuels.
- **Instruments :** les anciens calculs portaient sur la finition d’ébauches ; ils ne couvrent pas l’usinage CNC, ses machines, ses cycles ou son coût matière.
- **Antiseptiques et désinfectants :** formules et usages distincts, nomenclatures, coûts rendus, postes de remplissage et prix nets manquent pour les circuits aqueux et alcooliques.

Les huit dossiers conservent leurs 17 rubriques et 51 postes illustrés. Aucun des huit n’est déclaré entièrement validé : trois scénarios calculables sont maintenant visibles dans l’interface, cinq restent non calculables pour leur configuration combinée actuelle.

## Contrôles exécutés après recalcul

- `node tester115.cjs` : **PASS** — 96 UP, 12 filières, 17 rubriques par UP, contenus médicaux et 51 postes rattachés.
- **69 scénarios** calculés sur 60 UP : 3 exercices, 12 mois de trésorerie et 3 bilans contrôlés ; financement 40/60 et équilibres vérifiés.
- **28 comparaisons Lot 114** : résultats et soldes de trésorerie inchangés à la tolérance du test.
- Archive Edge reconstruite depuis le même HTML et le même JSON consolidés ; les deux parties s’extraient dans une seule arborescence et les fichiers sont comparés au runtime.
- **Limite :** pas de recette native dans Microsoft Edge sous Windows. Les vérifications exécutées sont programmatiques ; elles ne valident pas le rendu natif ni l’impression PDF Edge.

## Fichiers substantiellement modifiés

- `data/p2i-bp-decouverte-donnees.json` et données intégrées dans `business-plan-decouverte.html` : références financières mobilier/béquilles, budgets et qualifications, financement 40/60.
- `js/p2i-medical-lot114.js` et son intégration HTML : libellés financiers médicaux propres à chaque UP.
- `MATRICE_96_UP.csv` : avancement et RN A1 des deux nouveaux scénarios.
- `data/medical-lot116-resultats.json` : instantané traçable des trois scénarios calculés.
- `tester115.cjs`, `release115/P2I_Edge` et archives de livraison : recalcul et non-régression.

Le fichier source, les visuels, l’ensemble des 96 UP et les archives historiques sont conservés. Le résultat du lot est une progression calculée et qualifiée, pas la finalisation financière des huit UP.
