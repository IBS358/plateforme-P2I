# P2I — Lot 238 — Qualification documentaire fournisseurs

Base: archive complète Lot237. Aucune modification du moteur v107 ni du catalogue 96 UP.

## Avancement réel
- 7 entrées documentaires, dont 6 avec URL publique pour plastique et pneus; métal non qualifié.
- Deux lignes candidates techniquement identifiées: TENGLONG TL-GPL (plastique) et EcoShred ESG-1000 (pneus).
- Prix indicatifs publiés: TL-GPL 85 000–260 000 USD; SUHUI 50 000–150 000 USD FOB; Kitech 200 000–420 000 USD; Optima pneus 200 000–600 000 USD. Ces montants portent sur des périmètres différents et ne sont pas directement comparables.
- Aucun prix catalogue vérifié pour une presse/cisaille métaux, ni pour le modèle ESG-1000.
- 8 UP conservées; 33 postes historiques conservés; 24 scénarios conservés.

## Limites
Les informations sont issues de pages commerciales de fabricants et non de devis; l'indication FOB doit être vérifiée au niveau de la référence et des inclusions. Les ventes et la rentabilité ne sont pas validées. Aucune simulation v107 n'a été exécutée.

## Tests
Contrôle de l'existence des fichiers sources, structure CSV, 8 lignes de décisions, 7 références documentaires, navigation relative et intégrité ZIP. Aucun test navigateur Edge réel.
