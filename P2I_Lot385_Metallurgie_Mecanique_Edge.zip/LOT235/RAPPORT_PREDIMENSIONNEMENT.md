# P2I — Lot 235 : prédimensionnement industriel des 8 UP Recyclage

**Base intégrale : lot 234.** Les 33 postes historiques sont conservés; aucune des huit UP n'est déclarée financièrement validée. Les trois capacités proposées pour chaque UP sont des **points de test d'ingénierie**, et non des caractéristiques de machines ou des tonnages de collecte constatés.

## Décisions industrielles

- Plastique : privilégier une ligne complète jusqu'au granulé commercial, mais établir explicitement la frontière avec l'UP granulés d'une autre filière. Séchage et filtration sont indispensables à vérifier.
- Métaux : préparation/densification des ferrailles plutôt que fonderie, à distinguer de la métallurgie.
- Pneus : granulation avec séparation acier/textile et aspiration; bilan matière à renseigner.
- Papier/carton : **ne pas mélanger** la ligne de fabrication de pâte historique et une ligne de balles triées; deux investissements et deux marchés différents. Aucun choix définitif sans prix ni débouché.
- Compost : dimensionnement par tonne/jour, durée de maturation, surface de plateforme et eau de ruissellement.
- Verre : vente de calcin calibré conditionnée à des exigences de pureté et un repreneur.
- Huiles : nature des huiles à spécifier avant le choix du réacteur, sans assimiler huiles moteur et alimentaires.
- DEEE : dépollution et traçabilité avant fragmentation.

## Méthode de calcul sans invention de prix

Tonnage entrant mensuel théorique = débit horaire × 8 heures/jour × 22 jours/mois, ou débit journalier × 22 jours. **Ce n'est ni la capacité effective, ni une prévision de vente.** Tonnage commercialisable = entrants × rendement mesuré. Chiffre d'affaires = sorties vendues × prix net documenté. Coûts variables = collecte + tri + énergie + eau + consommables + résidus + livraison. Le personnel et le dirigeant sont affichés séparément. Calcul v107 uniquement après collecte des preuves de capacité, prix, rendements et marchés.

## Verrous de validation

1. Fabricant, modèle, capacité, alimentation, prix catalogue EXW/FOB, date et URL pour chaque machine; compatibilité entre étapes.
2. Collecte mensuelle réaliste, qualité et saisonnalité du gisement; distance de collecte.
3. Rendements, fractions valorisées, refus et coûts de traitement des déchets secondaires.
4. Prix de vente documenté, clients potentiels, modalités de paiement et crédit client.
5. CAPEX complet rendu site, personnel, rémunération dirigeant, BFR, financement 40/60.
6. Calcul v107 sur 3 ans, trésorerie 12 mois et contrôles de bilan; visuels 17 rubriques ensuite.

**Tests exécutés :** conservation des 474 fichiers du lot 234, 8 UP distinctes, 24 scénarios de capacité, ZIP CRC et liens relatifs de la page de consultation. Aucun résultat financier v107 nouveau n'est revendiqué.
