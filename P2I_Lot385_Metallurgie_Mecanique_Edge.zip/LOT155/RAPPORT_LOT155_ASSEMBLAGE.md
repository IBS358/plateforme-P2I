# P2I — Lot 155 : intégration active de trois BP Assemblage & Montage

## Livrable et portée

La copie Edge complète du Lot 154 a été mise à jour. Trois scénarios sont maintenant les références de calcul affichées dans le parcours BP Découverte : tricycles utilitaires, vélos, et équipements sportifs. Pour ces seules UP, le renderer lit les entrées Lot 155 et recalcule la fiche par le moteur commun v107. Les scénarios Lot 152 et Lot 153 restent archivés et non écrasés.

Les volumes A1 proviennent d’un test de seuil antérieur, puis ont été contrôlés contre les capacités annuelles programmées dans le scénario historique. Ils sont sous ces plafonds; cela vérifie une compatibilité arithmétique avec la capacité inscrite au modèle, **pas** des temps de cycle observés, des ventes assurées ou une validation d’investissement. Les prix, coûts et charges restent ceux des hypothèses P2I déjà présentes. Les marges ne sont donc pas garanties.

## Trois BP intégrés — résultats recalculés v107

| UP | Volumes A1 / A2 / A3 vendus | CA A1 / A2 / A3 (USD) | Résultat net A1 / A2 / A3 (USD) | Marge nette A1 / A2 / A3 | CAPEX | Réserve distincte | Besoin total | Trésorerie min. 12 mois | BFR max. 36 mois |
|---|---|---|---|---|---:|---:|---:|---:|---:|
| Tricycles utilitaires | 88 / 110 / 140 | 162 800 / 207 570 / 269 360 | 9 999,60 / 28 316,30 / 54 102,46 | 6,14 / 13,64 / 20,09 % | 52 000 | 17 721,90 | 69 721,90 | 5 477,77 | 30 617,49 |
| Vélos | 1 002 / 1 000 / 1 250 | 235 470 / 239 700 / 305 500 | 14 142,90 / 14 082,07 / 32 104,85 | 6,01 / 5,87 / 10,51 % | 58 000 | 27 727,06 | 85 727,06 | 6 192,86 | 42 740,68 |
| Équipements sportifs | 132 / 120 / 150 | 165 000 / 153 000 / 195 000 | 10 311,60 / 4 013,83 / 19 143,46 | 6,25 / 2,62 / 9,82 % | 42 000 | 16 520,50 | 58 520,50 | 4 486,43 | 23 254,31 |

Le financement porte sur le CAPEX : apport 40 %, dette 60 % (respectivement 20 800/31 200 USD, 23 200/34 800 USD et 16 800/25 200 USD). La réserve reste séparée et augmente le besoin total; une trésorerie minimale positive obtenue avec cette réserve n’est pas une preuve de viabilité commerciale. Les comptes de résultat, les flux mensuels, les BFR sur 36 mois et les bilans sont conservés intégralement dans `RESULTATS_V107_BP_ACTIFS.json`.

### Cadence arithmétique A1

- **Tricycles :** 88 unités, 0,35/jour sur 250 jours, soit 44 % de la capacité programmée de 200/an.
- **Vélos :** 1 002 unités, 4,01/jour sur 250 jours, soit 80,16 % de 1 250/an.
- **Buts sportifs :** 132 unités, 0,53/jour sur 250 jours, soit 88 % de 150/an.

Les capacités programmées viennent des scénarios Lot 152; elles n’ont pas été mesurées sur une ligne reçue. Les gammes et temps de soudage/assemblage, la disponibilité, les rebuts et les périodes de pointe restent à vérifier. Pour les vélos et équipements sportifs, A2 est légèrement inférieur à A1 : la trajectoire héritée n’est pas une courbe de croissance commerciale et doit être confirmée au BP Pro.

## Présentation dans les BP

- Les trois références actives sont injectées avant le renderer : la page du BP recalcule maintenant les tableaux principaux avec les entrées Lot 155.
- La rubrique 14 affiche une fiche Lot 155 avec volumes/production, compte de résultat trois ans, financement, réserve, trésorerie mensuelle, BFR et bilans.
- Les fonds d’atelier, médaillons produits, variantes et six étapes illustrées par UP déjà intégrés au Lot 153 sont conservés; aucune image ni machine nouvelle n’est présentée comme un modèle fournisseur vérifié.
- Les 17 rubriques communes restent dans le renderer. La filière conserve ses huit identifiants et le catalogue ses 96 UP/12 filières.

## Quatre autres UP — travaux ciblés intégrés aux fiches

| UP | Élément nouveau qualifié | Ce qui n’est pas encore établi |
|---|---|---|
| Smartphones reconditionnés | Il existe une filière ivoirienne d’acteurs de collecte/réparation/reconditionnement. Une offre publique affiche un iPhone 13 reconditionné/d’occasion à 262–268 USD FOB, MOQ 2, sans preuve d’un lot homogène par grade. Le rapport public cite 9 t d’équipements électroniques multi-catégories collectées/traitées avec Orange en 2024; ce n’est pas 9 t de téléphones disponibles pour cette UP. Les prix locaux observés sont des prix de détail; les grossistes locaux identifiés vendent des pièces, pas des appareils entrants par grade. | Coût d’acquisition par modèle/grade, taux réparables, pièces, rebuts, garantie, cadence de test et ventes annuelles. La capacité de 4 393 ne devient pas une cible commerciale. |
| Tablettes SKD | La fiche Smartlink identifie bien un produit non assemblé 10,1 pouces, 4/128 Go, à 154,47 USD FOB, minimum 300 pièces. Des offres moins chères autour de 62–65 USD concernent des tablettes catalogue sans démonstration d’un kit SKD équivalent. | Aucun kit alternatif chiffré et compatible avec prix net/assemblage local n’est retenu; l’ancien scénario reste inactif et déficitaire, avec sa contribution unitaire historique négative. |
| Remorques agricoles | Le concept de travail reste la fabrication locale du châssis, plancher et structures, avec achat d’un ensemble roulant complet compatible. Un nouveau comparateur Zeyi décrit une remorque complète 3 t à un essieu à 1 850–1 950 USD FOB, poids à vide annoncé 1 050 kg et pneus 10.0/75-15.3; c’est un produit fini importé, pas un prix local ou le prix de composants. Le panier acier Lot154 demeure partiel. | Charge nominale, architecture un/deux essieux, calcul de résistance/freinage/attelage, nomenclature complète, temps de fabrication, coût rendu et prix net local. Aucune des 36 simulations historiques n’a été relancée; le 750 kg ancien n’est pas transposé. |
| Stockage/manutention | Un détaillant à Abidjan affiche une étagère 5 niveaux de 2,36 × 1,50 × 0,50 m à 80 000 FCFA. Cette référence a un format et un canal différents de la baie P2I 1,80 × 0,90 × 0,40 m. | Prix départ usine, épaisseur/masse acier, charge validée par niveau, BOM, ligne complète traverses/plateaux/poinçonnage, capacité effective et ventes. Le seuil de 20 641 unités n’est pas adopté. |

Les notes de qualification apparaissent dans les rubriques 14 de ces quatre fiches. Aucune hypothèse nouvelle n’est passée au moteur pour ces UP; aucune marge n’est déclarée redressée.

## Atelier partagé

La ventilation historique de 54 000 USD (24 000 sports / 30 000 remorques) n’était pas calculée à partir d’heures-machine. Elle n’est pas transformée en allocation validée. Les postes dédiés au profilage de rayonnages ne sont pas considérés mutualisables par défaut. Le Lot 155 n’ajoute pas de CAPEX partagé et ne compte pas d’immobilisation deux fois. Une allocation horaire réelle exige des gammes et heures par produit; elle reste donc à établir.

## Contrôles effectués et limites

- Exécution de v107 sur les trois entrées actives; trois résultats annuels, 12 flux mensuels de trésorerie, 36 points BFR et trois bilans pour chaque scénario.
- Vérification des écarts de bilan (inférieurs à 0,000001 USD), du financement 40/60 du CAPEX, des volumes A1 sous les plafonds programmés et de la correspondance des références actives avec les données utilisées par le renderer.
- Vérification syntaxique JavaScript, ordre des scripts dans `index.html`, 96 identifiants uniques/12 filières, 17 rubriques, et présence des atlas/postes/variantes des trois UP.
- Un essai headless Chromium a été tenté mais le conteneur interdit l’ouverture du socket requis. Aucun rendu graphique réel, test Edge, clic d’export PDF ou parcours manuel n’est revendiqué.

## Sources ciblées consultées le 16/11/2026

- Smartlink, tablette explicitement non assemblée 10,1 pouces/4 Go/128 Go : 154,47 USD FOB, MOQ 300 : https://fr.made-in-china.com/video-channel/sysmartlink_jAqrHNFcLvYu_SKD-CKD-Computer-Provider-Mediatek-Mtk6771-Powered-10-1-Inch-Android-Tablet-Unassembled-4GB-128GB-Hardware-Kids-Tablet-PC.html
- Offre publique d’iPhone 13 d’occasion/reconditionné : 262–268 USD FOB, MOQ 2; comparateur d’approvisionnement, non coût rendu ni grille par état/grade : https://m.made-in-china.com/hot-china-products/Wholesale_Refurbished_Phone-2.html
- Yucheng Zeyi, catalogue de remorques agricoles, offre 3 t un essieu à 1 850–1 950 USD FOB; produit fini comparateur : https://zeyimachinery.en.made-in-china.com/product-group/EMyAzmTuRLUk/trailer-catalog-1.html
- Revvo, catalogue de smartphones quasi-neufs avec filtre de prix et garantie annoncée; prix catalogue au détail, non coût d’approvisionnement : https://www.revvo.africa/catalogue/iphone
- Ministère ivoirien chargé des Télécommunications, rapport public sur la filière DEEE, acteurs locaux et collecte Orange multi-catégories en 2024 : https://www.telecom.gouv.ci/uploads/publications/178066624486.pdf
- Repare-Moi CI, catalogue grossiste de pièces détachées et réparation; ne constitue pas une cotation de téléphones usagés : https://repare-moi.ci/grossiste.php
- SMARTSEE Abidjan, étagère 5 niveaux 2,36 × 1,50 × 0,50 m affichée à 80 000 FCFA : https://smartseeci.com/produit/etagere-de-rangement-metallique-premium-a-5-niveaux-xxl-h-2--240.html

**Conclusion :** trois BP sont désormais activement intégrés et recalculés dans le parcours; leurs résultats A1 dépassent 6 % dans les hypothèses conservées, mais les ventes et la capacité effective restent à confirmer. Les quatre autres pages ont reçu des qualifications ciblées; elles ne sont pas économiquement redressées. Le Lot 155 ne clôt donc pas les sept UP comme investissements validés.
