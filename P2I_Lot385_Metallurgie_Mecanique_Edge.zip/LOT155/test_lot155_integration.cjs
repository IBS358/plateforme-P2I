'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const app=path.resolve(__dirname,'..');
const rt=path.join(app,'runtime');
const c={console,Math,Number,String,Array,Object,Map,Set,JSON,Error,TypeError,Date,Intl,URL,URLSearchParams};
c.window=c;
c.location={search:'?unit_id=tricycles_utilitaires',href:'file:///P2I_Edge/index.html?unit_id=tricycles_utilitaires'};
c.history={replaceState(){}};
vm.createContext(c);
const files=['script-0.js','script-1.js','script-2.js','script-3.js','script-4.js','script-5.js','script-6.js','script-7.js','script-8.js','script-9.js','script-10.js','script-11.js','script-12.js','script-13.js','script-14.js','script-15.js','script-16.js','lot147-data.js','lot149-data.js','lot150-assemblage-data.js','lot152-assemblage-finances.js','lot153-assemblage-finances.js','catalogue-up-actif.js','script-17.js','lot152-assemblage-visuels.js','lot153-assemblage-visuels.js','lot154-remorques.js','lot154-remorque-finances.js','lot155-assemblage-finances.js'];
for(const f of files)vm.runInContext(fs.readFileSync(path.join(rt,f),'utf8'),c,{filename:f});
new vm.Script(fs.readFileSync(path.join(rt,'script-18.js'),'utf8'),{filename:'script-18.js'});
const expected={tricycles_utilitaires:0.061422604422604415,velos:0.06006242833481973,equipements:0.06249454545454545};
const old={};
for(const id of Object.keys(expected))old[id]=JSON.stringify(c.P2I_LOT152_FINANCES.units[id].input);
const active=c.P2I_LOT155_ACTIVE_FINANCES;
assert.equal(active.engine,'v107');
assert.equal(active.status,'indicatif_non_valide');
for(const [id,margin] of Object.entries(expected)){
 const x=active.units[id];
 assert.ok(x,`scénario actif absent: ${id}`);
 const a=x.result.annuel;
 assert.equal(a.length,3);
 assert.equal(x.result.tresorerie.length,12);
 assert.equal(x.result.bfr.length,36);
 assert.equal(x.result.bilans.length,3);
 assert.ok(Math.abs(a[0].resultat_net/a[0].chiffre_affaires-margin)<1e-9);
 assert.ok(x.result.bilans.every(b=>Math.abs(b.ecart)<1e-6));
 assert.equal(x.result.controles.bilans_equilibres,true);
 assert.equal(x.result.controles.financement,'40/60');
 const capacityUnits=x.input.capacite*250*8;
 assert.ok(x.input.production[0]<=capacityUnits,`${id}: production A1 au-dessus de la capacité programmée`);
 assert.equal(JSON.stringify(c.P2I_BP_DONNEES.unites[id].variantes.reference.reference),JSON.stringify(x.input));
 assert.equal(JSON.stringify(c.P2I_LOT152_FINANCES.units[id].input),old[id],'historique Lot152 modifié');
}
const html=fs.readFileSync(path.join(app,'index.html'),'utf8');
assert.ok(html.indexOf('lot155-assemblage-finances.js')<html.indexOf('runtime/script-18.js'));
assert.ok(fs.readFileSync(path.join(rt,'script-18.js'),'utf8').includes('Scénario intégré Lot 155'));
const cat=c.P2I_CATALOGUE_UP_ACTIF;
assert.equal(cat.filieres.flatMap(f=>f.up_ids).length,96);
assert.equal(cat.filieres.length,12);
const visuals=c.P2I_BP_LOT81_VISUALS;
for(const id of Object.keys(expected)){
 assert.ok(fs.existsSync(path.join(app,'assets/lot153/'+id+'-atlas.jpg')),`atlas absent: ${id}`);
 assert.equal(visuals.unites[id].reference.product_index,0);
 assert.equal(visuals.processus[id].steps.length,6);
 assert.equal(Object.keys(visuals.processus[id].images_by_step).length,6);
 assert.equal(visuals.variantes_commerciales[id].reference.length,2);
 assert.ok(visuals.ateliers[id].image,`fond d’atelier absent: ${id}`);
}
const short=fs.readFileSync(path.join(rt,'script-18.js'),'utf8').match(/const SHORT=(\[[^;]+\]);/);
assert.ok(short);
assert.equal((short[1].match(/'[^']*'/g)||[]).length,17);
const out={lot:155,engine:'v107',status:'three_active_conditional_scenarios',catalogue:{up:96,filieres:12,rubriques:17},scenarios:{}};
for(const [id,x] of Object.entries(active.units)){
 const res=x.result;
 out.scenarios[id]={name:x.nom,units_A1:x.input.ventes[0],capacity_programmed_units_year:x.input.capacite*250*8,utilization_A1_pct:100*x.input.production[0]/(x.input.capacite*250*8),annual:res.annuel.map(a=>({year:a.annee,revenue_usd:a.chiffre_affaires,operating_result_usd:a.ebit,net_result_usd:a.resultat_net,net_margin_pct:100*a.resultat_net/a.chiffre_affaires,roi_annual:res.performance.annuel[a.annee-1].roi_annuel})),capex_usd:x.input.investissement,equity_capex_usd:x.input.investissement*.4,debt_capex_usd:x.input.investissement*.6,reserve_usd:res.reserve_initiale,total_funding_need_usd:x.input.investissement+res.reserve_initiale,minimum_cash_12m_usd:Math.min(...res.tresorerie.map(m=>m.solde_final)),cash_12m:res.tresorerie,bfr_max_36m_usd:Math.max(...res.bfr.map(m=>m.bfr)),bfr_36m:res.bfr,balance_checks:res.bilans.map(b=>({year:b.annee,assets_usd:b.actif_total,liabilities_equity_usd:b.passif_total,gap_usd:b.ecart})),controls:res.controles,label:x.label};
}
fs.writeFileSync(path.join(__dirname,'RESULTATS_V107_BP_ACTIFS.json'),JSON.stringify(out,null,2));
console.log(JSON.stringify({passed:true,engine:'v107',scenarios:Object.fromEntries(Object.entries(out.scenarios).map(([id,x])=>[id,{units_A1:x.units_A1,utilization_A1_pct:x.utilization_A1_pct,net_A1:x.annual[0].net_result_usd,margin_A1_pct:x.annual[0].net_margin_pct,min_cash_12m:x.minimum_cash_12m_usd,bfr_max_36m:x.bfr_max_36m_usd,balance_gaps:x.balance_checks.map(b=>b.gap_usd)}]))},null,2));
