Lot 155 — scénarios actifs et qualification Assemblage & Montage

Trois BP Découverte sont intégrés au parcours actif et recalculés par le moteur commun v107 : Tricycles utilitaires, Vélos et Équipements sportifs. Résultats, 12 mois de trésorerie, BFR et bilans : RESULTATS_V107_BP_ACTIFS.json.

Les quatre autres UP (Smartphones, Tablettes, Remorques, Stockage) conservent leurs scénarios financiers antérieurs; les notes de rubrique 14 exposent les comparateurs trouvés et les données encore insuffisantes. Elles ne sont pas redressées ni présentées comme validées.

Le rapport donne les marges, hypothèses, cadence arithmétique et contrôles. Les scénarios et archives Lot 152 à Lot 154 restent conservés.
