'use strict';
// Lot155: targeted v107 thresholds; does not overwrite Lot152/153 inputs or results.
const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const app=path.resolve(__dirname,'../../edge_package/P2I_Edge'),rt=path.join(app,'runtime');
const c={console,Math,Number,String,Array,Object,Map,Set,JSON,Error,TypeError,Date,Intl,URL,URLSearchParams};c.window=c;c.location={search:'',href:'file:///P2I_Edge/index.html'};c.history={replaceState(){}};vm.createContext(c);
for(const f of ['script-0.js','script-1.js','script-2.js','script-3.js','script-4.js','script-5.js','script-6.js','script-7.js','script-8.js','script-9.js','script-10.js','script-11.js','script-12.js','script-13.js','script-14.js','script-15.js','script-16.js','lot147-data.js','lot149-data.js','lot150-assemblage-data.js','lot152-assemblage-finances.js','lot153-assemblage-finances.js','catalogue-up-actif.js','script-17.js','lot152-assemblage-visuels.js','lot153-assemblage-visuels.js'])vm.runInContext(fs.readFileSync(path.join(rt,f),'utf8'),c,{filename:f});
const targetIds={tricycles_utilitaires:88,velos:1002,equipements:132};
const result={lot:155,engine:'v107',type:'seuils_conditionnels_non_adoptes',historical_archives_preserved:true,scenarios:{}};
for(const [id,units] of Object.entries(targetIds)){
 const prior=c.P2I_LOT152_FINANCES.units[id].input;
 const input=JSON.parse(JSON.stringify(prior)); input.production[0]=units;input.ventes[0]=units;
 const r=c.P2I_BP_SIMULATION_COMMUNE.calculer(input);
 const margin=r.annuel[0].chiffre_affaires?r.annuel[0].resultat_net/r.annuel[0].chiffre_affaires:null;
 const annual=r.annuel.map(y=>({year:y.annee,revenue_usd:y.chiffre_affaires,operating_result_usd:y.ebit,net_result_usd:y.resultat_net,net_margin:y.chiffre_affaires?y.resultat_net/y.chiffre_affaires:null,roi_annual:r.performance.annuel[y.annee-1].roi_annuel}));
 const data={up_id:id,units_A1:units,input:input,annual:annual,capex_usd:input.investissement,capex_equity_usd:input.investissement*input.part_apport,capex_debt_usd:input.investissement*input.part_dette,reserve_usd:r.reserve_initiale,total_funding_need_usd:input.investissement+r.reserve_initiale,minimum_cash_12m_usd:Math.min(...r.tresorerie.map(x=>x.solde_final)),cash_12m:r.tresorerie,bfr_max_36m_usd:Math.max(...r.bfr.map(x=>x.bfr)),bfr_36m:r.bfr,balance_checks:r.bilans.map(x=>({year:x.annee,gap_usd:x.ecart,assets_usd:x.actif_total,liabilities_equity_usd:x.passif_total})),controls:r.controles,status:'conditional_volume_threshold_not_a_sales_forecast'};
 if(!Number.isFinite(margin)||Math.abs(margin-0.06)>0.005||r.controles?.bilans_equilibres!==true||r.controles?.financement!=='40/60')throw new Error('v107 check failed '+id+' margin='+margin);
 result.scenarios[id]=data;
}
fs.writeFileSync(path.join(__dirname,'SEUILS_V107_CONDITIONNELS.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify({passed:true,engine:'v107',scenarios:Object.fromEntries(Object.entries(result.scenarios).map(([id,x])=>[id,{units_A1:x.units_A1,net_A1:x.annual[0].net_result_usd,margin_A1:x.annual[0].net_margin,min_cash:x.minimum_cash_12m_usd,bfr:x.bfr_max_36m_usd,balance_gaps:x.balance_checks.map(b=>b.gap_usd)}]))},null,2));
