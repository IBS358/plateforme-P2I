# P2I — Lot 239 — Audit énergétique transversal

Source : archive complète Lot238. Conservation des 96 UP, 17 rubriques existantes, moteur v107 et historiques ; aucun fichier historique modifié.

## Ajouts
- Calculateur local `ENERGIE_8UP_EDGE.html` : puissance moyenne, utilisation, tarif, matière entrante, rendement, coût de secours, kWh et FCFA par tonne vendable.
- Matrice énergétique des huit UP avec champs non renseignés plutôt que zéros artificiels.
- Pneus : référence candidate EcoShred ESG-1000, 204 kWh/h annoncés, 290,9 kW installés. Données à vérifier avant intégration au BP.

## Limites
Aucun tarif contractuel ivoirien, aucune puissance vérifiée des sept autres UP, aucun coût fournisseur supplémentaire, aucun résultat v107. Les coûts du groupe électrogène ne sont calculés que s'ils sont explicitement saisis. La puissance appelée ne suffit pas à reconstituer une facture incluant abonnement, puissance souscrite et éventuelles pénalités.

## Priorité
Qualifier les puissances et coûts réels des lignes complètes et des auxiliaires ; distinguer énergie thermique et électrique ; répercuter les charges dans le moteur commun v107 avant de conclure à la rentabilité.
