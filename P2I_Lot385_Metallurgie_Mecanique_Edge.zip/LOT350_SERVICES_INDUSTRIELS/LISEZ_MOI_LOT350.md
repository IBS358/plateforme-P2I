# Lot 350 — Services industriels et état de la cohorte 96 UP

## Production livrée

Huit BP autonomes enrichis (17 rubriques chacune) avec calcul v107 exécuté sur trois ans et trésorerie des douze mois A1. Les scénarios conservent les marges issues des hypothèses; aucune correction n'a été ajoutée pour atteindre un seuil. Les tableaux d'équipements distinguent prix publics observés, incoterm non publié et composants encore non chiffrés.

## Maturité générale

- 96 UP inventoriées et préservées; aucun dossier de la matrice source n'était marqué BP Découverte achevé et vérifié.
- Les 31 UP avec scénario financier historique sont désormais identifiées comme **avancées avec calcul hérité à valider**; leurs travaux ne sont pas recalculés.
- Les 57 UP sans données suffisantes restent **incomplètes / non calculables**.
- Services industriels: 8 BP retravaillés. Les résultats et réserves se trouvent dans la matrice CSV et sur les pages de l'index.

## Résultats Services industriels (USD)

Voir `index.html` et `SIMULATIONS_V107_INDICATIVES.json` pour CA/RN, marges, réserves de trésorerie, BFR, bilan et détail mensuel. Règles communes: 40 % apport, 60 % dette, taux dette 8 %, TVA 18 %, IS 25 %, A1–A3, personnel +4 %/an, autres charges +3 %/an.

## Limites de clôture technique

- Les prix importés affichés sont des tarifs catalogue/distributeur publics, mais ne sont généralement pas des prix EXW/FOB ni rendus en Côte d'Ivoire. Transport, assurance, douane, installation, mise en service et SAV sont réservés.
- Certaines nomenclatures d'équipements demeurent non tarifées; chaque BP le signale explicitement. Les 8 dossiers sont donc améliorés et calculés, mais pas abusivement labellisés « achevés et validés » avant ces vérifications.
- Les recettes de vente sauf tarifs publiés (formation, consultants, repères nettoyage) restent des hypothèses de scénario. Une marge calculée n'est pas une preuve de demande.
- Formation et Études & Conseils contiennent un modèle hybride physique/numérique, des coûts de licences repérés et des identifiants futurs; aucun portail de formation ou de conseil n'est développé.
- Les audits énergétiques réglementaires doivent être signés par un auditeur industriel agréé par la DGE.
- Le logo maître P2I original n’est pas présent dans l’archive reprise; les pages ne le remplacent pas par un dessin. Les icônes sont des schémas propres aux services.

## Préservation et utilisation locale

Le dossier source complet reste conservé dans `LOT349_SERVICES_INDUSTRIELS`; les pages historiques LOT346 et l'ensemble du site local sont inclus. Ouvrir `index.html`, puis sélectionner « Lot 350 — Services industriels » pour accéder aux huit BP. Les pages autonomes fonctionnent sous Edge; les sources externes demandent une connexion internet.
