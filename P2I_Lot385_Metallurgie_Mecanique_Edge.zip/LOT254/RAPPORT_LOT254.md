# P2I — Lot 254 : stress-test de trésorerie, plastique PEHD

## Travail nouveau
À partir des hypothèses exactes du scénario historique Lot 251, calcul de cinq prix de vente (350 à 550 FCFA/kg), 12 flux mensuels chacun, intérêts et amortissement mensuel d'un prêt sur 60 mois, DSCR opérationnel indicatif. Aucun autre BP ni moteur v107 modifié.

## Hypothèses additionnelles non sourcées
- Emprunt : 60 % du CAPEX de 89,100,000 FCFA, 10 % annuel, remboursement constant 60 mois.
- Fonds de roulement initial financé séparément : 17,741,920 FCFA (un mois de décaissements opérationnels) ; ni saisonnalité, ni délai de paiement, ni TVA.
- Ventes et dépenses réparties uniformément sur 12 mois ; aucune fiscalité et aucune variation de stock ou de BFR.
- Les prix de vente de 350 à 550 FCFA/kg sont des **hypothèses de stress**, pas des cotations vérifiées.

## Résultats (indicatifs)
- 350 FCFA/kg : EBITDA -0.75 M FCFA, DSCR -0.06, trésorerie finale avant fiscalité 3.36 M FCFA.
- 400 FCFA/kg : EBITDA 29.55 M FCFA, DSCR 2.17, trésorerie finale avant fiscalité 33.67 M FCFA.
- 450 FCFA/kg : EBITDA 59.86 M FCFA, DSCR 4.39, trésorerie finale avant fiscalité 63.97 M FCFA.
- 500 FCFA/kg : EBITDA 90.17 M FCFA, DSCR 6.62, trésorerie finale avant fiscalité 94.28 M FCFA.
- 550 FCFA/kg : EBITDA 120.48 M FCFA, DSCR 8.84, trésorerie finale avant fiscalité 124.59 M FCFA.

## Interprétation
Un DSCR supérieur à 1 dans ce modèle ne prouve pas la viabilité bancaire : il manque les impôts, les variations de BFR, la saisonnalité, les frais financiers annexes et les CAPEX de remplacement. Le scénario 500 kg/h ne doit pas être retenu comme configuration industrielle finale : priorité à la qualification de lignes 1–2 t/h et à la sécurisation des débouchés.

## Portée
Les huit UP de Recyclage & Valorisation restent ouvertes ; aucune nouvelle UP déclarée achevée. Les neuf UP déjà traitées, le catalogue 96 UP et le moteur v107 restent intacts.
