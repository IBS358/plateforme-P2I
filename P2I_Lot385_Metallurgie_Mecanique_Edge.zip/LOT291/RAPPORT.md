# P2I lot 291 — Consultation et coût rendu site
Livrables : huit BP intégrés, huit cahiers de consultation fournisseur et huit calculateurs de coût rendu site utilisables hors connexion sous Microsoft Edge.
Les prix machines et taux de change démarrent à zéro : aucun coût rendu site n'est calculé sans saisie documentée. Le calcul est (EXW/FOB + fret + assurance) × FCFA/USD + douane + port-site + installation + formation/pièces/SAV.
Le calcul ne traite pas les variations Incoterm et les risques de double comptage (ex. fret déjà inclus dans FOB/CIF) : les postes doivent être qualifiés.
Aucune recherche fournisseur ou prix catalogue n'a été effectuée dans ce lot. Les neuf UP validées ne sont pas modifiées. Les états financiers et projections historiques demeurent non validés.
