# P2I — Demande d'information et de prix (RFI/RFQ) — Plastique PEHD/PP
STATUT : DOCUMENT DE CONSULTATION, AUCUN FOURNISSEUR NI PRIX VALIDÉ

## 1. Objet
Fourniture d'une ligne industrielle de Plastique PEHD/PP, débit nominal visé 3 t/h, 16 heures/jour, 22 jours/mois. Le débit doit être garanti sur un échantillon représentatif de matière locale ; rendement matière de travail 78 %, non garanti.

## 2. Fonctions et débits minimaux à proposer
- Tri : débit minimal cible 3.6 t/h ; référence et prix à confirmer.
- Lavage : débit minimal cible 3.5 t/h ; référence et prix à confirmer.
- Sechage : débit minimal cible 3.2 t/h ; référence et prix à confirmer.
- Extrusion : débit minimal cible 3.0 t/h ; référence et prix à confirmer.

## 3. Réponse fournisseur obligatoire
1. Fabricant légal, site industriel, pays d'origine, contacts et références clients vérifiables.
2. Modèles exacts, photos réelles, fiches techniques et schéma de procédé.
3. Capacités nominale et effective sur matières d'entrée, tolérances, disponibilité et rendements garantis.
4. Bilan matière complet : produits, coproduits, rebuts et déchets dangereux.
5. Puissance installée (kW), consommation réelle (kWh/t), eau (m³/t), air comprimé, chaleur et rejets.
6. Implantation (m²), génie civil, bruit, poussières, protection incendie et sécurité opérateurs.
7. Prix détaillés par poste, devise, validité et Incoterm EXW/FOB, port de départ.
8. Conditionnement export, poids, volumes, délai de fabrication, garantie, pièces de rechange.
9. Supervision installation, mise en service, formation, tests de réception FAT/SAT et maintenance.
10. Liste des exclusions, exigences réglementaires ivoiriennes et modalités de paiement.

## 4. Conditions de réception
Les capacités, la qualité produit et les consommations devront être démontrées à partir de matières représentatives. Aucun engagement commercial avant vérification du prix rendu site, des autorisations et des débouchés.

## 5. Points de vigilance propres à l'UP
Séparer PEHD et PP selon spécifications clients ; humidité et contamination à mesurer ; eaux de lavage et boues à traiter.

## 6. Statut
Prix catalogues EXW/FOB : NON VÉRIFIÉS. Fournisseurs : NON QUALIFIÉS. Document à compléter par consultation réelle.
