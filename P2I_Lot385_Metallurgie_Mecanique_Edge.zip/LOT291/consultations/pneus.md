# P2I — Demande d'information et de prix (RFI/RFQ) — Pneus usagés
STATUT : DOCUMENT DE CONSULTATION, AUCUN FOURNISSEUR NI PRIX VALIDÉ

## 1. Objet
Fourniture d'une ligne industrielle de Pneus usagés, débit nominal visé 4 t/h, 16 heures/jour, 22 jours/mois. Le débit doit être garanti sur un échantillon représentatif de matière locale ; rendement matière de travail 65 %, non garanti.

## 2. Fonctions et débits minimaux à proposer
- Predecoupage : débit minimal cible 4.8 t/h ; référence et prix à confirmer.
- Broyage primaire : débit minimal cible 4.6 t/h ; référence et prix à confirmer.
- Granulation : débit minimal cible 4.0 t/h ; référence et prix à confirmer.
- Separation magnetique : débit minimal cible 4.0 t/h ; référence et prix à confirmer.

## 3. Réponse fournisseur obligatoire
1. Fabricant légal, site industriel, pays d'origine, contacts et références clients vérifiables.
2. Modèles exacts, photos réelles, fiches techniques et schéma de procédé.
3. Capacités nominale et effective sur matières d'entrée, tolérances, disponibilité et rendements garantis.
4. Bilan matière complet : produits, coproduits, rebuts et déchets dangereux.
5. Puissance installée (kW), consommation réelle (kWh/t), eau (m³/t), air comprimé, chaleur et rejets.
6. Implantation (m²), génie civil, bruit, poussières, protection incendie et sécurité opérateurs.
7. Prix détaillés par poste, devise, validité et Incoterm EXW/FOB, port de départ.
8. Conditionnement export, poids, volumes, délai de fabrication, garantie, pièces de rechange.
9. Supervision installation, mise en service, formation, tests de réception FAT/SAT et maintenance.
10. Liste des exclusions, exigences réglementaires ivoiriennes et modalités de paiement.

## 4. Conditions de réception
Les capacités, la qualité produit et les consommations devront être démontrées à partir de matières représentatives. Aucun engagement commercial avant vérification du prix rendu site, des autorisations et des débouchés.

## 5. Points de vigilance propres à l'UP
Rendement caoutchouc indicatif ; comptabiliser séparément acier et fibres ; contrôler granulométrie, poussières et risques incendie.

## 6. Statut
Prix catalogues EXW/FOB : NON VÉRIFIÉS. Fournisseurs : NON QUALIFIÉS. Document à compléter par consultation réelle.
