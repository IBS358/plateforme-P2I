# Lot 177 — premier BP de simulation structuré sur 17 rubriques

Source : Lot 176, moteur v107 existant, hypothèses historiques Lot 152.

**Livré :** page autonome de 17 rubriques Smartphones et sortie financière v107 intégrale, avec script de recalcul.

**Contrôles exécutés :** 3 comptes annuels, 12 mois de trésorerie, 36 mois BFR, 3 bilans équilibrés, financement 40/60, trésorerie minimale positive, marges A1–A3 >=6 %.

**Limites :** prix 174 USD A1 et 1 800 ventes/an non validés ; aucun devis pour les postes TBK/ESD ; absence de nomenclature produit par grade et de taux de retour ; aucune validation marché, aucun test manuel Edge. La simulation ne remplace pas le BP public. Les trois autres UP déficitaires ne sont pas finalisées.

**Archives :** ZIP complet sans suppression des lots historiques ; moteur et GitHub main non modifiés.
