# P2I — Lot 267 : qualification industrielle et contrainte de gisement de l’UP Verre

## Résultat déterminant
Le lot 266 suppose **17 741 tonnes de verre entrant par an** pour une ligne de 6 t/h à 70 % d’utilisation. Or les données historiques d’exportation de verre de la Côte d’Ivoire (2016–2019) sont très inférieures : **cela ne prouve pas que le gisement national est insuffisant**, mais interdit de présumer qu’un opérateur pourra capter 17 741 t/an sans contrats de collecte.

## Équipements techniquement identifiés, prix non publiés
- Krysteline K500 : broyeur 5–6 t/h (pas une usine complète).
- Andela AGB-06HD : broyeur 5 t/h.
- Andela Clean Up : ligne de nettoyage/séparation 5–20 t/h selon configuration.
- Binder+Co : tri des impuretés et tri couleur, compact possible dès environ 3 t/h.
**Aucun prix EXW/FOB vérifié n’a été obtenu** ; le plafond de 800 M FCFA est une hypothèse financière et non un devis.

## Test de disponibilité matière
Les scénarios reprennent **sans les valider** les prix de vente et coûts variables du lot 264 et un CAPEX hypothétique de 800 M FCFA. Le débit nominal est 6 t/h, rendement 85 %, 16 h/j × 22 j/mois. Le résultat A1 intègre amortissement 10 ans, dette 60 % à 10 %, impôt illustratif de 25 % sur résultat positif ; DSCR simplifié EBITDA/service de dette. **Aucun contrat ni prix de vente local n’est établi.**

## Décision
Ne pas figer le scénario 6 t/h à 70 % d’utilisation avant qualification de **17 741 t/an d’approvisionnement et 15 080 t/an de débouchés**. Si volumes insuffisants, tester un équipement plus petit ou un modèle de regroupement multi-sites, avec ses propres coûts fixes et investissements ; ne pas supposer qu’une ligne plus petite conserve les mêmes coûts unitaires. Ne pas valider l’UP sur la seule marge de 6,03 % du lot 266.

## Travail à terminer
Prix catalogue EXW/FOB ou offre fournisseur documentée de la **chaîne complète**, logistique, bâtiment, tri couleur, dépoussiérage, eau, refus, contrats matière, spécifications clients, prix nets CI, BFR réel, bilan 3 ans, trésorerie 12 mois, moteur v107, visuels et 17 rubriques conformes.

## Sources et périmètre
Voir SOURCES_TECHNIQUES_VERRE.json. Données d’exportation historiques : ne sont ni les déchets totaux générés ni les volumes aujourd’hui disponibles. Aucune autre UP ni moteur existant modifié.
