# Lot 289 — Recalcul prudent sur base physique
Ce lot reconstruit A1 à A3 avec : débit * 4224h * 70% * rendement historique LOT270 * prix unitaire LOT270. Coûts variables : tonnes entrantes * (achat/collecte + kWh/t * prix kWh + autres variables/t). Charges fixes selon LOT270. Amortissements, intérêts et principal des trois projections historiques conservés. Impôt indicatif 25 % sur bénéfice avant impôt positif.
Pas de croissance de volume ni prix ; aucune recette secondaire inventée. Le rendement différent du LOT287 est signalé, pas utilisé silencieusement.
Flux mensuels : ventes à crédit 30j, achats 15j, stock 15j, réserve BFR supplémentaire supposée financée.
IMPORTANT : hypothèses de prix et de coûts non vérifiées, pas de devis, pas de modèle v107 exécuté, pas de fiscalité/TVA complète. Les anciens tableaux restent dans les BP pour traçabilité et ne doivent pas être interprétés comme les résultats de ce scénario.
