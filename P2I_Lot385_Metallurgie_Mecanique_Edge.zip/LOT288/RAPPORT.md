# Lot 288 — Rapprochement physique et commercial
Chaque BP reçoit un tableau de cohérence : volume vendable issu du dimensionnement LOT287 × prix de vente historique LOT270, comparé au CA retenu par les projections financières LOT270.
L'écart est explicité et non masqué. On calcule le prix unitaire ou le volume qu'exigerait le CA financier.
Les volumes du LOT287 reposent sur des rendements matière non vérifiés ; le prix LOT270 n'est pas un prix marché vérifié. Ce contrôle ne valide donc aucun scénario : il identifie les incompatibilités à corriger dans le moteur v107.
Tous les 921 fichiers du lot287 sont conservés dans l'archive cumulative.
