# P2I — Lot 258 — Premiers seuils économiques comparables des huit UP

Ce lot conserve intégralement le lot 257. Il ajoute un **outil de préqualification**, pas huit BP financiers validés.

## Périmètre et avertissements
- Huit UP de Recyclage & Valorisation uniquement ; aucune modification des autres BP, du catalogue ou du moteur v107.
- Dimensionnement de travail : 16 h/jour, 22 jours/mois, 70 % d'utilisation, soit 2 956,8 h/an effectives.
- Toutes les capacités, rendements, prix de vente, coûts de collecte, consommations énergétiques, autres charges et charges fixes de ce tableau sont des **hypothèses illustratives**, sauf la continuité des hypothèses du plastique avec le lot 257. Elles **ne sont ni des devis fournisseurs ni des cotations de marché ivoirien**.
- La capacité huiles (2,5 t/h) équivaut à 40 t/jour nominales sur deux équipes.
- Pour le compost, le rendement représente une conversion massique simplifiée ; les durées de maturation, les stocks et la surface foncière ne sont pas encore modélisés.
- Pour les DEEE, la valeur de vente dépend fortement de la composition et de la séparation des fractions : un prix unique par tonne est un raccourci non validé.
- Pour les pneus, les produits de sortie (granulats, acier, textile) doivent être distingués dans le futur modèle.
- Pour les métaux, les coûts de collecte, le tri, les prix de ferrailles et les débouchés ne sont pas validés.
- Pour le verre, ne pas confondre calcin trié/broyé et verre refondu.
- Pour les huiles, ne pas confondre régénération industrielle, simple filtration et valorisation énergétique ; les exigences environnementales et les rendements sont différents.

## Calculs
Entrant annuel = capacité nominale × 16 × 22 × 12 × taux d'utilisation.
Vendable annuel = entrant annuel × rendement.
EBITDA simplifié = ventes − coût des déchets entrants − électricité − autres coûts variables − charges fixes.
Prix seuil de vente = (coûts variables annuels + charges fixes) / tonnage vendable.

Ces résultats excluent CAPEX, transport et installation détaillés, amortissements, intérêts, fiscalité, BFR, service de dette, trésorerie mensuelle, ventes de coproduits, conformité et financement. Ils ne constituent **pas** les calculs v107.

## Conditions préalables à la validation
1. Prix catalogues EXW/FOB traçables et périmètre de ligne complet, débit de chaque poste et puissance installée.
2. Collecte contractuelle suffisante, coûts rendus site, composition/qualité des flux entrants.
3. Offres commerciales ou références locales récentes par produit réellement vendable.
4. Calcul multi-produits et rendements par fraction, consommation spécifique, eau, traitement des rejets.
5. Simulation v107 complète : compte de résultat et bilan sur 3 ans, trésorerie mensuelle sur 12 mois, 40 % apport et 60 % dette, BFR, fiscalité et contrôles.
