# Rapport de validation visuelle P2I — Lot 127

Date : 14 novembre 2026  
Version de départ : archive `P2I_Edge_96_UP_Correctif_Modele_BP_Decouverte_20261113.zip`, manifeste Lot 117 — 96 UP, 12 filières, 73 scénarios financiers.  
Périmètre : consolidation visuelle des 49 UP déjà travaillées. Les autres filières et leurs calculs n’ont pas été retouchés.

## Résultat

- **47/47 illustrations de postes ajoutées** dans 14 UP : les emplacements qui n’avaient pas de visuel spécifique sont maintenant associés à une scène de procédé pertinente.
- Les 47 images ajoutées sont des **illustrations générées par IA**, extraites d’atlas de procédé ciblés. Elles sont étiquetées comme illustrations non contractuelles et ne représentent pas une machine ni un fournisseur identifié.
- **49/49 fonds d’atelier** sont reliés au bandeau d’activité et réutilisés dans le bloc 17 comme visuel de contexte. Sources recensées : 45 illustrations IA, 3 visuels de la banque P2I, et 1 visuel existant dont la provenance reste à confirmer. Les fonds sont floutés/voilés bleu nuit ; les médaillons et vignettes de poste ne reçoivent pas ce flou.
- **49/49 rendus ciblés exposent les 17 rubriques**. Le moteur a rendu 143 cartes de procédé sur les UP qui disposent d’une chaîne détaillée dans la version de départ ; les UP à chaîne technique spéciale conservent leur contenu spécifique.
- Configuration de référence, équipements, fournisseurs, prix et hypothèses financières : **inchangés**.

## Ajustements ciblés

- Les atlas IA manquants ont été rattachés aux postes précis au lieu d’afficher des cases vides.
- Les cinq mises en page techniques spéciales ont été enveloppées dans le bandeau d’atelier commun afin de conserver leur galerie tout en rétablissant le fond flouté.
- Les fonds d’atelier ont été raccordés aussi au bloc 17, avec leur qualification de source.
- Dans l’UP Engrais, le flux affiché est aligné sur la ligne liquide de référence : les six fonctions de la ligne et une étape manuelle de contrôle final/préparation à l’expédition. Cette opération manuelle n’ajoute aucun équipement ni investissement.
- Le visuel Javel et deux anciens styles d’Engrais ont été corrigés pour retirer des références d’image erronées.

## Tests exécutés

- Syntaxe JavaScript : scripts 17 et 18 et registre de chemins d’images valides (`node --check`).
- Rendu isolé des **49 UP** : 49 sans erreur JavaScript bloquante, 49 avec fond d’atelier, 49 avec 17 rubriques, 0 image de poste non illustrée dans le périmètre ciblé.
- Contrôle des 47 ajouts IA dans les cartes de poste : **47 détectés** dans le HTML rendu.
- Contrôle du registre des ressources : **266 chemins d’images** vers des fichiers présents dans le ZIP, aucune cible manquante.
- Archive finale : contrôle d’intégrité ZIP effectué après création.

**Limite du test :** le rendu est contrôlé par le moteur HTML/JS local. Une ouverture graphique dans le Microsoft Edge de l’utilisateur n’a pas été effectuée dans cet environnement. Les sources des images de contexte signalées ci-dessus restent indicatives ; les illustrations IA ne prouvent ni l’existence d’un atelier, ni les performances d’une machine.

## Suite

La prochaine filière dans l’ordre de la matrice après les 49 UP travaillées est **BTP & Matériaux de Construction** (8 UP) : Mini-cimenterie ; Briques et tuiles ; Éléments préfabriqués ; Tuiles et éléments toiture ; Agglos et parpaings ; Peintures bâtiment ; Centrale à béton ; Menuiserie aluminium/PVC. Elle est identifiée pour le lot suivant ; ses configurations et scénarios financiers ne sont pas déclarés terminés dans ce lot visuel.

## Fichiers modifiés

- `runtime/script-17.js` — manifestes atelier et procédé, rattachement des 47 scènes de poste.
- `runtime/script-18.js` — sélection des vignettes, fonds d’atelier, rendu des mises en page spéciales, bloc 17, alignement visuel de l’UP Engrais.
- `runtime/style-2.css` — flou/voile des fonds, habillage des mises en page spéciales.
- `runtime/style-1.css` et `runtime/historique-p2i-bp-decouverte-v108.css` — correction des anciennes références Javel/Engrais.
- `runtime/asset-paths.js` — référence Javel locale corrigée.
- `runtime/build-manifest.json` — version, provenance et intégrité des 14 atlas WebP ajoutés.
- `assets/media/ia-processus-*.webp` — 14 atlas de procédé ciblés.
- `MATRICE_VISUELS_49_LOT127.csv` — détail UP par UP.
