# P2I — Lot 351 — Services industriels

Cette version reprend et conserve le lot 350 ainsi que l’application P2I et les lots historiques inclus dans l’archive. Les huit pages BP sont produites dans `LOT351_SERVICES_INDUSTRIELS/BP_FINALISES/` avec les 17 rubriques, le calcul v107 sur 3 ans, la trésorerie mensuelle A1, les références d’équipements, les effectifs et les enveloppes fixes.

## Accès local

Ouvrir `OUVRIR_LOT351.html` dans Edge ou directement `LOT351_SERVICES_INDUSTRIELS/index.html`. Le bouton d’impression des pages permet l’export PDF depuis Edge. Les BP restent consultables hors ligne; les liens de prix catalogue requièrent Internet.

## Résultats A1 du moteur v107 (USD)

| UP | CA | Résultat net | Marge nette | Solde mensuel minimal A1 |
|---|---:|---:|---:|---:|
| Nettoyage industriel | 237 756 | 88 612 | 37,3 % | 10 961 |
| Maintenance industrielle | 180 000 | 24 738 | 13,7 % | 7 374 |
| Logistique industrielle | 300 000 | 17 595 | 5,9 % | 15 489 |
| Formation industrielle | 391 680 | 150 669 | 38,5 % | 14 185 |
| Qualité | 120 000 | 14 115 | 11,8 % | 5 392 |
| Études & Conseils | 134 454 | 14 783 | 11,0 % | 4 411 |
| Sécurité industrielle | 180 000 | 19 222 | 10,7 % | 8 034 |
| Services énergétiques | 180 000 | 2 007 | 1,1 % | 9 113 |

Le capital du plateau de formation a été revu de 75 000 à 100 000 USD pour couvrir son centre technique et l’équipement pédagogique hybride; le moteur v107 a été relancé. Les 40/60 apport/dette, 8 % d’intérêt, TVA/IS du moteur et hypothèses d’évolution sont conservés. Tous les huit bilans s’équilibrent et la trésorerie mensuelle A1 calculée reste positive, avec coussin initial distinct de l’apport couvrant l’investissement. Aucun tarif ni volume n’a été augmenté pour atteindre une marge cible.

## Réserves à conserver visibles

- **Nettoyage :** le scénario de l’archive portait 19 000 USD de coût direct unitaire sur un contrat de nettoyage, ce qui était incompatible avec le prix de référence et les salaires déjà saisis séparément. Le lot 351 le remplace par une estimation décomposée de 1 600 USD de consommables/effluents par site/an, 600 USD de déplacements par contrat, et une enveloppe salariale explicite. Cette estimation est déterminante pour la marge de 37,3 % et reste une réserve à valider par métré et bordereau de coûts. Tarifs locaux publiés repris pour l’entretien d’entrepôt, le nettoyage intensif et la désinfection générique. La décontamination chimique/biologique est techniquement prévue, mais n’est pas monétisée sans tarif spécifique et protocole contractualisé.
- **Logistique :** unité explicitée en position-palette équivalente/an; le prix de 300 USD/an est un repère de planification externe, faute de tarif local publié. La marge v107 est 5,9 %. La capacité d’entrepôt, l’occupation et les contrats sont le point de validation commercial.
- **Formation :** 60 cohortes/an de huit participants sur trois jours; tarif calculé à partir du prix public ATEWA et de la remise de groupe. Le modèle associe centre technique et accès numérique progressif aux ateliers P2I; l’outil LMS reste tiers et aucune plateforme n’est développée.
- **Études & Conseils :** le prix/jour est appuyé sur le repère public ARCOP; 320 jours facturés/an impliquent deux consultants seniors à 160 jours chacun. Le pipeline et les jours non facturables restent à vérifier.
- **Énergie :** marge nette 1,1 % en A1 et proche de zéro en A3; les audits réglementaires périodiques doivent être portés par un auditeur industriel agréé DGE. L’enveloppe de sous-traitance et les missions signées restent à contractualiser.
- Les prix machine hors Côte d’Ivoire sont des prix de catalogue/distributeur, souvent sans incoterm EXW/FOB publié. Le CSV d’équipements applique une provision transparente fret/assurance 12 %, port/transit 4 % et droits/prélèvements de planification 12,5 % du CIF. Cette dernière dépendra du classement SH; la TVA 18 % n’est exclue du CAPEX HT que si elle est récupérable.
- Le logo maître P2I original n’était pas présent dans l’archive reprise; aucun remplacement n’a été inventé. L’identité visuelle P2I existante est préservée et les pictogrammes restent des schémas de service.

## Fichiers remis

- `BP_FINALISES/` : huit BP améliorés.
- `SIMULATIONS_V107_INDICATIVES.json` : sorties détaillées, 3 ans / 36 mois et contrôles.
- `MATRICE_96_UP_LOT351.csv` : 96 UP; huit Services industriels mis à jour, 88 lignes historiques préservées.
- `CONFIGURATION_EQUIPEMENTS_CI.csv` : références publiques, budgets complémentaires et coût rendu estimatif CI.
- `REFERENCES_PRIX_CATALOGUE_ET_RESERVES.csv` : références et limites conservées du lot précédent.
- `IDENTIFIANTS_FUTURE_INTEGRATION.json` : identifiants des modules futurs conservés, modules non développés.

Le ZIP préserve la base complète du lot 350 et les travaux historiques. Aucune branche GitHub ni `main` n’a été modifiée.
