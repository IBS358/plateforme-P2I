# P2I — Lot 172 — Audit exhaustif des 960 scénarios v107

Source de départ : copie locale du Lot 171 ; historique des entrées financières Lot 152. Aucun changement de GitHub `main` ou des archives antérieures.

## Résultat

960 scénarios recalculés (240 par UP), zéro erreur de calcul. Les 45 scénarios Smartphones qui franchissent la marge A1 de 6 % avec trésorerie non négative et bilans équilibrés ne donnent **aucun** résultat positif sur A1–A3 si seules les hypothèses A1 changent. En revanche, **45** franchissent 6 % de marge sur chacune des trois années quand les facteurs de prix, volume et coût sont appliqués aux trois années. Les autres UP ne franchissent pas le seuil dans cette grille.

## Méthode

Facteurs par UP : volume x1 / x1,25 / x1,5 / x2 (plafond de capacité historique), prix x1 / x1,1 / x1,2 / x1,3, matières x1 / x0,9 / x0,8 / x0,7 / x0,6, charges fixes x1 / x0,9 / x0,8 si champ existant. Deux calculs par combinaison : modification A1 seule et modification des trois années. Le moteur v107 contrôle les bilans et le financement 40/60 ; trésorerie minimale mensuelle sur 12 mois.

## Limites

Aucun de ces facteurs n'est un prix fournisseur ou un prix de vente local vérifié. La méthode prolonge les hypothèses historiques et **ne construit pas les quatre nouvelles configurations industrielles**. Le passage de la grille ne signifie pas qu'un BP est économiquement validé. Les chiffres A2 et A3 restent dépendants des hypothèses du moteur et du maintien des améliorations. Les quatre BP déjà avancés ne sont pas modifiés.

## Fichiers

- `recalcul_960_v107.cjs` : script reproductible ; exécuter depuis le dossier LOT172 avec Node.js.
- `960_SCENARIOS_COMPLETS.json` : résultats individuels A1–A3 pour chaque scénario et chaque méthode.
- `SYNTHESE_960.json`, `SYNTHESE_960.csv` : synthèse des qualifications.

## Tests

- Exécution complète du script Node.js : réussite (960/960, 0 erreur).
- Test de syntaxe Node.js : réussite.
- Vérification intégrité ZIP : réussite.
- Test manuel Edge : non réalisé.

Statut : audit financier terminé, quatre BP industriels restants non finalisés.
