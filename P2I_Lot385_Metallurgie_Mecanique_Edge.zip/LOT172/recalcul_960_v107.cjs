'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.resolve(__dirname,'..'),rt=path.join(root,'runtime');
const c={console,Math,Number,String,Array,Object,Map,Set,JSON,Error,TypeError,Date,Intl,URL,URLSearchParams};c.window=c;c.location={search:'',href:'file:///P2I_Edge/index.html'};c.history={replaceState(){}};vm.createContext(c);
const files=['script-0.js','script-1.js','script-2.js','script-3.js','script-4.js','script-5.js','script-6.js','script-7.js','script-8.js','script-9.js','script-10.js','script-11.js','script-12.js','script-13.js','script-14.js','script-15.js','script-16.js','lot147-data.js','lot149-data.js','lot150-assemblage-data.js','lot152-assemblage-finances.js','lot153-assemblage-finances.js','catalogue-up-actif.js','script-17.js','lot152-assemblage-visuels.js','lot153-assemblage-visuels.js','lot154-remorques.js','lot154-remorque-finances.js','lot155-assemblage-finances.js'];
for(const f of files)vm.runInContext(fs.readFileSync(path.join(rt,f),'utf8'),c,{filename:f});
const clone=x=>JSON.parse(JSON.stringify(x));
const ids=['smartphones','tablettes','remorques_agricoles','stockage_manutention'];
const summary={lot:172,source:'Lot152 historical inputs; Lot170 factor grid',engine:'v107',warning:'Exploratory simulations, not validated selling prices or cost evidence',units:{}};
const all=[];
for(const id of ids){
 const base=clone(c.P2I_LOT152_FINANCES.units[id].input);const cap=base.capacite*250*8;
 const counters={tested:0,pass_A1:0,pass_A1_A2_A3_with_A1_only_changes:0,pass_A1_A2_A3_with_3year_changes:0,pass_3year_margin_6pct:0,errors:0};
 for(const vf of [1,1.25,1.5,2])for(const pf of [1,1.1,1.2,1.3])for(const mf of [1,.9,.8,.7,.6])for(const ff of [1,.9,.8]){
  const vol=Math.min(cap,Math.round(base.ventes[0]*vf));
  const run=(applyAllYears)=>{const x=clone(base);const years=applyAllYears?[0,1,2]:[0];for(const y of years){const multiplier=vol/base.ventes[0];x.ventes[y]=Math.min(cap,Math.round(base.ventes[y]*multiplier));x.production[y]=Math.min(cap,Math.round(base.production[y]*multiplier));x.prix[y]=base.prix[y]*pf;x.matieres_kg_annuel[y]=base.matieres_kg_annuel[y]*mf;if(Array.isArray(x.charges_fixes_annuel))x.charges_fixes_annuel[y]=base.charges_fixes_annuel[y]*ff;}return c.P2I_BP_SIMULATION_COMMUNE.calculer(x);};
  try{const a=run(false),b=run(true);const extract=r=>({rn:r.annuel.map(z=>z.resultat_net),ca:r.annuel.map(z=>z.chiffre_affaires),margin:r.annuel.map(z=>z.chiffre_affaires?z.resultat_net/z.chiffre_affaires:null),cash_min:Math.min(...r.tresorerie.map(z=>z.solde_final)),balance:r.controles.bilans_equilibres,financing:r.controles.financement});const p=extract(a),q=extract(b);const ok=r=>r.cash_min>=0&&r.balance===true&&r.financing==='40/60';const a1=ok(p)&&p.margin[0]>=.06;const allPos=r=>ok(r)&&r.rn.every(v=>v>0);const three6=allPos(q)&&q.margin.every(v=>v>=.06);
   counters.tested++;if(a1)counters.pass_A1++;if(a1&&allPos(p))counters.pass_A1_A2_A3_with_A1_only_changes++;if(allPos(q)&&q.margin[0]>=.06)counters.pass_A1_A2_A3_with_3year_changes++;if(three6)counters.pass_3year_margin_6pct++;
   all.push({id,vf,pf,mf,ff,vol,price_A1:base.prix[0]*pf,material_A1:base.matieres_kg_annuel[0]*mf,A1_only:p,all_years:q,passes_A1:a1,passes_3year_positive_all_years:allPos(q)&&q.margin[0]>=.06,passes_3year_6pct:three6});
  }catch(e){counters.errors++;all.push({id,vf,pf,mf,ff,error:String(e)});}
 }
 summary.units[id]=counters;
}
summary.total=Object.values(summary.units).reduce((a,v)=>{for(const k of Object.keys(v))a[k]=(a[k]||0)+v[k];return a;},{});
fs.writeFileSync(path.join(__dirname,'960_SCENARIOS_COMPLETS.json'),JSON.stringify({metadata:summary,scenarios:all},null,2));
fs.writeFileSync(path.join(__dirname,'SYNTHESE_960.json'),JSON.stringify(summary,null,2));
const rows=['UP;Testes;A1_6pct;A1_6pct_et_A2_A3_positifs_A1_seule_modifiee;A1_6pct_et_A2_A3_positifs_3ans_modifies;Marge_6pct_3ans;Erreurs'];for(const [id,x] of Object.entries(summary.units))rows.push([id,x.tested,x.pass_A1,x.pass_A1_A2_A3_with_A1_only_changes,x.pass_A1_A2_A3_with_3year_changes,x.pass_3year_margin_6pct,x.errors].join(';'));fs.writeFileSync(path.join(__dirname,'SYNTHESE_960.csv'),rows.join('\n')+'\n');
console.log(JSON.stringify(summary,null,2));
