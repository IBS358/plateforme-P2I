# Lot 199 — Fiabilisation des chiffrages

Base : Lot 198. Deux chiffrages ventilés (machines de conditionnement et stockage) modifiés, ainsi que leurs alias historiques LOT197.

- Import JSON contrôlé (UP, schéma, indices de postes, natures, nombres non négatifs, limite 2 Mo et 500 lignes).
- Export compatible avec le nouveau schéma P2I-199 et import des exports P2I-198.
- Sauvegarde automatique à chaque changement et rappel de sauvegarde externe pour l'utilisation locale Edge.
- Blocage des natures de coût inconnues afin d'éviter un total NaN.
- Aucun prix, aucune marge ou projection v107 inventés.
- Limite : les résultats des trois UP non chiffrées restent indisponibles.
