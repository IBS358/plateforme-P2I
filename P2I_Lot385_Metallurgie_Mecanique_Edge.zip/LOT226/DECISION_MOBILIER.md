# LOT 226 — Arbitrage de clôture de la qualification mobilier

## Décision
**Ne pas prolonger les micro-lots de sensibilité.** La fabrication de mobilier scolaire et professionnel est pertinente industriellement et socialement, mais son scénario financier n'est pas validé. Le lot 226 ne modifie ni le catalogue actif ni les sept autres BP. Il clôt l'analyse sur les données actuelles, sans annoncer de BP achevé.

## Données vérifiées dans les fichiers P2I
- A1: CA 70 000 000 FCFA, coûts variables 50 240 000 FCFA, frais fixes hors personnel 8 925 000 FCFA, personnel 14 280 000 FCFA. Solde avant amortissements, intérêts, impôts = -3 445 000 FCFA.
- Table-banc: coût variable 25 200 FCFA dont 18 200 FCFA acier/bois et 7 000 FCFA non ventilés. L'optimisation de découpe acier est **déjà comprise** dans ces 18 200 FCFA; ne pas la soustraire à nouveau.
- Bureau: 71 000 FCFA de coût variable hypothétique, sans nomenclature chiffrée suffisante. Armoire: 108 000 FCFA, même limite.
- Dirigeant: inclusion dans la masse salariale historique non documentée. Les simulations présentent les deux cas.

## Garde-fous
1. Coût de revient présenté **hors personnel**, conformément à la décision de l'utilisateur. Personnel et dirigeant en charges distinctes.
2. Aucun pourcentage de réduction n'est présenté comme acquis.
3. Ne pas confondre solde avant DAI et résultat net. Les cibles de 6 % et 10 % du tableau sont des seuils de solde **avant DAI**, donc insuffisants pour certifier la marge nette.
4. Ventes à crédit: conserver les acomptes, délais clients, décalage d'achat matière, BFR et trésorerie mensuelle.
5. Aucune commande publique ou subvention présumée.

## Recommandation opérationnelle
Geler ce candidat au statut **qualifié industriellement / non validé financièrement**, sans fabriquer de visuels définitifs ni migrer le catalogue. Réorienter le développement vers les UP prioritaires disposant de nomenclatures, fournisseurs et capacités suffisamment étayés. Réouverture du mobilier uniquement lorsque sont disponibles: (i) nomenclatures et prix rendus atelier des bureaux/armoires, (ii) ventilation des 7 000 FCFA du table-banc, (iii) plan de capacité/équipes, (iv) hypothèses de commandes et de crédit vérifiables.

## Tests
- Réconciliation 70 000 000 - 50 240 000 - 8 925 000 - 14 280 000 = -3 445 000 FCFA.
- Aucun changement des fichiers historiques de l'archive source.
- Aucun calcul v107 supplémentaire revendiqué.
