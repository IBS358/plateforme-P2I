# P2I — Lot 153 : réévaluation économique et visuels Assemblage & Montage

**Statut du lot :** calculs v107 exécutés pour sept unités; le lot ne redresse pas artificiellement les scénarios. Les sensibilités ci-dessous ne deviennent pas des références commerciales validées. Le Lot 152 est conservé intact comme historique.

## Résultat comparatif A1

| UP | Lot 152 : RN / marge A1 | Sensibilité Lot 153 : RN / marge A1 | CAPEX | Réserve séparée | Besoin total | Conclusion |
|---|---:|---:|---:|---:|---:|---|
| Reconditionnement industriel de smartphones | -46 831 USD / -35.89% | -21 631 USD / -8.29% | 42 000 USD | 55 501 USD | 97 501 USD | Déficit persistant même au plafond de capacité théorique (1 800 ventes/an); coût d’achat par grade et taux de réparation non établis. |
| Assemblage de tablettes éducatives et professionnelles | -130 421 USD / -129.39% | -130 421 USD / -129.39% | 28 000 USD | 166 173 USD | 194 173 USD | Non viable avec le kit FOB affiché à 154,47 USD et prix net 112 USD; aucune nouvelle offre SKD comparable vérifiée. |
| Assemblage de tricycles utilitaires | 3 400 USD / 2.30% | 5 800 USD / 3.92% | 52 000 USD | 16 681 USD | 68 681 USD | Sensibilité FOB bas publiée : marge 3,92%, sous repère P2I et dépendante des coûts rendus estimatifs; non adoptée. |
| Assemblage de vélos économiques, scolaires et utilitaires | -4 579 USD / -2.60% | 14 003 USD / 5.96% | 58 000 USD | 27 723 USD | 85 723 USD | Sensibilité à 1 000 ventes A1 : 5,96%, mais ce volume est déplacé de l’année 2 et le kit de 112 USD reste estimatif; non adoptée. |
| Fabrication et installation d’équipements sportifs de proximité | -14 181 USD / -12.61% | 4 327 USD / 2.88% | 42 000 USD | 15 829 USD | 57 829 USD | Sensibilité 120 équipements A1 : 2,88%; demande et charge atelier ne sont pas établies, prestations d’installation exclues. |
| Fabrication de remorques agricoles et utilitaires légères | -70 398 USD / -102.03% | -59 898 USD / -43.40% | 55 000 USD | 81 538 USD | 136 538 USD | Déficit de 43,40% même à capacité nominale (120 unités/an); modèle de charge et prix de vente ne sont pas défendables en l’état. |
| Fabrication d’équipements de stockage et de manutention légère | -85 845 USD / -116.80% | -91 053 USD / -133.33% | 118 000 USD | 112 859 USD | 230 859 USD | Déficit de 133,33% avec prix-sensibilité basé sur un comparateur local non équivalent; ligne et coût matière restent incomplets. |

Les résultats annuels A2 et A3, les états mensuels de trésorerie (12 mois), le BFR (36 mois), les écarts de bilan, les paramètres exacts et les financements sont dans `RESULTATS_COMPARATIFS_V107.json`. `RESULTATS_COMPARATIFS.csv` fournit la synthèse tabulaire. Le bilan est équilibré par le moteur sur chaque sensibilité. Le besoin total est CAPEX + réserve distincte; apport total à prévoir = 40% du CAPEX + réserve; dette = 60% du CAPEX. Les trésoreries minimales positives sont conditionnées au financement effectif de cette réserve et ne sont pas un indicateur de viabilité.

## Diagnostic et décisions par unité

### Reconditionnement de smartphones
- Le Lot 152 produit 900 ventes A1 et 1 800 unités/an de capacité nominale. Avec prix net 145 USD, coût de production 112 USD et distribution 5 USD, la contribution avant charges fixes est de 28 USD/appareil. Les charges de personnel et charges fixes représentent 66 000 USD/an avant amortissements/intérêts; le scénario perd donc de l’argent à 900 ventes.
- Le test à 1 800 ventes A1, soit 100% de la capacité nominale sans preuve de débouché, relève la marge de −35,89% à −8,29%, mais ne l’efface pas. Les deux prix d’appareils usagés repérés concernent des modèles/grades distincts; ils ne démontrent ni un panier d’achat homogène, ni un rendement de remise en état et garantie.
- Décision : aucune hausse de prix/volume adoptée; coût d’acquisition par grade, taux de réparabilité, taux de rebut et garantie manquants.

### Tablettes SKD
- Le kit Smartlink 10,1 pouces 4/128 est affiché à 154,47 USD FOB, soit déjà au-dessus du prix net P2I de 112 USD, avant fret/douane, montage, test et distribution. Le coût matière retenu par Lot 152 est 178 USD (rendu estimatif), puis 6 USD de conversion et 4 USD de distribution.
- Mitec affiche un produit fini Atouch KT37 10,1 pouces 4/128 à 44 900 FCFA, mais la page indique promotion épuisée : comparaison indicative de détail, pas une cotation grossiste ni un kit SKD. Cette observation ne rend pas un assemblage local compétitif à 112 USD.
- Décision : scénario négatif conservé, aucun kit de remplacement trouvé à un prix publié et comparable; segment non recalibré sans BOM et offre de kit.

### Tricycles utilitaires
- Test de borne basse du catalogue du même modèle JLM31001 : FOB 420 USD au lieu de 460 USD. Les caractéristiques publiées (1000 W, batterie plomb 45 Ah, CKD 52 unités/40HQ) concordent avec le produit indiqué, mais la plage FOB ne prouve pas quel niveau de prix s’applique au packing list exact. Les 175 USD de coûts rendus et 80 USD de conversion restent P2I estimatifs.
- Résultat sensibilité : RN A1 +5 800 USD; marge 3,92%, vs 2,30% historique. Ce n’est pas une marge de 6–10% et la trésorerie dépend d’une réserve séparée de 16 681 USD.
- Décision : sensibilité conservée mais non adoptée. À confirmer : contenu CKD, conformité/homologation, coût rendu réel et débouchés. Un comparateur thermique local n’est pas assimilé au véhicule électrique.

### Vélos
- Sensibilité à 1 000 ventes A1, volume qui figurait en A2 Lot 152, sans preuve que les commandes ou la demande peuvent être avancées : RN +14 003 USD, marge 5,96%.
- Le coût BOM de 112 USD reste une estimation faute de kit CKD coté. Un vélo 26 pouces local d’occasion à 129 000 FCFA n’est pas comparable au produit P2I neuf ni à un prix de gros. Un appel d’offres PSI-CI de 2023 confirme un lot de 1 500 vélos avec montage/distribution, mais le document consulté ne fournit pas de prix attribué.
- Décision : sensibilité non adoptée; obtenir coût du kit documenté et valider volumes institutionnels/distributeurs.

### Équipements sportifs
- À 120 buts A1 au lieu de 90, le moteur donne +4 327 USD, marge 2,88%. Il ne s’agit pas d’une justification du volume vendu. Le comparateur public d’un but installé inclut un autre périmètre et n’établit pas un prix net départ atelier. La pose d’infrastructures n’a pas été comptabilisée.
- Le CAPEX est celui déjà alloué au poste partagé du Lot 152 (24 000 USD dans cette UP). Ce rapport ne consolide pas l’atelier commun sports/remorques en un bilan d’exploitation unique : les coûts partagés doivent être rapprochés avant adoption pour exclure un double comptage dans le portefeuille.
- Décision : aucun scénario de référence redressé; besoin de nomenclature cotée, temps de soudage/finition et carnet de prospects démontrable.

### Remorques agricoles
- Test à 120 unités/an, plafond nominal contre 60 unités A1 historiques : marge encore −43,40%, RN −59 898 USD. Contribution unitaire indicative avant frais fixes : 1 150 − 930 − 45 = 175 USD; à 120 unités cela représente 21 000 USD, face à 73 000 USD de personnel + charges fixes, avant amortissement et dette.
- Le PTAC visé de 750 kg ne définit pas la charge utile. La nomenclature matière est estimative et il manque un plan coté, calculs de résistance, tare, essieu/attelage exacts et prix net local fiable.
- Décision : aucune optimisation commerciale défendable avec les données disponibles; garder le déficit visible et ne pas augmenter le prix.

### Stockage et manutention
- L’essai à 97,56 USD (64 000 FCFA) s’appuie sur un rayonnage local WADFOW de format et capacité différents (180×160×60 cm, 4 niveaux, capacité publiée 500 kg/niveau) de la référence P2I (180×90×40 cm, 5 niveaux). Ce n’est pas une preuve de prix pour le produit P2I.
- La contribution unitaire à ce prix-sensibilité est 97,56 − 84 − 8 = 5,56 USD; 700 ventes donnent moins de 3 900 USD avant coûts fixes, contre 78 000 USD de personnel + charges fixes. L’investissement inclut 67 500 USD de profileuse en borne haute, mais ligne traverses/plateaux et poinçonnage ne sont pas suffisamment chiffrés.
- Décision : aucune référence économique; réserver ou réviser la gamme et documenter le coût des composants et l’offre de ligne complète avant un nouveau scénario.

## Visuels et intégration
- Sept planches photoréalistes propres aux UP ont été ajoutées; elles sont générées par IA, clairement signalées comme illustrations non contractuelles et ne prétendent pas montrer les références fournisseur retenues. Les personnes représentées sont placées dans des ateliers ivoiriens crédibles.
- Chaque UP a son fond atelier, son médaillon produit, deux variantes (hors calcul lorsqu’elles ne sont pas la référence) et six étapes de processus associées aux cellules de sa planche. Elles ne recréent pas le logo P2I; le fichier du logo officiel de la plateforme est conservé.
- Les sensibilités et réserves sont visibles dans la rubrique 14 « Hypothèses et sources » sous un panneau repliable Lot 153. Le scénario Lot 152 reste le scénario principal affiché; une sensibilité non adoptée ne le remplace pas.
- Aucun autre dossier ni archive historique n’est modifié. Le catalogue conserve 96 identifiants uniques répartis en 12 filières et l’UP Cuisines & Chambres froides demeure inchangée.

## Contrôles exécutés
- Tests Node/VM : moteur commun v107, sept recalculs, projections A1–A3, trésorerie 12 mois, BFR 36 mois, équilibres de bilan, financement apport/dette 40/60 du CAPEX et réserve séparée.
- Contrôles structurels : 96 UP uniques, 12 filières, identifiants Assemblage exacts, 17 rubriques du renderer, sept atlas distincts existants, six images d’étapes et deux images de variantes par UP.
- Syntaxe JavaScript du renderer et ordre de chargement contrôlés; liens locaux et images intégrées vérifiés par présence. ZIP vérifié par `unzip -t` après création.
- Un essai de lancement Chromium a échoué : le conteneur bloque l’ouverture du socket requis par le navigateur. Aucun rendu graphique dans Chromium ou Microsoft Edge, clic de navigation, export PDF ou impression n’est donc déclaré testé.

## Sources ciblées consultées
- Catalogue Jolmolangma juillet 2025, fiche JLM31001 et FOB 420–460 USD : https://jolmolangma.com/wp-content/uploads/2025/07/Jolmolangmal%C2%AE-Locomotive-catalogue-202507.pdf (modèle documenté, conditions/packing list à confirmer).
- Mitec CI, tablette finie Atouch KT37, prix affiché 44 900 FCFA, mais promotion épuisée : https://www.mitec.ci/products/tablette-educative-atouch-kt37-neuve-4-gb-128-gb-avec-puce-101-pouces-avec-gadget.
- Sport3 CI, comparateurs vélo d’occasion 26 pouces 129 000 FCFA et Specialized 189 000 FCFA : https://sport3.ci/categorie-produit/velo/vtt/ (pas des prix de gros ni des produits neufs identiques).
- PSI-CI, appel d’offres 2023, 1 500 vélos avec montage et distribution; pas de prix attribué dans le document consulté : https://www.educarriere.ci/pics/telechargements/581-psi-ci_appel-d-offres-pour-acquisition-de-1500-velos-le-montage-et-la-distribution-vf1_ng.pdf.
- Les autres sources documentaires conservées sont dans `../LOT152/HYPOTHESES_ET_SOURCES.csv`; les limites de comparabilité y sont maintenues.

**Conclusion opérationnelle :** le Lot 153 ne rend pas les sept UP économiquement acceptables. Il permet de quantifier les sensibilités sans changer les hypothèses non prouvées en références. Deux sensibilités restent proches du repère mais non prouvées (vélos à 5,96%, tricycles à 3,92%); aucune des sept ne peut être déclarée économiquement validée sur les éléments actuellement documentés.
