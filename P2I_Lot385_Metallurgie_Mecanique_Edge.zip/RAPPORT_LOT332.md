# Lot 332 — Enrichissement éditorial des huit BP

- 56 enrichissements opérationnels : rubriques 3, 4, 5, 6, 7, 9 et 16 de chacune des huit UP.
- Aucun calcul financier ni fichier visuel existant modifié.
- 17 rubriques conservées par BP.
- Les photographies individuelles des machines restent à compléter et ne sont pas prétendues vérifiées.
- Scénario DEEE dépend toujours de la prestation de dépollution à 300 USD/t.
