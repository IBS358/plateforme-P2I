# Lot 331 — Clarification éditoriale des huit BP

Les huit BP du lot 330 sont préservés. Les annexes historiques ont été rendues repliables, les rubriques 10 à 15 signalent la présence de chiffres historiques, et des liens permettent de rejoindre les données financières v107. Les marges et données financières ne sont pas recalculées. Les galeries et schémas existants sont conservés ; les photographies des machines fabricant restent absentes. Le scénario DEEE demeure conditionnel.

{
  "plastique": {
    "historical_sections_collapsed": 14,
    "rubrics": 17,
    "images": 8
  },
  "papier-carton": {
    "historical_sections_collapsed": 14,
    "rubrics": 17,
    "images": 8
  },
  "metaux": {
    "historical_sections_collapsed": 14,
    "rubrics": 17,
    "images": 8
  },
  "compost": {
    "historical_sections_collapsed": 16,
    "rubrics": 17,
    "images": 8
  },
  "verre": {
    "historical_sections_collapsed": 16,
    "rubrics": 17,
    "images": 8
  },
  "pneus": {
    "historical_sections_collapsed": 17,
    "rubrics": 17,
    "images": 8
  },
  "huiles": {
    "historical_sections_collapsed": 16,
    "rubrics": 17,
    "images": 8
  },
  "deee": {
    "historical_sections_collapsed": 17,
    "rubrics": 17,
    "images": 8
  }
}