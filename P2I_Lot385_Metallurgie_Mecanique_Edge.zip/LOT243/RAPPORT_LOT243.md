# P2I — Lot 243 : huit projets de BP en 17 rubriques

Base : archive complète du lot 242. Huit projets HTML autonomes de structure, conservant les 33 postes historiques, les 7 références commerciales candidates et les orientations du lot 241.

**Non livré comme BP validé :** absence de prix catalogue par configuration complète, de gisements, rendements, tarifs énergétiques, volumes et prix de vente. Aucun résultat financier inventé.

Le catalogue et le moteur v107 ne sont pas modifiés. Aucun test graphique réel dans Microsoft Edge.
