# P2I — Lot 249 : bilans matière et énergie des huit UP de recyclage

Base : archive cumulative du lot 248. Intervention limitée au nouveau dossier LOT249 ; aucun fichier historique ni moteur v107 modifié.

## Réalisation
- Huit fiches de simulation consultables hors ligne dans Edge.
- Bilans mensuels entrants/vendables, électricité et coût électrique par tonne vendable.
- Distinction explicite entre capacités exploratoires historiques et valeurs vérifiées.
- Champs rendements, puissance moyenne et tarif laissés vides pour éviter les résultats fictifs.
- Différenciation des procédés : carton compacté sans pulpage, métal sans fusion, verre sans refusion, pneus sans pyrolyse, compost en t/j.

## Limites bloquantes
Aucun prix de ligne complet, aucune qualification de rendement ou tarif d'électricité, aucun contrat d'approvisionnement ni débouché chiffré nouveau. Les huit BP demeurent NON_CALCULABLES pour v107. Les neuf autres UP déjà traitées ne sont pas modifiées. Ce lot n'est pas la livraison finale demandée.
