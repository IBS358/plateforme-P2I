# Lot 166 — protection visible contre les BP non validés

**Base :** Lot165, sans modification des archives historiques ni de GitHub.

**Changement fonctionnel :** un bandeau d’avertissement apparaît dans la page `index.html` lorsqu’une des quatre UP est demandée par `?unit_id=...` (également `up_id`, `unit`, `up`). Il signale que les chiffres appartiennent à une ancienne simulation rejetée. Il ne change aucun résultat du moteur commun.

**Fichiers modifiés :** `index.html`; nouveau `runtime/lot166-visual-guard.js`. **Créés :** les fichiers `LOT166/`.

**Tests :** syntaxe JS, insertion unique, identifiants, préservation des sources, recalcul historique v107. Aucun test manuel dans Microsoft Edge. Aucun nouveau BP financier calculé, aucune nouvelle BOM validée, aucun prix inventé.

**Limite :** la sélection d’une UP peut aussi se faire via des contrôles internes sans modifier l’URL : le bandeau ne couvre alors pas nécessairement cette sélection. Les anciennes simulations restent présentes et ne doivent pas être considérées comme des BP validés.
