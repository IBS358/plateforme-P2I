# P2I — Lot 241 — Consolidation industrielle de Recyclage & Valorisation

Source exacte : Lot 240. Conservation de 494 fichiers historiques avant ajout des 5 livrables du lot 241.

## Résultats vérifiables
- 8 UP couvertes ; 33 postes industriels historiques audités ; 7 lignes de références commerciales candidates reprises du lot 238.
- Cadrage du produit de référence pour chaque UP, sans inventer de capacité, prix, puissance ou débouché.
- Papier/carton : le scénario de tri/compactage est proposé à la place de la fabrication de pâte/papier; les équipements historiques de pulpage et séchage restent archivés.
- Huiles : distinction impérative entre huiles minérales usagées et huiles alimentaires.
- DEEE : dépollution préalable impérative, pas de broyage indifférencié.
- Métaux : préparation de ferrailles sans fusion, périmètre à distinguer de la métallurgie.
- Pneus : la consommation 204 kWh/h est une donnée candidate d'un fournisseur, non une consommation certifiée de la configuration P2I.

## Limitations
- Les prix du registre sont des indications historiques commerciales, pas des devis et pas des lignes complètes comparables.
- Aucun BP v107 calculé ou modifié. Aucun moteur, catalogue, logo ou BP historique modifié.
- Vérification statique de liens et d'intégrité seulement; pas de test graphique Microsoft Edge.
