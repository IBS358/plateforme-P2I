# P2I — Lot 233 — Revue de Recyclage & Valorisation

Source: archive complète du lot 232, `P2I_Edge/runtime/catalogue-up-actif.js`. Les huit IDs actifs sont `plastique`, `papier`, `metaux`, `compost`, `verre`, `pneus`, `huiles`, `deee`.

## Résultat
- Les 8 UP sont inventoriées, sans changement de catalogue ni de moteur v107.
- Doublons potentiels: `plastique` / `granules` et `metaux` / `recyclage_metaux` (filières différentes).
- Aucun prix, capacité industrielle ni marge n'est validé dans ce lot. Les CAPEX historiques éventuels ne doivent pas être traités comme des devis vérifiés.
- Priorité de qualification: plastique et métaux sous réserve d'arbitrage des doublons; pneus et compost ensuite; papier, verre, huiles et DEEE selon débouchés et autorisations.

## Règle de dimensionnement
Capacité annuelle vendable = min(capacité effective après arrêts et rendement, gisement sécurisé × rendement, demande contractualisable). Tester plusieurs tailles seulement en interne; BP Découverte présente une seule référence.

## Tests effectués
- ZIP source ouvert et entrées copiées sans modification.
- Matrice CSV 8 lignes et page HTML ajoutées.
- Intégrité ZIP de sortie contrôlée.

## Limites
Ce lot est un cadrage sectoriel, pas huit BP Découverte. Aucune exécution nouvelle de v107 ni vérification fournisseur externe.
