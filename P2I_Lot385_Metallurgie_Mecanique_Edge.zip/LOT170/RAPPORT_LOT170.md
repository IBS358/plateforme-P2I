# P2I — Lot 170 — Simulations multileviers v107

## Périmètre
Quatre anciennes configurations de la filière Assemblage & Montage, reprises des données Lot 152 dans la copie Lot 169. Aucune modification des BP de référence ni de GitHub main.

## Méthode
Pour chaque UP : 240 combinaisons (volume A1 x1, x1,25, x1,5, x2 plafonné à la capacité programmée ; prix A1 x1, x1,1, x1,2, x1,3 ; coût matière unitaire A1 x1, x0,9, x0,8, x0,7, x0,6 ; charges fixes A1 x1, x0,9, x0,8 lorsque le champ existe). A2/A3 historiques. Passage = marge nette A1 >= 6 %, trésorerie mensuelle minimale >= 0, bilans équilibrés.

## Résultats
- Smartphones : 45 / 240 combinaisons franchissent les seuils. Exemple : 1 350 ventes A1 à 188,50 USD, matières 98 USD/unité, marge nette A1 7,22 %, trésorerie minimale 4 710,29 USD. Hypothèses **non validées** commercialement.
- Tablettes SKD : 0 / 240.
- Remorques 750 kg : 0 / 240.
- Rayonnages légers : 0 / 240.

## Limites importantes
- Les variations sont des **hypothèses de sensibilité**, et non des prix catalogues, des devis, des contrats ou des prévisions commerciales.
- La variation des charges fixes n'a d'effet que si le champ de charges correspondant est présent dans l'entrée historique.
- Les coûts variables historiques peuvent ne pas correspondre à une nouvelle configuration de produit.
- Les scénarios ne constituent pas quatre BP nouveaux validés ; aucune nouvelle nomenclature n'est créée.
- Pas de test manuel dans Microsoft Edge.

## Décision
Le scénario smartphones est une piste à confronter aux prix et débouchés réels. Ne pas publier sa marge comme rentabilité acquise. Pour les trois autres UP, ne pas poursuivre l'ancienne configuration : reconstruire une nomenclature et un modèle commercial documentés.
