# Lot 207 — Remplacement de l'UP Remorques agricoles

**État :** remplacement intégré au catalogue actif, BP descriptif de 17 rubriques présent, nouvelle UP **non validée financièrement**. Les sept autres BP et leurs résultats historiques sont inchangés. Le dossier et les sorties financières de la remorque sont conservés dans les archives précédentes.

## Décision

L'UP active `remorques_agricoles` est remplacée par **Assemblage d'ensembles de pompage et d'irrigation de surface** (`irrigation_kits_surface`). La configuration documentaire de référence à instruire est un ensemble goutte-à-goutte de 0,5 ha avec motopompe diesel 3 pouces, filtration et réseau. Elle exclut le forage, le pompage solaire et les grands travaux hydrauliques. L'identifiant historique de remorque redirige vers cette nouvelle UP; son BP historique demeure dans les lots d'archives, avec ses calculs.

La piste irrigation est la plus défendable des trois candidates étudiées parce qu’elle réunit un besoin agricole national mesuré, des prix de composants locaux accessibles et des tarifs publiés de kits installés. Le recensement officiel 2024 rapporte seulement 3 % des parcelles équipées; c’est un déficit d’équipement, pas une mesure de demande solvable ([recensement agricole](https://www.agriculture.gouv.ci/uploads/publications/177556586029.pdf)). Le Ministère annonce aussi environ 100 centres de services agricoles et des investissements de maîtrise de l’eau ([feuille de route](https://web.agriculture.gouv.ci/index.php/actualite/128)).

## Comparaison des candidates

La note [CHOIX_NOUVELLE_UP.md](CHOIX_NOUVELLE_UP.md) consigne les périmètres, critères, bases de prix, sources et limites de chaque piste.

| Candidate | Éléments documentés | Réserves décisives | Décision |
|---|---|---|---|
| Groupes électrogènes professionnels | Groupe diesel insonorisé 10 kVA affiché 1 500–2 000 USD FOB; distributeurs ivoiriens visibles et exemples de prix locaux sur d'autres puissances. | FOB observé pour un groupe complet, pas un kit de montage; fortes offres locales et aucun coût comparable pour moteurs/alternateurs séparés, banc de charge et volumes. | Non retenue. |
| Pompage et irrigation de surface | Offre locale FECI affichée à 750 000 FCFA/0,5 ha, logistique à part, tarif local de motopompes 3 pouces, catalogue local de 105 références et prix FOB d’une pompe 3 pouces ([FECI](https://forage-express-ci.lovable.app/blog-sur-les-forages-en-cote-d-ivoire/prix-kit-irrigation-cote-ivoire), [CI Irrigation](https://www.ci-irrigation.com/boutique), [Hebei Sunrising](https://sunrisingmachinery.en.made-in-china.com/product-group/tocTUmpHIDWi/Diesel-Engine-Pump-1.html)). | Forte concurrence; niveaux de prix à périmètres variables. Recouvrement de frontière avec Forage & équipements eau et Kits solaires; limité ici à l’irrigation de surface, hors forage et solaire. BOM et ventes annuelles non établies. | Retenue comme meilleur candidat à instruire, statut non validé. |
| Manutention d’atelier | Transpalette manuel 2,5 t affiché autour de 96–106 USD FOB, avec MOQ; distributeur local COMATEC présente des équipements d’entrepôt ([listing FOB](https://yiyinggroup.en.made-in-china.com/product-group/EextwzJPTlpu/Hand-Pallet-Truck-1.html), [COMATEC CI](https://www.comatec.ci/fr/produits/)). | Prix de l’équipement complet, pas de kit CKD; valeur locale de montage faible sans preuve de sous-ensembles. Proximité avec Stockage & manutention et Quincaillerie industrielle. | Non retenue. |

## Pourquoi aucun résultat v107 n'est publié

Le moteur commun v107 n’a pas été exécuté pour cette nouvelle configuration: les données nécessaires manquent pour établir des entrées de ventes et de coûts complètes sans les inventer. Le tarif FECI comprend conception, matériel et mise en service; il n’est pas repris comme prix net P2I ni comme preuve de vente. HYS Consulting publie un autre repère d’irrigation, de périmètre à confirmer. L’offre FOB de motopompe affiche un MOQ de 100 pièces ([FECI](https://forage-express-ci.lovable.app/blog-sur-les-forages-en-cote-d-ivoire/prix-kit-irrigation-cote-ivoire), [HYS Consulting](https://hystech.ci/expertise/guides-dachat/prix-dune-irrigation), [Hebei Sunrising](https://sunrisingmachinery.en.made-in-china.com/product-group/tocTUmpHIDWi/Diesel-Engine-Pump-1.html)).

Les blocs financiers 9 à 13 du nouveau BP sont donc visibles mais portent **non calculable**, sans ventes, prix P2I, CAPEX, BFR, bilan, marges ou trésorerie fabriqués. La règle de référence 40 % d'apport et 60 % de dette est mentionnée comme règle, sans montant tant que l'investissement ne peut être consolidé.

## Données empêchant encore un calcul financier honnête

1. Plan et nomenclature quantitative normalisés du kit 0,5 ha, dimensionnés pour culture, débit de la source, pente et pertes de charge.
2. Appariement définitif du modèle de pompe, de sa courbe débit/hauteur, des raccords et du contenu exact de l'offre FOB.
3. Coûts complets rendus Abidjan par composant: fret, assurance, taxes, transit et livraison, sans mélanger prix FOB, prix local de détail et prix de système installé.
4. Coût/modèle/capacité du banc de pression/débit et des moyens de test; temps de gamme, installation, emballage, garantie et SAV.
5. Prix net de vente P2I et ventes annuelles étayés par commandes, historique distributeur ou enquête de marché traçable.
6. CAPEX consolidé, effectifs, charges fixes, conditions d'achat et de paiement clients, bilan d'ouverture et échéancier de dette pour alimenter les états v107.

## Préservation et fichiers intégrés

- Les sept pages BP hors remorques et le fichier `LOT193/SCENARIOS_FINANCIERS_V107.json` ont été comparés octet par octet avec l'archive source : aucun changement.
- Le BP remorques historique, son dossier et les résultats `remorque_3t` demeurent dans les lots historiques.
- Le catalogue actif conserve 96 identifiants uniques; l'identifiant de remplacement apparaît dans l'UP Assemblage & Montage et l'ancien identifiant de remorque n'est plus actif.
- `LOT192/INDEX_8_BP_ASSEMBLAGE.html` présente les huit BP ensemble et ouvre le nouveau BP en 17 rubriques.
- Aucun fichier n'a été poussé vers GitHub; `main` n'a pas été modifiée.

## Fichiers du lot

- [BP de remplacement — 17 rubriques](BP_IRRIGATION_KITS_SURFACE_17_RUBRIQUES.html)
- [Comparaison des trois candidates et sources](CHOIX_NOUVELLE_UP.md)
- [Tests exécutés](RAPPORT_TESTS_LOT207.md)
- [Test reproductible du catalogue et des liens](test_lot207.cjs)
