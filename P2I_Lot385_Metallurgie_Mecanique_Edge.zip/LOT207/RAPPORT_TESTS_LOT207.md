# Lot 207 — Rapport synthétique des contrôles

## Contrôles exécutés

- Catalogue actif : 96 identifiants uniques; `irrigation_kits_surface` est actif et `remorques_agricoles` ne l'est plus.
- Index de la filière : 8 BP présents; ligne 7 dirigée vers la nouvelle fiche.
- Nouvelle fiche : 17 rubriques numérotées dans l'ordre; rubriques financières marquées non calculables; liens retour vers index et accueil contrôlés.
- Fichiers locaux : les destinations HTML et SVG référencées dans l'index et la nouvelle fiche existent; illustration SVG analysée comme XML valide.
- Préservation : les sept BP historiques de la filière et le fichier source des scénarios v107 sont inchangés par rapport à l'archive Lot 206; le dossier historique Remorques reste présent.
- Moteur : aucun résultat v107 n'a été généré pour la nouvelle UP, puisque prix de vente, volumes et nomenclature locale complète ne sont pas établis. Aucun résultat financier fictif n'est affiché.
- ZIP : contrôle d’intégrité effectué après empaquetage; index, fiche, rapports et illustration du Lot 207 présents.

## Réserves

Le navigateur disponible dans l'environnement n'est pas Microsoft Edge. Les liens locaux, ressources et scripts ont été contrôlés statiquement et par exécution isolée du registre; l'ouverture utilisateur visée reste un HTML/SVG autonome compatible Edge.

Voir [rapport de décision](RAPPORT_LOT207.md) et [choix comparatif](CHOIX_NOUVELLE_UP.md).
