const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert/strict');

const root = path.resolve(__dirname, '..');
const indexFile = path.join(root, 'LOT192/INDEX_8_BP_ASSEMBLAGE.html');
const bpFile = path.join(__dirname, 'BP_IRRIGATION_KITS_SURFACE_17_RUBRIQUES.html');
const index = fs.readFileSync(indexFile, 'utf8');
const bp = fs.readFileSync(bpFile, 'utf8');
const rows = [...index.matchAll(/<tr><td>([1-8])<\/td>/g)];
assert.equal(rows.length, 8, 'index commun : huit BP');
assert.match(index, /irrigation_kits_surface/);
assert.match(index, /LOT207\/BP_IRRIGATION_KITS_SURFACE_17_RUBRIQUES\.html/);
assert.match(index, /Non calculable/);

const anchors = [...bp.matchAll(/<section class="section" id="p2i-r(\d+)"/g)].map(m => Number(m[1]));
assert.deepEqual(anchors, Array.from({ length: 17 }, (_, i) => i + 1), 'BP remplaçant : 17 rubriques ordonnées');
assert.match(bp, /Compte de résultat prévisionnel v107 — non calculable/);
assert.match(bp, /Aucun compte de résultat v107 n'est produit/);
assert.match(bp, /Trésorerie mensuelle v107 — non calculable/);
assert.match(bp, /irrigation_kits_surface/);
assert.match(bp, /assets\/lot207/);
const home = fs.readFileSync(path.join(root, 'accueil-local.html'), 'utf8');
assert.match(home, /LOT192\/INDEX_8_BP_ASSEMBLAGE\.html/);

for (const [file, html] of [[indexFile, index], [bpFile, bp], [path.join(root, 'accueil-local.html'), home]]) {
  for (const match of html.matchAll(/(?:href|src)="([^"]+)"/g)) {
    const target = match[1];
    if (/^(?:https?:|mailto:|data:|javascript:|#)/i.test(target)) continue;
    const local = decodeURIComponent(target.split('#')[0].split('?')[0]);
    assert.ok(fs.existsSync(path.resolve(path.dirname(file), local)), `${path.relative(root, file)} lien local absent: ${target}`);
  }
}

const visual = path.join(root, 'assets/lot207/kit-irrigation-0_5ha.svg');
assert.ok(fs.statSync(visual).size > 1000, 'visuel SVG présent');
assert.ok(fs.existsSync(path.join(root, 'LOT178/BP_REMORQUES_AGRICOLES_17_RUBRIQUES_HISTORIQUE.html')),
  'dossier historique remorques conservé');
const oldResults = JSON.parse(fs.readFileSync(path.join(root, 'LOT193/SCENARIOS_FINANCIERS_V107.json'), 'utf8'));
assert.ok(oldResults.scenarios.some(x => x.key === 'remorque_3t'), 'résultat v107 historique remorque conservé');

// Exécute la migration active et le contrôle de cohérence 96 UP dans un contexte isolé.
const context = {
  console, URLSearchParams,
  location: { search: '', href: 'file:///P2I/index.html' },
  history: { replaceState() {} },
  document: { readyState: 'complete', addEventListener() {}, body: {}, getElementById() { return null; } },
  addEventListener() {}, setTimeout() {}
};
context.window = context;
vm.createContext(context);
for (const relative of [
  'runtime/script-0.js', 'runtime/script-16.js', 'runtime/lot147-data.js', 'runtime/lot149-data.js',
  'runtime/lot150-assemblage-data.js', 'runtime/lot207-remplacement-assemblage.js', 'runtime/catalogue-up-actif.js'
]) vm.runInContext(fs.readFileSync(path.join(root, relative), 'utf8'), context, { filename: relative });
const active = context.P2I_CATALOGUE_UP_ACTIF.filieres.flatMap(f => f.up_ids);
assert.equal(active.length, 96);
assert.equal(new Set(active).size, 96);
assert.ok(active.includes('irrigation_kits_surface'));
assert.ok(!active.includes('remorques_agricoles'));
assert.ok(context.P2I_BP_DONNEES.unites.remorques_agricoles, 'identifiant historique toujours archivé dans les données');
assert.ok(context.P2I_BP_DONNEES.unites.irrigation_kits_surface);
assert.ok(vm.runInContext('P2I_UP_DATA.irrigation_kits_surface', context));

console.log(JSON.stringify({
  index_bp_count: rows.length,
  replacement_sections: anchors.length,
  local_links_checked: true,
  new_active_id: 'irrigation_kits_surface',
  active_catalogue_count: active.length,
  active_catalogue_unique: true,
  trailer_historical_data_preserved: true,
  trailer_v107_history_preserved: true,
  new_financial_status: 'non_calculable; no fabricated v107 result'
}, null, 2));
