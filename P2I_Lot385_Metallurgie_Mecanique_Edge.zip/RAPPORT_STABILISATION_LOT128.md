# Lot 128 — stabilisation du raccordement visuels/postes

Date : 14 novembre 2026.
Base : plateforme complète Lot 127, archive historique conservée sans modification.

## Correction

Le rendu commun utilisait des classes CSS atlas globales dont certaines pointaient vers une planche de biscuiterie. Les mêmes indices d’image pouvaient donc afficher une vignette d’une autre UP. Le Lot 128 remplace ce chemin par des ressources et grilles limitées à l’UP courante, avec une résolution des postes par fonction nommée. Les cartes de rubrique 17 n’ajoutent plus un second flux lorsqu’une configuration de référence fournit déjà ses fonctions. Une fonction non associée ne reprend aucune image d’une autre UP.

L’UP Fabrication de chaussures reçoit dix vignettes distinctes, découpées d’un atlas dédié à la chaussure. Ce sont des illustrations générées par IA, non des photographies de machines fournisseurs.

Les quatorze atlas de procédé précédemment ajoutés ont été contrôlés visuellement au niveau de l’activité. Les images restent illustratives et ne certifient ni une machine fournisseur, ni une capacité, ni la conformité du procédé.

## Contrôles réalisés

- `node --check` sur `runtime/script-17.js` et `runtime/script-18.js` : réussi.
- Rendu isolé des 49 UP couvertes par la matrice visuelle : 49 sans erreur JavaScript, 49 avec 17 rubriques, 49 avec fond d’atelier; 254 cartes de poste/configuration rendues; aucun emplacement d’image manquant dans ces cartes après correction.
- Contrôle ciblé des fonctions de chaussures : 10 fonctions et 10 fichiers WebP propres à la chaussure présents.
- Contrôle des ressources référencées par les registres de visuels : aucun chemin local absent.
- Régression financière : SHA-256 de `runtime/script-16.js` identique à celui du Lot 127 (`4babd284c9c74e807e759f5b49bf8c568ba332bca89d9d4ca4cc94a47fc0caac`). Aucune hypothèse financière ni configuration de machine modifiée.
- Intégrité ZIP : vérifiée après création.

## Périmètre et limites

Ce contrôle s’appuie sur le rendu HTML/JavaScript isolé et les ressources locales; l’ouverture dans le Microsoft Edge de l’utilisateur n’a pas été exécutée depuis cet environnement. Le contrôle sémantique des images reste une validation d’illustrations d’activité, pas une preuve documentaire des postes exacts. Les performances, prix et conformité restent ceux des dossiers antérieurs; ils ne sont pas recalculés dans ce lot.

## Fichiers modifiés

- `runtime/script-17.js` : registres d’images explicitement rattachés à l’UP/fonction et atlas nommés.
- `runtime/script-18.js` : rendu des fonctions, sélection d’images avec contexte UP, suppression du repli inter-UP et des doublons de flux en rubrique 17.
- `runtime/style-2.css` : disposition des cartes fonction/image.
- `runtime/build-manifest.json` : version 128 et empreintes des nouveaux visuels.
- `assets/media/postes/chaussures/` : neuf découpes WebP couvrant les dix postes (contrôle et emballage réutilisent la même vignette finale).
- `MATRICE_VISUELS_49_LOT127.csv` : résultats de rendu Lot 128 ajoutés en colonnes sans effacer l’historique.
- `docs/RAPPORT_STABILISATION_LOT128.md` : présent rapport.

La configuration financière et le moteur commun de calcul n’ont pas été modifiés. Le Lot 127 original reste disponible comme archive historique séparée.
