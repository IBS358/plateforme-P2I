# P2I — Lot 227 — Test de croissance A1, mobilier scolaire et professionnel

**Statut : test v107 reproductible, NON VALIDÉ comme BP Découverte.** Point de départ : Lot 226 (443 fichiers). Les sept autres BP et le catalogue des 96 UP sont conservés. Aucun changement de `main`.

## Ce qui a été exécuté
Six exécutions du moteur commun `P2I_BP_SIMULATION_COMMUNE.calculer` (v107) : trois trajectoires de volumes, chacune avec dirigeant supposé déjà inclus dans le personnel ou rémunération supplémentaire de 300 000 FCFA/mois. Les coûts variables restent **hors personnel**. Le taux de conversion historique est 595 FCFA/USD.

| Scénario | Tables-bancs A1 | Bureaux A1 | Armoires A1 | CA A1 FCFA | RN A1 sans dirigeant supplémentaire USD | RN A1 avec dirigeant supplémentaire USD |
|---|---:|---:|---:|---:|---:|---:|
| Base | 1 200 | 160 | 80 | 70 000 000 | -15 132 | -21 182 |
| Croissance | 1 600 | 220 | 110 | 94 600 000 | -4 314 | -10 364 |
| Forte croissance | 2 000 | 280 | 140 | 119 200 000 | +4 879 | +341 |

Pour le scénario **forte croissance avec dirigeant supplémentaire**, le moteur retourne une marge nette A1 d'environ **0,2 %**, A2 **6,8 %** et A3 **7,5 %**. **L'objectif de 10 % n'est pas atteint**. Un RN positif marginal ne constitue pas une validation commerciale ou industrielle.

## Conditions du scénario (hypothèses, pas faits)
- Prix unitaires testés : table-banc 33 000, bureau 110 000, armoire 160 000 FCFA. Les deux derniers ne sont pas des prix fabricants vérifiés.
- Coûts variables unitaires hors personnel : 25 200, 71 000, 108 000 FCFA. Les nomenclatures bureau et armoire restent incomplètes. Le gain sur les barres d'acier des tables-bancs est **déjà compris** dans le coût de 25 200 FCFA.
- Personnel historique 24 000 USD/an ; frais fixes 15 000 USD/an ; CAPEX 45 000 USD ; machines 30 000 USD : montants de simulation non validés. La rémunération du dirigeant de 300 000 FCFA/mois est un **test supplémentaire**, et non un salaire constaté.
- A1 : tester une répartition de 30 % des volumes sur M1–M5 et 70 % sur M6–M12. Cette répartition n'est **pas** imposée dans les calculs mensuels internes de v107 ; elle nécessite un moteur de trésorerie de commandes et de crédit séparé.
- A2 et A3 : volumes de forte croissance 3 600/520/260 et 4 800/700/350. Les ventes, le plan de charge, les commandes, la capacité et les fournisseurs restent à confirmer.

## Contrôles et réserves
- Les sorties v107 comprennent 12 mois de trésorerie, 36 mois de BFR et les bilans équilibrés selon les contrôles moteur.
- **La trésorerie positive calculée par v107 ne démontre pas le financement des ventes à crédit.** Les scénarios des lots 219–221 montrent des besoins opérationnels importants ; il faut une trésorerie mensuelle réaliste avec 60 % de crédit à 60 jours, acomptes, stocks et achats avant livraison.
- Aucune subvention publique présumée ; aucune commande garantie ; aucun nouveau prix fournisseur inventé.
- Les visuels de la huitième UP et son BP à 17 rubriques ne sont pas encore intégrés. Ne pas remplacer l'irrigation dans le catalogue sur ce seul résultat.

## Décision
**Le blocage du RN A1 est surmontable mathématiquement par le volume, sans baisse arbitraire des coûts.** Cependant, même le scénario le plus élevé est trop fragile en A1 avec dirigeant distinct, et la validation industrielle/commerciale manque. La prochaine livraison doit être un BP complet uniquement après vérification des capacités, prix, investissements et financement du crédit.
