# Lot 274 — Contrôle de cohérence matière / produits / chiffres d'affaires

Le présent contrôle est effectué sur les **données réelles des fichiers des lots 258 et 263**, sans substituer de nouveaux prix ou rendements. Il conserve toutes les archives précédentes et ne modifie aucun BP historique.

## Règles vérifiées
- Tonnes de produits valorisés = somme des quantités de chaque produit du lot 263.
- Écart matière = somme des produits du lot 263 − volume vendable théorique du lot 258. Un écart supérieur à 1 % ou 2 tonnes est signalé.
- Somme des CA par produit comparée au CA global ; contrôle de l'égalité CA − charges variables − charges fixes = EBITDA.
- Les marges financières des lots 270–273 ne sont **pas** recalculées ici : ce contrôle ne les valide pas.

## Anomalies structurantes
- Verre : le lot 263 ne chiffre que 13 660 tonnes de calcin (6 209 + 7 451), contre 15 080 tonnes vendables dans le lot 258. La différence doit être classée en pertes, rebuts, autres fractions ou vente documentée, et non implicitement commercialisée.
- Verre : la baisse de CAPEX de 1,5 Md à 800 M FCFA n'est étayée par aucun devis de ligne complète ; la marge positive de 6,03 % est donc conditionnelle.
- Les scénarios multiflux ne peuvent être validés sans identification des flux entrants, rendements par fraction, prix de vente vérifiables, coûts spécifiques, stocks et contrats.
- Aucun bilan comptable équilibré ni exécution du moteur v107 n'est démontré par ce rapport.

## Décision de production
Conserver les huit UP en développement, sans marquer leurs marges comme acquises. Les prochaines modifications utiles sont dans les huit BP opérationnels (équipements complets, données sources, images, BFR, bilan), pas dans de nouvelles séries de scénarios abstraits.
