# P2I — Lot 220 : arbitrage économique et crédit client, sans rentabilité fictive

**Statut : qualification interne non validée.** Reprise de l'archive intégrale du lot 219 ; aucun changement des 7 BP existants, des 96 UP ou du moteur v107. Les prix des bureaux/armoires, leurs coûts, le CAPEX et les charges fixes demeurent des hypothèses non sourcées.

## 1. Seuil économique à mix commercial constant

Données du lot 219 : CA A1 **70,000,000 FCFA**, contribution **19,760,000 FCFA** (28.23% du CA), charges fixes/personnel testées **23,205,000 FCFA**. Le seuil mathématique de couverture des seules charges fixes est **1.174 fois** les volumes A1, soit environ **1410 tables-bancs, 188 bureaux et 94 armoires**. Il s'agit d'une approximation : les arrondis modifient le seuil.

Pour dégager **10 % du CA avant amortissements, intérêts et impôt**, le facteur théorique est **1.819 fois** les volumes. **Ce n'est pas une marge nette de 10 %.** Il faut financer les machines, le BFR, les amortissements, l'emprunt, les stocks et la fiscalité. Une hausse des volumes implique potentiellement davantage d'équipements et de personnel : les charges fixes ne resteront pas constantes à l'infini.

Les volumes 1× à 3× sont calculés dans `SEUILS_VOLUME_A1_EXPLORATOIRES.csv`. **Ils ne sont ni des commandes ni des capacités démontrées.** Ne pas publier ces hypothèses comme BP.

## 2. Acomptes : baisse du besoin de trésorerie, pas amélioration du résultat

Modèle conservateur simplifié du lot 219 : 60 % des ventes à crédit, 60 jours de règlement, 40 % comptant, matières payées immédiatement, charges fixes lissées. Nouvelle sensibilité : acompte de 0/20/30/40 % **sur la seule part vendue à crédit** ; le solde est encaissé à 60 jours. Hypothèse simplificatrice : commande et livraison le même mois ; dans la réalité, il faudra modéliser séparément la commande, l'acompte, la fabrication, la livraison et le solde. Les acomptes sont des **encaissements anticipés**, non du CA supplémentaire.

| Acompte sur commandes à crédit | Créances A1 fin (FCFA) | Besoin maximal partiel (FCFA) |
|---|---:|---:|
| 0% | 10,780,800 | 14,225,800 |
| 20% | 8,624,640 | 12,084,530 |
| 30% | 7,546,560 | 11,099,570 |
| 40% | 6,468,480 | 10,156,820 |

Ces chiffres **ne sont pas le BFR complet** : exclus stocks, délais fournisseurs, investissements, TVA, intérêts, remboursements, impôts, acomptes reçus avant livraison et impayés. Une avance client doit être comptabilisée comme passif jusqu'à la livraison.

## 3. Capacité industrielle : une contrainte encore non levée

`SENSIBILITE_CHARGE_ATELIER.csv` croise des temps de travail hypothétiques par produit avec les volumes A1/A2/A3. Les heures et ETP sont **des bornes de charge théorique**, pas un dimensionnement machine : il manque chronométrages, équilibrage des postes, disponibilité réelle, pertes, maintenance, délais d'approvisionnement, espace et séchage peinture. L'atelier ne peut être validé avant ce plan de charge.

## 4. Décision industrielle

- **Conserver le mobilier scolaire et professionnel comme candidat prioritaire** : il constitue une fabrication locale tangible et une gamme utile aux écoles, universités, entreprises.
- **Ne pas activer dans le catalogue public** sans nomenclatures et devis/prix publics suffisamment documentés, capacité vérifiée et calcul v107 complet.
- **Différenciation** : tables-bancs avec logement mécanique pour tablette, bureaux professionnels avec logement tablette ; lampe LED amovible achetée et proposée en option, non chiffrée et non incluse dans le CA. Vérifier ergonomie, stabilité, entretien et sécurité.
- **Visuels** : maquettes de concept possibles, mais ne pas représenter comme validée une ligne industrielle non configurée ; ne pas recréer le logo P2I original.

## 5. Tests réalisés

- Conservation de la quantité annuelle par répartition mensuelle pour chaque gamme.
- Réconciliation annuelle CA = encaissements + créances clients fin A1, pour 8 scénarios.
- Le montant d'acompte ne modifie pas le CA ni les coûts variables du modèle.
- Fichiers historiques et catalogue inchangés ; aucun push GitHub.
