# P2I lot 287 — Dimensionnement industriel
8 BP Découverte enrichis par des tableaux de dimensionnement industriel et achats, avec 31 fonctions critiques (valeurs nominales de travail).
Les 8 débits sont des objectifs de conception, non des capacités garanties fabricant. Base : 16 heures/jour × 22 jours/mois × 12 mois × 70 % d'utilisation. Rendements matière proposés pour illustration uniquement, sans qualification locale.
Attention : les rendements et volumes ne remplacent pas ceux du moteur financier LOT270 ; les incohérences éventuelles nécessitent un recalcul financier complet v107. Les prix et références catalogue EXW/FOB sont non vérifiés. Les équipements annexes, énergie, transport, conformité et fournisseurs sont à qualifier.
Les 9 UP validées hors filière ne sont pas modifiées ; les fichiers précédents sont conservés dans l'archive cumulative.
