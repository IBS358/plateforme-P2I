# Lot 178 — trois BP de contrôle historiques en 17 rubriques

Point de départ : Lot 177.

Trois documents de 17 rubriques ont été générés pour Tablettes SKD, Remorques 750 kg et Rayonnages légers, avec les nomenclatures documentées du Lot 176 et les résultats **réellement recalculés** avec le moteur commun v107.

**Attention :** ces dossiers ne sont PAS les nouveaux BP Découverte de référence. Ils conservent les anciennes hypothèses déficitaires pour éviter de les confondre avec les futures configurations. Aucune marge artificielle n’a été recherchée.

Tests : 3 années de CR, 12 mois de trésorerie, 3 bilans équilibrés par UP ; présence de 17 rubriques et des postes documentés ; ZIP testé. Test manuel Microsoft Edge non réalisé.

À compléter : nouvelle nomenclature produit/machines, prix catalogue EXW/FOB, prix commerciaux CI, compatibilités et capacités, calcul de nouvelles hypothèses, visuels et intégration au BP public. GitHub main non touchée.
