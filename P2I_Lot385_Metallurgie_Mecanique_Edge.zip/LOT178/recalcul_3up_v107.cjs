'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.resolve(__dirname,'..'),rt=path.join(root,'runtime');
const c={console,Math,Number,String,Array,Object,Map,Set,JSON,Error,TypeError,Date,Intl,URL,URLSearchParams};c.window=c;c.location={search:'',href:'file:///P2I_Edge/index.html'};c.history={replaceState(){}};vm.createContext(c);
const files=['script-0.js','script-1.js','script-2.js','script-3.js','script-4.js','script-5.js','script-6.js','script-7.js','script-8.js','script-9.js','script-10.js','script-11.js','script-12.js','script-13.js','script-14.js','script-15.js','script-16.js','lot147-data.js','lot149-data.js','lot150-assemblage-data.js','lot152-assemblage-finances.js','lot153-assemblage-finances.js','catalogue-up-actif.js','script-17.js','lot152-assemblage-visuels.js','lot153-assemblage-visuels.js','lot154-remorques.js','lot154-remorque-finances.js','lot155-assemblage-finances.js'];
for(const f of files)vm.runInContext(fs.readFileSync(path.join(rt,f),'utf8'),c,{filename:f});
const clone=x=>JSON.parse(JSON.stringify(x));
const ids=['tablettes','remorques_agricoles','stockage_manutention'];
const out={};
for(const id of ids){
 const base=clone(c.P2I_LOT152_FINANCES.units[id].input);
 const r=c.P2I_BP_SIMULATION_COMMUNE.calculer(base);
 const checks={annees:r.annuel.length,mois_tresorerie:r.tresorerie.length,bilans:r.bilans.length,bilans_equilibres:r.controles.bilans_equilibres,financement:r.controles.financement,marges:r.annuel.map(z=>z.chiffre_affaires?z.resultat_net/z.chiffre_affaires:null),resultats:r.annuel.map(z=>z.resultat_net),cash_min:Math.min(...r.tresorerie.map(z=>z.solde_final))};
 if(checks.annees!==3||checks.mois_tresorerie!==12||checks.bilans!==3||checks.bilans_equilibres!==true)throw Error('Structure v107: '+id);
 out[id]={statut:'historique_rejete_non_valide',input:base,checks,output:r};
}
fs.writeFileSync(path.join(__dirname,'RESULTATS_HISTORIQUES_3UP_V107.json'),JSON.stringify(out,null,2));
console.log(JSON.stringify(Object.fromEntries(Object.entries(out).map(([k,v])=>[k,v.checks]))));
