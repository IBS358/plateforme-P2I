# Lot 191 — Accès effectif aux trois BP Assemblage & Montage

Source immuable : ZIP complet Lot 190.

Modifications : accueil-local.html (liens visibles), trois BP Lot190 (illustrations produit déjà présentes dans assets/lot153 et lien retour).

Les résultats v107 historiques sont inchangés. Aucun prix ou chiffre financier nouveau.

Vérifications automatisées : intégrité ZIP, existence des liens, des illustrations, 17 rubriques et absence de modification des autres entrées. Test graphique manuel dans Microsoft Edge non effectué.

Statut : dossiers conditionnels, nomenclatures industrielles et hypothèses commerciales non validées. Remorque 3 t reste non calculable.

Ouverture : extraire le ZIP, ouvrir P2I_Edge/accueil-local.html dans Edge puis choisir l'un des trois BP.
