# P2I — Lot 275 : réconciliation physique des huit UP

Ce lot ne modifie **aucun** fichier du lot 274 ; il ajoute huit fiches de calcul et un référentiel recalculable.

## Correction de méthode
La comparaison « rendement mono-produit initial » / « somme des flux multi-produits » du lot 274 n'est **pas** un bilan matière. Les vrais contrôles comparent les entrées aux **sommes des sorties, y compris fractions non vendues**, et calculent le solde (pertes, refus ou stocks à documenter). Un solde positif n'est pas une preuve de pertes physiques : humidité, évaporation, maturation, stocks et refus nécessitent des preuves.

Le lot 275 calcule les masses par `chiffre d'affaires / prix unitaire` lorsque la recette et le prix existent, pour éviter les écarts dus à l'arrondi des tonnes affichées dans le lot 263. Les fractions à prix nul conservent leur tonnage déclaré. La catégorie « fraction sans CA » n'est pas assimilée à un produit commercialisable.

## Calcul économique vérifiable
EBITDA = chiffre d'affaires multi-produits − charges variables déclarées − charges fixes déclarées. Résultat **avant impôt simplifié** = EBITDA − CAPEX/10 − (CAPEX × 60 % × 10 %). Le verre reprend le CAPEX conditionnel de 800 M FCFA du lot 270, non un prix catalogue. Les autres CAPEX proviennent des scénarios précédents.

**Ce calcul ne produit PAS un résultat net v107.** Impôts, BFR, coûts de traitement des résidus, amortissements réels, intérêts dégressifs, maintenance détaillée, encaissements, dette et bilans équilibrés restent à établir. Aucun chiffre d'affaires nouveau n'a été ajouté.

## Suites nécessaires
1. Justifier les sorties par pesées et fiches techniques ; identifier les fractions dangereuses et coûts de traitement.
2. Vérifier machines, puissance, consommations, rendement et prix EXW/FOB, plus coûts rendus site.
3. Valider contrats de collecte et débouchés en Côte d'Ivoire.
4. Exécuter les vrais états financiers v107 (CR/bilan 3 ans, trésorerie 12 mois, BFR, 40/60).
5. Intégrer les illustrations P2I et les 17 rubriques dans les pages BP officielles.
