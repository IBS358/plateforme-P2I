# P2I — Lot 237 : seuil de viabilité conditionnel des huit UP

**Source :** archive intégrale du Lot 236. Aucun fichier existant modifié.

## Livraison
- Outil autonome Edge : `OUVRIR_SEUIL_VIABILITE_8UP_EDGE.html`.
- Reprise des 8 UP et des 24 débits exploratoires du Lot 236.
- Reprise des 33 postes historiques du Lot 234, sans les qualifier de machines vérifiées.
- Simulation conditionnelle du tonnage mensuel, bilan matière, contribution, solde d’exploitation simplifié et seuil de traitement mensuel.
- Les neuf variables économiques sont vides par défaut : aucune hypothèse inventée.

## Calculs
Débit nominal mensuel = débit nominal × heures/jour (pour t/h) × jours/mois. Capacité disponible = débit nominal mensuel × disponibilité. Traitement = min(capacité disponible, gisement). Vente = traitement × rendement × part vendue. Contribution unitaire par tonne entrante = rendement × part vendue × prix de vente par tonne sortante − coût variable par tonne entrante. Seuil en tonnes entrantes = charges fixes / contribution unitaire, seulement si contribution unitaire strictement positive. Solde d'exploitation simplifié = ventes − charges variables − charges fixes.

## Limites importantes
Ce solde **n'est pas un résultat net**. Il n'intègre ni amortissements, intérêts, impôts, BFR, trésorerie ni coût d'investissement. Les charges fixes doivent inclure personnel et direction sans double comptage. Les débits exploratoires ne sont pas des performances fournisseurs vérifiées. Les huit BP Découverte ne sont pas finalisés. Le moteur v107 et le catalogue 96 UP sont conservés à l'identique.

## Suite
Qualifier des références exactes de machines, leurs capacités, prix catalogues EXW/FOB, les gisements collectables et les débouchés ivoiriens. Retenir ensuite une seule configuration industrielle par UP et exécuter v107.
