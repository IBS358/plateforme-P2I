# Lot 194 — consolidation de références industrielles existantes

Base exacte : ZIP Lot 193.

- 20 postes de la matrice Lot176 vérifiés et repris sans changer leurs références ni leurs prix.
- 5 postes Smartphones, 6 postes Remorques et 6 postes Stockage ajoutés comme annexes techniques aux BP correspondants.
- 3 postes Tablettes SKD conservés uniquement dans la matrice historique ; aucune transplantation vers la proposition Machines de conditionnement.
- Aucun montant documentaire intégré automatiquement au CAPEX, aux coûts de revient ou aux résultats v107.
- Les 8 dossiers restent consultables, mais tous ne sont pas financièrement validés.
- Les archives existantes, moteur commun, et historique des simulations ne sont pas modifiés.

Tests automatiques : intégrité ZIP, 20 lignes sources, 17 rubriques des 8 BP, liens index, présence des annexes. Test visuel Edge non exécuté.
