# Lot 286 - Sensibilites industrielles et financieres
8 BP repris integralement du lot 285, avec ajout d'un controle de resistance economique.
5 scenarios par UP : reference, prix -10 %, volume -20 %, cout variable +15 %, prix -10 % et cout +15 %.
Donnees sources LOT270 ; rapprochement mensuel selon LOT284. Charges fixes, interets, amortissements et principal constants.
Impot indicatif 25 % du resultat positif ; sans credit d'impot sur perte.
Les reserves de BFR sont supposees financees en sus du CAPEX 40/60 ; aucun financement reel n'est confirme.
Aucune qualification catalogue, aucun devis ni verification du marche ivoirien n'a ete effectue dans ce lot. Pas de moteur v107 execute. Ne pas interpreter les marges comme validees.
