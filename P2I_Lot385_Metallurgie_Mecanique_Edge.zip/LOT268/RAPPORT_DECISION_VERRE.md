# P2I — Lot 268 : décision de taille pour le verre — comparaison 3, 4 et 6 t/h

## Résultat de travail
Ce lot compare 27 scénarios (3 capacités × 3 utilisations × 3 investissements). **Aucun scénario n'est validé** : les CAPEX de 450/650/800 M FCFA ne sont pas des devis; les prix commerciaux, rendements et coûts d'exploitation hérités des lots 264–267 ne sont pas vérifiés en Côte d'Ivoire.

## Pourquoi changer de méthode
Le lot 267 montre que 6 t/h à 70 % implique 17 741 t/an d'entrées et 15 080 t/an de calcin commercialisable. Un broyeur 5–6 t/h n'est pas une chaîne complète. Les statistiques historiques d'exportation ne mesurent pas le gisement disponible. Il faut conditionner le choix de taille à des volumes contractuels et à des offres de vente.

## Formules
16 heures/jour × 22 jours/mois × 12 mois. Rendement 85 %. CA par tonne entrante et marge sur coût variable extrapolés depuis la ligne 17 741 t du lot 267. Charges fixes de 150 M FCFA à 6 t/h extrapolées en puissance 0,65 selon la capacité, **sans validation industrielle**. Amortissement linéaire 10 ans, 60 % dette à 10 %, impôt simplifié 25 % si résultat positif, service annuel de dette en annuité 7 ans. Le DSCR est une approximation EBITDA / annuité. Aucune modélisation complète du BFR, bilan, TVA, stocks, foncier, traitement des refus ou trésorerie réelle.

## Décision de conception
- Conserver le produit principal calcin trié par couleur, avec granulats secondaires uniquement si contrats de vente.
- Ne pas figer la capacité à 6 t/h avant de disposer de contrats d'approvisionnement d'environ 17 700 t/an et de vente d'environ 15 000 t/an pour ce scénario.
- Demander des offres de **lignes complètes** à 3–4 t/h et 5–6 t/h (tri, retrait impuretés, broyage, criblage, dépoussiérage, manutention, énergie, installation), puis comparer le coût total rendu site.
- Envisager la collecte multi-sites et le pré-tri à proximité des gisements ; chiffrer séparément les transports et pertes.
- Vérifier si les produits sortants respectent les spécifications des acheteurs (céramiques, métaux, couleurs, granulométrie, humidité).
- N'intégrer aucun résultat dans le moteur v107 avant justification de la configuration et des prix.

## État du livrable
Les 8 prototypes de BP du lot 261 et les autres fichiers historiques sont conservés **sans modification**. Le lot 268 ajoute uniquement ce comparatif de décision ; ce n'est pas un BP finalisé. Aucune image IA nouvelle n'a été générée.
