const fs=require('fs');
const vm=require('vm');
const path=require('path');
const root=path.resolve(__dirname,'..');
const ctx={console,Math,JSON,Number,Object,Array,Set,Map,Error};ctx.window=ctx;vm.createContext(ctx);
for(const n of [2,3,4,5,11]) vm.runInContext(fs.readFileSync(path.join(root,`runtime/script-${n}.js`),'utf8'),ctx,{filename:`script-${n}.js`});
const params=JSON.parse(fs.readFileSync(path.join(root,'LOT298/HYPOTHESES_8UP.json'),'utf8'));
const historical=JSON.parse(fs.readFileSync(path.join(root,'LOT301/RESULTATS_RECALCULES.json'),'utf8'));
const fx=600;
const results={schema:'p2i.lot316.v107.recalculation.v1',engine:'runtime/script-11.js',base_lot:'315',date:'2026-11-18',currency:'USD',exchange_assumption_xof_per_usd:fx,inputs_qualification:'Reprise des paramètres physiques et économiques historiques des LOT298/301. Les CAPEX restent estimatifs LOT315; les prix catalogues ne valident pas l’ensemble des lignes. Personnel non isolé des frais fixes historiques: aucune charge additionnelle injectée; réserves financières ouvertes.',units:{}};
for(const old of historical){
 const p=params[old.slug];
 const outputKg=old.vendable_t*1000;
 const inputT=old.entrees_t;
 const directPerKg=old.charges_variables/fx/outputKg;
 const materialPerKg=inputT*p.collecte/fx/outputKg;
 const capex=p.capex/fx;
 const s={
  up_id:old.slug,configuration_id:`lot315-${old.slug}-reference`,unite:'kg/h',source:'LOT298/HYPOTHESES_8UP.json + LOT301/donnees historiques; conversion de travail 600 XOF/USD; données non validées marché/fournisseur',
  investissement:capex,machines:null,matieres_kg:materialPerKg,personnel:0,charges_fixes:p.fixes/fx,
  part_apport:.4,part_dette:.6,taux_interet:.10,duree_dette_mois:84,duree_amortissement_ans:10,
  taux_tva:.18,taux_is:.25,coussin_tresorerie:.10,croissance_personnel:0,croissance_charges:0,
  production:[outputKg,outputKg,outputKg],ventes:[outputKg,outputKg,outputKg],
  prix:[old.ca_physique/fx/outputKg,old.ca_physique/fx/outputKg,old.ca_physique/fx/outputKg],
  cout_production_kg:[directPerKg,directPerKg,directPerKg],
  stock_matieres_jours:30,cout_distribution_unite:0,delai_disponibilite_mois:0
 };
 const result=ctx.P2I_BP_SIMULATION_COMMUNE.calculer(s);
 results.units[old.slug]={up:old.up,source_inputs:s,physical:{feed_t_A1:inputT,output_sellable_t_A1:old.vendable_t,yield_pct:inputT?old.vendable_t/inputT*100:null},engine_result:result,
  reconciliation:{historic_CA_usd:old.ca_physique/fx,engine_CA_A1:result.annuel[0].chiffre_affaires,historic_variable_cost_usd:old.charges_variables/fx,engine_CPV_A1:result.annuel[0].cout_produits_vendus,capex_estimate_usd:capex,capex_source:'LOT298/HYPOTHESES_8UP.json; historical P2I estimate, not catalog-confirmed'}};
}
fs.writeFileSync(path.join(root,'LOT316/RESULTATS_V107.json'),JSON.stringify(results,null,2));
const rows=[];
for(const [slug,u] of Object.entries(results.units)){const a=u.engine_result.annuel[0];rows.push([slug,u.up,u.reconciliation.capex_estimate_usd.toFixed(2),a.chiffre_affaires.toFixed(2),a.resultat_net.toFixed(2),(a.resultat_net/a.chiffre_affaires*100).toFixed(2),u.engine_result.reserve_initiale.toFixed(2),Math.min(...u.engine_result.mois.slice(0,12).map(x=>x.tresorerie_libre)).toFixed(2),u.engine_result.bilans.every(x=>Math.abs(x.ecart)<.02)]);}
const csv=['slug;up;capex_estimate_usd;revenue_A1_usd;net_result_A1_usd;net_margin_A1_pct;reserve_required_usd;min_free_cash_months1_12_usd;balances_balanced',...rows.map(r=>r.join(';'))].join('\n')+'\n';
fs.writeFileSync(path.join(root,'LOT316/RESULTATS_V107.csv'),csv);
console.log(csv);
