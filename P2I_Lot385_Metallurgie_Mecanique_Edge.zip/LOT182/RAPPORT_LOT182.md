# P2I — Lot 182 : gamme de fabrication locale de remorque agricole 3 t

## Livrable
Gamme de production à partir de tôles et profilés d’acier (9 postes), distincte de l’assemblage d’un kit complet. Nomenclature des coûts non documentés jointe. Une seule architecture étudiée : 2 essieux / 4 roues. Les essieux et organes de sécurité spécialisés restent achetés, sans que cela transforme l’UP en assemblage de kit.

## Données reprises, non revérifiées
- Acier livré Abidjan : 614,04 USD, estimation de débit et de géométrie non validée (Lot 154).
- Deux essieux Darong : 438,60 à 543,00 USD FOB, sans frais d’importation (Lots 154 et 181).
- Sous-total indicatif : 1 052,64 à 1 157,04 USD, incomplet et sur bases tarifaires différentes.
- Remorque complète Weito : 1 550–1 750 USD FOB (Lot 181), comparateur non directement homogène.

## Décision
Retenir comme *orientation industrielle* la transformation locale de l’acier et la fabrication mécano-soudée du châssis et de la benne. Ne pas valider encore la capacité 3 t, les coûts complets ni la rentabilité. La simulation v107 sera lancée après renseignement des coûts déterminants; aucune valeur manquante n'est assimilée à zéro.

## Contrôle effectué
9 opérations présentes, 13 catégories de coûts/validations à compléter, 5 lignes d’acier correspondant à 614,04 USD, cohérence du sous-total 614,04 + 438,60 = 1 052,64 USD et 614,04 + 543 = 1 157,04 USD. Pas de calcul v107 nouveau, ni essai dans Edge.

## Conservation
Fichiers ajoutés sans modifier les fichiers historiques du Lot 181, les BP existants, le moteur commun ou GitHub main.
