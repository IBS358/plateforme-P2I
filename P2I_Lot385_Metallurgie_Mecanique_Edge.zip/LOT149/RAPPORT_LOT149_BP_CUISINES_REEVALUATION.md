# Lot 149 — Réévaluation BP Découverte : cuisines professionnelles et chambres froides

**Base de travail :** copie du ZIP complet Lot 147. Le dossier, les résultats et les archives Lot 147 restent présents sans modification. Aucun changement à la branche `main`.

## Conclusion exécutive

Le moteur v107 a été exécuté de nouveau sur le scénario historique, puis sur trois mixes produit et un stress. Le scénario actif de planification est le mix équilibré **150 tables / 60 éviers / 8 chambres froides positives en A1**, avec une montée prudente sur 3 ans. Il donne **24 459 USD de résultat net A1, soit 9,19 %**, contre **11 378 USD et 4,84 %** pour le scénario Lot 147. Le gain vient du mix et des volumes de vente supposés, à prix unitaires inchangés : ce n'est pas une hausse de prix ni une réduction des charges fixes.

Ce résultat est réellement calculé et intégré dans le BP, mais **il n'est pas économiquement validé** : ventes non contractualisées, prix nets unitaires hérités, coût et périmètre de la chambre non confirmés. Le scénario stress tombe à 2,89 % A1. L'objectif de marge n'a donc pas été utilisé comme cible de réglage.

## 1. Correction de la chambre froide

La fiche technique CIBO associe le modèle C65B/BF à des dimensions de 2 000 × 2 000 × 2 200 mm et un groupe AP75M-1B, mais annonce aussi 3,35 m³. Une fiche catalogue HORECA pour le modèle correspondant affiche 7 400 000 FCFA HT; CIBO indique que son tarif fixe dépend du projet et demande un devis. Le produit des dimensions est **8,8 m³**. Les 3,35 m³ publiés sont donc contradictoires avec ces dimensions. La plateforme ne présente plus 3,35 m³ comme une donnée validée.

Si les dimensions citées sont extérieures et si les panneaux ont 100 mm, l'espace intérieur géométrique estimé est 1,8 × 1,8 × 2,0 = **6,48 m³**, avant évaporateur et rayonnages. Ce n'est qu'une estimation : la fiche n'indique pas si les cotes sont intérieures ou extérieures. Le fabricant du groupe donne, à 43 °C ambiant, 1 232 W pour 10,4 m³ à +5 °C, et 1 081 W pour 6,1 m³ à 0 °C. Cela rend une consigne positive proche de +5 °C plausible à première vue, mais ne remplace pas le calcul de charge frigorifique, qui dépend des panneaux, du sol, de la porte, des entrées de marchandises, des ouvertures et de la température ambiante.

Le prix publié de 7,4 M FCFA HT est conservé comme **comparateur commercial seulement** : le conflit de volume empêche de l'associer avec certitude à la chambre corrigée. Le coût P2I de 5 500 USD et le prix P2I hérité de 10 571 USD restent dans les scénarios pour préserver la comparaison; ils ne sont pas confirmés pour l'enveloppe de 8,8 m³. La quantité de 28 m² de panneaux est également provisoire et à vérifier par plans.

## 2. Personnel et frais fixes

L'équipe de planification comporte 10 ETP : 1 responsable atelier/qualité (500 000 FCFA brut/mois), 2 soudeurs inox (300 000 chacun), 3 tôliers-assembleurs (250 000 chacun), 2 frigoristes (350 000 chacun), 1 technicien pose/SAV (300 000) et 1 commercial/administration (250 000). Total brut : 3,1 M FCFA/mois, soit 37,2 M/an.

Le calcul patronal indicatif utilise 7,7 % retraite sur la masse salariale (plafond retraite de 3 375 000 FCFA/mois appliqué), puis les branches employeur PF 5 %, maternité 0,75 % et AT/MP à 2 % sur le plafond mensuel de 75 000 FCFA par salarié. Ce taux AT/MP de 2 % est le bas de la fourchette réglementaire; le taux dépend du secteur et peut aller jusqu'à 5 %. Cotisations modélisées : 3,5619 M FCFA/an; brut chargé 40,7619 M FCFA/an, soit environ 68 507 USD au taux de planification de 595 FCFA/USD. Le budget moteur a été arrondi vers le haut à **68 510 USD A1**. La grille salariale est une hypothèse P2I, pas une enquête de rémunération locale; minima catégoriels, avantages et autres prélèvements sont à qualifier. Le SMIG officiel est de 75 000 FCFA depuis le 1er janvier 2023, ce qui sert uniquement de plancher général et ne justifie pas les salaires métiers.

Les **38 000 USD de frais fixes sont conservés sans réduction** : site/loyer 12 000; énergie/eau 8 000; maintenance/pièces 5 000; assurance/sécurité 3 000; administration/télécoms 4 000; commercial/logistique fixe 6 000 USD par an. Ce sont des provisions P2I, sans bail, facture, police ou contrat de maintenance. Au tarif professionnel BT CIE publié (88,81–104,43 FCFA/kWh HT selon la tranche), 8 000 USD équivaudraient à environ 45,6–53,6 MWh/an si tout était de l'électricité. L'eau étant incluse, cette conversion n'est pas une prévision de consommation. Il faut en outre séparer le périmètre du poste commercial/logistique fixe des coûts variables de distribution pour écarter tout chevauchement.

## 3. Configuration, coûts et programme de production

Le CAPEX historique de **98 994 USD** est conservé : 64 440 USD de machines, 16 110 transport/assurance/port/douane estimés, 6 444 installation/mise en service/formation estimées et 12 000 site/électricité/ventilation/sécurité estimés. Aucune machine, opération de sécurité, contrôle qualité ou poste indispensable n'a été retiré. La réévaluation n'a pas réouvert une recherche générale de machines.

Le financement v107 conserve 40/60 sur le CAPEX : 39 597,60 USD d'apport et 59 396,40 USD de dette. Le moteur ajoute une réserve de trésorerie financée séparément par apport : 28 860,03 USD pour le mix actif; l'apport total correspondant est donc 68 457,63 USD. Cette réserve ne change pas la clé 40/60 du CAPEX.

Temps atelier indicatifs : table 5 h, évier 7,5 h, chambre positive 20 h. Capacité planifiée : 1 500 heures/an. Mix actif :

| Année | Tables | Éviers | Chambres positives | Heures estimées |
| --- | ---: | ---: | ---: | ---: |
| A1 | 150 | 60 | 8 | 1 360 |
| A2 | 156 | 62 | 8 | 1 405 |
| A3 | 162 | 64 | 8 | 1 450 |

La capacité provient des cycles estimés et de la disponibilité d'atelier supposée; elle n'est ni une garantie machine ni une validation des débouchés. Les quantités vendues égalent les quantités produites dans les scénarios faute de taux de rebut/stock documenté : c'est une hypothèse, pas une commande. Les installations, mises en service et maintenances chez le client restent hors recettes calculées; aucun revenu de service n'a été ajouté.

Les prix nets et coûts directs unitaires ont été laissés aux hypothèses Lot147 : table 1 141,68 USD puis indexation existante; évier 1 199,05 USD puis indexation; chambre 10 571 USD; coûts directs A1 table 459,22 USD, évier 467,61 USD, chambre 5 500 USD. Distribution variable A1 moyenne pondérée : 26,83 USD par unité. Les matières et accessoires sont détaillés dans le BOM Lot147 et le CSV Lot149. Les prix de vente sont des hypothèses nettes P2I, pas des offres acceptées; les prix de détail observés servent seulement de repères. L'écart matières/coût direct et la provision de montage/test/consommables de la chambre sont conservés, avec risque de chevauchement salarial à ventiler.

## 4. Résultats moteur v107

Les ROI ci-dessous sont un indicateur simple **résultat net annuel / CAPEX de 98 994 USD**, non un TRI ni une période de récupération. Le BFR indiqué est celui du mois 12 de l'année 1; la trésorerie libre est suivie chaque mois et reste positive dans les scénarios exécutés.

| Scénario | Année | CA USD | Résultat net USD | Marge nette | ROI simple/CAPEX | BFR M12 USD |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Lot147 historique | A1 | 235 186 | 11 378 | 4,84 % | 11,49 % | 18 448 |
| Lot147 historique | A2 | 255 398 | 20 417 | 7,99 % | 20,62 % | — |
| Lot147 historique | A3 | 277 615 | 30 377 | 10,94 % | 30,69 % | — |
| Lot149 mix équilibré | A1 | 266 188 | 24 459 | 9,19 % | 24,71 % | 20 964 |
| Lot149 mix équilibré | A2 | 288 614 | 34 598 | 11,99 % | 34,95 % | — |
| Lot149 mix équilibré | A3 | 312 200 | 45 320 | 14,52 % | 45,78 % | — |
| Sensibilité chambres | A1 | 265 595 | 21 127 | 7,95 % | 21,34 % | 21 480 |
| Sensibilité inox | A1 | 233 764 | 16 454 | 7,04 % | 16,62 % | 16 966 |
| Stress ventes/matières | A1 | 237 455 | 6 868 | 2,89 % | 6,94 % | 18 574 |

La simulation stress réduit le volume par rapport au mix équilibré et augmente les coûts matières unitaires de 10 %, à prix inchangés. Le scénario mix-chambres A1 est à 130/55/10; le scénario mix-inox est à 180/40/4. Tous restent dans la capacité calculée. Le détail des 36 résultats annuels, des flux de trésorerie mensuels, des bilans et des scénarios est dans `RESULTATS_V107.json` et les CSV associés.

Trésorerie libre du mix actif A1 par mois (USD) : 9 899; 12 827; 14 560; 16 299; 18 046; 19 353; 22 328; 24 027; 25 800; 27 579; 29 365; 30 711. Trésorerie minimale : 9 899 USD. BFR M12 : 20 964 USD. Les bilans des A1–A3 équilibrent à moins de 0,000001 USD d'écart numérique. Les bilans historiques Lot147 se reproduisent également à la précision du moteur.

Contribution estimée par heure d'atelier selon les prix/coûts Lot147 A1 : table ≈117 USD/h, évier ≈60,93 USD/h, chambre ≈238,55 USD/h. Cela explique les mixes testés, mais ne démontre pas la demande : la chambre porte à elle seule une forte contribution supposée et son coût/prix est celui à confirmer en priorité.

## 5. Contrôles effectués et limites

Le script `run_lot149.cjs` appelle le moteur v107 présent dans la copie complète, reproduit les trois résultats historiques Lot147, exécute quatre scénarios de réévaluation/stress, charge le nouveau dossier dans les données runtime et recalcule le scénario actif. Les contrôles vérifient le registre de 96 identifiants uniques et 12 filières, les 17 rubriques, les heures atelier (≤1 500), 12 mois de trésorerie, 36 mois de BFR, les bilans, le partage de financement CAPEX 40/60 et l'identité des résultats actifs et recalculés.

Contrôles de syntaxe Node sur les modules Lot149 et intégrité du ZIP effectués. Le scénario intégré a été recalculé avec v107 et rapproché des sorties détaillées. Ce travail n'a pas été ouvert dans Microsoft Edge réel : le rendu visuel final sur Windows, les clics de navigation, le téléchargement CSV et l'export PDF restent à vérifier par ouverture locale dans Edge.

**Statut recommandé :** BP Découverte construit et calculé par v107, techniquement intégré, mais **simulation économique conditionnelle**, pas dossier d'investissement validé. Avant toute décision d'investissement : corriger/faire confirmer le plan dimensionnel de chambre, sa charge frigorifique et son coût complet; étayer prix/volumes net par circuit; mesurer consommation et clarifier salaires/charges; séparer coûts fixes et variables de distribution; décomposer la provision montage/test de la chambre.

## Sources publiques consultées

- CIBO World, chambre positive C65B/BF : https://ciboworld.net/catalogue/chambres-froides/chambre-froide-positive/ (dimensions et volume publiés contradictoires; le tarif est sur devis). HORECA World, fiche catalogue du modèle : https://www.horecaworld.net/produits/chambre-froide-positive-c65b-bf-ap75m-1b/ (affiche 7,4 M FCFA HT).
- Diamond, document technique AP75M-1B : https://diamond-eu-prod.s3.eu-central-1.amazonaws.com/media/11624654/FTEC-AP75M-1B.pdf (capacités publiées selon température et volume).
- CIE, tarif professionnel basse tension : https://www.cie.ci/entreprise/tarifs-electricite (prix du kWh par tranche/puissance).
- CNPS, employeur : https://www.cnps.ci/employeur/ (taux, dont AT/MP 2–5 % selon secteur; les plafonds affichés sur cette page sont anciens). CNPS, nouveau plafond applicable depuis janvier 2023 : https://www.cnps.ci/wp-content/uploads/2023/01/NOUVEAU-PLAFOND-DES-COTISATIONS-SOCIALES-DE-LA-CNPS.pdf (retraite 3 375 000 FCFA/mois; autres branches 75 000 FCFA/mois).
- Gouvernement de Côte d'Ivoire, SMIG 75 000 FCFA à compter du 1er janvier 2023 : https://www.gouv.ci/doc/1671692497Communique-du-Conseil-des-Ministres-du-mercredi-21-decembre-2022.pdf.
- HORECA World, comparateurs inox : https://horecaworld.net/univers/restaurants-hotels/page/106/ et https://horecaworld.net/catalogue/mobilier-inox-hygiene/page/6/ (dimensions et prix de matériel fini; pas prix producteur).
