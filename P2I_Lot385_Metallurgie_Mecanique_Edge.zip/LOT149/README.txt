P2I — LOT 149
Réévaluation BP Découverte — Cuisines professionnelles & chambres froides

Dossier basé sur le ZIP complet Lot147. L’archive Lot147, son scénario v107 et ses résultats historiques sont conservés.
Le scénario Lot149 actif est une simulation conditionnelle, pas une validation économique : volumes de vente, prix nets et coûts de chambre froide à confirmer.

Contenu Lot149 :
- RAPPORT_LOT149_BP_CUISINES_REEVALUATION.md : synthèse et réserves.
- RESULTATS_V107.json : résultats détaillés, bilans, BFR, trésorerie et scénarios.
- COMPARAISON_SCENARIOS.csv : comparatif des 5 scénarios sur 3 ans.
- COMPTE_RESULTAT_MIX_REVISE_3_ANS.csv et TRESORERIE_MIX_REVISE_12_MOIS.csv.
- HYPOTHESES_COUTS_ET_CAPACITE.csv : hypothèses, sources et limites.
- MATRICE_TESTS_LOT149.json et run_lot149.cjs : contrôles reproductibles.

Utilisation : extrayez l’archive, ouvrez P2I_Edge/index.html dans Microsoft Edge, puis choisissez Cuisines professionnelles & chambres froides.
Les clics d’interface et l’export PDF restent à vérifier dans Edge sur le poste utilisateur.
