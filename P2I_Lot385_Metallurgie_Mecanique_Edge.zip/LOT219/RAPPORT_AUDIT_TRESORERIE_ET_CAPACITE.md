# P2I — Lot 219 : audit du cash et de la montée en cadence du mobilier

**Statut : étude de sensibilité NON VALIDÉE.** Source : archive Lot 218 (400 fichiers). Les 7 BP et le catalogue restent inchangés. Aucun soutien public présumé. Aucune marge nette >10 % affirmée.

## Diagnostic économique immédiat
- Chiffre d'affaires A1 simulé : **70,000,000 FCFA** ; coûts variables **50,240,000 FCFA** ; contribution **19,760,000 FCFA**.
- Personnel + frais fixes annuels de test hérités du lot 217 : **23,205,000 FCFA** (39 000 USD × 595). La contribution **moins ces seules charges** est **-3,445,000 FCFA**, avant amortissement, intérêts, impôt, stocks, TVA et éventuels autres coûts.
- Ainsi, **la croissance A1 proposée ne suffit pas à elle seule à garantir un RN positif**, malgré la montée des ventes après M6.
- Écart arithmétique à couvrir pour obtenir une contribution résiduelle égale à 10 % du CA **avant** amortissements, intérêts et IS : **10,445,000 FCFA**. Ce n'est **pas** le seuil d'une marge nette de 10 %.

## Crédit clients et besoin de liquidités
- Cas central : 60 % du CA à 60 jours, 40 % comptant, coûts variables payés immédiatement et frais fixes mensuels lissés.
- Créances clients au 31 décembre : **10,780,800 FCFA**.
- Point bas cumulé des flux d'exploitation de ce modèle partiel : **14,225,800 FCFA**, soit **23,909 USD**. Ce chiffre ne représente ni le BFR complet ni le financement total de l'entreprise.
- Les acomptes à la commande, factures progressives et contrôle du crédit peuvent améliorer la situation ; ils ne sont pas inclus dans le calcul.

## Capacité de production à qualifier
| Année | Tables-bancs | Bureaux | Armoires |
|---|---:|---:|---:|
| A1 | 1 200 | 160 | 80 |
| A2 | 2 800 | 400 | 200 |
| A3 | 4 200 | 600 | 300 |

Ces volumes sont des **hypothèses commerciales**, non des commandes ni une capacité technique démontrée. La gamme doit avoir un plan de charge par atelier (métal, bois, finition, assemblage), ses temps de cycle, effectifs et machines.

## Conditions de crédit à étudier
1. Acompte contractuel avant achat des matières, lorsque le client l'accepte ; conditions distinctes pour marchés publics.
2. Plafond d'encours par client et revue des retards ; provisions pour créances douteuses.
3. Suivi mensuel des encaissements, créances échues et trésorerie minimale ; préfinancement des gros marchés si nécessaire.
4. Ne pas confondre commande, livraison, facturation et encaissement.

## Produits innovants et visuels
- Table-banc secondaire : rangement tablette **mécanique, sans électronique intégrée**, anti-pincement, antivol, nettoyage facile.
- Amphithéâtre/supérieur : tablette écritoire et logement pour tablette numérique, tests de résistance et ergonomie.
- Bureau professionnel : logement tablette et **lampe LED amovible achetée**, clairement distinguée de la fabrication locale. La lampe n'est pas chiffrée, ne génère aucun CA dans ce modèle.
- **Visuels définitifs des blocs 2/17 non réalisés** : avant validation, ils pourraient suggérer à tort une offre industrialisée et rentable. Préparer ensuite les images produits et postes réels, avec logo P2I original, sans le recréer.

## Limites de calcul
La présente simulation **n'est pas une exécution v107 complète** : elle isole les encaissements clients et les décaissements opérationnels simples. Elle ne calcule pas bilan, TVA, IS, BFR complet, emprunt, stock ni résultat net. Les chiffres de prix et coûts des bureaux/armoires demeurent **non sourcés**. Ne pas utiliser ces sorties comme BP Découverte public.

## Contrôles réalisés
- Conservation des quantités annuelles après répartition mensuelle.
- Conservation CA = encaissements + créances fin A1.
- Neuf combinaisons 0/30/60 % crédit × 30/60/90 jours.
- Exclusion explicite de toute aide publique ou marge nette supposée.
