import os,csv,json,zipfile,html,math
root='/mnt/data/p2i_219/P2I_Edge'; out=root+'/LOT219';os.makedirs(out,exist_ok=True)
products=[('Tables-bancs',1200,33000,25200),('Bureaux',160,110000,71000),('Armoires',80,160000,108000)]
weights=[.045,.05,.05,.055,.06,.075,.09,.10,.105,.115,.12,.135]; s=sum(weights);weights=[x/s for x in weights]
# assign integers preserving annual sums
q=[]
for _,n,_,_ in products:
 a=[int(n*w) for w in weights]; left=n-sum(a)
 for i in sorted(range(12),key=lambda i:n*weights[i]-a[i],reverse=True)[:left]:a[i]+=1
 q.append(a)
assert all(sum(q[i])==products[i][1] for i in range(3))
FX=595;fixed=39000*FX/12
rows=[]; scenarios=[]
for share in [0,.3,.6]:
 for delay in [1,2,3]:
  monthly=[]; due=[0]*16; cum=0; mincum=0; receiv=0
  for m in range(12):
   revenue=sum(q[j][m]*products[j][2] for j in range(3)); variable=sum(q[j][m]*products[j][3] for j in range(3))
   cash_now=revenue*(1-share); due[m+delay]+=revenue*share
   receipts=cash_now+due[m]; cash_operating=receipts-variable-fixed;cum+=cash_operating;mincum=min(mincum,cum)
   monthly.append(dict(mois=m+1,table_banc=q[0][m],bureau=q[1][m],armoire=q[2][m],ca_fcfa=round(revenue),cout_variable_fcfa=round(variable),encaissements_fcfa=round(receipts),charges_fixes_et_personnel_fcfa=round(fixed),flux_exploitation_fcfa=round(cash_operating),cumul_exploitation_fcfa=round(cum)))
  receiv=sum(due[12:]); assert round(sum(x['ca_fcfa'] for x in monthly)-sum(x['encaissements_fcfa'] for x in monthly))==round(receiv)
  summary=dict(part_credit=share,delai_mois=delay,ca_fcfa=sum(x['ca_fcfa'] for x in monthly),creances_fin_fcfa=round(receiv),besoin_maximal_de_tresorerie_exploitation_fcfa=round(-mincum),flux_exploitation_a1_fcfa=round(cum),besoin_maximal_usd=round(-mincum/FX),exclusions='Hors CAPEX, dette, intérêts, TVA, IS, stocks, acomptes, retards, fournisseurs')
  scenarios.append(dict(summary=summary,months=monthly))
  rows.append(summary)
with open(out+'/SENSIBILITE_TRESORERIE_9_SCENARIOS.csv','w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
with open(out+'/TRESORERIE_12_MOIS_60PC_60J.csv','w',newline='',encoding='utf-8-sig') as f:
 a=next(x['months'] for x in scenarios if x['summary']['part_credit']==.6 and x['summary']['delai_mois']==2);w=csv.DictWriter(f,fieldnames=a[0]);w.writeheader();w.writerows(a)
contrib=sum(n*(p-c) for _,n,p,c in products); rev=sum(n*p for _,n,p,c in products); var=sum(n*c for _,n,p,c in products)
fixedannual=39000*FX
capacity={'A1':{'tables_bancs':1200,'bureaux':160,'armoires':80},'A2':{'tables_bancs':2800,'bureaux':400,'armoires':200},'A3':{'tables_bancs':4200,'bureaux':600,'armoires':300}}
# estimate only assembly hours illustrative, avoid treating as capacity verified
with open(out+'/HYPOTHESES_ET_RESULTATS.json','w',encoding='utf8') as f:json.dump(dict(status='SIMULATION NON VALIDEE',products=[dict(nom=n,volume_a1=v,prix_test_fcfa=p,cout_variable_test_fcfa=c) for n,v,p,c in products],monthly_distribution=weights,annual_revenue=rev,annual_variable=var,annual_contribution=contrib,annual_fixed_test=fixedannual,annual_operating_contribution_before_financing_tax_depreciation=contrib-fixedannual,scenarios=scenarios,capacity_scenarios=capacity),f,ensure_ascii=False,indent=2)
# margin guardrail
needed=(fixedannual+0.10*rev-contrib) # simplistic pretax target, NOT net
chosen=next(x['summary'] for x in scenarios if x['summary']['part_credit']==.6 and x['summary']['delai_mois']==2)
report=f'''# P2I — Lot 219 : audit du cash et de la montée en cadence du mobilier

**Statut : étude de sensibilité NON VALIDÉE.** Source : archive Lot 218 (400 fichiers). Les 7 BP et le catalogue restent inchangés. Aucun soutien public présumé. Aucune marge nette >10 % affirmée.

## Diagnostic économique immédiat
- Chiffre d'affaires A1 simulé : **{rev:,.0f} FCFA** ; coûts variables **{var:,.0f} FCFA** ; contribution **{contrib:,.0f} FCFA**.
- Personnel + frais fixes annuels de test hérités du lot 217 : **{fixedannual:,.0f} FCFA** (39 000 USD × 595). La contribution **moins ces seules charges** est **{contrib-fixedannual:,.0f} FCFA**, avant amortissement, intérêts, impôt, stocks, TVA et éventuels autres coûts.
- Ainsi, **la croissance A1 proposée ne suffit pas à elle seule à garantir un RN positif**, malgré la montée des ventes après M6.
- Écart arithmétique à couvrir pour obtenir une contribution résiduelle égale à 10 % du CA **avant** amortissements, intérêts et IS : **{needed:,.0f} FCFA**. Ce n'est **pas** le seuil d'une marge nette de 10 %.

## Crédit clients et besoin de liquidités
- Cas central : 60 % du CA à 60 jours, 40 % comptant, coûts variables payés immédiatement et frais fixes mensuels lissés.
- Créances clients au 31 décembre : **{chosen['creances_fin_fcfa']:,.0f} FCFA**.
- Point bas cumulé des flux d'exploitation de ce modèle partiel : **{chosen['besoin_maximal_de_tresorerie_exploitation_fcfa']:,.0f} FCFA**, soit **{chosen['besoin_maximal_usd']:,.0f} USD**. Ce chiffre ne représente ni le BFR complet ni le financement total de l'entreprise.
- Les acomptes à la commande, factures progressives et contrôle du crédit peuvent améliorer la situation ; ils ne sont pas inclus dans le calcul.

## Capacité de production à qualifier
| Année | Tables-bancs | Bureaux | Armoires |
|---|---:|---:|---:|
| A1 | 1 200 | 160 | 80 |
| A2 | 2 800 | 400 | 200 |
| A3 | 4 200 | 600 | 300 |

Ces volumes sont des **hypothèses commerciales**, non des commandes ni une capacité technique démontrée. La gamme doit avoir un plan de charge par atelier (métal, bois, finition, assemblage), ses temps de cycle, effectifs et machines.

## Conditions de crédit à étudier
1. Acompte contractuel avant achat des matières, lorsque le client l'accepte ; conditions distinctes pour marchés publics.
2. Plafond d'encours par client et revue des retards ; provisions pour créances douteuses.
3. Suivi mensuel des encaissements, créances échues et trésorerie minimale ; préfinancement des gros marchés si nécessaire.
4. Ne pas confondre commande, livraison, facturation et encaissement.

## Produits innovants et visuels
- Table-banc secondaire : rangement tablette **mécanique, sans électronique intégrée**, anti-pincement, antivol, nettoyage facile.
- Amphithéâtre/supérieur : tablette écritoire et logement pour tablette numérique, tests de résistance et ergonomie.
- Bureau professionnel : logement tablette et **lampe LED amovible achetée**, clairement distinguée de la fabrication locale. La lampe n'est pas chiffrée, ne génère aucun CA dans ce modèle.
- **Visuels définitifs des blocs 2/17 non réalisés** : avant validation, ils pourraient suggérer à tort une offre industrialisée et rentable. Préparer ensuite les images produits et postes réels, avec logo P2I original, sans le recréer.

## Limites de calcul
La présente simulation **n'est pas une exécution v107 complète** : elle isole les encaissements clients et les décaissements opérationnels simples. Elle ne calcule pas bilan, TVA, IS, BFR complet, emprunt, stock ni résultat net. Les chiffres de prix et coûts des bureaux/armoires demeurent **non sourcés**. Ne pas utiliser ces sorties comme BP Découverte public.

## Contrôles réalisés
- Conservation des quantités annuelles après répartition mensuelle.
- Conservation CA = encaissements + créances fin A1.
- Neuf combinaisons 0/30/60 % crédit × 30/60/90 jours.
- Exclusion explicite de toute aide publique ou marge nette supposée.
'''
open(out+'/RAPPORT_AUDIT_TRESORERIE_ET_CAPACITE.md','w',encoding='utf8').write(report)
# reproducible source: copy this generator to archive
import shutil;shutil.copy('/tmp/make219.py',out+'/REPRODUIRE_LOT219.py')
# offline html summary
tr=''.join('<tr>'+''.join(f'<td>{html.escape(str(v))}</td>' for v in [str(int(r['part_credit']*100))+' %',str(r['delai_mois']*30)+' jours',f"{r['creances_fin_fcfa']:,}",f"{r['besoin_maximal_de_tresorerie_exploitation_fcfa']:,}",f"{r['flux_exploitation_a1_fcfa']:,}"] )+'</tr>' for r in rows)
page=f'''<!doctype html><html lang="fr"><meta charset="utf-8"><title>P2I — Lot 219 — Mobilier</title><style>body{{font:16px system-ui;margin:2rem auto;max-width:1050px;color:#17283e;line-height:1.55}}h1{{color:#102744}}table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #b9c7d2;padding:.65rem;text-align:right}}th{{background:#102744;color:white}}td:first-child,th:first-child{{text-align:left}}.warning{{border-left:5px solid #c08b25;padding:1rem;background:#fff9ec}}a{{color:#07588d}}</style><h1>P2I — Mobilier scolaire et professionnel</h1><p class="warning"><strong>Étude exploratoire, non validée.</strong> Les prix et coûts des bureaux et armoires ne sont pas documentés. Ce tableau ne constitue pas le BP Découverte.</p><p><strong>CA A1 testé :</strong> {rev:,} FCFA ; <strong>contribution avant charges fixes :</strong> {contrib:,} FCFA ; <strong>personnel et charges fixes testés :</strong> {fixedannual:,} FCFA.</p><h2>Impact des délais de paiement — A1</h2><table><tr><th>Crédit</th><th>Délai</th><th>Créances fin A1 (FCFA)</th><th>Besoin maximal exploitation partielle (FCFA)</th><th>Flux exploitation A1 (FCFA)</th></tr>{tr}</table><p>Le besoin maximal ci-dessus exclut investissement, emprunt, TVA, stocks, fiscalité et retards de paiement. Il ne doit pas être présenté comme BFR total.</p><p><a href="RAPPORT_AUDIT_TRESORERIE_ET_CAPACITE.md">Rapport complet</a> · <a href="TRESORERIE_12_MOIS_60PC_60J.csv">Trésorerie mensuelle CSV</a></p></html>'''
open(out+'/CONSULTER_AUDIT_MOBILIER.html','w',encoding='utf8').write(page)
zipout='/mnt/data/P2I_Lot219_Mobilier_Audit_Tresorerie_Capacite_Core.zip'
with zipfile.ZipFile(zipout,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for dp,ds,fs in os.walk(root):
  for fn in fs:
   path=os.path.join(dp,fn);z.write(path,os.path.relpath(path,'/mnt/data/p2i_219'))
with zipfile.ZipFile(zipout) as z:print('zip',zipout,'files',len(z.namelist()),'bad',z.testzip())
print('selected',chosen,'contribution',contrib,'fixed',fixedannual)
