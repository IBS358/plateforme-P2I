# P2I — Lot 187 : coût industriel intégré au BP remorque 3 t

Base : Lot 186, sans modification de la branche GitHub main.

Livrable : BP de travail à 17 rubriques enrichi d'une nomenclature de 19 postes **directement dans le BP**, avec saisie des coûts absents, calcul bloqué tant que les 19 coûts ne sont pas renseignés, affichage du coût direct indicatif une fois complet et export JSON. Aucun coût absent n'est remplacé par zéro. Les cinq postes acier (614,04 USD) sont conservés en lecture seule ; la fourchette des deux essieux est conservée en source et demande un choix justifié.

L'investissement, le prix de vente et le volume A1 sont également requis avant de transférer la configuration au moteur commun v107. **Aucun nouveau résultat net n'a été calculé**, faute de données. Le calcul de coût direct ne représente pas un compte de résultat.

Contrôles : 19 lignes BOM ; somme des cinq postes acier 614,04 USD ; 17 titres numérotés préservés ; archive ZIP testée. Tests interactifs manuels Edge non effectués.
