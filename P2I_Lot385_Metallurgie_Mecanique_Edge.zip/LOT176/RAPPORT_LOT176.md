# Lot 176 — Consolidation des postes industriels documentés

Base : copie Lot 175, référentiel permanent et runtime/lot150-assemblage-data.js.

- 20 postes regroupés sur les quatre UP, avec références et prix conservés tels que documentés dans la source interne.
- Aucune modification du moteur commun ni des BP publics.
- Aucune nouvelle rentabilité prétendue.
- Prix et modèles à revalider auprès des sources publiques avant calcul final.
- Navigation locale HTML, CSV et JSON ajoutés.
- Tests de syntaxe / cohérence / archive automatisés ; Edge manuel non testé.
- `main` non modifiée.
