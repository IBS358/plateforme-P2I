# P2I — Lot 221 : acomptes à la commande, préfinancement et créances

**Statut : simulation de trésorerie partielle, non BP validé.** Base intégrale lot 220 préservée. Les 7 BP existants, le catalogue des 96 UP, le moteur v107 et les archives ne sont pas modifiés.

## Correction méthodologique substantielle

Les lots 218–220 supposaient que la commande et la livraison intervenaient le même mois. Cette hypothèse surestimait l'utilité d'un acompte **à la commande** : elle ne modélisait pas son rôle dans le préfinancement des achats. Le lot 221 distingue **M0 (commande et matières premières)**, **M1 (livraison et encaissement comptant)**, puis **M2/M3 (règlement des créances à 30/60 jours)**. Le chiffre d'affaires n'est comptabilisé qu'à la livraison. Les acomptes ne créent aucun CA supplémentaire.

## Scénario central, purement exploratoire

- CA A1 : **70 000 000 FCFA** ; coûts variables **50 240 000 FCFA** ; personnel et fixes **23 205 000 FCFA**, repris du lot 219.
- 60 % des ventes à crédit ; 30 % d'acompte **sur les commandes à crédit**, solde 60 jours après livraison ; 40 % de ventes au comptant.
- Une période de fabrication d'un mois ; achat des matières à la commande, paiement comptant ; coûts fixes étalés sur M1–M12.
- **Besoin maximal de trésorerie partiel : 16,217,290 FCFA** ; créances fin A1 : **7,546,560 FCFA** ; cumul M12 : **-10,991,560 FCFA**.

## Ce que ce modèle ne permet PAS d'affirmer

Ce n'est **pas** un BFR complet : il exclut les stocks de sécurité, les produits finis invendus, les décalages de TVA, le CAPEX, les intérêts, les remboursements de dette, les impôts, les pertes, les SAV, les retards/impayés et les investissements d'extension A2. La répartition des volumes mensuels, les prix des bureaux et armoires, la capacité atelier et les charges restent des hypothèses non sourcées. **Aucune rentabilité nouvelle n'est revendiquée.**

## Décision

Conserver le mobilier scolaire et professionnel comme candidat prioritaire et le concept d'emplacement tablette / lampe LED amovible comme variantes à documenter. Ne pas activer publiquement cette UP ni présenter les hypothèses comme commandes acquises. La prochaine vraie condition de validation reste : nomenclatures et prix vérifiables pour les trois gammes, CAPEX, capacité industrielle, calcul v107 complet et trésorerie sans déficit après financement.

## Contrôles

- 10 scénarios : acomptes 0, 20, 30, 40, 50 %, soldes à 30 ou 60 jours ; 60 % de ventes à crédit.
- CA annuel et coûts variables réconciliés aux données du lot 220 ; avances comptées une seule fois ; commandes du mois M13 exclues.
- Aucun fichier antérieur modifié. Aucun push GitHub.
