# P2I — Lot 179 : reconstruction chiffrable remorque 3 t

Base : archive Lot 178, nomenclature et sources du Lot 154.

## Livré
- Page autonome Microsoft Edge avec nomenclature complète des postes connus/inconnus et saisie des 10 familles de coûts complémentaires.
- Calcul bloqué si une valeur manque : aucune assimilation d’un inconnu à zéro.
- Fourchette vérifiée arithmétiquement acier + deux essieux : 614,04 + 2 × [219,30 ; 271,50] = [1 052,64 ; 1 157,04] USD, incoterms mélangés, **non comparable à un prix rendu**.
- Comparaison informative Weito/Yijia, sans confusion entre produits complets et composants.

## Non réalisé
Pas de prix local validé, de BOM complète ni de BP v107 pour la remorque 3 t. Aucun test manuel dans Edge. Les trois autres UP déficitaires ne sont pas finalisées.

## Tests
Syntaxe du JavaScript du calculateur vérifiée avec Node ; contrôle des dix champs et des formules ; ZIP testé. Les scripts historiques ne sont pas modifiés.
