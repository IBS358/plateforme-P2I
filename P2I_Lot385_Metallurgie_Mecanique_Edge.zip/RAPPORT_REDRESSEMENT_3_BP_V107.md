# P2I — Rapport consolidé final

Ce fichier historique a été remplacé par le rapport consolidé courant. Pour les résultats v107 définitifs, l’identifiant actif de la machine de conditionnement, le statut économique de la remorque et les contrôles des huit BP, consulter [RAPPORT_FINALISATION_8_BP_ASSEMBLAGE.md](RAPPORT_FINALISATION_8_BP_ASSEMBLAGE.md).
