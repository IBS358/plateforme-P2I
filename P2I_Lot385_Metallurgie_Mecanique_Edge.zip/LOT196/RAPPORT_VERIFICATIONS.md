# P2I — Lot 196 : restitution financière vérifiable

Correction de trois BP du Lot 190 : bilans agrégés A1–A3 et détail du BFR M1–M12, recopiés des résultats v107 archivés du Lot 155. Aucun chiffre simulé ou inventé.

| UP | Bilan A1 actif/passif USD | Écart A1 USD |
|---|---:|---:|
| tricycles_utilitaires | 78 450,00 | 0,00 |
| velos | 99 463,86 | -0,00 |
| equipements | 68 932,10 | -0,00 |

Contrôles : bilans équilibrés A1–A3, formule BFR sur les 12 mois, 17 rubriques conservées, ZIP intègre. Le rendu Microsoft Edge reste à vérifier. Les trois autres configurations sans données restent non calculables.
