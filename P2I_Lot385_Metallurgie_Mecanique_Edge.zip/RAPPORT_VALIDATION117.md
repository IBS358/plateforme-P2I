# P2I — Rapport Lot 117 : consolidation économique médicale

**Base de départ.** Copie de développement consolidée Lot 115, intégrant les résultats Lot 116 déjà calculés pour Kits médicaux, Mobilier médical et Béquilles/cannes. Les archives Lot 114 et les travaux des autres filières sont conservés. Lot de livraison identifié : Lot 117. Aucun changement GitHub et aucune modification de `main`.

## Résultat médical

Les 8 unités gardent leurs 17 rubriques et leurs **51 postes industriels**. Sept ont maintenant un calcul indicatif exécuté par le moteur commun; aucune n’est déclarée financièrement validée, car les prix/volumes de plusieurs entrées restent des hypothèses et les configurations doivent être confirmées par essais et acheteurs. Montants en USD.

| UP | État financier | Postes | CA A1 | Résultat net A1 (marge nette) | Trésorerie minimale mensuelle A1 |
|---|---|---:|---:|---:|---:|
| Kits médicaux et premiers secours | Calcul indicatif, non validé | 7 | 450,000 | 69,354 (15.4 %) | 5,235 |
| Mobilier médical | Calcul indicatif, non validé | 7 | 420,000 | 82,932 (19.7 %) | 17,710 |
| Béquilles et cannes | Calcul indicatif, non validé | 7 | 375,000 | 73,690 (19.7 %) | 13,264 |
| Alèses médicales absorbantes et protections de literie hospitalière | Non calculable sans substitution de données | 6 | — | — | — |
| Sparadraps, pansements adhésifs et compresses médicales | Calcul indicatif, non validé | 5 | 810,000 | 212,963 (26.3 %) | 20,926 |
| Fauteuils roulants | Calcul indicatif, non validé | 7 | 340,000 | 35,970 (10.6 %) | 6,581 |
| Instruments médicaux | Calcul indicatif, non validé | 7 | 280,000 | 28,144 (10.1 %) | 7,321 |
| Antiseptiques et désinfectants | Calcul indicatif, non validé | 5 | 260,000 | 2,518 (1.0 %) | 8,660 |

Tous les calculs indiqués suivent le financement 40 % apport / 60 % dette. Le moteur produit le compte de résultat et le bilan sur 3 ans, le BFR mensuel sur 36 mois et la trésorerie sur 12 mois. Pour les sept scénarios calculables, le test confirme 3 bilans équilibrés, 12 mois de trésorerie non négative, et une mobilisation équilibrée de ressources/emplois. Ces validations arithmétiques ne prouvent pas que ventes, achats ou prix soient acquis.

## Hypothèses et réserves principales

- **Kits médicaux** : scénario Lot116 conservé; marché/prix, volumes et capacité restent à confirmer.
- **Mobilier médical** : Lot116 conservé sans recalcul économique inutile. Une référence de cintreuse YT-50 NC à 6 500 USD est documentée; l’enveloppe équipements de 78 000 USD comprend encore une large part de postes/gabarits P2I non tarifés par catalogue. La marge A1 de 19,7 % est indicative, non validée.
- **Béquilles et cannes** : Lot116 conservé. Une poinçonneuse hydraulique Aona est repérée à 6 000 USD; sur 58 000 USD d’enveloppe machines, le solde n’est pas couvert par des prix catalogue comparables. La marge A1 de 19,7 % est indicative, non validée.
- **Sparadraps/compresses** : calcul consolidé en deux références vendues séparément, campagnes distinctes, mix fixe 50/50 en unités. Bandelettes adhésives hors calcul. Les prix usine, volumes et cadences restent des hypothèses Lot77/78; l’investissement intègre deux prix équipement documentés et des compléments estimatifs.
- **Fauteuils roulants** : configuration corrigée vers l’assemblage local de châssis finis et composants achetés; aucune fabrication de châssis sans équipements tarifés. Prix composants, programme commercial et tarifs hérités Lot77 restent à confirmer.
- **Instruments** : périmètre limité à la finition de pinces à partir d’ébauches inox quasi finies, puis nettoyage ultrasonique et emballage non stérile; pas de CNC ni stérilisation. Prix d’ébauches, rendement et ventes Lot77 restent non validés.
- **Antiseptiques** : calcul limité au conditionnement 500 ml d’un vrac fini acheté; aucune formulation locale ou allégation réglementaire présumée. La marge A1 de 1,0 % est très sensible aux prix du vrac, emballages et aux débouchés et ne vaut pas rentabilité confirmée.
- **Alèses médicales** : pas de calcul. La page fabricant BERICH publie le modèle BR-HLD300-UP mais présente sa cadence comme « 200–300 m » alors que le tableau d’origine annonce une unité « pièces/minute » et demande confirmation; la page ne fournit pas un prix du modèle. Une page de pharmacie ivoirienne affiche 23 500 FCFA pour 30 unités Hartmann 60×90 cm/8 gouttes (≈783 FCFA/unité au détail), mais c’est un prix détaillant d’un produit importé, pas le prix net usine. Il manque donc le BOM pesé/coût rendu des composants absorbants et barrières, le rendement/cadence effective et le prix net B2B atteignable. Aucun chiffre financier ni zéro de substitution n’a été injecté.

## Tests réellement exécutés

- `node --check plateforme115/machines-data.js` : PASS après correction de quatre fermetures d’objet en trop.
- `node tester115.cjs` : PASS — 96 UP, 12 filières, 17 rubriques par UP, 51 postes médicaux rattachés/illustrés, contenus médicaux spécifiques, 73 scénarios dans 64 UP.
- Comparaison non-régression avec le moteur Lot 114 : 28 scénarios comparés, CA/RN 3 ans et trésorerie mensuelle identiques pour le périmètre comparé.
- Sur les 7 scénarios médicaux : moteur commun, 40/60, compte de résultat et bilans 3 ans, BFR 36 mois, trésorerie 12 mois; bilans équilibrés et minima de trésorerie positifs. Sortie source : `TESTS_117.json`.
- Génération du runtime Edge autonome : 225 images uniques, 64,4 MB d’images livrées contre 244,4 MB de fichiers image d’entrée, dimensions conservées; aucun serveur requis pour les fiches Découverte.
- Export PDF et retour dashboard testés : clic simulé vers `window.print()` et lien local vers `accueil-local.html` : PASS.
- Limite : test DOM/rendu automatisé, pas de recette visuelle native dans une session Microsoft Edge Windows. Le contrôle de liens/assets est réalisé sur le runtime généré.

## Fichiers de suivi

- Matrice complète : `MATRICE_96_UP_Lot117.csv` (96 lignes UP; autres filières reprises sans modification).
- Rapport technique : `RAPPORT_VALIDATION117.md`.
- Tests : `TESTS_117.json`.
- Base JSON et HTML interactive consolidés; moteur commun conservé. Les ZIP Edge sont construits après ce rapport et vérifieront leur somme de contrôle et leur reconstitution.
