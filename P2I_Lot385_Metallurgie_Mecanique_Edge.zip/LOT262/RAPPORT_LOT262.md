# P2I — Lot 262 : diagnostic consolidé de redressement des huit BP

## Portée
Cette livraison cumulative conserve sans modification les fichiers des lots précédents. Elle ajoute une analyse de seuils **après amortissement et intérêts** pour les huit BP prototypes du lot 261. Ce n'est pas une livraison de BP finalisés.

## Calculs inverses
Sous la convention fiscale simplifiée du lot 261 (25 % sur résultat positif), pour obtenir RN/CA = 6 %, le résultat avant impôt doit être égal à 8 % du CA. En conservant toutes les autres hypothèses :
- CA requis = (charges variables + fixes + amortissements + intérêts) / 0,92 ; prix requis = CA requis / tonnage vendu.
- Coût de collecte maximal = coût actuel + [0,92 × CA actuel − (charges variables + fixes + amortissements + intérêts)] / tonnage entrant.
- Utilisation minimale à prix constant : résoudre 0,92 × CA(utilisation) − charges variables(utilisation) − charges fixes − amortissements − intérêts = 0. Si la contribution marginale est insuffisante, le volume seul ne peut atteindre 6 %.

Les charges variables sont supposées linéaires avec le volume, sans nouveaux postes, heures supplémentaires, augmentation de puissance ni dégradation du prix. La TVA, l'IS réel, le BFR, les remboursements de capital, les pertes, les besoins en trésorerie et les investissements supplémentaires ne sont pas intégrés. Les seuils sont des **tests algébriques**, non des prix de marché ni des recommandations de hausse tarifaire.

## Actions industrielles requises
- Plastique : vérifier le goulot d'étranglement entre lavage et extrusion, le coût de collecte et la vente des granulés versus paillettes.
- Papier-carton : vérifier le prix des balles triées, le coût de ramassage et les contrats avec papetiers.
- Métaux : séparer ferreux/non ferreux et contrats de reprise ; maîtriser le coût d'achat des ferrailles.
- Compost : intégrer la maturation, le foncier, le stock immobilisé et les analyses agronomiques ; envisager contrats de traitement rémunérés uniquement s'ils sont documentés.
- Verre : contractualiser les repreneurs de calcin, coûts de transport et pureté colorimétrique ; ne pas modéliser une verrerie de fusion.
- Pneus : distinguer granulats, acier, textiles et leur marché ; vérifier les consommations énergétiques des broyeurs.
- Huiles : distinguer prétraitement et véritable régénération, rendement des huiles de base, résidus dangereux et autorisations.
- DEEE : modéliser chaque fraction et les coûts de traitement dangereux ; éviter le prix moyen unique.

## État de validation
Aucun des huit BP n'est validé : équipements et CAPEX catalogue à sourcer, débouchés ivoiriens à documenter, bilan équilibré, BFR, trésorerie 12 mois et calcul v107 à intégrer. Aucune illustration IA n'a été ajoutée à ce lot.
