# P2I — Lot 349 — Avancement Services industriels et matrice des 96 UP

Date : 19 novembre 2026

## Travaux réalisés

- Archive du Lot 348 conservée sans réécrire les BP historiques. Le Lot 346 et ses 8 documents à 17 rubriques sont conservés.
- Exécution du moteur commun P2I v107 sur les huit UP Services industriels, avec états sur trois ans, trésorerie mensuelle, BFR, financement 40/60, bilan et réserve de démarrage.
- Hypothèses de prix et de volumes conservées comme hypothèses de planification. Aucun résultat n’est calibré à une cible de marge.
- Relevé de prix publics ponctuels dans `REFERENCES_PRIX_CATALOGUE_ET_RESERVES.csv`; ces références ne sont pas des prix EXW/FOB complets et ne valident pas les configurations d’équipements.
- Ajout de liens d’identifiants stables pour les futurs modules dans `IDENTIFIANTS_FUTURE_INTEGRATION.json`; aucun BP Pro, tutoriel, formation, conseil ni comptabilité n’est développé.

## Résultats A1 issus des hypothèses actuelles

| UP | CA USD | RN USD | Marge RN | État |
|---|---:|---:|---:|---|
| Services de nettoyage industriel | 144,000 | -28,570 | -19.8% | Simulation indicative non validée |
| Maintenance industrielle | 144,000 | -40,016 | -27.8% | Simulation indicative non validée |
| Logistique industrielle | 300,000 | 17,595 | 5.9% | Simulation indicative non validée |
| Formation industrielle | 120,000 | -26,770 | -22.3% | Simulation indicative non validée |
| Services qualité | 120,000 | -20,206 | -16.8% | Simulation indicative non validée |
| Études et conseil | 150,000 | -18,116 | -12.1% | Simulation indicative non validée |
| Sécurité industrielle | 180,000 | 19,222 | 10.7% | Simulation indicative non validée |
| Services énergétiques | 180,000 | 2,007 | 1.1% | Simulation indicative non validée |

Les scénarios déficitaires sont un signal de rejet ou de redimensionnement à instruire, pas une invitation à relever les prix ou à augmenter artificiellement les volumes. Le scénario Logistique reste sous 10 % de marge nette A1; Énergie est presque à l’équilibre; les autres doivent être interprétés avec les réserves de sources ci-dessous.

## Réserves déterminantes

1. Lot 348 rapporte lui-même quatre prix ponctuels de distributeurs (Fluke 117, Fluke 971) et précise que le moteur v107 n’avait pas été exécuté. Le Lot 349 ajoute quelques références mais ne transforme pas une référence partielle en configuration complète.
2. Les prix vérifiés visibles sont pour la plupart des prix publics distributeur. Ils ne sont pas EXW/FOB, ne comprennent pas le fret, assurance, douane CI, mise en service, étalonnage, licences, consommables et pièces.
3. Les volumes, tarifs commerciaux, coûts du personnel, niveaux de sous-traitance et délais d’encaissement n’ont pas été corroborés par contrats, appels d’offres ou relevés locaux.
4. Le moteur v107 est commun à la plateforme et assure ici les contrôles financiers; les prestations sont modélisées par unité de service annuelle, avec stocks de consommables. L’équilibre du bilan vérifie l’arithmétique du scénario, pas son adéquation opérationnelle à chaque service.

## Matrice générale

La matrice `MATRICE_96_UP_LOT349.csv` garde toutes les 96 lignes de la matrice source et sépare `INCOMPLET_SIMULATION_V107_INDICATIVE_NON_VALIDEE` pour les huit Services industriels de `INCOMPLET_NON_RETRAITE_DANS_CE_LOT` pour les 88 autres UP. La présence de 17 rubriques ne suffit pas à valider un BP. La matrice reste donc sans UP achevée certifiée à l’issue de ce lot.

## Étape suivante

Après la validation technique et commerciale des huit Services industriels, reprendre d’abord les UP non calculables de la matrice, puis les UP déficitaires et celles dont les prix/ventes restent historiques. Cette livraison fait progresser les calculs, mais ne prétend pas achever les 96 BP Découverte.
