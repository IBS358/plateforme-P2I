'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path');
const app=path.resolve(__dirname,'..'),rt=path.join(app,'runtime');
const c={console,Math,Number,String,Array,Object,Map,Set,JSON,Error,TypeError,Date,Intl,URL,URLSearchParams};c.window=c;c.location={search:'',href:'file:///P2I_Edge/index.html'};c.history={replaceState(){}};vm.createContext(c);
const files=['script-0.js','script-1.js','script-2.js','script-3.js','script-4.js','script-5.js','script-6.js','script-7.js','script-8.js','script-9.js','script-10.js','script-11.js','script-12.js','script-13.js','script-14.js','script-15.js','script-16.js','lot147-data.js','lot149-data.js','lot150-assemblage-data.js','lot152-assemblage-finances.js','lot153-assemblage-finances.js','catalogue-up-actif.js','script-17.js','lot152-assemblage-visuels.js','lot153-assemblage-visuels.js','lot154-remorques.js','lot154-remorque-finances.js','lot155-assemblage-finances.js'];
for(const f of files)vm.runInContext(fs.readFileSync(path.join(rt,f),'utf8'),c,{filename:f});
const ids=['smartphones','tablettes','remorques_agricoles','stockage_manutention'];
const result={lot:164,engine:'v107',type:'test_plafond_capacite_historique',warning:'Capacites et prix historiques non valides commercialement; les volumes A2/A3 restent historiques. Aucune nouvelle configuration ni prevision commerciale.',units:{}};
for(const id of ids){
 const prior=c.P2I_LOT152_FINANCES.units[id].input;
 const historical=JSON.parse(JSON.stringify(prior));
 const cap=historical.capacite*250*8;
 const x=JSON.parse(JSON.stringify(historical));
 x.ventes[0]=cap; x.production[0]=cap;
 const old=c.P2I_BP_SIMULATION_COMMUNE.calculer(historical),r=c.P2I_BP_SIMULATION_COMMUNE.calculer(x);
 const summarize=(a)=>({CA_A1:a.annuel[0].chiffre_affaires,RN_A1:a.annuel[0].resultat_net,marge_A1_pct:100*a.annuel[0].resultat_net/a.annuel[0].chiffre_affaires,trezo_min_12m:Math.min(...a.tresorerie.map(m=>m.solde_final)),bilans_equilibres:a.controles.bilans_equilibres});
 if(r.annuel.length!==3||r.tresorerie.length!==12||r.bfr.length!==36||r.bilans.length!==3||r.controles.bilans_equilibres!==true)throw Error('invalid v107 '+id);
 result.units[id]={produit:prior.nom,prix_historique:prior.prix[0],ventes_historiques_A1:prior.ventes[0],capacite_historique_programmee_A1:cap,ancien:summarize(old),plafond_historique_conditionnel:summarize(r),limitations:['Volume au plafond technique historique non valide commercialement','Aucun changement de machines, personnel, prix, couts ou investissements','Resultats A2/A3 conserves selon scenario historique','Non transferable a une UP de remplacement']};
}
fs.writeFileSync(path.join(__dirname,'TEST_LIMITES_V107.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify(Object.fromEntries(Object.entries(result.units).map(([id,x])=>[id,{capacity:x.capacite_historique_programmee_A1,margin:x.plafond_historique_conditionnel.marge_A1_pct}])),null,2));
