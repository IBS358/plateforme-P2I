# Lot 329 — Schémas industriels et contrôle des ressources

Source : lot 328, sans modification des scénarios financiers ni du moteur v107.
Les huit BP conservent leurs 17 rubriques et leurs galeries de variantes. Un schéma original lisible et imprimable est intégré au bloc 17 de chaque BP, reprenant les opérations et équipements déjà indiqués dans les tableaux des postes.

| UP | Postes | Images HTML | Images manquantes |
|---|---:|---:|---:|
| plastique | 7 | 8 | 0 |
| papier-carton | 6 | 8 | 0 |
| metaux | 6 | 8 | 0 |
| compost | 7 | 8 | 0 |
| verre | 7 | 8 | 0 |
| pneus | 7 | 8 | 0 |
| huiles | 7 | 8 | 0 |
| deee | 7 | 8 | 0 |

Les schémas SVG ne sont **pas** des photos réelles. Les photographies individuelles des machines restent à qualifier et ne sont pas inventées. Les 17 rubriques n’ont pas fait l’objet d’une validation éditoriale exhaustive. DEEE : marge 18,05 % conditionnelle à une prestation rémunérée de 300 USD/t ; verre 3,20 % accepté.

Aucune modification des résultats v107, investissements ou prix catalogues.