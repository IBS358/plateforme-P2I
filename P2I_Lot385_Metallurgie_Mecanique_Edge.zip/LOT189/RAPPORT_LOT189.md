# Lot 189 — qualification des coûts et des justificatifs

Base: ZIP Lot 188. Modification ciblée du BP Remorque 3t sans changement du moteur financier commun.

## Modification effective
Chaque coût saisi dans les 19 lignes conserve désormais son justificatif (fournisseur/devis/date). Les coûts historiques restent en lecture seule avec leur provenance. Le statut « prêt à instruire dans v107 » exige simultanément : les 16 coûts directs, la ligne de charges indirectes, le montant d’investissement, le prix, le volume et les justificatifs des coûts nouvellement saisis. Les rubriques commerciales restent hors du coût industriel.

## Limites
Ce contrôle de complétude ne prouve pas la véracité des devis. Le prix de vente ivoirien, les volumes, la résistance mécanique et le coût industriel complet restent non validés. Aucun résultat net v107 nouveau n’est annoncé. Les 17 rubriques historiques et les autres UP sont conservées. Aucun test manuel Microsoft Edge.
