# Lot 272 — Dossiers de décision des huit UP

Ouvrir `OUVRIR_8_BP_LOT272_EDGE.html` dans Microsoft Edge. Huit dossiers HTML de 17 rubriques sont regroupés et reliés par une page d’accueil.

**Limites impératives :** Ces dossiers utilisent les hypothèses des lots 258, 263, 270 et l’audit 271. Ils ne constituent ni des BP définitifs, ni des simulations v107 exécutées, ni des devis, ni des preuves de rentabilité. Les cinq écarts d’EBITDA ne sont pas justifiés commercialement. Aucun visuel IA nouveau n’a été généré et aucun bilan équilibré n’a été calculé. La trésorerie est indicative, sans véritable BFR mensuel.

Tous les fichiers antérieurs sont conservés sans modification. Le dossier LOT272 ajoute des pages de décision sans altérer le moteur commun ni les neuf UP antérieures.
