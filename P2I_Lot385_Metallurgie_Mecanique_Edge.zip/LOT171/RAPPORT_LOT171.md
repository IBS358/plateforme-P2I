# P2I — Lot 171 — Contrôle pluriannuel des scénarios Lot 170

## Résultat

- 960 combinaisons déclarées testées au Lot 170, dont 45 satisfont ses critères A1.
- Seuls **8 exemples détaillés** figurent dans le JSON du Lot 170.
- Parmi ces exemples, **0** présentent un résultat net non négatif en A1, A2 et A3.
- **0** franchissent simultanément ce contrôle, la marge A1 de 6 %, la trésorerie positive et l'équilibre du bilan.
- Le premier scénario Smartphones (1 350 unités, 188,50 USD) présente RN A1 **18 370,35 USD**, RN A2 **−39 594,60 USD** et RN A3 **−32 307,96 USD** : **rejet du statut de BP satisfaisant sur trois ans**.

## Portée et limites

Ce contrôle examine les données **archivées** du Lot 170, sans inventer de prix ni de résultats. Le fichier disponible ne contient pas les 960 simulations détaillées ; les 45 cas réussis en A1 ne peuvent donc pas être tous requalifiés sur trois ans. Un résultat net A2/A3 négatif ne prouve pas à lui seul une insolvabilité, mais empêche de présenter le scénario comme durablement rentable. Aucun BP nouveau n'est déclaré achevé.

## Fichiers

- `CONTROLE_PLURIANNUEL_SCENARIOS.csv` : contrôle de chaque exemple disponible.
- `CONTROLE_PLURIANNUEL.json` : données vérifiables et limites.
- `CONTROLE_PLURIANNUEL.html` : consultation locale Edge.

## Tests

Vérification des 8 exemples du JSON, cohérence RN/CA et marge A1, cohérence du nombre de périodes (3), ouverture des fichiers, intégrité ZIP. Aucun test interactif Microsoft Edge exécuté. Aucune modification GitHub.
