# P2I — Lot 256 — Capacité effective et approvisionnement PEHD/PP

Base cumulative : lot 255, inchangé. Ajout d’un calcul explicite des goulets d’étranglement pour une usine industrielle PEHD/PP.

## Méthode
Deux équipes de 8 h, 22 jours/mois, 12 mois; utilisation 50/70/85%; lavage 2 ou 3 t/h; granulation 1, 1,5, 2 ou 3 t/h. Rendement paillettes 82% (hypothèse héritée du lot 255), rendement de granulation 97% (nouvelle hypothèse illustrative). Capacité réelle = minimum du flux de paillettes et de la capacité annuelle du granulateur. Aucune vente de paillettes excédentaires n'est présumée.

Le prix fournisseur 345-630 k USD concerne une configuration de lavage 2 t/h avec granulation 1-1,5 t/h; il ne valide pas une ligne de 3 t/h ni un CAPEX rendu site. Les coûts de douane, énergie, eau, foncier, collecte, BFR, fiscalité et dette restent non validés.

## Décision industrielle provisoire
Ne pas annoncer 2 t/h de granulés finis sur la seule base d'un laveur 2 t/h. Pour 2 t/h d'intrants et 70% d'utilisation, prévoir environ 5 914 t/an de déchets à approvisionner; granulés vendables entre environ 2 868 et 4 302 t/an selon granulateur 1 ou 1,5 t/h (hypothèses ci-dessus). Vérifier par contrats les tonnages, la qualité et les débouchés.

## Réserves
Les statistiques nationales de déchets plastiques divergent fortement selon sources et périmètres; elles ne prouvent pas la disponibilité de PEHD/PP propre. Aucune rentabilité, simulation v107 ou conformité de BP n'est validée. Les sept autres UP restent à chiffrer.
