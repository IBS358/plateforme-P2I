# Lot 198 — Ventilation des coûts de deux UP

Base : archive complète Lot 197. Deux modules de chiffrage remplacés en conservant leurs chemins historiques et les liens des BP. Les dix postes de chaque nomenclature sont conservés ; ajout de plusieurs lignes par poste pour séparer investissements, charges variables et charges fixes annuelles. Les données existantes des Lots 193–197 ne sont pas modifiées.

**Limites :** aucune donnée fournisseur nouvelle, aucun résultat v107 nouveau. Les totaux restent partiels ; un poste couvert n'implique pas que tous ses sous-composants soient chiffrés. Les saisies enregistrées dans les anciens formulaires Lot 197 ne sont pas migrées automatiquement. Le test visuel manuel Microsoft Edge reste à réaliser.
