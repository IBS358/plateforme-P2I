# Lot 317 — Recyclage & Valorisation

## Livraison et méthode

Les huit BP Lot315 restent les fiches de base, avec leurs 17 rubriques, illustrations, variantes, liens de navigation et impression navigateur. Une annexe Lot317 a été ajoutée à chacune. L’index Lot316 redirige désormais vers l’index commun Lot317 ; l’index historique Lot316 est conservé.

Une configuration industrielle unique a été modélisée par UP. Les prix publics de machines sont repris des références listées dans `CONFIGURATIONS_8UP.json`; la ligne auxiliaire, le transport, l’installation, la manutention, les utilités et le site apparaissent distinctement comme estimations P2I lorsqu’ils ne disposent pas d’un prix catalogue public.

Le calcul est réellement exécuté par `runtime/script-11.js`, fonction `P2I_BP_SIMULATION_COMMUNE.calculer`, avec financement 40 % apport / 60 % dette. La production est ajustée à la capacité et au rendement retenus. Le prix de vente, les coûts de collecte et les charges variables restent ceux des hypothèses historiques LOT298/301, converties au taux de travail 600 XOF/USD; ils ne constituent pas des prix ou volumes de marché validés. Le personnel est désormais visible sous forme d’une estimation annuelle par UP; il est imputé à l’enveloppe de charges fixes historiques proratisée afin d’éviter un double comptage des charges, mais sa compatibilité avec les frais fixes d’origine reste à confirmer.

## Résultats

Voir `SYNTHESE_V107.csv` et `RESULTATS_V107.json` pour les résultats A1–A3, la trésorerie mensuelle, le BFR, les bilans et les contrôles moteur.

- Les bilans v107 sont équilibrés sur les huit calculs.
- La trésorerie mensuelle A1 est positive selon le modèle pour les huit configurations, avec les réserves initiales requises affichées.
- Compost : marge nette A1 indicative faible et positive après redimensionnement ; non validée au regard de la forte incertitude sur le prix de vente et l’écoulement des volumes.
- Verre : déficit A1 indicatif.
- Pneus : déficit A1 indicatif.
- Huiles : positif dans la simulation, mais marge A1 sous 6 % et aucune preuve d’achat d’huile usagée ou de vente d’huile régénérée.
- DEEE : déficit A1 indicatif; configuration limitée aux appareils de froid, tandis que le scénario de recettes conserve la base historique DEEE générique — incohérence de périmètre empêchant la validation.
- Plastique, papier-carton et métaux : résultats positifs indicatifs; les capacités annoncées et le périmètre machine doivent être rapprochés d’une configuration intégrée avant validation.

Aucune vente, commande ou marge cible n’a été inventée pour forcer un résultat. Les configurations avec marge positive demeurent des scénarios d’orientation, pas des business cases validés.

## Références publiques exploitées

- Plastique : Polytec, catalogue PE/PP, 500–1 000 kg/h, FOB 105–115 kUSD (retenu 115 kUSD).
- Papier : Henan Kunteng KT-120, offre publique 15 899–18 600 USD et plage 5–8 t/h sur le listing TradeIndia (retenu 18 600 USD).
- Métaux : ENERPAT AMB-L2014-250, listing public 80–140 kUSD et 2–10 t/h selon matière (retenu 140 kUSD).
- Compost : ligne poudreuse 5 t/h annoncée à 45 kUSD; incoterm et périmètre exacts non affichés.
- Verre : Henan Jingwel, ligne verre 5–10 t/h, 9 kUSD FOB sur le catalogue public; variante et périmètre exact non détaillés.
- Pneus : Anhui Well, ligne 3 t/h à 120 kUSD FOB.
- Huiles : Shangqiu Sanrong WR-W1, 20 t/j à 89,9 kUSD affichés; incoterm absent et rendement technique du scénario reste prudent.
- DEEE : Henan Paibo, ligne réfrigérateurs à 600 kg/h et 17 kUSD affichés; incoterm non publié.

Les URLs, fabricant, modèle, prix et limites figurent dans `CONFIGURATIONS_8UP.json`. Les coûts complémentaires sont des estimations et ne sont pas étiquetés comme prix fournisseur.

## Tests exécutés

- Recalcul réussi avec le moteur commun v107 pour huit configurations.
- 3 exercices de compte de résultat, 36 mois de production et 12 mois de trésorerie A1 disponibles par UP.
- 12 mois de trésorerie A1 et 3 bilans par UP.
- Contrôle de financement 40/60 exécuté dans le moteur.
- Équilibre des huit bilans : écart nul au seuil moteur.
- 17 rubriques héritées conservées par fiche; chemins locaux des images et liens vérifiés par test d’intégrité locale.
- Impression/PDF via navigateur conservée (impression Microsoft Edge).

## Réserves empêchant la validation financière définitive

Les données suivantes restent indispensables : prix de vente contractuels ou observations locales récentes par qualité de matière; accords de collecte et quantités disponibles; spécifications et rendement garantis par les fabricants; coût de transport/importation décomposé; coûts d’électricité, eau, traitements, personnel et maintenance propres aux lignes; débouchés et taux de rejet des produits finis. Le DEEE nécessite en plus de recalculer une nomenclature et des prix de fractions limités aux réfrigérateurs. Les résultats v107 sont donc techniquement exécutés et équilibrés, mais les huit projets ne sont pas tous validés économiquement ou commercialement.
