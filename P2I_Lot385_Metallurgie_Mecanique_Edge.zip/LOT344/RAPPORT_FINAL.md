# Lot 344 — Consolidation opérationnelle des huit BP Recyclage & Valorisation

Base : archive complète du lot 343. Aucun recalcul, aucun changement de configuration ou de résultat financier.

## Périmètre de la livraison
- Index unique vers les huit pages BP existantes.
- Conservation des 17 rubriques, des blocs 2 et 17, des galeries et des postes déjà illustrés.
- Pas de nouvelle exigence de 54 photographies différentes pour la phase Découverte.
- Images IA à valeur illustrative ; le logo P2I original doit être conservé comme référence distincte.

## Résultats A1 conservés
- Recyclage plastique : 21,26 %
- Papier-carton : 16,97 %
- Métaux : 18,24 %
- Compost : 21,67 %
- Verre : 3,20 % (acceptée)
- Pneus usagés : 9,06 %
- Huiles usagées : 17,99 %
- DEEE — équipements frigorifiques : 18,05 % (conditionnelle)

## Réserves
- Verre : 3,20 % accepté, sans prétendre atteindre 6 %.
- DEEE : 18,05 % conditionnel à une rémunération de dépollution de 300 USD/t.
- Prix de vente, volumes et contrats de collecte : hypothèses Découverte à approfondir dans le BP Pro.
- La présence d’une rubrique ou d’une image ne prouve pas sa conformité éditoriale ou technique complète.

## Contrôles automatiques des ressources
- Recyclage plastique: 30 images HTML, 0 référence(s) manquante(s), 0 ancre(s) interne(s) non résolue(s)
- Papier-carton: 28 images HTML, 0 référence(s) manquante(s), 0 ancre(s) interne(s) non résolue(s)
- Métaux: 28 images HTML, 0 référence(s) manquante(s), 0 ancre(s) interne(s) non résolue(s)
- Compost: 30 images HTML, 0 référence(s) manquante(s), 0 ancre(s) interne(s) non résolue(s)
- Verre: 30 images HTML, 0 référence(s) manquante(s), 0 ancre(s) interne(s) non résolue(s)
- Pneus usagés: 30 images HTML, 0 référence(s) manquante(s), 0 ancre(s) interne(s) non résolue(s)
- Huiles usagées: 30 images HTML, 0 référence(s) manquante(s), 0 ancre(s) interne(s) non résolue(s)
- DEEE — équipements frigorifiques: 30 images HTML, 0 référence(s) manquante(s), 0 ancre(s) interne(s) non résolue(s)

## Décision de périmètre
Cette livraison est une consolidation exploitable des BP Découverte. Elle ne certifie pas la validation commerciale, la correspondance photographique exacte avec chaque modèle fournisseur, ni un test visuel manuel exhaustif.
