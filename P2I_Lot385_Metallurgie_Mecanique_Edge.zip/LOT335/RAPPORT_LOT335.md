# Lot 335 — Recyclage & Valorisation

Livraison cumulative depuis le lot 334.

- 8 BP Découverte conservés, 17 rubriques numérotées présentes dans chaque BP.
- 54 schémas fonctionnels de postes individuels ajoutés directement dans le bloc 17 (non photographiques et non contractuels).
- Images existantes et variantes conservées.
- Aucun recalcul ni changement de marge; verre à 3,20 % accepté, DEEE conditionnel à 300 USD/t de prestation.
- Les photographies authentiques des machines ne sont pas présentes et ne sont pas présentées comme réalisées.
- Contrôle de présence de rubriques et de liens images, pas validation de complétude éditoriale ou commerciale.

Ouvrir `P2I_Edge/OUVRIR_LOT335.html` après extraction.
