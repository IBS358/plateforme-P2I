# Lot 310 — couverture des postes

54 postes audités. Aucun prix précis modèle/capacité/poste n’est démontré par les seules annonces consolidées. 2 nouvelles annonces pneus avec fourchettes publiques FOB mais sans attribution à une ligne précise 4 t/h. Les 8 BP précédents sont conservés inchangés. Ne pas confondre ce contrôle de couverture avec la finalisation des investissements. Prochaine priorité : catalogue complet à modèle et capacité exacts ou reconfiguration industrielle chiffrable, sans devis officiels.
