# P2I — Lot 180 : contrôle de décision remorque 3 tonnes

## Point de départ
Archive complète Lot 179. Aucune modification des fichiers antérieurs, du moteur v107 ou de `main`.

## Livré
- Page locale Edge autonome de saisie et de qualification des 10 familles de coûts manquants.
- Calcul du coût direct indicatif seulement si tous les montants sont renseignés ; contrôle des valeurs négatives et invalides.
- Sept validations techniques, commerciales et d'investissement explicitement séparées des prix.
- Frontière inverse de **marge brute** pour un prix hypothétique, sans la présenter comme marge nette v107.
- Script testable avec Node et contrôles automatisés.

## Résultat de référence conservé
Acier livré Abidjan : 614,04 USD ; deux essieux Darong FOB : 438,60–543 USD ; sous-total incomplet : 1 052,64–1 157,04 USD. Prix historiques Lot 154, non revalidés. L'ensemble ne constitue pas une nomenclature dimensionnée pour 3 t de charge utile.

## Non réalisé
Aucun prix ivoirien, coût complet ni BP v107 3 t validé. Les données manquantes ne sont pas remplacées par des zéros. Aucun test graphique manuel dans Edge.

## Tests
`node P2I_Edge/LOT180/test180.cjs` ; contrôle syntaxique JS ; intégrité de l'archive. La page est conçue pour une utilisation locale dans Microsoft Edge.
