# Lot 129 — garde-fou catalogue actif et consolidation BTP ciblée

Date : 14 novembre 2026. Base de travail : source extraite Lot 128, sans écraser les ZIP historiques Lot 127 et Lot 128. Aucun changement GitHub/main.

## Catalogue actif et décisions de remplacement

Le catalogue actif porte 96 identifiants uniques répartis dans 12 filières. Le registre central `runtime/catalogue-up-actif.js` contrôle les identifiants des données, la présentation et les filières; il bloque les doublons, les identifiants absents et les anciennes clés retirées. La navigation et les fiches reçoivent la même liste active. Les anciens liens conservés sont redirigés vers l’identifiant du remplacement, sans réactiver l’ancienne fiche. Le tableau d’accueil statique a également été réaligné sur ces identifiants.

Les clés héritées des anciennes données ont été dissociées des UP actives : `cimenterie` (ancien libellé Mini-cimenterie) est remplacée dans le catalogue actif par `colles_enduits` — **Colles et enduits**; `javel` (ancien libellé Eau de Javel) est remplacée par `hygiene_desinfection_pro` — **Hygiène & désinfection professionnelles**. Les anciennes matrices Lot 117/122 sont conservées telles quelles comme historique. Le libellé Mini-cimenterie figurant dans le rapport visuel Lot127 est ancien et ne définit pas le catalogue courant.

Les huit UP BTP actives sont : Colles et enduits, Briques et tuiles, Éléments préfabriqués, Tuiles et éléments toiture, Agglos et parpaings, Peintures bâtiment, Centrale à béton, Menuiserie aluminium/PVC. Mini-cimenterie n’est ni une neuvième UP ni une clé active.

## Calculs BTP consolidés

Les huit scénarios de référence ont été recalculés par le moteur industriel et financier commun, avec 40 % d’apport et 60 % de dette. Tous produisent un compte de résultat sur 3 ans, un bilan équilibré à la précision flottante du calcul et 12 mois de trésorerie sans solde négatif.

| UP | RN A1 USD | Marge nette A1 | ROI A1 | Trésorerie minimale 12 mois |
|---|---:|---:|---:|---:|
| Colles et enduits | 79 515,02 | 6,89 % | 28,40 % | 30 208,75 USD |
| Briques et tuiles | 14 557,39 | 7,19 % | 32,39 % | 5 303,74 USD |
| Éléments préfabriqués | 31 198,32 | 8,08 % | 22,62 % | 15 523,24 USD |
| Tuiles et éléments toiture | 114 046,29 | 15,50 % | 38,67 % | 35 825,91 USD |
| Agglos et parpaings | 47 380,60 | 10,30 % | 40,19 % | 14 422,26 USD |
| Peintures bâtiment | 55 827,64 | 6,57 % | 36,54 % | 16 830,77 USD |
| Centrale à béton | 142 247,53 | 8,04 % | 49,38 % | 32 758,58 USD |
| Menuiserie aluminium/PVC | 85 323,10 | 12,54 % | 124,11 % | 9 245,09 USD |

Les marges de Colles et enduits, Briques et tuiles, Éléments préfabriqués, Peintures bâtiment et Centrale à béton restent sous le repère indicatif de 10 %. Les chiffres du moteur ne sont pas relevés pour atteindre ce repère. L’interface signale le caractère indicatif et le besoin de qualifier volumes, prix de vente, intrants et références de machines; les décisions commerciales et devis seront approfondis au BP Pro.

## Vérifications ciblées exécutées

- Registre chargé après `script-16.js` : 96 UP, 12 filières, aucun doublon/manquant, clés retirées absentes; huit IDs BTP actifs confirmés.
- Chargement/rendu isolé de chacune des huit fiches BTP : 17 rubriques, fond de rubrique 2 présent, aucun blocage JavaScript; les quatre panneaux commerciaux communs sont présents (des `<details>` supplémentaires viennent d’autres blocs).
- Moteur commun recalculé sur les huit scénarios : 12 mois de trésorerie et trois bilans équilibrés par UP; soldes minimums positifs.
- `node --check` des scripts modifiés : réussi.

Le test a été exécuté dans un navigateur simulé/VM avec ressources locales, pas dans le Edge de l’utilisateur. Il ne constitue pas une certification des prix, des débouchés ou de conformité réglementaire. Aucun ZIP n’est produit dans ce correctif intermédiaire.

## Fichiers modifiés dans le point de reprise

- `index.html`, `accueil-local.html` : chargement du registre central et liens d’accueil alignés.
- `runtime/catalogue-up-actif.js` : liste active unique et assertions de cohérence.
- `runtime/script-0.js`, `script-1.js`, `script-16.js`, `script-17.js`, `script-18.js`, `script-19.js` : renommage des clés actives héritées et raccordement des textes, visuels et scénarios aux remplacements.
- `MATRICE_96_UP.csv` : huit lignes BTP mises à jour selon les calculs courants; les matrices historiques restent intactes.
- `MATRICE_SUIVI_BTP_LOT129.csv` : détail des résultats et réserves des huit scénarios.
- `runtime/build-manifest.json` : versionnement du registre actif Lot129.
