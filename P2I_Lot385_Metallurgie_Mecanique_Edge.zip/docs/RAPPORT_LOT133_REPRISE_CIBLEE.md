# Lot 133 — reprise financière ciblée et rubrique 17

> Note de clôture : le présent compte rendu décrit la première reprise ciblée. Il est complété et remplacé pour la conclusion économique et l’archive téléchargeable par `docs/RAPPORT_LOT133_ARBITRAGE_ECONOMIQUE.md`.

Date : 14 novembre 2026. Base : Lot 132 complet. Périmètre : trois scénarios déficitaires, 11 rubriques 17 signalées. Aucun autre scénario ni la filière Assemblage n’a été modifié.

## Décision financière

Le moteur commun a été exécuté sur les trois scénarios actifs inchangés. Les trois bilans sont équilibrés, le financement est à 40/60 et la trésorerie minimale A1 est positive. Aucun nouveau scénario positif n’a été intégré : il manquerait des preuves de prix nets et de ventes pour ajuster les paramètres sans fabriquer de débouchés.

| UP | Cause principale observée | Résultat commun A1 | Résultat A2 / A3 | Suite requise |
|---|---|---:|---:|---|
| Boulangerie industrielle | Produit de référence « petits pains ronds frais » ; prix net commercial non documenté. L’A1 absorbe la paie du dirigeant, les charges fixes, l’amortissement et les intérêts à seulement 40 t vendues. | –5 524,88 USD (–5,76 %) | +8 683,66 USD / +21 873,84 USD | Ne pas relever le programme A1 sans commandes ou étude de débouchés. Obtenir prix net boulangerie/gros par format, coût complet et volumes achetables. |
| Non-tissés & textiles techniques | Le coût de production A1 (1,7086 USD/kg) dépasse le prix simulé (1,55 USD/kg) avant frais de structure. Le RN reste négatif sur les trois années, même si le coût unitaire baisse avec le volume. | –74 733,40 USD (–62,13 %) | –63 350,96 USD / –54 291,25 USD | Configuration économiquement bloquée dans son état actuel. Il faut documenter un coût matière réellement rendu et un prix B2B vérifiable, ou présenter une activité de remplacement avec sa ligne et ses données sourcées. Aucun remplacement n’a été activé. |
| Recyclage & valorisation textile | Contribution brute positive, mais insuffisante en A1 pour couvrir direction, autres charges, amortissement et dette. La vente de 300 t/an en A3 donne seulement +2,23 % et n’est pas étayée par des commandes. | –19 580,88 USD (–14,02 %) | –5 049,27 USD / +5 352,64 USD | Une montée en charge plus rapide ne peut pas être intégrée sans demande vérifiable. Documenter les clients utilisant ces fibres et les volumes annuels acceptables. |

Repères de trésorerie A1 : boulangerie 8 911,19 USD ; non-tissés 20 680,60 USD ; recyclage textile 7 430,60 USD. Les écarts actifs-passifs sur trois ans sont négligeables (erreurs numériques de l’ordre de 10⁻¹⁰ USD). Les scénarios restent des simulations indicatives, non des validations commerciales ou bancaires.

**Conclusion économique :** les trois objectifs de résultat net A1 positif ne sont pas atteints. Aucun prix, volume, effectif ou charge n’a été modifié. L’UP non-tissés est la seule dont la marge industrielle elle-même est négative en A1 au prix et coût actuels; aucun remplacement documenté ne peut être proposé à partir du Lot 132 seul.

## Rubrique 17 — séquences affichées après correction

| Identifiant actif | Activité affichée | Postes |
|---|---|---:|
| jus_boissons | Production de jus et boissons | 10 |
| engrais | Engrais & pesticides | 7 |
| recyclage_metaux | Rideaux métalliques et portails sur mesure | 6 |
| sacs | Centre intégré d’emballage personnalisé | 7 |
| bouteilles_pet | Bouteilles PET | 6 |
| tuyaux_pvc | Tuyaux PVC | 6 |
| emballages | Emballages plastique | 5 |
| profiles | Profilés plastique | 6 |
| jouets | Films étirables alimentaires & palettes | 6 |
| joints | Joints et pièces caoutchouc | 4 |
| granules | Feuillards de cerclage PP | 6 |

La liste historique des 11 signalements mélange des identifiants actifs réaffectés : `recyclage_metaux` affiche actuellement les rideaux/portails, `sacs` le centre intégré d’emballage, `jouets` les films étirables et `granules` les feuillards. Aucun ancien procédé n’a été réactivé pour ces identifiants.

Quatre planches IA ont été intégrées et compressées en WebP pour les postes des rideaux/portails, bouteilles PET, tuyaux PVC et profilés PVC. Elles sont explicitement déclarées comme illustrations non contractuelles, pas comme photos des fournisseurs. Les postes sans caractéristiques de machine individualisées les signalent au lieu de les inventer. L’engrais utilise ses images de procédé existantes. Les autres rendus conservent leurs séquences existantes.

## Contrôles réellement exécutés

- Syntaxe `runtime/script-18.js` (`node --check`) : PASS.
- Rendu ciblé des 11 UP et séquence sans doublons ni rupture de numérotation : 11/11 PASS ; 63 postes affichés au total.
- Présence d’une image dans chacune des cartes de poste lorsque le rendu utilise des cartes : PASS ; les formats historiques à galerie/tableau conservent leurs visuels et séquences.
- Présence des quatre fichiers image WebP et chemins relatifs : PASS.
- Non-régression des données/moteur financiers par comparaison Lot 132 : `script-11.js`, `script-16.js`, catalogue actif et garde-fou économique inchangés. Les autres scénarios, dont la Biscuiterie, n’ont pas été recalculés avec des hypothèses modifiées.

Fichiers modifiés dans la plateforme : `runtime/script-18.js`, `scripts/test-lot133-render.cjs`, `assets/media/lot133-rideaux-portails-processus.webp`, `assets/media/lot133-bouteilles-pet-processus.webp`, `assets/media/lot133-tuyaux-pvc-processus.webp`, `assets/media/lot133-profiles-pvc-processus.webp`, ce rapport et le résultat JSON du test. Le ZIP Lot 132 original et les archives précédentes restent inchangés.

## Limite de livraison

Aucun ZIP consolidé n’est produit dans ce lot : les trois conditions économiques demandées — RN A1 positif sans hypothèses artificielles — ne sont pas remplies. Le Lot 132 reste la version complète téléchargeable de référence ; les corrections Lot 133 demeurent dans l’arbre de travail jusqu’à une décision sur la solution économique des non-tissés et la documentation de ventes nécessaire aux deux scénarios de montée en charge.
