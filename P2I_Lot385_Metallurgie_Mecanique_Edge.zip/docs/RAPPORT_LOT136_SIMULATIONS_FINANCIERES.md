# P2I — Lot 136 : simulations financières ciblées des trois UP

**Date :** 15 novembre 2026  
**Base complète :** Lot 133 (`P2I_Edge_96_UP_Lot133_Complet.zip`), avec les ajustements de référence de la Boulangerie consignés dans les sources de travail et le dimensionnement Lot 135.  
**Périmètre modifié :** scénario actif de Boulangerie; calcul exploratoire de deux candidats non activés pour Non-tissés et Recyclage textile. Aucune autre UP et aucune donnée Assemblage modifiées.  
**Moteur commun :** version 107.

## Décision en bref

- **Boulangerie :** nouvelle simulation centrale exécutée pour du pain de mie tranché, sur une ligne annoncée à 300 kg/h. Les calculs sont positifs, mais les prix nets par canal, le coût de recette et les volumes restent des hypothèses P2I. Statut : **calculée, indicative, à qualifier commercialement** — pas une validation d’investissement.
- **Non-tissés :** candidat géotextile PP aiguilleté de 200 g/m² sur AL‑TGB. Le résultat A1 demeure déficitaire à –17,31 %. Le seuil de 6 % serait atteint à environ 645 t vendues en A1 au prix-proxy utilisé; aucune demande locale de ce volume n’est établie. Le candidat n’est donc pas intégré comme scénario actif rentable.
- **Recyclage textile :** candidat chiffons industriels découpés. Après prise en compte d’un rendement matière de 90 % et du coût de collecte déjà retenu dans la P2I, le scénario reste fortement déficitaire. Le seuil de rentabilité nécessiterait environ 219 t/an de produit fini, soit 243 t de chutes propres avec 90 % de rendement; ce besoin dépasse le repère sectoriel brut de 198 t/an cité par la source secondaire. Candidat non intégré comme référence active.

Les scénarios historiques restent préservés dans les données et dans les archives. Les deux candidats textiles sont fournis comme simulations de décision, non comme options d’équipement proposées à l’investisseur.

## Résultats effectivement calculés

Montants en USD. Les volumes A1/A2/A3 sont production puis ventes; dans les trois simulations, la production planifiée égale les ventes planifiées (variation de stock de produits finis nulle). Les stocks de matières, délais clients, BFR, dette et amortissement sont calculés par le moteur.

| UP / scénario | CAPEX | CA A1 / A2 / A3 | Résultat net A1 / A2 / A3 | Marge nette A1 / A2 / A3 | Trésorerie minimale A1 | BFR M12 A1 | Réserve de démarrage supplémentaire |
|---|---:|---:|---:|---:|---:|---:|---:|
| Boulangerie — pain de mie tranché | 155 000 | 492 900 / 754 200 / 1 025 700 | 86 980 / 213 737 / 347 589 | 17,65 % / 28,34 % / 33,89 % | 17 916 | 26 094 | 33 559 |
| Non-tissés — géotextile PP aiguilleté 200 g/m² | 700 000 | 675 000 / 945 000 / 1 215 000 | –116 873 / –50 286 / 11 448 | –17,31 % / –5,32 % / 0,94 % | 70 000 | 66 603 | 280 842 |
| Recyclage textile — chiffons industriels | 35 000 | 40 000 / 60 000 / 80 000 | –50 044 / –44 156 / –38 401 | –125,11 % / –73,59 % / –48,00 % | 3 500 | 1 093 | 55 216 |

Tous les bilans des trois exercices sont équilibrés à l’arrondi numérique près. Le financement du **CAPEX** respecte 40 % d’apport et 60 % de dette. La réserve de démarrage est ajoutée séparément et financée par apport dans le moteur : elle augmente donc l’apport total requis. Trésorerie calculée sur 12 mois; BFR et comptes sur 3 ans.

### Boulangerie — hypothèses de référence

- Capacité annoncée : 300 kg/h; calendrier de planification P2I : 8 h/j × 250 j/an × 90 % disponibilité × 95 % rendement = **513 t/an**. Production et ventes simulées : **150 / 225 / 300 t**, soit 29 % / 44 % / 58 % du plafond; stock fini simulé : 0 t/an.
- Prix public observé : pain de mie 500 g à 1 300 FCFA au détail, soit 2 600 FCFA/kg. Ce prix n’est ni un prix de gros ni un prix départ usine.
- Hypothèses de prix nets A1 par canal : écoles/restauration collective 1 560 FCFA/kg (20 % des ventes); entreprises/hôtels/restaurants 1 820 (20 %); supermarchés/commerces 1 950 (40 %); vente directe 2 340 (20 %). Les remises appliquées au prix de détail, le mix, les prix nets et les volumes sont des **estimations P2I à vérifier**, sans contrats acquis. Prix moyen pondéré moteur : 3,286 USD/kg A1; croissance nominale 2 %/an.
- Coûts utilisés : matières 0,55 USD/kg; coût industriel complet 1,05 USD/kg (matières, emballage, énergie et consommables); distribution/livraison 0,12 USD/kg; personnel 25 200 USD/an; charges fixes 65 000 USD/an. Le coût de recette est une enveloppe P2I, pas une nomenclature fournisseur validée.
- Investissement : 75 000 USD FOB, borne haute publique d’une offre dont le titre annonce 300 kg/h; la source ne relie pas sans ambiguïté ce prix précis à cette cadence. Compléments P2I estimatifs : 80 000 USD. CAPEX total : 155 000 USD. Apport CAPEX 62 000; dette 93 000; réserve initiale distincte 33 559 USD.
- Seuils de prix, volumes et coûts inchangés : résultat net A1 nul à 2,513 USD/kg; marge nette 6 % à 2,731 USD/kg; marge 8 % à 2,813 USD/kg. Ce sont des seuils calculés, pas des prix retenus.
- Le modèle ne retient financièrement qu’un produit de référence : pain de mie tranché. Petits pains et autres formats ne sont pas ajoutés aux recettes, faute de confirmation du périmètre exact de la ligne et de nomenclatures séparées.

**Limites à qualifier :** portée réelle de la ligne intégrée (pétrissage, fermentation, cuisson, refroidissement, tranchage, ensachage), lien exact entre prix et capacité 300 kg/h, formulation et rendement de recette, prix nets de gros, frais/retours de livraison, mix de clients et montée en charge commerciale. Les marges A2/A3 supérieures à 20 % résultent notamment de l’effet volume sous charges fixes quasi stables; elles demandent une revue économique avant tout usage public comme prévision centrale.

### Non-tissés — hypothèses et seuil de redimensionnement

- Configuration candidate : AL‑TGB 5000 mm, aiguilletage PP, géotextile 200 g/m²; largeur utile retenue 5 m. À la borne publiée de 650 kg/h, cela représente 3 250 m²/h et un plafond de planification de 1 111,5 t/an (8 h × 250 j × 90 % × 95 %). Cela ne constitue ni une capacité garantie pour ce grammage ni une prévision commerciale.
- Prix d’équipement public : 350 000 USD FOB/set; le catalogue ne relie pas explicitement ce prix à la borne haute de capacité. CAPEX complet : 700 000 USD, dont 350 000 USD de compléments estimatifs P2I. Les postes détaillés totalisent ce budget.
- Produit simulé : 200 g/m², donc 5 m²/kg; surfaces A1/A2/A3 : 1,25 / 1,75 / 2,25 millions m². Production et ventes : 250 / 350 / 450 t/an; aucun stock fini.
- Prix de vente 2,70 USD/kg : annonce publique de géotextile PP aiguilleté 200 g/m² à 2 700 USD/t FOB, même famille de technologie; utilisé comme **repère export/proxy**, pas comme prix net local livré ou départ usine. Matière : 1,45 USD/kg FOB observé pour une fibre PP staple comparable 2D/4D/6D, 51/64 mm; +0,10 USD/kg logistique P2I estimée, puis rendement 98 % P2I. Coût de transformation 0,35 USD/kg; emballage 0,04; distribution 0,08.
- À prix et coûts inchangés, seuil A1 de rentabilité : environ **430 t**; seuil de marge nette 6 % : **645 t**. Ce dernier équivaut à 58 % du plafond technique calculé, mais il manque une preuve de demande locale pour ce tonnage. Le candidat reste déficitaire dans le scénario central.

**Limites à qualifier :** prix rendu réel des fibres en Côte d’Ivoire, qualité requise des matières, cadence garantie pour 200 g/m² et largeur utile, propriétés/essais du produit, prix B2B départ usine et volumes accessibles. Le prix de détail d’un autre géotextile ou d’une technologie thermoliée n’a pas été transféré au calcul.

### Recyclage textile — hypothèses et faisabilité d’approvisionnement

- Configuration candidate : tri manuel et retrait des composants impropres, GM800C pour la coupe, contrôle, pesée/pliage et mise en balles. La GM800C n’est pas traitée comme une ligne complète. Borne haute catalogue 800 kg/h; puissance annoncée 7 kW (5,5 + 1,5). CAPEX cellule 35 000 USD : coupeuse 4 500 USD FOB, auxiliaires et compléments P2I estimatifs 30 500 USD.
- Produit : chiffons industriels coupés à partir de chutes propres pré-consommation; lavage et ouverture de fibres exclus de cette chaîne. Production/ventes : 50 / 75 / 100 t/an; stockage fini nul.
- Prix 0,80 USD/kg : borne haute d’annonces publiques d’export de chiffons industriels, pas prix local. Matière/collecte : 0,24 USD/kg d’achat des chutes + 0,06 de collecte et transport par kg brut (repères P2I antérieurs, comparateur étranger, non tarifs ivoiriens), divisés par un rendement de 90 %. Transformation 0,08/kg, emballage 0,04/kg, distribution 0,05/kg.
- Besoin d’approvisionnement brut : **55,6 / 83,3 / 111,1 t/an** pour 50 / 75 / 100 t de chiffons finis; résidus de tri/perte : 5,6 / 8,3 / 11,1 t. Seuil de rentabilité moteur : 218,7 t finis/an, requérant **243,0 t bruts/an**; seuil de marge 6 % : 278,8 t finis, requérant **309,8 t bruts/an**. Le repère secondaire disponible de 198 t/an est un gisement brut sectoriel national rapporté, pas un inventaire officiel et encore moins une part accessible à l’UP. Même le seuil de rentabilité le dépasse.

**Conclusion :** ce scénario de chiffons finis n’est pas défendable à ce prix et ce niveau de charges à partir des données actuelles. Ne pas le publier comme opportunité rentable. Pour redémarrer ce dossier, il faudrait soit un gisement propre contractable supérieur à 243 t/an avec preuve de prix local net dépassant le coût complet, soit une nouvelle activité/produit dont l’approvisionnement, la chaîne et le marché sont documentés. Aucune de ces conditions n’est inventée dans cette simulation.

## Validation exécutée

- `scripts/test-lot136-simulations.cjs` : **7/7 contrôles PASS** — trois scénarios calculés, trois ans de compte de résultat, 12 mois de trésorerie, financement 40/60, CAPEX ventilé, bilan équilibré, candidats textiles non promus.
- `scripts/test-lot136-render.cjs` : **3/3 rendus ciblés PASS** — Boulangerie, Non-tissés, Recyclage textile; séquence de postes continue, sans doublons, illustrations présentes sur chaque carte.
- `node --check` : scripts de données/machines et simulation valides.
- Contrôle des entrées et sorties du moteur : production ne dépasse pas le plafond technique; production = ventes; stock de produit fini nul; taux de perte matière distincts (2 % pour géotextile et 10 % pour chiffons); bilans équilibrés; trésorerie mensuelle positive dans les scénarios simulés uniquement grâce à la réserve de démarrage calculée.

Ces contrôles ciblés ne valent pas certification technique de ligne ni validation commerciale. La plateforme garde 96 UP; ce lot n’a pas relancé l’audit général.

## Sources publiques consultées le 15 novembre 2026

1. [OMEGA/LINKON — ligne de pain de mie, 300 kg/h annoncés, prix public FOB 25 000–75 000 USD](https://omegabake.en.made-in-china.com/product-group/JboQaWRGTYpq/Toast-bread-line-1.html) — capacité exacte/prix exact non appariés.
2. [Marché Facile — pain de mie 500 g à 1 300 FCFA](https://marchefacile.com/produit/pain-de-mie-mf000142.html) — prix au détail, pas prix usine.
3. [Shandong Yaotian — géotextile PP aiguilleté 200 g/m², 2 700 USD/t FOB](https://yaotiangeo.en.made-in-china.com/product/kKwEJdGzgXrm/China-High-Quality-Polypropylene-Non-Woven-Needle-Punched-Geotextile-200g-Sqm-White-and-Black-Color-Manufacturer-Factory.html) — repère export.
4. [Tianjin Glory Tang — fibre PP staple 2D/4D/6D, 51/64 mm, 1,35–1,45 USD/kg FOB](https://glorytanggroup.en.made-in-china.com/product-group/neBadVOEgLpt/Polypropylene-Fiber-1.html) — offre comparable, spécification finale à confirmer.
5. [Made-in-China — chiffons industriels d’essuyage 0,60–0,80 USD/kg](https://www.made-in-china.com/products-search/hot-china-products/Industrial_Wiping_Rags.html) — offre export, non tarif local.
6. [GM800C — coupeuse textile, 500–800 kg/h, puissance publiée 5,5 + 1,5 kW](https://www.made-in-china.com/video-channel/rongdamachinery_fvmEzuwyCKUs_GM800c-Cloth-Textile-Rag-Waste-Cutting-Machine.html) — prix public 2 800–4 500 USD FOB.
7. Rapport FIMORE relayé par L’Observateur : [16,5 t/mois de déchets textiles de couture rapportés](https://lobservateur.info/article/112037/afrique/cote-divoireyamoussoukrorevolutionne-le-recyclage-de-la-mode) — indicateur secondaire, non inventaire officiel; sert uniquement au test de plausibilité du gisement.
