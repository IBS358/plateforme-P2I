# Lot 124 — correction visuelle commune et vérifications ciblées

## Point de départ
Lot 123 Audit (plateforme complète P2I Edge, 96 UP / 12 filières). Les archives Lot 117, 122 et 123 restent conservées; aucun changement GitHub ni à `main`.

## Modifications
- Le moteur visuel partagé accepte désormais une image locale dédiée à l’atelier (`atelier_image`), sans la confondre avec le médaillon produit.
- La même illustration de contexte est affichée dans le bandeau et rappelée en rubrique 17, après le panneau des variantes et avant les postes, avec une qualification explicite.
- Trois fonds absents sont rattachés à des visuels existants dont le sujet correspond au procédé : centre d’emballage flow-pack (`sacs`), extrusion/film plastique (`jouets`, films étirables), fabrication de feuillard PP (`granules`). Avec les 62 routes déjà relevées au Lot 123, le référentiel Lot 124 compte maintenant 65/96 routes d’atelier. Les visuels restent qualifiés comme illustrations IA, non comme photos de machines fournisseur.
- Les images déjà documentées via `atelier_atlas` (dont les alèses et pansements) sont réutilisées et rappelées en rubrique 17. Le rattachement des alèses contenait une clé d’atlas erronée (`p2i-atelier-aleses-v3`); elle a été raccordée à l’atlas existant `p2i-atelier-aleses`.
- Aucun prix, volume, résultat financier, équipement ni référence fournisseur n’a été modifié.

## Limites et statut
Cette correction ne rend pas les 96 UP conformes par elle-même. L’audit du Lot 123 demeure la référence de statut: les BP ne sont pas déclarés terminés ou vérifiés. Les postes dont la photographie exacte n’existe pas restent à qualifier; aucune image de contexte n’est présentée comme photo spécifique d’une machine. Les textes internes et la cohérence de chaque contenu exigent encore une passe éditoriale UP par UP.

## Vérifications réellement exécutées
- `node --check` sur `script-17.js` et `script-18.js` : réussi après correctifs.
- Test unitaire ciblé du bloc commercial avec le marqueur interne injecté dans priorité, différenciation, approfondissement et emballage : le texte interne ne ressort pas et le remplacement cite le produit et le segment client (réussi).
- Présence locale des trois nouveaux fichiers d’image : vérifiée.
- Clés d’atlas : vérification de tous les rattachements `atelier_atlas`; le seul nom invalide a été corrigé.
- Matrices Lot 122 et Lot 123 : 96 lignes chacune, conservées dans la plateforme.
- La feuille `style-5.css` et les deux scripts modifiés sont bien inclus dans `index.html`.
- Matrice Lot 124 : 96 lignes et 96 identifiants distincts; statuts de conformité inchangés par rapport au Lot 123.
- Vérification visuelle Microsoft Edge de l’archive générée : non réalisée dans cet environnement; les visuels et interactions doivent encore être confirmés dans Edge par l’utilisateur.
