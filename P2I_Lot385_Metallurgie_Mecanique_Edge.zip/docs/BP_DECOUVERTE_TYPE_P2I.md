# Référentiel de conformité — BP Découverte P2I

**Version de travail Lot 123 — 13 novembre 2026.** Ce document fixe le modèle à appliquer aux 96 UP. Une rubrique présente dans le menu ne suffit pas à déclarer un BP conforme : son contenu doit être spécifique, lisible, sourcé et cohérent avec le procédé.

## 1. Architecture visuelle commune

- Bandeau P2I bleu nuit avec logo officiel intact, nom de la filière, UP et configuration de référence.
- Cartes de titre qui s’adaptent à la longueur des intitulés, sans coupure au milieu des mots; tailles cohérentes et contrastes lisibles.
- Zone visuelle du produit : image principale en médaillon et variantes distinctes, clairement indiquées comme calculées ou hors calcul.
- Image d’atelier / usine liée au procédé de l’UP, utilisée en arrière-plan avec flou et contraste suffisant. Cette image est également rappelée dans la rubrique 17. Une image d’une autre activité n’est jamais substituée.
- Toutes les images sont locales, avec chemin testé dans Edge. Chaque image est qualifiée : photo documentaire fournisseur/site, photographie illustrative, illustration IA, ou schéma de concept. Une illustration ne prouve ni l’existence d’une machine, ni la conformité d’un produit.
- Menu des 17 rubriques, retour au tableau de bord et export PDF restent accessibles; l’ouverture et la consultation du BP Découverte ne dépendent pas d’un serveur.

## 2. Les 17 rubriques obligatoires

1. **Projet et activité** — identité de l’UP, périmètre, porteur type et formalités communes; CEPICI, RCCM, fiscalité et obligations sociales; implantation; autorisations propres au produit/activité. Les régimes d’incitation sont présentés comme potentiels et sous conditions, jamais acquis.
2. **Synthèse économique** — scénario de référence, produits calculés, résultats clés, statut de validation et limites. Aucune donnée absente n’est transformée en zéro.
3. **Configuration industrielle de référence** — une seule chaîne P2I cohérente, séquence complète des opérations, capacité effective et utilités.
4. **Marché cible et débouchés** — clients, concurrence et prix fondés sur des sources; séparer prix public détaillant, prix grossiste et prix sortie usine. Les prospects ne sont pas des commandes acquises.
5. **Stratégie commerciale, outils et marketing** — sous-parties fixes : *Priorité commerciale*; *Différenciation à démontrer*; *À approfondir dans le BP Pro*; puis *Présentation, suggestions et autres actions commerciales*. Ce dernier sous-bloc couvre emballage, diversification, lancement, communication, distribution, B2B et recommandations propres à l’UP.
6. **Opportunités, contraintes et risques** — risques industriels, commerciaux, d’approvisionnement, réglementaires et de mise en œuvre, avec mesures réalistes.
7. **Investissements et financement** — prix catalogue sourcés, coûts complémentaires estimés identifiés séparément, manutention et réserve/BFR; financement de référence 40 % apport / 60 % dette.
8. **Production, ventes et stocks** — capacité nominale puis effective, disponibilité, rendements, plan de production et ventes non supérieures à la demande justifiable; inventaires cohérents.
9. **Compte de résultat prévisionnel** — trois exercices, charges visibles, amortissements, financement et fiscalité paramétrés; résultats calculés par le moteur commun.
10. **Besoin en fonds de roulement mensuel** — stocks, clients, fournisseurs et délais sans double comptage.
11. **Bilan prévisionnel simplifié** — trois ans et bilan équilibré.
12. **Indicateurs de performance** — marges, seuil de rentabilité, ROI et ratios issus des états calculés, sans cible maquillée.
13. **Financement et trésorerie** — plan mensuel sur douze mois, apport/dette, échéancier et solde sans mois négatif non expliqué.
14. **Hypothèses et traçabilité** — sources, dates, hypothèses P2I, données à qualifier et distinctions entre fait documenté, estimation et point à confirmer.
15. **Du BP Découverte au projet industriel** — prochaines études et décisions réellement nécessaires.
16. **Préparer mon dossier de passage** — éléments à collecter pour la suite, sans promesse d’automatisation ou d’accord de financement.
17. **Dossier technique** — premièrement variantes et visuels; deuxièmement image d’atelier/procédé associée; troisièmement postes numérotés POSTE 01/n à POSTE n/n, chacun avec fonction, machine/référence disponible, rôle, capacité, utilités, compatibilité, source et image concordante. Un poste qui n’a pas de photo réelle peut avoir un schéma ou une illustration explicitement qualifiée, jamais une machine sans rapport.

## 3. Règles d’acceptation financière et industrielle

- Une seule configuration P2I de référence par UP dans le BP Découverte; compatibilité des machines et goulots vérifiés.
- Prix EXW/FOB publics et datés lorsqu’ils existent; compléter par des coûts P2I estimatifs clairement signalés. Aucun devis officiel exigé pour une simulation Découverte.
- Matières, consommations, rendement, effectifs, énergie, emballages, maintenance et commerciaux explicités. Une hypothèse estimative est marquée comme telle et justifiée.
- Moteur commun uniquement : CR et bilan sur trois ans; BFR mensuel; trésorerie 12 mois; financement 40/60; contrôles de cohérence, d’équilibre et de liquidité.
- Une UP est **calculable** seulement si données clés alimentent le moteur; **validée financièrement** seulement après justification des prix, capacités et hypothèses. Une simulation positive ne suffit pas.

## 4. États d’audit

- **Conforme vérifiée** : 17 contenus renseignés et spécifiques, visuels cohérents et chemins testés, chaîne industrielle cohérente, calculs contrôlés ou limites chiffrées documentées, test Edge réussi.
- **À corriger** : élément connu absent, trompeur, provisoire, mal présenté ou incohérent.
- **À qualifier** : source, prix, capacité, réglementation ou hypothèse nécessaire encore manquante; le dossier reste utilisable avec cette limite visible.
- **À tester dans Edge** : contrôles statiques réalisés, mais affichage local ou interactions non encore vérifiés.

Aucune UP ne doit être annoncée terminée avant ces contrôles.


## Addendum Lot 124 — application du contrat visuel

- Le champ `atelier_image` est accepté comme chemin d’image locale dédiée à l’atelier, sans le confondre avec l’image produit du médaillon.
- Toute image d’atelier disponible est utilisée dans le bandeau flouté et reprise en rubrique 17 avec la même qualification. Elle reste distincte des photos individuelles des postes.
- Un atelier sans image précisément rattachée reste signalé « à documenter » ; aucune image d’un autre procédé n’est utilisée pour remplir artificiellement la case.
- Les mentions internes de la famille `Redaction_interne_P2I_a_qualifier_non_etude_de_marche` sont filtrées dans le bloc commercial. La rédaction de remplacement cite le produit de l’UP et les acheteurs à prospecter issus des données, sans inventer de prix, volumes ou contrats.
- L’état de conformité demeure celui de l’audit par UP : la correction d’un composant commun ne suffit pas à marquer une UP conforme.


## Addendum Lot 125 — audit des 17 contenus

- Les 17 titres utilisent une enveloppe de rubrique et un bandeau CSS communs pour les 96 UP. La conformité du contenu est évaluée séparément par rubrique et ne découle pas de la seule présence du menu.
- Le bloc Marché doit reprendre les données de marché et segments de l’UP concernée. Une mention générique d’un autre secteur ne doit jamais écraser ces données. Si elles manquent, la rubrique indique précisément les éléments à relever.
- La matrice Lot 125 qualifie chaque rubrique pour chaque UP selon les données source disponibles; les états « calculable » restent à auditer financièrement et visuellement.
