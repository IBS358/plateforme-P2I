# Lot 133 — arbitrage économique ciblé et correction d’identité active

Date : 14 novembre 2026. Base : plateforme complète du Lot 132 (96 UP/12 filières), avec les correctifs ciblés Lot 133 déjà appliqués à la rubrique 17. L’archive Lot 132 est conservée. Ce lot ne change aucun paramètre économique des trois UP et ne modifie aucun autre scénario.

## Synthèse comparative

| UP | Référence industrielle actuelle | Résultat commun actuel | Piste examinée | Conclusion / action recommandée |
|---|---|---:|---|---|
| Boulangerie industrielle | Petits pains ronds frais, scénario à 40 kg/h; équipement financier 45 511,86 USD; investissements totaux 89 111,86 USD. Une liste historique de sept machines atteint 110 000 USD et ne se rapproche pas du montant chargé dans le scénario : réconciliation nécessaire avant tout nouveau BP. | Prix simulé 2,40 USD/kg; ventes A1 40 t; RN –5 524,88 USD (–5,76 %). A2 +8 683,66 USD (7,09 %); A3 +21 873,84 USD (14,60 %). Trésorerie mensuelle minimale A1 +8 911,19 USD; bilans équilibrés. | Dimensionnement cohérent à étudier à partir des produits déjà compatibles (pains ronds, pains de mie/petits pains si outillage correspondant), avec suivi des invendus et pertes. La référence locale officielle au pain standard est un prix de détail, pas le produit ni le canal du scénario. | **Pas de redressement démontré.** Ne pas augmenter les ventes ni le prix usine. Obtenir prix net boulangerie/gros, poids unitaire et coût complet des emballages/distribution, ainsi que la réconciliation machines 45,5 kUSD / liste historique 110 kUSD. Une petite annonce de 10 petits pains à 500 FCFA n’indique pas le poids et ne permet pas un prix au kg. Sensibilité du seul prix du scénario actuel : seuil RN nul 2,5381 USD/kg; 6 % 2,7588; 8 % 2,8412 — seuils mathématiques, pas prix recommandés. |
| Non-tissés et textiles techniques | Scénario actuel : feutre aiguilleté d’ameublement, 120 kg/h, 99 900 USD d’équipement et 206 806 USD investis. Étapes génériques ouvrantes/mélange, cardage/nappe, consolidation, découpe/enroulement; fabricants, modèles, puissances et références machine non documentés. | Prix 1,55 USD/kg; coût de production A1 1,7086 USD/kg; ventes 77,6 t sur 80 t produites; RN –74 733,40 USD (–62,13 %). A2 –63 350,96; A3 –54 291,25 USD. Trésorerie min A1 +20 680,60 USD; bilans équilibrés. | Comparaison : feutre agricole PP 100 g/m² localement listé en rouleau 3,2 × 100 m, 32,06 kg et prix détaillant 182 322 FCFA; geotextile non tissé localement listé en rouleau 2 × 50 m à 132 760 FCFA, mais grammage/masse absents. Une ligne aiguilletée intégrée publique est listée à 350 000 USD, mais les conditions EXW/FOB ne sont pas données; capacité publiée dépend du produit (100–650 kg/h). La thermolaison/UV du produit agricole et le procédé du géotextile ne sont pas démontrés compatibles avec l’équipement actif. | **Piste prioritaire à instruire : feutre agricole PP**, car sa fiche donne matière, grammage, dimensions et poids; toutefois le prix observé est détail, non départ-usine, et la stabilisation UV/liaison ainsi que la compatibilité de ligne restent à confirmer. Le géotextile est moins documenté en masse et la fiche produit n’établit pas qu’il soit aiguilleté. Ni l’une ni l’autre ne justifie un calcul BP positif aujourd’hui. La sensibilité prix sur le produit actuel (non applicable aux nouveaux produits) donne 2,7316 USD/kg pour 6 % et 2,8131 pour 8 %. Garder l’UP et son historique; ne pas activer de remplacement ni modifier la configuration tant que prix B2B/usine, consommation matière rendue, procédé et compatibilité ne sont pas établis. |
| Recyclage et valorisation textile | Fibres issues de chutes textiles triées; 153 kg/h; équipement 23 500 USD, investissement total 74 306 USD. | Prix 0,80 USD/kg; ventes A1 174,6 t pour 180 t produites; RN –19 580,88 USD (–14,02 %). A2 –5 049,27; A3 +5 352,64 USD (2,23 %). Trésorerie min A1 +7 430,60 USD; bilans équilibrés. La vente A3 à 300 t/an n’est pas étayée par des commandes. | Les chiffons d’essuyage industriel existent chez un distributeur ivoirien local (gammes coton/polycoton recyclé), mais aucun tarif public exploitable ou volume d’achat n’est donné dans la fiche consultée. Une fabrication de chiffons découpés peut contourner l’effilochage; la ligne existante, les tris qualité, le conditionnement et les coûts de collecte ne sont pas documentés pour ce produit. Fibres de rembourrage nécessiteraient aussi qualité/longueur/teneur poussières et débouchés spécifiés. | **Ne pas ajouter de chiffre d’affaires de diversification.** Tester d’abord l’option chiffons dans une note produit séparée : qualité d’entrée coton, rendement après tri, découpe/emballage déjà disponibles ou coûtés, prix net B2B et volumes demandés. Sensibilité du prix du produit actuel : seuil RN nul 0,9121 USD/kg; 6 % 0,9915; 8 % 1,0211, sans preuve de prix marché. Maintenir le scénario indicatif courant. |

### Hypothèses et contrôles moteur

Le moteur industriel/financier commun a calculé les trois configurations historiques sans les modifier. Les trois ont un financement 40/60, une trésorerie mensuelle A1 positive et des bilans équilibrés à l’erreur numérique près (moins de 10⁻⁶ USD). Les résultats restent indicatifs; le test confirme la calculabilité, non la validation des prix ou volumes. Les prix de sensibilité sont issus d’un calcul isolé en mémoire, réinitialisé après chaque essai; ils ne sont pas enregistrés et ne constituent ni une hypothèse commerciale ni un résultat de BP.

| UP | RN A1 | RN A2 | RN A3 | Trésorerie min. A1 | Sensibilité mécanique 6–8 % (USD/kg) |
|---|---:|---:|---:|---:|---:|
| Boulangerie industrielle | –5 524,88 | +8 683,66 | +21 873,84 | +8 911,19 | 2,7588–2,8412 |
| Non-tissés / feutre d’ameublement | –74 733,40 | –63 350,96 | –54 291,25 | +20 680,60 | 2,7316–2,8131* |
| Recyclage textile / fibres | –19 580,88 | –5 049,27 | +5 352,64 | +7 430,60 | 0,9915–1,0211 |

*Prix de sensibilité du feutre actuel uniquement; ne représente pas le prix d’un géotextile ou feutre agricole. Ces seuils supposent toutes les autres données actuelles inchangées.

## Piste de remplacement

Aucune décision de remplacement n’est indispensable sur la base actuelle : les trois UP conservent leur place et leur historique, mais les deux pistes de repositionnement (agricole et chiffons) ne sont pas encore calculables comme scénarios de référence sans inventer prix ou volumes. Pour les non-tissés, l’aiguilletage est un procédé technique existant pour géotextiles et non-tissés techniques, mais cela ne prouve pas la capacité de la ligne P2I active ni l’adéquation de son prix d’investissement. Aucun remplacement industriel distinct n’est proposé comme décision ferme, car l’analyse disponible ne démontre pas qu’il soit préférable à ces pistes ni n’apporte un scénario documenté.

## Contrôle ciblé de l’identifiant réaffecté

`recyclage_metaux` est l’identifiant actif de **Rideaux métalliques et portails sur mesure**. Le test conjoint du catalogue, du nom actif, du scénario financier, du processus affiché, des machines de présentation et de l’atlas d’images confirme l’alignement. Les anciens libellés/étapes du recyclage métallique (collecte, tri, broyage, compactage, presse à balles) ne remontent plus dans les données actives de présentation. Le scénario actif porte le même intitulé que l’UP. La correction ne change pas le moteur ni les nombres financiers.

## Limites documentaires à conserver

- **Boulangerie :** prix départ-usine/gros pour petits pains ronds, poids/format, emballage et marges de distribution; volumes achetables; réconciliation du coût d’équipement. Les prix publics de baguette standard et les annonces de petits pains non pesés ne sont pas comparables assez précisément pour servir de prix usine.
- **Non-tissés :** prix net B2B/usine du produit cible, grade/grammage et spécification d’usage, liaison/traitement UV, fiche exacte de la ligne active (constructeur/modèles/utilités), prix EXW/FOB; coût matière rendu et rendement. Le prix de rouleaux agricoles observé est un prix détaillant.
- **Recyclage textile :** qualité et composition des matières collectées, taux de pertes, processus de finition/conditionnement, prix B2B et volumes confirmés pour chiffons/fibres/rembourrage, charges de collecte et transport.

## Tests exécutés et périmètre

- `node --check runtime/script-18.js` : PASS.
- `scripts/test-lot133-finances-identite.cjs` : 8 assertions PASS (calcul des trois scénarios, financement 40/60, trésorerie positive, bilans équilibrés, aucun scénario promu/modifié, identité active cohérente et bon atlas rideaux/portails).
- `scripts/test-lot133-render.cjs` : 11/11 UP ciblées PASS; 69 postes sans rupture/duplication de séquence signalée. Les galeries/tableaux historiques sont conservés pour certaines UP; « cartes de poste illustrées » n’est pas le mode d’affichage universel.
- Les scripts financiers communs et catalogue des UP sont conservés; pas de recalcul ou modification d’autre UP.
- ZIP complet pour Edge : contrôle `ZipFile.testzip()` PASS, 333 fichiers sous un seul dossier `P2I_Edge`.

## Sources publiques consultées (14 novembre 2026)

1. ANStat, *Bulletin hebdomadaire des prix – juillet 2026*, prix détail du pain standard à Abidjan : https://www.anstat.ci/assets/publications/files/rapport_ehpm_juillet_2026.pdf (repère de contexte seulement; ce n’est ni le petit pain du scénario ni un prix usine).
2. Marché Facile, annonce de 10 petits pains à 500 FCFA, poids non indiqué : https://marchefacile.com/produit/petits-pains-choco-la-croissanterie-10-pieces-mf000245.html (inutilisable pour établir un prix/kg).
3. GEXA/BATIRICI, GEOSPAN GT BB 90, rouleau 2 × 50 m à 132 760 FCFA : https://batirici.com/product/geospan-gt-bb-90-2x50m-geo-textile-non-tisse/ (masse/grammage non affichés dans la fiche consultée).
4. GEXA, AGROTEX Couverture 100, non-tissé PP UV 100 g/m², rouleau 3,2 × 100 m, 32,06 kg, prix affiché 182 322 FCFA : https://batirici.com/product/agrotex-couverture-100-3-2x100m/ (prix de vente public/détail, pas un prix départ-usine).
5. DongYang AoLong, ligne d’aiguilletage AL--TGB 6500 mm, fiche de gamme/capacité et prix affichés : https://www.alibaba.com/product-detail/AL-TGB-6500mm-Needle-Punch-Nonwoven_1601422408968.html (offre publique de marketplace, conditions EXW/FOB non établies; pas retenue comme référence de prix P2I).
6. Trützschler Nonwovens, T-SUPREMA, applications et capacité technique annoncée : https://www.truetzschler.com/en/nonwovens/products/machines/needle-punching/t-suprema/ (source procédé; pas de prix public).
7. Bamata Distribution, gammes de chiffons coton/polycoton recyclés : https://www.bamata-distribution.com/produits/ (preuve de présence de la catégorie en offre locale, sans prix public ou volume d’achat consultable).

## Fichiers ajoutés ou modifiés

Ajoutés : `docs/TEST_LOT133_FINANCE_IDENTITE.json`, `docs/MATRICE_REMEDIATION_ECONOMIQUE_LOT133.csv`, ce rapport. `LIRE_AVANT_OUVERTURE.txt` comporte un court repère Lot 133. Le rendu actif a été corrigé uniquement pour aligner `recyclage_metaux` sur la fiche rideaux/portails; les 4 planches de processus Lot 133 et les 69 postes ciblés sont préservés. `runtime/script-11.js`, `runtime/script-16.js`, les scénarios financiers et le catalogue d’Assemblage n’ont pas été modifiés.
