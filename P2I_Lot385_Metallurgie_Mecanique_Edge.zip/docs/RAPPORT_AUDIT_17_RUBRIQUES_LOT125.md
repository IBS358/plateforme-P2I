# Rapport d’audit transversal — rubriques des 96 BP Découverte

**Lot 125 · 13 novembre 2026**

## Périmètre et méthode

Base : Lot 124, consolidé à partir du Lot 117, des correctifs Lot 122 et des audits Lot 123/124. Aucun fichier des archives historiques n’a été supprimé. GitHub et la branche `main` ne sont pas modifiés. Contrôle statique du gabarit HTML/CSS, du moteur de rendu et des données des 96 UP; ce contrôle ne remplace pas l’ouverture de chaque page dans Edge.

## Constat sur le design commun

Les 96 BP sont produits par le même composant de rendu : une enveloppe `<section class="section">` et un bandeau `<h2 class="band">` pour chacune des 17 rubriques, soit **1 632 rubriques structurellement rattachées au même gabarit**. La feuille CSS commune définit leurs bandeaux, espacements et cartes. Les tableaux, graphiques, listes et encarts internes diffèrent selon la rubrique et les données, ce qui est normal; un contrôle visuel pixel par pixel de 1 632 affichages n’a pas été possible ici.

## Défaut corrigé dans ce lot

Dans le chemin des BP calculables non pilotes, le bloc Marché était écrasé par une note générique évoquant la biscuiterie. Ce défaut rendait le contenu trompeur ou non spécifique. Le rendu lit désormais le texte de marché et de positionnement propres à l’UP, ses segments documentés lorsqu’ils existent, et signale les prix/concurrents à vérifier sans inventer de débouché. Le bloc Configuration reprend les étapes et besoins fonctionnels historiques en les qualifiant clairement; le bloc Risques s’appuie sur les opportunités et risques de l’UP. Aucun calcul, prix, volume ou financement n’a été modifié.

## Couverture des données par rubrique

| Rubrique | Données sources constatées | Conclusion d’audit statique |
|---|---|---|
| 01 Projet | 93/96 ont une rédaction source de projet | Formalités générales et règles propres aux activités restent à contrôler; RCCM et autorisations ne sont pas certifiés par ce lot. |
| 02 Synthèse | 27 UP sont `PARTIEL_CALCULABLE`; 69 `PARTIEL_NON_CALCULABLE` dans la matrice Lot 122 | Les 17 titres ne signifient pas 96 prévisions complètes. |
| 03 Configuration | 96/96 ont un processus; 96/96 ont des besoins machines; 38 entrées de référence comportent un bloc équipement tarifé | Les besoins historiques ne valent pas tous une configuration fournisseur validée. |
| 04 Marché | 93/96 ont un texte marché; 41/96 une liste de segments | Le défaut d’écrasement générique est corrigé; les sources marché et prix restent à vérifier fiche par fiche. |
| 05 Commercial | 93/96 ont une rédaction commerciale dédiée; 81 marqueurs de qualification internes en source | Marqueur ciblé filtré au rendu; les recommandations commerciales restent à relire pour leur adéquation. |
| 06 Risques | opportunités 82/96; risques 85/96 | Les fiches sans les deux volets doivent être complétées. |
| 07–13 Finances | 27 UP calculables selon la matrice Lot 122 | Les calculs restent à valider; 69 UP ne disposent pas de scénario financier calculable dans cette base. |
| 14 Sources | 93/96 fiches ont des sources listées | Présence d’une source ne signifie pas validation de chaque hypothèse ni de son actualité. |
| 15 Suite | 82/96 ont une recommandation de suite dédiée | Les autres restent sur le parcours standard. |
| 16 Dossier de passage | composant et étapes communs | Contenu d’orientation à adapter dans la prochaine passe éditoriale. |
| 17 Technique | processus et besoins machines pour 96; 65/96 routes d’atelier en rubrique 17; 51 postes médicaux détaillés dans l’audit antérieur | Les postes d’autres filières et les images exactes restent à contrôler. |

## Résultat

Le **design structurel est commun**, mais le contrôle ne conclut pas que les 17 contenus sont tous spécifiques et complets pour les 96 UP. Les principaux écarts de données sont documentés dans `MATRICE_AUDIT_17_RUBRIQUES_96_UP_LOT125.csv` (une ligne par UP et rubrique). Aucune UP n’est déclarée entièrement validée par ce lot.

## Tests réellement exécutés

- `node --check` sur les scripts modifiés : réussi.
- Matrice générée : 1632 lignes, 96 UP × 17 rubriques, sans identifiant UP manquant.
- Présence locale de 225 images du manifeste et des 26 références runtime locales : 0 chemin manquant.
- Test unitaire du filtre de rédaction interne (Lot 124) : réussi.
- `unzip -t` de l’archive Lot 124 : réussi avant la correction de marché.
- Microsoft Edge/Chromium : lancement headless bloqué dans l’environnement par l’interdiction système de créer un socket; aucun test visuel Edge n’est revendiqué pour Lot 125.
