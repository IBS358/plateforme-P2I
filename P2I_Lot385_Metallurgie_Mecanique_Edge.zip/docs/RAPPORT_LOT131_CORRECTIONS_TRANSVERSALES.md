# Lot 131 — corrections transversales ciblées

Date : 14 novembre 2026. Base : Lot 130 complet. Les archives Lot 127/128 sont conservées. Aucune modification de `main`.

## Corrections

- **Rubrique 1** : le tableau réglementaire horizontal est remplacé par six cartes verticales adaptatives dans le composant commun. Les contenus propres à l’UP, les statuts, les liens et la date des sources sont conservés. La largeur n’impose plus de défilement horizontal et les textes reviennent à la ligne à une taille lisible.
- **Rubrique 17 / Biscuiterie** : une seule séquence POSTE 01/05 à 05/05 décrit les cinq étapes de la ligne intégrée Crackers. Chaque carte reprend l’illustration de fonction, la ligne de référence P2I, sa capacité nominale de 500 kg/h et le prix total de 450 000 USD (non ventilé). Fabricant/modèle, puissance, utilités et interfaces non documentés sont signalés comme tels. La série distincte « ÉQUIPEMENT 01–05 » et le flux générique ajouté en doublon ont été supprimés.
- **Protection financière** : ajout d’un registre explicite des scénarios réellement validés, distinct d’une liste de surveillance des scénarios indicatifs, et d’un test déterministe qui bloque toute modification silencieuse des données d’entrée, du moteur ou des états financiers verrouillés. Le test n’écrit jamais une nouvelle référence automatiquement.

## Biscuiterie — origine du résultat

La marge nette A1 affichée est **36,04 %** (résultat net **490 713,89 USD**). Cette valeur était déjà présente dans les matrices Lot 117, Lot 127 et Lot 128. Le bloc Crackers du référentiel Lot 128 est identique à celui du Lot 130 (empreinte SHA-256 `5806b307…73655d1`) et le moteur financier (`runtime/script-15.js`) est identique (empreinte `96bcc89f…bfe2bf`). Le Lot 130 n’a donc pas introduit cette hausse.

Le calcul emploie notamment un prix de vente P2I estimatif de **1 500 FCFA/kg** (2,5595 USD/kg en A1) et une hausse supposée de 2 % par an, en plus des hypothèses de volume et de charges inscrites dans le scénario. Aucun relevé local de prix ni contrat de vente n’est attaché. La matrice classe le dossier « partiel » et `BP_termine_verifie_ce_lot=NON`; aucune archive consultée ne fournit une référence financière explicitement approuvée pour la Biscuiterie. Ce résultat reste donc calculable mais **non validé** et ne doit pas être présenté comme rentabilité acquise. Les hypothèses, les calculs et la ligne 500 kg/h / 450 000 USD sont préservés.

Au moment du lot, la matrice Lot 130 ne marque aucun BP comme terminé/vérifié (`OUI`). Le registre `data/p2i-financial-reference-lock.json` conserve donc zéro scénario promu « validé » et place Crackers dans la liste de surveillance indicative. Les futures références validées doivent être ajoutées avec identifiant, configuration, entrées, version moteur, résultats, trésorerie, date et trace de validation.

## Vérifications ciblées

- Rendu isolé Biscuiterie, Colles et enduits, Mobilier médical et Chaussures : 17 sections; six cartes administratives; aucun tableau dans le bloc administratif; aucune erreur JavaScript.
- Biscuiterie : cinq cartes POSTE uniques dans le processus de la ligne intégrée; aucune série ÉQUIPEMENT séparée; budget et capacité maintenus; note visible de non-validation financière.
- Test `node scripts/check-financial-regressions.cjs` : **PASS**. Il compare les trois années de résultats, les 12 soldes mensuels de trésorerie, le BFR M1–M12, les bilans, le financement et les empreintes des entrées/moteur. RN A1 : 490 713,89 USD; marge nette A1 : 36,04 %; trésorerie minimum A1 : 74 459,22 USD; écart maximal bilan : moins de 0,000001 USD.
- `node --check runtime/script-18.js` et `node --check scripts/check-financial-regressions.cjs` : **PASS**.
- Contrôle visuel interactif dans le Microsoft Edge de l’utilisateur non exécuté depuis cet environnement; la version locale est à ouvrir pour confirmer l’apparence sur son écran.

## Fichiers modifiés

- `runtime/script-18.js` — cartes administratives; séquence unique de postes Crackers; avertissement de résultat indicatif.
- `runtime/style-2.css` — mise en page responsive, retours à la ligne, cartes R1 et R17.
- `data/p2i-financial-reference-lock.json` — registre d’état de validation et résultat indicatif surveillé.
- `scripts/check-financial-regressions.cjs` — garde-fou reproductible.
- `MATRICE_96_UP.csv` — réserve documentaire Biscuiterie, sans changement de valeur financière.
- `runtime/build-manifest.json` — version et empreintes Lot 131.
