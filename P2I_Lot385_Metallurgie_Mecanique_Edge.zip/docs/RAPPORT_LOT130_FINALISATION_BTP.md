# Lot 130 — clôture structurelle et finalisation ciblée BTP

Date : 14 novembre 2026. Base : source de développement consolidée Lot128, avec registre actif et scénarios financiers BTP issus du Lot129. Archives ZIP Lot127/Lot128 préservées. Aucun changement GitHub/main. Aucun calcul financier ni paramètre industriel n’a été modifié dans ce lot.

## Corrections du modèle commun

- Rubrique 1 : formalités de création et d’exploitation, Code des investissements (Ordonnance n° 2018-646, admissibilité à instruire auprès du CEPICI sans avantage présumé), implantation, procédure environnementale selon le décret n° 2024-595, vérification conditionnelle des installations classées, exigences sectorielles et liens vers les portails officiels. Les orientations BTP sont différenciées par UP et par procédé; elles ne remplacent pas les décisions des autorités.
- Rubrique 2 : le composant commun conserve le fond d’atelier flouté, le médaillon principal net et les variantes distinctes. Le registre Lot128 continue d’associer les images au couple UP/fonction et ne reprend pas le visuel d’une autre filière en cas d’absence de correspondance.
- Rubrique 5 : quatre encarts natifs `<details>`/`<summary>` sont présents dans le parcours commercial et s’ouvrent au clic.
- Rubrique 17 : rendu ciblé des huit BTP et de la fabrication de chaussures : une seule séquence de cartes numérotées, avec fonction, poste/machine et image rattachée à la fonction. Aucun doublon de numéro n’a été observé sur ces rendus.

## Catalogue actif

Le catalogue conserve 96 identifiants uniques et 12 filières. Les remplacements sont stables : `cimenterie` → **Colles et enduits** (`colles_enduits`), `javel` → **Hygiène & désinfection professionnelles** (`hygiene_desinfection_pro`). Les deux anciennes clés ne sont pas actives; les anciens liens sont redirigés vers leur remplacement. Les 8 UP Assemblage et leurs identifiants restent inchangés; aucune orientation proposée (vélos électriques/cargos, tuk-tuks, tablettes) n’a été ajoutée.

Les huit UP BTP actives sont : Colles et enduits; Briques et tuiles; Éléments préfabriqués; Tuiles et éléments toiture; Agglos et parpaings; Peintures bâtiment; Centrale à béton; Menuiserie aluminium/PVC.

## Scénarios financiers BTP conservés

Les hypothèses et résultats courants sont conservés sans recalcul ni modification. Le financement de référence reste 40 % d’apport et 60 % de dette. Les huit scénarios sont calculables dans le moteur commun, avec résultat net A1 positif, trésorerie 12 mois non négative et bilans équilibrés sur trois ans selon les contrôles enregistrés au Lot129.

Cinq marges A1 restent sous le repère indicatif de 10 % : Colles et enduits (6,89 %), Briques et tuiles (7,19 %), Éléments préfabriqués (8,08 %), Peintures bâtiment (6,57 %) et Centrale à béton (8,04 %). Elles sont signalées dans la matrice; aucun prix ou volume n’a été ajusté artificiellement. Les hypothèses documentaires et commerciales restent à qualifier pour le BP Pro.

## Contrôles exécutés

- Vérification de la matrice : 96 lignes, 12 filières; 96 liens d’accueil distincts et aucun lien vers les clés retirées.
- Registre central chargé : 96 identifiants, 12 filières; liste BTP exacte et clés retirées exclues.
- Vérification de syntaxe `node --check` sur les scripts touchés : réussite.
- Rendu JavaScript isolé des huit UP BTP et de Fabrication de chaussures : 17 rubriques, une rubrique administrative, sources réglementaires visibles, quatre encarts commerciaux, fond de rubrique 2, médaillon et variantes; aucune erreur JS.
- Rubrique 17 : 5 à 7 postes sur les UP BTP selon la configuration, 10 postes chaussures; séquences non dupliquées dans les rendus testés. Pour chaussures, dix ressources visuelles propres au dossier chaussures sont présentes.
- CSS du bandeau : filtre de flou appliqué à l’arrière-plan; les médaillons restent nets.
- Aucun contrôle graphique interactif dans Microsoft Edge n’a pu être exécuté ici. Les tests sont des rendus locaux en VM; ils n’attestent pas de l’affichage sur l’ordinateur de l’utilisateur.

## Réserves

Les images générées par IA restent des illustrations non contractuelles, pas des photos de machines fournisseurs. Les sources publiques de réglementation indiquent le cadre et les procédures; l’autorisation exacte, le classement environnemental, les normes de produit, les seuils et les incitations doivent être confirmés pour le site, le procédé et l’investissement réels. Les calculs sont indicatifs et ne constituent pas un dossier bancaire.

## Fichiers principaux modifiés

- `runtime/script-18.js` : rubrique 1, liens de sources à jour, cadre environnemental 2024-595 et spécificités administratives des huit BTP; aucune branche de calcul modifiée.
- `runtime/catalogue-up-actif.js` : registre unique, validations et redirection des anciennes clés.
- `accueil-local.html` : liens alignés sur les identifiants de remplacement.
- `MATRICE_96_UP.csv` : indicateurs explicites de structure, calculabilité financière et niveau de complétude.
- `MATRICE_SUIVI_BTP_LOT129.csv` : résultats et réserves des huit scénarios conservés.
- `runtime/build-manifest.json` : version Lot130 et empreintes de contrôle.
