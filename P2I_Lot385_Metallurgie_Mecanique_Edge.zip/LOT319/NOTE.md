# Lot 319 — Correction effective des huit pages BP

Les huit pages du LOT315 affichaient encore des résultats LOT316, notamment un CAPEX historique de 4 000 000 USD pour les DEEE, alors que l’index LOT317 affichait 302 000 USD. Cela constituait une divergence majeure entre les BP et leur index.

Ce lot crée huit pages BP actualisées : les annexes obsolètes LOT316 sont remplacées par les configurations, tableaux A1–A3, trésorerie 12 mois, bilan et prix machines issus du calcul v107 réel LOT317. Les 17 rubriques historiques restent conservées.

La filière n'est PAS validée financièrement : aucune hypothèse commerciale n'a été changée ; cinq UP restent sous la cible de 6 %. Pour les DEEE, la simulation n'est pas exploitable à cause de l'incohérence entre ligne réfrigérateurs et recettes DEEE génériques.
