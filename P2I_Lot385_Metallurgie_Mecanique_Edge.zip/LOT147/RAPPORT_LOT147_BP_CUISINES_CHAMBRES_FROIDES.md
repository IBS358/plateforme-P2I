# Lot 147 — BP Découverte : cuisines professionnelles et chambres froides modulaires

## Résultat de livraison

Une première fiche BP Découverte est intégrée à une copie complète de la plateforme de base Lot 136. La recherche de bibliothèque n’a retrouvé aucune archive plateforme complète postérieure; les éléments isolés du Lot 139 ne sont pas présentés comme intégrés.

L’UP active remplace l’entrée Ventilateurs dans le catalogue sous le nouvel identifiant `cuisines_pro_chambres_froides`. L’ID historique `electromenager` n’est pas actif dans le registre de navigation; les données historiques du Lot 136 restent conservées dans les fichiers de base. Le registre compte 96 UP dans 12 filières.

## Configuration de référence

Deux ateliers séparés :

- Atelier inox pour une table 1 800 × 700 × 850 mm et un évier 1 cuve + égouttoir 1 200 × 600 mm : débit, pliage, soudage, finition, contrôle.
- Atelier frigorifique pour une chambre positive 2 000 × 2 000 × 2 200 mm (3,35 m³) : panneaux/porte, groupe froid, commande, câblage, étanchéité et essais.

La ligne de référence comporte 6 postes dans l’ordre du processus. Les machines majeures ont des prix publics de catalogue ou de listings; les accessoires, plusieurs budgets de machines et les frais rendus site sont des provisions P2I. Les machines partagées par table et évier sont inscrites une seule fois au CAPEX. Les variantes (évier double, autre format, chambre négative) sont hors simulation.

## Simulation exécutée par le moteur commun v107

| Année | Production et ventes | CA USD | Résultat net USD | Marge nette | ROI annuel |
|---|---:|---:|---:|---:|---:|
| A1 | 206 | 235,186 | 11,378 | 4.84% | 11.49% |
| A2 | 213 | 255,398 | 20,417 | 7.99% | 20.62% |
| A3 | 221 | 277,615 | 30,377 | 10.94% | 30.69% |

- CAPEX complet : **98 994 USD** (machines 64 440; transport/assurance/port/douane estimés 16 110; installation/formation 6 444; site/sécurité 12 000).
- Financement CAPEX : apport **39 598 USD** (40 %) et dette **59 396 USD** (60 %). Réserve initiale financée séparément par apport : **27 368 USD** selon le calcul moteur; total d’apport ≈66 966 USD.
- Trésorerie libre minimale sur les 12 mois : **+9 899 USD**. BFR au mois 12 : **18 448 USD**.
- Bilans A1–A3 équilibrés par v107 (écart maximal < 0,000000001 USD). Contrôles moteur : 36 mois de BFR, 12 mois de trésorerie, financement 40/60.
- Marge A1 (4,84 %) et ROI A1 (11,49 %) sont sous les repères indicatifs internes du moteur (10 % et 15 %). Le dossier reste **indicatif, non validé économiquement**; aucun ajustement de prix n’a été appliqué pour viser une marge.

## Hypothèses déterminantes et incertitude

Programme mixte : 120 tables, 80 éviers et 6 chambres en A1 (206 unités au total), puis 125/82/6 (213) et 130/85/6 (221). Temps de gamme P2I : 5 h/table, 7,5 h/évier et 20 h/chambre. L’atelier dispose dans le modèle de 1 500 h/an (250 jours × 8 h × 75 %). Le mix mobilise 1 320 h en A1, 1 360 h en A2 et 1 407,5 h en A3. Ces durées sont des hypothèses, non des chronométrages ni une capacité constructeur garantie.

Les prix nets P2I de vente dérivent de comparateurs ivoiriens publiés : table 880 USD contre 654 400 FCFA HT pour une table proche; évier 827 USD contre 615 200 FCFA HT pour un comparable proche; chambre positive 10 571 USD contre 7 400 000 FCFA HT pour une référence de 3,35 m³. Ce sont des prix de planification calculés en appliquant 80 % aux comparables table/évier et 85 % au comparateur chambre, au taux budgétaire arrondi 595 FCFA/USD; ces rabais ne sont pas des prix producteur observés. Les ventes sont des hypothèses P2I sans commandes.

Le coût matière table est estimé à 45 kg × 3 USD/kg avec 20 % de préparation/pertes, soit 162 USD. L’évier est estimé à 65 kg × 3 USD/kg × 1,20 = 234 USD. Le groupe froid AP75M-1B est référencé à 2 400 EUR en catalogue; conversion budgétaire arrondie ≈2 647 USD. Panneaux et porte reposent sur des fourchettes FOB publiées; accessoires froids provisionnés. Les salaires chargés (68 000 USD/an) et les autres charges fixes (38 000 USD/an) sont des hypothèses P2I sans enquête salariale ni factures locales. Les prix FOB n’incluent pas le transport réel, les taxes douanières exactes ni la pose.

Réserves majeures : tarifs B2B acceptés, demande et volumes, plans et masses des équipements, coût rendu et compatibilité du groupe froid, puissances/utilités des machines, droits de douane, temps de fabrication, salaires locaux et délais de paiement. L’installation ne génère aucun chiffre d’affaires additionnel dans ce scénario.

## Contrôles et limites du test

- Moteur v107 lancé avec le scénario du nouvel ID; résultats annuels, trésorerie mensuelle, BFR, bilans et financement enregistrés dans `RESULTATS_MOTEUR_V107.json`.
- Tests locaux automatisés : 96 IDs uniques, 12 filières, ancien ID absent du catalogue actif, 17 rubriques générées, 4 encarts interactifs au bloc 5, 6 postes numérotés au bloc 17, 10 références d’images locales et code JS contrôlé par `node --check`.
- Le rendu graphique réel dans Microsoft Edge et le clic sur l’export PDF **n’ont pas pu être testés dans cet environnement**. Le ZIP est préparé pour ouverture locale dans Edge, mais le contrôle visuel reste à faire sur votre ordinateur.
- Les images produit/atelier/postes du Lot 147 sont des illustrations IA signalées dans la fiche; elles ne sont pas des photos de machines fournisseurs. Le logo P2I original de la base est conservé.

## Sources retenues

- Comparateur table inox 1 800 mm : https://www.horecaworld.net/univers/restaurants-hotels/page/106/
- Comparateur évier 1 200 × 600 mm : https://horecaworld.net/catalogue/mobilier-inox-hygiene/page/6/
- Comparateur chambre positive C65B/BF + AP75M-1B : https://ciboworld.net/catalogue/chambres-froides/chambre-froide-positive/
- Tôle inox AISI 304 : repère public consulté à 3 USD/kg (prix rendu Côte d’Ivoire non établi).
- Panneaux PU 100 mm et porte isolée : listings publics, fourchettes 23–28 USD/m² FOB et 600–900 USD/set.
- AP75M-1B : catalogue public à 2 400 EUR.
- Découpe laser 3015 : https://www.made-in-china.com/price/prodetail_Laser-Cutting-Machine_PnTYHNFjCMRV.html
- Presse plieuse Shinite : https://masshenlite.en.made-in-china.com/product-group/AoqtpDcvgLVz/Press-Brake-catalog-1.html
- Cisaille QC11Y-8×3200 : https://ntwoke.en.made-in-china.com/product-group/UepaGjOJhlhK/Engineering-machinery-catalog-1.html
- Postes TIG Aland : https://alandwelding.en.made-in-china.com/product-group/LqlnEXjHOrpz/TIG-Welding-Machine-1.html
- Conversion fixe EUR/XOF : 655,957 FCFA/EUR; 595 FCFA/USD est seulement un taux budgétaire arrondi.

Fichiers joints : `BOM_LOT147_3_PRODUITS.csv`, `RESULTATS_MOTEUR_V107.json`, `MATRICE_TESTS_LOT147.json`, `runtime/lot147-scenario.json`. La fiche complète est dans `index.html` et ses fichiers runtime associés.
