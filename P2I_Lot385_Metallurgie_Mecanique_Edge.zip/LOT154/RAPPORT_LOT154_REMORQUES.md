# P2I — Lot 154 ciblé : remorque agricole 3 t

## Décision de périmètre

Le produit de référence étudié est une remorque agricole à ridelles fixes, non basculante, quatre roues, annoncée pour une charge utile de 3 t, tractée par tracteur ou motoculteur adapté. L'activité reste distincte des UP Vélos et Tricycles. Les versions basculantes et les capacités 2, 5 et 6 t restent hors calcul.

Le comparateur principal est le Weito 7C-3 (offre publique, non un plan de fabrication locale) : 3 t, deux essieux/quatre roues, plateforme 3 400 × 1 700 × 460 mm, tare annoncée 820 kg, cible tracteur annoncée 20–30 hp. La fiche affiche 1 750 USD FOB pour 1–17 pièces et 1 550 USD à partir de 18. La page contient des contradictions sur le freinage; les spécifications, le conditionnement et le bon code douanier nécessitent une confirmation. Charge utile annoncée + tare donneraient 3 820 kg avant accessoires, mais cette masse n'est pas une vérification structurelle.

Les annonces Restone indiquent des références de prix FOB : 2 t 700–800 USD; 5 t 2 000–2 400 USD; 6 t 3 000–3 500 USD. Ce sont des repères fournisseurs, sans preuve que dimensions, essieux, charge et équipement soient comparables au 7C-3. Ils ne sont pas utilisés comme hypothèses financières pour le produit 3 t.

## BOM quantitative préliminaire — acier tarifé

Un panier géométrique minimal a été construit à partir de tubes et tôles affichés comme livrés à Abidjan. Il totalise 614,04 USD avant chutes, découpe, soudure, peinture et traitement. Il comprend 2 tubes 100×100×3 mm de 6 m, 3 tubes 80×80×3 mm de 6 m, 3 tubes 50×50×3 mm de 6 m, 2 tôles 3 mm de 1500×3000 mm et 2 tôles 2 mm de 1250×2500 mm.

Ce panier n'est pas un plan de fabrication ni une nomenclature d'ingénierie : aucune résistance de longeron, traverse, timon, plancher, ridelle, essieu ou attelage n'a été calculée. La géométrie et les sections doivent être vérifiées avant prototype. L'essieu, les roues/pneus, moyeux, suspension, freinage, éclairage, timon/anneau, boulonnerie, consommables de soudage, peinture, emballage, main-d'œuvre directe et chutes sont à chiffrer. Le CSV détaille le panier et les postes inconnus.

## Parité d'importation — ordre de grandeur, pas coût rendu validé

Le transport public indicatif 40HC Qingdao–Abidjan varie de 3 639 à 5 590 USD sur les exemples consultés. En reprenant l'annonce Weito de 18 unités par 40HC, la division donne 202,17–310,56 USD par unité. Cette division n'est pas une réservation de fret ni une garantie de conditionnement. Elle donne un CAF proxy (FOB + fret, assurance encore exclue) de 1 752,17 à 2 060,56 USD.

Pour illustration, une classification provisoire « autre remorque non basculante » HS 8716399000 avec DD 10 % et prélèvements import hors TVA totalisant 2,5 % donne 1 971,19–2 318,13 USD avant TVA, frais portuaires locaux, courtage, livraison intérieure et assurance. Le classement, le taux et l'assiette doivent être confirmés par la douane/commissionnaire. Ce chiffre est un proxy de parité import, non un prix de vente local, ni un coût rendu complet. Une page locale Massey Ferguson affiche « prix sur demande ». Un listing GlobalGros observé en points ne constitue pas un prix cash de comparaison. Aucun prix net professionnel local équivalent fiable n'a été identifié.

## Machines et investissement atelier

Panier public partiellement tarifé :

| Poste | Référence / fournisseur | Prix public indicatif | Limites |
|---|---|---:|---|
| Découpe | Plasma CNC 1530, gamme Jinan Zhongke | 4 400–7 800 USD FOB | Fourchette de gamme; tarif non relié au modèle exact, puissance et accessoires à confirmer |
| Profilés | Scie à ruban horizontale GHS4228B, Tengzhou Uni-Tech | 5 400–5 800 USD FOB | Capacité de coupe, lames et livraison à confirmer |
| Formage | Presse plieuse 100 t/3 200 mm, gamme Anhui Huaxia | 5 500–18 600 USD FOB | Fourchette large, matrice et modèle exact non arrêtés |
| Soudage | MIG 350 A, Beijing ALAND | 1 989–2 488 USD FOB | Cycle de service, torche, consommables/accessoires à vérifier |
| **Panier partiel** | Machines ci-dessus | **17 289–34 688 USD FOB** | Pas une ligne complète; auxiliaires, air, gabarits, levage, peinture, contrôle, sécurité, transport, douane, installation et formation exclus |

L'atelier peut être partagé avec l'UP Équipements sportifs pour plasma, sciage, pliage et soudage seulement si plages de matière, outillages et qualité sont compatibles. Pour un calcul consolidé, ces machines ne doivent être acquises qu'une fois et leurs coûts ventilés par heures-machine. Aucun relevé des heures par UP n'étant disponible, aucune quote-part n'est présentée comme réelle. Les calculs de seuil ci-dessous chargent par prudence le panier partiel complet au scénario remorque seul; ils ne peuvent pas être additionnés au CAPEX sport. Le CAPEX complet remorque reste inconnu.

## Programmes de cadence et charges — exploratoires

Trois volumes sont testés pour mesurer les seuils : 120, 240 et 360 remorques par an. Aucun temps de cycle ou historique de marché ne permet d'appeler ces nombres capacité effective ou ventes défendables.

| Programme exploratoire | Effectif budgétaire | Paie annuelle P2I | Autres frais fixes P2I | Organisation simplifiée |
|---:|---:|---:|---:|---|
| 120 unités/an | 7 ETP | 45 000 USD | 28 000 USD | Chef d'atelier; 2 soudeurs; coupe/scie; montage; finition/contrôle; magasin/vente |
| 240 unités/an | 10 ETP | 64 000 USD | 36 000 USD | Chef; 3 soudeurs; 2 coupe/formage; 2 montage; contrôle/finition; logistique/vente |
| 360 unités/an | 14 ETP | 88 000 USD | 45 000 USD | Chef; 6 soudeurs; 3 coupe/formage; 2 montage; contrôle; logistique/vente |

Paie et frais fixes sont des enveloppes P2I de sensibilité, pas des salaires observés ou devis d'exploitation locaux. Le panier machines est constant comme minimum de départ; besoins d'équipements additionnels selon cadence non chiffrés.

## Simulations effectivement exécutées

36 cas ont été calculés par le moteur commun v107. Pour chaque combinaison de cadence (120/240/360), prix test (1 774,07 ou 2 318,12 USD) et panier machine (17 289 ou 34 688 USD), le coût variable total maximal par unité a été recherché par inversion numérique pour atteindre 0 %, 6 % ou 10 % de marge nette A1. Le coût variable comprend la matière chiffrée et une enveloppe résiduelle pour tous organes/consommables/conversion non chiffrés. Il s'agit de seuils, pas de comptes de résultat réels.

Exemple à 120 unités/an, prix test 1 774,07 USD, panier machines 17 289 USD : pour 6 % de marge nette A1, coût variable total maximal = 1 003,12 USD/unité; le panier acier tarifé absorbe 614,04 USD et il reste 389,08 USD/unité pour essieux, roues, suspension, attelage, freinage/électricité éventuels, consommables, finition et autres variables. À 10 % de marge, le coût total maximal descend à 908,50 USD, laissant 294,46 USD après le panier acier. Ce reliquat ne peut pas être déclaré suffisant tant que les organes ne sont pas chiffrés.

Le cas 360 unités/an au prix test supérieur 2 318,12 USD permet mécaniquement une enveloppe de 1 756,33 USD de coûts variables totaux pour 6 % de marge (1 142,29 USD après l'acier), mais suppose 360 ventes à un prix non observé, une forte hausse de demande, des charges P2I estimatives et un CAPEX toujours partiel. Ce n'est pas un résultat à retenir.

Les calculs couvrent 3 ans, 12 mois de trésorerie, 36 mois de BFR, bilans et financement 40/60 du seul CAPEX partiel. Les bilans du moteur s'équilibrent dans tous les cas. La réserve initiale générée par le moteur est distincte du CAPEX et soutient la trésorerie; une trésorerie positive à un seuil ne prouve pas la viabilité. Le BFR est incomplet, car il n'intègre pas correctement les pièces/organes dont les coûts manquent. Aucun compte de résultat, ROI, BFR ou besoin de financement complet n'est publié comme scénario actif.

## Conclusion de référence

La référence produit à poursuivre est unique : remorque agricole 3 t à ridelles fixes, non basculante, quatre roues, avec compatibilité tracteur à valider. Les capacités 120/240/360 restent des sensibilités de planification. Il n'existe pas encore de référence financière adoptable : prix net local, volumes vendables, BOM des organes, temps opératoires et CAPEX complet ne sont pas justifiés. Le redressement Lot153 ne doit donc pas être déclaré acquis.

Le scénario Lot153 sur remorque 750 kg reste intact dans son archive et les historiques Lot152/153 restent non modifiés. Le nouvel affichage actif ne réutilise pas ses chiffres comme résultat de la remorque 3 t.

## Contrôles effectués

- 36 simulations exécutées via `P2I_BP_SIMULATION_COMMUNE` v107.
- 3 exercices, 12 mois de trésorerie, BFR sur 36 mois et financements 40/60 présents.
- Contrôle moteur : bilans équilibrés (écarts flottants inférieurs à 0,02 USD) pour les 36 cas.
- Vérification des 96 identifiants uniques et des 12 filières; pas de modification de catalogue.
- Vérification de la présence des 17 sections dans le moteur de rendu.
- Vérification du nouveau visuel local et de son attribution IA.
- Vérification de syntaxe des scripts modifiés et intégrité de l'archive.
- Aucun rendu graphique réel dans Microsoft Edge n'a été exécuté dans cette session.


## Sources documentaires consultées

- Weito, modèle 7C-3 : https://es.made-in-china.com/co_sd-weito/product_Factory-Supply-3-Ton-Four-Wheel-Farm-Truck-Trailer-for-Farm-Tractor_ysyrreynuy.html
- Restone, catalogue : https://cnrestone.en.made-in-china.com/product-catalog/Farm-Trailer-1.html
- Zhongke, plasma : https://zhongkecnc.en.made-in-china.com/product-group/SbtxiMdrapRU/Plasma-cutting-machine-catalog-1.html
- Huaxia, presse plieuse : https://ahhxjc.en.made-in-china.com/product-group/YMsaxjKFniGD/ESA-S630-1.html
- Uni-Tech, scie à ruban : https://uni-techmachinery.en.made-in-china.com/product-group/aqZxBsJVHtrW/Band-Sawing-Machine-catalog-1.html
- ALAND, MIG 350A : https://alandwelding.en.made-in-china.com/product-group/oMHEsBSdlUpc/MIG-MAG-Welding-Machine-1.html
- Ferabeton, tôles et tubes affichés pour Abidjan : https://ferabeton.com/tole-en-acier-abidjan-cote-d-ivoire/ et https://ferabeton.com/tube-carre-en-acier-abidjan-cote-d-ivoire
- Fret 2026 Chine–Abidjan : https://goodhopefreight.com/ivory-coast/2026-freight.html
- Tarif ivoirien (GUCE, SH 8716399000) : https://guce.gouv.ci/douanes/tariff/export?format=pdf&keywords=marchandise ; droits et prélèvements : https://www.pwic.ci/tarif-exterieur-commun
- Comparateur local, prix sur demande : https://www.masseyferguson.ci/product/farm-trailer/
