# Lot 154 — addendum : architectures de roulement et repères de prix

**Objet.** Compléter le dossier Lot 154 avec les prix et fiches produits nouvellement repérés. Cet addendum conserve le rapport, la BOM et les 36 seuils v107 existants. Il ne les recalcule pas et ne transforme pas ces seuils en prévisions.

## Conclusion technique provisoire

La piste à poursuivre est la fabrication locale du châssis, du plancher et des ridelles, avec achat d'organes roulants dimensionnés et compatibles. La structure acier de 614,04 USD demeure un panier indicatif non validé par plans et calcul de résistance.

Pour le produit de référence de 3 t, l'architecture quatre roues / deux essieux reste le point de comparaison provisoire, car le comparateur Weito 7C-3 documente explicitement une remorque non basculante à deux essieux et quatre pneus. Ce choix n'est pas une validation d'ingénierie d'un châssis local.

L'architecture deux roues / un essieu est une alternative à tester, non une économie acquise. Une fiche Yijia annonce une remorque complète 3 t à deux roues, 580 kg à vide, pneus 7.50-16/2 et puissance tracteur 25–40 hp. La page décrit plusieurs variantes de suspension et de déchargement; la correspondance exacte du prix au modèle manuel non basculant doit être confirmée. La capacité publiée de l'essieu Darong est de 3 t, sans préciser que cela signifie 3 t de charge utile après la masse de la remorque. Une remorque locale 3 t ne doit donc pas être dimensionnée sur ce seul chiffre.

Avant de retenir une architecture, il faut vérifier au minimum : masse totale en charge (charge utile + tare), répartition entre attelage et essieu(x), charge dynamique par roue, résistance du timon et des longerons, suspension, freinage, stabilité en pente et en virage, vitesse de service, compatibilité tracteur/motoculteur et obligations d'homologation. La fiche Weito elle-même comporte des mentions de freinage non homogènes dans sa page catalogue.

## Prix et comparabilité

| Offre | Prix public repéré | Périmètre | Lecture P2I |
|---|---:|---|---|
| Weito 7C-3, 3 t, 4 roues / 2 essieux | 1 550–1 750 USD FOB Qingdao | Remorque complète; tare annoncée 820 kg; pneus 6.50-16/4; 20–30 hp; 18 unités/40HC | Comparateur complet; pas un prix rendu Côte d'Ivoire ni un coût de fabrication locale. Le prix 1 550 s'applique à partir de 18 pièces selon la fiche. |
| Yijia 7C-3, 3 t, 2 roues | 1 131–1 188 USD FOB (catalogue) | Remorque complète; tare indiquée 580 kg; pneus 7.50-16/2; 25–40 hp; plusieurs variantes de déchargement | Comparateur complet distinct de l'architecture Weito; prix à rattacher précisément à la version non basculante avant parité. |
| Zeyi 7CX-3E | 1 100–1 150 USD signalés dans les éléments fournis, prix non retrouvé sur la fiche ouverte | Fiche vérifiée : 3 t annoncés, 1 260 kg à vide, basculement arrière hydraulique, frein pneumatique, 25–40 hp | Variante basculante, donc hors référence à ridelles fixes. Ne pas reprendre le prix comme vérifié tant que son rattachement au modèle et à l'Incoterm n'est pas établi. |
| Darong DRT03 / C3SYCM08N07 | 219,30–271,50 USD FOB par essieu (catalogue de gamme) | Essieu seul, capacité publiée 3 t, voie 1 840 mm, tambour 320×95 mm, moyeu/entraxe documenté; pneus et suspension non établis dans le périmètre | Pièce d'un système roulant, jamais une ligne roulante complète. Le prix dépend du modèle et du lot; confirmer inclusions, voie, frein et charge avant achat. |
| Jiuzhou, essieu cité dans les recherches P2I | 480 USD FOB pour 10–199 pièces; 379 USD à partir de 200 | Essieu seul selon les données recueillies au Lot 143 | Gardé comme référence historique P2I; ne pas l'assimiler à un train roulant complet. |
| Tengfei, pneu 13R22.5 | 32–35 USD FOB selon les données reçues | Pneu de dimension 13R22.5 | Incompatible en l'état avec les montes 6.50-16 et 7.50-16 des deux comparateurs 3 t; exclu de la BOM. |

### Sous-totaux de composants à ne pas confondre avec un coût complet

- Structure acier Lot 154 + **deux** essieux Darong : 614,04 + 2 × (219,30 à 271,50) = **1 052,64 à 1 157,04 USD**. C'est un sous-total partiel; essieux FOB et acier annoncé livré à Abidjan ne partagent pas le même Incoterm. Roues/pneus, ressorts, freinage complet, attelage, éclairage, fixations, consommables, chutes, peinture, main-d'œuvre, transport et droits manquent.
- Structure acier + **deux** essieux Jiuzhou : **1 372,04 USD** au prix de 379 USD chacun, ou **1 574,04 USD** à 480 USD chacun, avant les mêmes éléments manquants et frais d'importation des essieux.
- Structure acier + **un** essieu Darong : 833,34 à 885,54 USD avant tous les composants manquants. Ce calcul arithmétique ne démontre pas qu'un essieu coté 3 t permet une remorque de 3 t de charge utile : le PTAC, la tare et les efforts dynamiques doivent être calculés.

Ces sommes partielles ne démontrent pas une économie face à Weito à 1 550–1 750 USD FOB ou Yijia à 1 131–1 188 USD FOB. On compare des composants incomplets avec des remorques finies. Le prix de détail du pneu Tengfei 13R22.5 ne peut pas être réutilisé comme prix pour les dimensions adaptées au produit.

## Orientation industrielle

1. Conserver une ligne locale de débit, formage, gabarits et soudage pour châssis/plancher/ridelles; utiliser l'atelier partagé avec Équipements sportifs uniquement après validation des plages matière, outillages, disponibilité et règles d'allocation horaire. Aucun équipement commun ne doit être compté deux fois ni offert gratuitement à l'une des deux UP.
2. Chiffrer un ensemble complet compatible : essieu(x), moyeux, roues, pneus de la bonne dimension et indice de charge, suspension, freinage, attelage, signalisation et boulonnerie. L'offre doit préciser les pièces incluses.
3. Faire produire un plan de définition et un calcul de structure pour le PTAC visé avant de fixer le tonnage de charge utile, les sections acier, la cadence ou l'effectif.
4. Mesurer le temps de cycle de coupe, pliage, soudage, montage, finition et contrôle. Les 120/240/360 unités/an des sensibilités Lot 154 ne sont pas des capacités démontrées. Les effectifs et frais fixes Lot 154 demeurent des enveloppes exploratoires.
5. Une fois la BOM d'organes, les temps opératoires, le CAPEX complet, les prix nets locaux et un volume de vente défendable renseignés, réutiliser l'adaptateur v107 pour un seul scénario industriel de référence et garder le reste en sensibilité. Aucun seuil v107 de Lot 154 n'est recalculé dans cet addendum.

## Données restant indispensables au calcul financier complet

1. Plan validé et tare cible, PTAC, géométrie, répartition de charge, classe de vitesse et freinage exigé.
2. Nomenclature et prix complets des ensembles roulants réellement compatibles, avec coût rendu Côte d'Ivoire distinct du FOB.
3. BOM acier corrigée par plan, chutes, consommables, finition, main-d'œuvre directe et temps par poste.
4. Devis/public catalogue exploitable pour auxiliaires manquants; capex importé rendu, sécurité et installation.
5. Prix professionnel encaissable en Côte d'Ivoire, circuits, frais de livraison et volumes raisonnablement vendables.
6. Ressources mutualisées et clé d'allocation de l'atelier partagé (heures machine, heures de main-d'œuvre, occupation).

Sans ces données, exécuter une prévision complète v107 confondrait inconnues et hypothèses arbitraires. Les 36 sensibilités du Lot 154 restent inchangées et ne constituent pas des scénarios de ventes ni des résultats validés.

## Sources consultées le 16 novembre 2026

- [Weito 7C-3, produit fini 3 t quatre roues](https://sd-weito.en.made-in-china.com/product/lJsRKAyMYpUY/China-Factory-Supply-3-Ton-Four-Wheel-Farm-Truck-Trailer-for-Farm-Tractor.html) : prix et spécifications publiés dans la fiche et son tableau de gamme.
- [Yijia 7C-3, produit fini 3 t deux roues](https://chinaharrow.en.made-in-china.com/product/xAPrgkwouURJ/China-7c-3-Factory-Supplier-Agricultural-Machinery-Trailer-Use-3-Ton-Carriage-2-Wheels.html) : prix indiqué au catalogue; masse, pneus et puissance sur la page produit.
- [Darong DRT03, essieu agricole](https://daroaxle.en.made-in-china.com/product/lxQUqJsdqGYi/China-3t-5t-6t-8t-9t-Light-Agricultural-Trailer-Axle-Hot-Sale-Trailer-Axle-Wheel-Hub-China-Manufacturer-Trailer-Axle.html) : fiche d'essieu et dimensions; prix repéré dans le catalogue public de gamme [3T axle](https://daroaxle.en.made-in-china.com/product-group/TMqaXKyHhPYx/3T-axle-1.html).
- [Zeyi 7CX-3E](https://zeyimachinery.en.made-in-china.com/product/MxSrBGnPVHpu/China-Hot-Selling-3-Ton-Farm-Utility-Trailer-Mobile-Single-Axle-Mini-Dump-Farm-Tractor-Trailer.html) : caractéristiques d'une remorque basculante; aucun prix FOB n'a été vérifié sur cette fiche.
- Le prix Jiuzhou et le pneu Tengfei 13R22.5 sont repris des données de recherche P2I fournies; leur page produit et leur compatibilité restent à confirmer.

## État des six autres UP Assemblage & Montage

Le travail sur la remorque ne change pas les résultats ni les statuts des six autres UP. Derniers résultats comparatifs Lot 153, conservés comme historiques et non comme validation économique :

| UP | RN A1 du cas comparatif Lot 153 | Marge A1 | Statut conservé |
|---|---:|---:|---|
| Smartphones reconditionnés | −21 631 USD | −8,29 % | Sensibilité non adoptée |
| Tablettes | −130 421 USD | −129,39 % | Sensibilité non adoptée |
| Tricycles utilitaires | +5 800 USD | +3,92 % | Sensibilité non adoptée; marge sous repère |
| Vélos | +14 003 USD | +5,96 % | Sensibilité non adoptée |
| Équipements sportifs | +4 327 USD | +2,88 % | Sensibilité non adoptée |
| Stockage/manutention | −91 053 USD | −133,33 % | Sensibilité non adoptée |

Ces historiques sont repris du fichier comparatif Lot 153. Ils ne sont ni recalculés ni modifiés par l'étude de la remorque. Le présent addendum ne déclare pas les six UP finalisées.
