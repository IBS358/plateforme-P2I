# Lot 322 — Atelier de scénarios commerciaux des cinq UP

Livraison cumulative issue du lot 321. Ajout d'un outil HTML **local, opérationnel et interactif** pour répartir les tonnes entre produits, saisir les prix nets, calculer le CA et la variation indicative de contribution pour compost, verre, pneus, huiles et DEEE.

Les données initiales sont issues du fichier LOT317/SYNTHESE_V107.csv, les fractions de LOT321/PLAN_VALORISATION_5UP.json. Aucun prix de vente supplémentaire n'est supposé. Les cinq BP et leurs calculs historiques ne sont pas altérés.

**Attention :** le résultat indicatif n'est pas un résultat net recalculé par v107. Les volumes de fractions, les rendements, la fiscalité, le BFR et le financement devront être recalculés par le moteur commun avant toute validation. Les recettes historiques DEEE ne correspondent pas à la ligne réfrigérateurs et ne doivent pas servir à une validation.

Ouvrir `P2I_Edge/OUVRIR_LOT322.html`.
