# Lot 324 — Intégration effective des résultats v107 dans quatre pages BP

- Compost : 21,67 % ; pneus : 9,06 % ; huiles : 17,99 % ; verre : 3,20 % accepté explicitement comme exception par le porteur du projet.
- Trois BP déjà rentables conservés (plastique, papier-carton, métaux).
- DEEE non validé : recettes de réfrigérateurs à reconstruire ; ne pas présenter les recettes DEEE génériques comme acquises.
- Les quatre nouvelles sections en tête des BP reprennent les sorties v107 du lot 323 ; les anciens tableaux sont conservés et clairement signalés comme historiques.
- Les hypothèses de commercialisation du lot 263 sont indicatives, sans validation de marché ; aucune marge n'est artificiellement imposée.
- Aucun changement de prix catalogue, capacité ou incoterm.
