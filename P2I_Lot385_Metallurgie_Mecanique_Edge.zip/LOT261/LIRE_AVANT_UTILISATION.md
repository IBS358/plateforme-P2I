# Lot 261 — 8 prototypes BP Découverte en 17 rubriques

Livrable : huit pages HTML autonomes consultables hors ligne, chacune avec production, compte de résultat sur trois ans, trésorerie simplifiée mensuelle sur douze mois, étapes industrielles, variantes et risques.

**Limites importantes :** aucun devis machine ni prix de vente/collecte local n’est vérifié ; CAPEX = enveloppes hypothétiques non sourcées ; financement 40/60, intérêt 10 %, durée 7 ans, amortissement 10 ans et impôt théorique 25 % sont des conventions de calcul ; bilan, BFR, TVA et trésorerie bancaire complète absents. Les pages ne sont pas intégrées au moteur v107 et ne doivent pas être présentées comme BP validés. Les 17 rubriques sont des trames de travail, non le rendu graphique v107 officiel. Pas de photos IA ni de logo original ajoutés.

Les données historiques du ZIP ont été conservées à l’identique ; seuls les fichiers LOT261 sont ajoutés.
