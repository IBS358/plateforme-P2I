# P2I — Lot 236 : bilan matière et portes de validation des huit UP

**Source intégrale : Lot 235.** Aucun fichier historique n'a été remplacé. Les huit UP et les 24 débits exploratoires du lot 235 sont conservés.

## Livrables nouveaux

- `OUVRIR_BILANS_MATIERE_EDGE.html` : calculateur hors connexion dans Edge, avec les huit UP, choix des débits et saisie des données manquantes. Ne suppose aucun rendement, volume collecté, prix ou disponibilité technique.
- `CONFIGURATIONS_8UP.json` : extraction structurée des 8 configurations et 24 débits exploratoires.
- `MATRICE_PREUVES_8UP.csv` : 64 exigences de qualification (8 catégories × 8 UP), toutes à documenter.

## Calculs et limites

Le débit théorique = débit horaire × heures/jour × jours/mois ou débit journalier × jours/mois. Le débit réellement traitable = minimum(capacité nominale × disponibilité technique, gisement collectable). Les sorties valorisables = entrants traités × rendement massique. Les ventes = sorties × fraction vendue. Le chiffre d'affaires et les coûts variables ne sont calculés que si les champs correspondants sont renseignés. Le bilan matière ne doit pas être confondu avec le résultat net, le flux de trésorerie ou un BP v107.

## Contrôles de qualité

- Les 8 UP sont présentes et chaque UP dispose de trois débits exploratoires (24 scénarios).
- Aucun prix ni rendement n'est prérempli.
- Le catalogue actif 96 UP et le moteur v107 n'ont pas été modifiés.
- La matrice de preuves ne déclare aucun équipement comme vérifié.

## Suite technique nécessaire

Rechercher les fabricants et références exacts pour chaque poste, vérifier capacités et prix catalogue EXW/FOB, consolider les marchés de collecte et de vente, puis renseigner les bilans matière pour exécuter le moteur v107. Les huit BP Découverte ne sont pas encore finalisés.
