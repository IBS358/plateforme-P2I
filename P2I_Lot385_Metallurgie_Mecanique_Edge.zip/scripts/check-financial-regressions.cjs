#!/usr/bin/env node
'use strict';
// Fast deterministic regression guard for explicitly locked P2I scenarios.
// Indicative watchlist entries are protected from silent change but are never
// promoted to validated financial references.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const root = path.resolve(__dirname, '..');
const lock = JSON.parse(fs.readFileSync(path.join(root, 'data/p2i-financial-reference-lock.json'), 'utf8'));
const failures = [];
const close = (a, b) => Number.isFinite(a) && Number.isFinite(b) && Math.abs(a - b) <= 1e-6;
const digest = value => crypto.createHash('sha256').update(value).digest('hex');
const stable = value => JSON.stringify(value, (_k, v) => v && !Array.isArray(v) && typeof v === 'object'
  ? Object.fromEntries(Object.keys(v).sort().map(k => [k, v[k]])) : v);
function element(id) {
  return { id, innerHTML: '', value: 'USD', disabled: false, isConnected: true,
    addEventListener(){}, removeEventListener(){}, setAttribute(){}, getAttribute(){return null},
    querySelectorAll(){return []}, querySelector(){return null},
    classList:{add(){},remove(){},toggle(){return false},contains(){return false}}, style:{},
    focus(){}, click(){}, closest(){return null}, dispatchEvent(){}, append(){}, appendChild(){},
    after(){}, remove(){} };
}
function runScenario(item) {
  let html = '';
  const elements = new Map();
  const document = {
    getElementById(id) {
      if (!elements.has(id)) {
        const el = element(id); elements.set(id, el);
        if (id === 'app') Object.defineProperty(el, 'innerHTML', { get:()=>html, set:v=>{html=v;} });
      }
      return elements.get(id);
    },
    querySelector(){return null}, querySelectorAll(){return []}, createElement(tag){return element(tag)},
    addEventListener(){}, body:element('body'), head:element('head'), documentElement:element('html')
  };
  const query = new URLSearchParams({unit_id:item.up_id, configuration_id:item.configuration_id});
  const location = {search:'?'+query.toString(),hash:'',pathname:'/index.html',protocol:'file:',href:'file:///index.html?'+query.toString()};
  const storage = {getItem(){return null},setItem(){},removeItem(){},clear(){}};
  const context = {console, document, location, history:{replaceState(){}}, URL, URLSearchParams, Intl, Date, Math,
    Number, String, Array, Object, Map, Set, RegExp, Promise, JSON, Error, TypeError, Blob:function(){},
    navigator:{userAgent:'p2i-regression-check'}, localStorage:storage, sessionStorage:storage,
    crypto:crypto.webcrypto, requestAnimationFrame(fn){fn()}, setTimeout(fn){return 0}, clearTimeout(){},
    addEventListener(){}, dispatchEvent(){}, CustomEvent:function(){}, Event:function(){},
    fetch:async()=>{throw new Error('offline in local regression test')}, print(){}};
  context.window = context; vm.createContext(context);
  for (const file of ['runtime/asset-paths.js', ...Array.from({length:18},(_,i)=>`runtime/script-${i}.js`)]) {
    vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'), context, {filename:file, timeout:30000});
  }
  vm.runInContext(fs.readFileSync(path.join(root,'runtime/economic-anomaly-guard.js'),'utf8'), context, {filename:'runtime/economic-anomaly-guard.js', timeout:30000});
  vm.runInContext(fs.readFileSync(path.join(root,'runtime/script-18.js'),'utf8'), context, {filename:'runtime/script-18.js', timeout:30000});
  const scenario = context.P2I_BP_DONNEES?.unites?.[item.up_id]?.variantes?.[item.configuration_id];
  const actual = context.P2I_BP_V108_RESULTAT;
  if (!scenario || !actual) throw new Error(`${item.up_id}/${item.configuration_id}: scénario non calculé`);
  if (digest(stable(scenario)) !== item.input_sha256) failures.push(`${item.up_id}: hypothèses économiques de référence modifiées`);
  if (scenario.reference?.capacite !== item.catalogue_line.capacity_kg_h || scenario.reference?.machines !== item.catalogue_line.equipment_budget_usd || scenario.prix_equipement?.prix !== item.catalogue_line.equipment_budget_usd) failures.push(`${item.up_id}: configuration industrielle intégrée modifiée`);
  const engineHash = digest(fs.readFileSync(path.join(root,'runtime/script-15.js')));
  if (engineHash !== item.engine_sha256) failures.push(`${item.up_id}: moteur financier modifié, révision de référence requise`);
  const expected = item.results;
  const marginA1=actual.annuel?.[0]?.resultat_net/actual.annuel?.[0]?.chiffre_affaires;
  if ((marginA1>.20||marginA1<.05) && !html.includes('p2i-economic-alert')) failures.push(`${item.up_id}: alerte de diagnostic économique absente du rendu`);
  if (marginA1>=.05&&marginA1<=.20 && html.includes('p2i-economic-alert')) failures.push(`${item.up_id}: alerte économique inattendue au scénario de contrôle`);
  if (Number(actual.version) !== Number(expected.engine_version)) failures.push(`${item.up_id}: version du moteur attendue ${expected.engine_version}, obtenue ${actual.version}`);
  for (let i=0;i<expected.annual.length;i++) {
    const want=expected.annual[i], got=actual.annuel[i];
    for (const k of ['production','ventes','chiffre_affaires','cout_produits_vendus','resultat_net','resultat_avant_impot','amortissements','charges_financieres','impots']) {
      if (!close(got?.[k],want[k])) failures.push(`${item.up_id} A${i+1} ${k}: attendu ${want[k]}, obtenu ${got?.[k]}`);
    }
    const margin=got?.resultat_net/got?.chiffre_affaires;
    const roi=got?.resultat_net/actual.financement?.besoin_total;
    if (!close(margin,want.marge_nette)) failures.push(`${item.up_id} A${i+1} marge nette modifiée`);
    if (!close(roi,want.roi_sur_besoin_total)) failures.push(`${item.up_id} A${i+1} ROI modifié`);
  }
  for (let i=0;i<expected.monthly_treasury_year1.length;i++) {
    const want=expected.monthly_treasury_year1[i],got=actual.tresorerie[i];
    if (got?.mois!==want.mois || !close(got?.solde_final,want.solde_final)) failures.push(`${item.up_id} trésorerie M${i+1} modifiée`);
  }
  for (let i=0;i<(expected.monthly_bfr_year1||[]).length;i++) {
    const want=expected.monthly_bfr_year1[i],got=actual.bfr[i];
    for (const k of ['stocks','creances_clients','dettes_exploitation','dettes_sociales','dettes_fiscales_salariales','bfr']) if (!close(got?.[k],want[k])) failures.push(`${item.up_id} BFR M${i+1} ${k} modifié`);
  }
  for (let i=0;i<expected.balances.length;i++) {
    const want=expected.balances[i],got=actual.bilans[i];
    for (const k of ['actif_total','passif_total','ecart']) if (!close(got?.[k],want[k])) failures.push(`${item.up_id} bilan A${i+1} ${k} modifié`);
  }
  for (const k of ['apport','dette','apport_reserve','apport_total','besoin_total','total_ressources']) {
    if (!close(actual.financement?.[k],expected.financing[k])) failures.push(`${item.up_id} financement ${k} modifié`);
  }
  return {up_id:item.up_id,configuration_id:item.configuration_id,status:item.status,
    annual:actual.annuel.map(a=>({annee:a.annee,marge_nette:a.resultat_net/a.chiffre_affaires,roi:a.resultat_net/actual.financement.besoin_total,resultat_net:a.resultat_net})),
    min_cash:Math.min(...actual.tresorerie.slice(0,12).map(x=>x.solde_final)),
    max_balance_gap:Math.max(...actual.bilans.map(x=>Math.abs(x.ecart))),
    cards: (html.match(/POSTE \d{2} \/ \d{2}/g)||[]).length };
}
if (!Array.isArray(lock.validated_scenarios)) failures.push('validated_scenarios doit être une liste');
// The completion marker in the BP matrix is not a financial approval; the two inventories stay separate.
const results=[];
try { for (const item of lock.validated_scenarios) results.push(runScenario({...item,status:'validated_reference'})); for (const item of lock.indicative_regression_watchlist||[]) results.push(runScenario(item)); }
catch (e) { failures.push(e.stack||String(e)); }
console.log(JSON.stringify({schema:lock.schema,validated_reference_count:lock.validated_scenarios.length,indicative_watchlist_count:results.length,results,failures},null,2));
if (failures.length) process.exitCode=1;
