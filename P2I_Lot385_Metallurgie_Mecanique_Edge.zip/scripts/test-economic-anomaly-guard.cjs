#!/usr/bin/env node
'use strict';
const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const root=path.resolve(__dirname,'..'),context={};context.window=context;vm.createContext(context);vm.runInContext(fs.readFileSync(path.join(root,'runtime/economic-anomaly-guard.js'),'utf8'),context);
const inspect=context.P2I_ECONOMIC_ANOMALY_GUARD.inspect;
const high=inspect({prix:[2.5],cout_production_kg:[.8],matieres_kg:.4,source:'hypothèse P2I',production:[100],ventes:[98],capacite:1},{annuel:[{chiffre_affaires:245,resultat_net:55}]});
if(!high.length||high[0].margin_a1<.2||!high[0].reasons.some(x=>x.includes('prix de vente')))throw Error('Seuil de marge atypique ou explication de cause non détecté.');
const low=inspect({prix:[1],cout_production_kg:[1.1],production:[100],ventes:[100],capacite:1},{annuel:[{chiffre_affaires:100,resultat_net:-5}]});
if(!low.length||low[0].severity!=='high'||!low[0].reasons.some(x=>x.includes('coût de production')))throw Error('Coût supérieur au prix non détecté.');
const excess=inspect({prix:[1],cout_production_kg:[.6],production:[7000],ventes:[7000],capacite:1},{annuel:[{chiffre_affaires:7000,resultat_net:700}]});
if(!excess.some(x=>x.warnings.some(w=>w.includes('6 000 heures'))))throw Error('Alerte de capacité vendable non détectée.');
const valid=inspect({prix:[1],cout_production_kg:[.65],matieres_kg:.3,prix_source_documentee:true,volume_commercial_documente:true,production:[100],ventes:[100],capacite:1},{annuel:[{chiffre_affaires:100,resultat_net:12}]});
if(valid.length)throw Error('Le détecteur crée une alerte sans motif économique/documentaire.');
console.log('PASS — seuil >20 %, faiblesse/valeur négative, coût unitaire incohérent, volume/capacité; aucun plafond automatique ni modification des données.');
