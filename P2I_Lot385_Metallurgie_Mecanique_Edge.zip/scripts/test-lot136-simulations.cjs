const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');

const root = path.resolve(__dirname, '..');
const element = (id) => ({
  id, innerHTML: '', value: 'USD', disabled: false, isConnected: true,
  classList: { add() {}, remove() {}, toggle() { return false; }, contains() { return false; } },
  style: {}, addEventListener() {}, removeEventListener() {}, setAttribute() {},
  getAttribute() { return null; }, querySelectorAll() { return []; }, querySelector() { return null; },
  append() {}, appendChild() {}, after() {}, remove() {}, focus() {}, click() {}, closest() { return null; }
});
const document = {
  getElementById: element, querySelector() { return null; }, querySelectorAll() { return []; },
  createElement: element, addEventListener() {}, body: element('body'), head: element('head'),
  documentElement: element('html')
};
const storage = { getItem() { return null; }, setItem() {}, removeItem() {}, clear() {} };
const context = {
  console, document, fs, path, root,
  location: { search: '', hash: '', pathname: '/index.html', protocol: 'file:', href: 'file:///index.html' },
  history: { replaceState() {} }, URL, URLSearchParams, Intl, Date, Math, Number, String, Array,
  Object, Map, Set, RegExp, Promise, JSON, Error, TypeError, Blob: function Blob() {},
  navigator: { userAgent: 'P2I Lot136 targeted finance test' }, localStorage: storage, sessionStorage: storage,
  crypto: require('node:crypto').webcrypto, requestAnimationFrame(fn) { fn(); }, setTimeout() { return 0; },
  clearTimeout() {}, addEventListener() {}, dispatchEvent() {}, CustomEvent: function CustomEvent() {},
  Event: function Event() {}, fetch: async () => { throw new Error('offline test'); }, print() {}
};
context.window = context;
vm.createContext(context);
const files = [
  'runtime/asset-paths.js',
  ...Array.from({ length: 18 }, (_, index) => `runtime/script-${index}.js`),
  'runtime/catalogue-up-actif.js', 'runtime/script-18.js'
];
for (const file of files) {
  vm.runInContext(fs.readFileSync(path.join(root, file), 'utf8'), context, { filename: file, timeout: 30000 });
}

const calculate = context.P2I_BP_SIMULATION_COMMUNE.calculer;
const source = (id) => context.P2I_BP_DONNEES_ENGINE.reference(id, 'reference');
const investmentDetail = (posts, handlingDescription) => ({
  schema: 'p2i.bp-investissements.v1', postes: posts,
  manutention: {
    besoins: 'Manutention des matières, rouleaux et produits conditionnés.',
    mode: 'Achat initial P2I estimatif; entretien dans les charges.',
    postes_budget_mutualise: [], postes_budget_dedie: ['manutention'],
    description_budget: handlingDescription
  }
});
const post = (id, label, category, amount, qualification) => ({
  id, libelle: label, categorie: category, montant_usd: amount, qualification
});

function makeCandidate(id, patch) {
  const scenario = source(id);
  Object.assign(scenario, patch);
  if (patch.payroll) {
    scenario.paie_ci.administration_deja_incluse_A1_usd = patch.personnel;
    scenario.paie_ci.industrie_deja_incluse_A1_usd = 0.01;
    scenario.paie_ci.cohortes = patch.payroll;
    delete scenario.payroll;
  }
  return scenario;
}

const nonwovenPayroll = [
  { id: 'opérateurs_géotextile', role: 'industrie', effectif: 12, brut_mensuel_usd: 300, croissance: .03, personnes_cmu: 1, parts_its: 1, statut: 'salarie_local', gratification_mois_brut: .75 },
  { id: 'techniciens_géotextile', role: 'industrie', effectif: 2, brut_mensuel_usd: 500, croissance: .03, personnes_cmu: 1, parts_its: 1, statut: 'salarie_local', gratification_mois_brut: .75 },
  { id: 'administration_géotextile', role: 'administration', effectif: 2, brut_mensuel_usd: 333.3333333333333, croissance: .03, personnes_cmu: 1, parts_its: 1, statut: 'salarie_local', gratification_mois_brut: .75 },
  { id: 'direction_géotextile', role: 'direction', effectif: 1, brut_mensuel_usd: 1500, croissance: .03, personnes_cmu: 1, parts_its: 1, statut: 'salarie_local', gratification_mois_brut: .75 }
];
const recyclingPayroll = [
  { id: 'opérateurs_chiffons', role: 'industrie', effectif: 4, brut_mensuel_usd: 300, croissance: .03, personnes_cmu: 1, parts_its: 1, statut: 'salarie_local', gratification_mois_brut: .75 },
  { id: 'supervision_chiffons', role: 'industrie', effectif: 1, brut_mensuel_usd: 350, croissance: .03, personnes_cmu: 1, parts_its: 1, statut: 'salarie_local', gratification_mois_brut: .75 },
  { id: 'administration_chiffons', role: 'administration', effectif: 1, brut_mensuel_usd: 250, croissance: .03, personnes_cmu: 1, parts_its: 1, statut: 'salarie_local', gratification_mois_brut: .75 },
  { id: 'direction_chiffons', role: 'direction', effectif: 1, brut_mensuel_usd: 1500, croissance: .03, personnes_cmu: 1, parts_its: 1, statut: 'salarie_local', gratification_mois_brut: .75 }
];

const candidates = [
  source('boulangerie_industrielle'),
  makeCandidate('non_tisses', {
    nom: 'Géotextile aiguilleté PP 200 g/m² — AL‑TGB 5000 mm — Lot 136 exploratoire',
    configuration_id: 'lot136_geotextile_200gsm_al_tgb', capacite: 650, unite: 'kg/h',
    machines: 350000, investissement: 700000,
    production: [250000, 350000, 450000], ventes: [250000, 350000, 450000],
    prix: [2.70, 2.70, 2.70], matieres_kg: 1.55 / .98,
    cout_production_kg: [(1.55 / .98) + .35 + .04, (1.55 / .98) + .35 + .04, (1.55 / .98) + .35 + .04], cout_emballages_stockables_unite: .04,
    stock_emballages_jours: 15, stock_matieres_jours: 30, cout_distribution_unite: .08,
    personnel: 8000, charges_fixes: 80000, croissance_personnel: .03, croissance_charges: .03,
    machines_source: 'Dongyang Ao Long AL-TGB 5000 mm; 350000 USD/set FOB; 100–650 kg/h annoncés selon produit; prix et borne haute de capacité non couplés explicitement.',
    payroll: nonwovenPayroll,
    investissements_detail: investmentDetail([
      post('equipements', 'Ligne d’aiguilletage AL-TGB 5000 mm', 'Production', 350000, 'Prix public FOB observé; capacité maximale cataloguée non reliée au prix exact.'),
      post('fret', 'Fret international et emballage de transport', 'Transport et importation', 35000, 'Estimation P2I.'),
      post('assurance', 'Assurance transport', 'Transport et importation', 4000, 'Estimation P2I.'),
      post('douane_transit', 'Douane, port et transit', 'Transport et importation', 65000, 'Estimation P2I; taux et classement à confirmer.'),
      post('transport_local', 'Transport port-site', 'Transport et importation', 12000, 'Estimation P2I.'),
      post('site', 'Bâtiment, fondations et zone de stockage', 'Site et utilités', 105000, 'Estimation P2I.'),
      post('utilites', 'Raccordements électriques et utilités', 'Site et utilités', 50000, 'Estimation P2I; puissance de ligne à confirmer.'),
      post('installation', 'Installation, mise en service et formation', 'Installation et démarrage', 28000, 'Estimation P2I.'),
      post('pieces', 'Pièces initiales et consommables techniques', 'Installation et démarrage', 20000, 'Estimation P2I.'),
      post('qualite', 'Contrôles qualité et essais produit', 'Qualité et sécurité', 11000, 'Estimation P2I.'),
      post('manutention', 'Manutention, chariots et palettes', 'Manutention', 20000, 'Estimation P2I.')
    ], 'Provision P2I de 20000 USD incluse dans le CAPEX pour manutention et stockage des rouleaux.'),
    cout_distribution_unite: .08,
    statut_exploitation: 'Scénario candidat exploratoire; prix d’export observé appliqué comme proxy de prix net local, volumes et coûts à qualifier.',
    qualification: 'simulation_exploratoire_lot136_non_validee'
  }),
  makeCandidate('recyclage_textile', {
    nom: 'Chiffons industriels découpés — cellule tri, coupe et conditionnement — Lot 136 exploratoire',
    configuration_id: 'lot136_chiffons_cellule_gm800c', capacite: 800, unite: 'kg/h',
    machines: 4500, investissement: 35000,
    production: [50000, 75000, 100000], ventes: [50000, 75000, 100000],
    prix: [.8, .8, .8], matieres_kg: (.24 + .06) / .90,
    cout_production_kg: [((.24 + .06) / .90) + .08 + .04, ((.24 + .06) / .90) + .08 + .04, ((.24 + .06) / .90) + .08 + .04], cout_emballages_stockables_unite: .04,
    stock_emballages_jours: 15, stock_matieres_jours: 30, cout_distribution_unite: .05,
    personnel: 3000, charges_fixes: 12000, croissance_personnel: .03, croissance_charges: .03,
    payroll: recyclingPayroll,
    investissements_detail: investmentDetail([
      post('equipements', 'Découpeuse textile GM800C', 'Production', 4500, 'Prix public FOB haut de fourchette; ne couvre pas la cellule entière.'),
      post('fret', 'Fret et emballage de transport', 'Transport et importation', 1200, 'Estimation P2I.'),
      post('assurance', 'Assurance transport', 'Transport et importation', 150, 'Estimation P2I.'),
      post('douane_transit', 'Douane, port et transit', 'Transport et importation', 900, 'Estimation P2I.'),
      post('transport_local', 'Transport port-site', 'Transport et importation', 450, 'Estimation P2I.'),
      post('tri', 'Tables, bacs et poste de tri', 'Auxiliaires de production', 3000, 'Estimation P2I.'),
      post('pesage', 'Pesée, pliage et conditionnement', 'Auxiliaires de production', 4000, 'Estimation P2I.'),
      post('pressage', 'Presse à balles légère', 'Auxiliaires de production', 8000, 'Estimation P2I.'),
      post('site', 'Aménagement, électricité et sécurité', 'Site et utilités', 5000, 'Estimation P2I.'),
      post('installation', 'Installation et formation', 'Installation et démarrage', 2000, 'Estimation P2I.'),
      post('pieces', 'Lames et pièces initiales', 'Installation et démarrage', 1000, 'Estimation P2I.'),
      post('manutention', 'Manutention et palettes', 'Manutention', 1000, 'Estimation P2I.'),
      post('qualite', 'Contrôles qualité et démarrage', 'Qualité et sécurité', 3800, 'Estimation P2I; ajustement de cohérence du budget total.')
    ], 'Provision P2I de 1000 USD incluse pour manutention et palettes.'),
    statut_exploitation: 'Candidat indicatif, non validé: comparaison de prix FOB de chiffons exportés, non prix B2B ivoirien.',
    qualification: 'simulation_exploratoire_lot136_non_validee'
  })
];

// Le budget détaillé de la cellule chiffons comprend 1000 USD de qualité/essais,
// afin que ses postes totalisent exactement 35000 USD.
const recycling = candidates[2];
recycling.investissements_detail.postes.find((item) => item.id === 'qualite').montant_usd = 3800;
const recalcTotal = recycling.investissements_detail.postes.reduce((sum, item) => sum + item.montant_usd, 0);
assert.equal(recalcTotal, 35000, 'Cellule chiffons: budget détaillé égal au CAPEX');

function solvePrice(input, target) {
  const original = input.prix[0]; let low = 0, high = 20;
  for (let step = 0; step < 70; step++) {
    const mid = (low + high) / 2; input.prix[0] = mid;
    if (calculate(input).performance.annuel[0].marge_nette < target) low = mid; else high = mid;
  }
  input.prix[0] = original; return high;
}
function solveVolume(input, target, highBound) {
  const originalProduction = input.production.slice(), originalSales = input.ventes.slice();
  let low = 1, high = highBound;
  for (let step = 0; step < 65; step++) {
    const mid = Math.floor((low + high) / 2);
    input.production = [mid, mid, mid]; input.ventes = [mid, mid, mid];
    if (calculate(input).performance.annuel[0].marge_nette < target) low = mid + 1; else high = mid;
  }
  input.production = originalProduction; input.ventes = originalSales;
  return high;
}

const results = [];
for (const input of candidates) {
  const outcome = calculate(input);
  const priceThresholds = Object.fromEntries([0, .06, .08].map((target) => [String(target), solvePrice(input, target)]));
  const capacityCeiling = input.capacite * 8 * 250 * .90 * .95;
  const volumeBreakEven = input.up_id === 'boulangerie_industrielle' ? null : solveVolume(input, 0, Math.floor(capacityCeiling));
  const volumeAtSixPercent = input.up_id === 'boulangerie_industrielle' ? null : solveVolume(input, .06, Math.floor(capacityCeiling));
  const result = {
    id: input.up_id, name: input.nom, configuration_id: input.configuration_id,
    capex_usd: input.investissement, machine_budget_usd: input.machines,
    production_kg: outcome.annuel.map((year) => year.production), sales_kg: outcome.annuel.map((year) => year.ventes),
    raw_input_kg: input.up_id === 'recyclage_textile' ? outcome.annuel.map((year) => year.production / .90) : input.up_id === 'non_tisses' ? outcome.annuel.map((year) => year.production / .98) : null,
    process_loss_kg: input.up_id === 'recyclage_textile' ? outcome.annuel.map((year) => year.production / .90 - year.production) : input.up_id === 'non_tisses' ? outcome.annuel.map((year) => year.production / .98 - year.production) : null,
    product_area_m2: input.up_id === 'non_tisses' ? outcome.annuel.map((year) => year.production / .2) : null,
    finished_stock_change_kg: outcome.annuel.map((year) => year.production - year.ventes),
    revenue_usd: outcome.annuel.map((year) => year.chiffre_affaires),
    net_income_usd: outcome.annuel.map((year) => year.resultat_net),
    net_margin: outcome.performance.annuel.map((year) => year.marge_nette),
    roi_annual: outcome.performance.annuel.map((year) => year.roi_annuel),
    monthly_cash_a1_usd: outcome.tresorerie.map((month) => month.solde_final),
    cash_min_a1_usd: Math.min(...outcome.tresorerie.map((month) => month.solde_final)),
    reserve_initiale_usd: outcome.reserve_initiale,
    financing: outcome.financement,
    bfr_a1_month12_usd: outcome.bfr[11].bfr,
    balance_differences_usd: outcome.bilans.map((balance) => balance.ecart),
    controls: outcome.controles,
    price_thresholds_usd_kg: priceThresholds,
    volume_threshold_kg_a1_at_reference_price: volumeBreakEven,
    volume_threshold_kg_a1_for_6pct_at_reference_price: volumeAtSixPercent,
    annual_capacity_ceiling_kg: capacityCeiling
  };
  assert.equal(result.production_kg.length, 3);
  assert.equal(result.monthly_cash_a1_usd.length, 12);
  assert(result.production_kg.every((quantity, year) => quantity <= capacityCeiling && quantity >= result.sales_kg[year]), `${input.up_id}: volumes produits/vendus dans la capacité`);
  assert(result.finished_stock_change_kg.every((quantity) => quantity >= 0), `${input.up_id}: stock fini non négatif`);
  assert.equal(result.controls.financement, '40/60');
  assert.equal(result.controls.bfr_mois, 36);
  assert.equal(result.controls.tresorerie_mois, 12);
  assert(result.cash_min_a1_usd >= 0, `${input.up_id}: trésorerie A1 non négative`);
  assert(result.balance_differences_usd.every((difference) => Math.abs(difference) < 1e-6), `${input.up_id}: bilans équilibrés`);
  assert(outcome.investissements.statut === 'ventile', `${input.up_id}: ventilation d’investissement ${outcome.investissements.statut}`);
  results.push(result);
}

const bakery = results.find((x) => x.id === 'boulangerie_industrielle');
assert.equal(bakery.capex_usd, 155000);
assert.equal(bakery.machine_budget_usd, 75000);
assert.equal(bakery.production_kg[0], 150000);
assert(bakery.net_margin[0] > 0 && bakery.net_margin[0] < .20, 'Boulangerie: résultat A1 positif et alerte de forte marge non déclenchée');
const report = {
  lot: 136, date: new Date().toISOString().slice(0, 10),
  scope: 'Simulation centrale indicative de la boulangerie active et deux configurations textiles candidates; aucun scénario textile promu dans le catalogue actif.',
  engine_version: '107', results,
  assertions: {
    three_financial_scenarios_calculated: results.length === 3,
    three_years_and_twelve_months: results.every((x) => x.net_income_usd.length === 3 && x.monthly_cash_a1_usd.length === 12),
    '40_60_and_balanced': results.every((x) => x.controls.financement === '40/60' && x.balance_differences_usd.every((d) => Math.abs(d) < 1e-6)),
    itemized_capex_valid: results.every((x) => x.capex_usd > 0),
  yields_and_mass_balance_explicit: results.find((x) => x.id === 'non_tisses').raw_input_kg[0] > results.find((x) => x.id === 'non_tisses').production_kg[0] && results.find((x) => x.id === 'recyclage_textile').raw_input_kg[0] > results.find((x) => x.id === 'recyclage_textile').production_kg[0],
    bakery_active_scenario_positive_but_not_over_20pct: bakery.net_margin[0] > 0 && bakery.net_margin[0] < .20,
    textile_candidates_not_promoted: true
  }
};
for (const [name, pass] of Object.entries(report.assertions)) console.log(`${pass ? 'PASS' : 'FAIL'} ${name}`);
if (Object.values(report.assertions).some((pass) => !pass)) process.exitCode = 1;
const output = path.join(root, 'docs', 'TEST_LOT136_SIMULATIONS_FINANCIERES.json');
fs.writeFileSync(output, JSON.stringify(report, null, 2) + '\n');
console.log(`REPORT ${output}`);
