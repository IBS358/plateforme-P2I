#!/usr/bin/env node
'use strict';
// Reproductible diagnostic, read-only: uses the same P2I data and financial engine.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.resolve(__dirname,'..'),failures=[];
function el(id){return {id,innerHTML:'',value:'USD',disabled:false,isConnected:true,addEventListener(){},removeEventListener(){},setAttribute(){},getAttribute(){return null},querySelectorAll(){return[]},querySelector(){return null},classList:{add(){},remove(){},toggle(){return false},contains(){return false}},style:{},focus(){},click(){},closest(){return null},dispatchEvent(){},append(){},appendChild(){},after(){},remove(){}}}
let html='';const els=new Map(),storage={getItem(){return null},setItem(){},removeItem(){},clear(){}};
const document={getElementById(id){if(!els.has(id)){const e=el(id);els.set(id,e);if(id==='app')Object.defineProperty(e,'innerHTML',{get(){return html},set(v){html=v}})}return els.get(id)},querySelector(){return null},querySelectorAll(){return[]},createElement(tag){return el(tag)},addEventListener(){},body:el('body'),head:el('head'),documentElement:el('html')};
const c={console,document,location:{search:'',hash:'',pathname:'/index.html',protocol:'file:',href:'file:///index.html'},history:{replaceState(){}},URL,URLSearchParams,Intl,Date,Math,Number,String,Array,Object,Map,Set,RegExp,Promise,JSON,Error,TypeError,Blob:function(){},navigator:{userAgent:'p2i-economic-scan'},localStorage:storage,sessionStorage:storage,crypto:require('node:crypto').webcrypto,requestAnimationFrame(fn){fn()},setTimeout(fn){return 0},clearTimeout(){},addEventListener(){},dispatchEvent(){},CustomEvent:function(){},Event:function(){},fetch:async()=>{throw Error('offline')},print(){}};
c.window=c;vm.createContext(c);
for(const f of ['runtime/asset-paths.js',...Array.from({length:18},(_,i)=>`runtime/script-${i}.js`),'runtime/economic-anomaly-guard.js']){try{vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),c,{filename:f,timeout:30000})}catch(e){failures.push(`${f}: ${e.message}`)}}
const units=c.P2I_BP_DONNEES?.unites||{},anomalies=[];let scenarioCount=0,calculated=0,notCalculated=0;
for(const [id,u] of Object.entries(units))for(const [variant,v] of Object.entries(u.variantes||{})){
 scenarioCount++;let s,r;try{s=c.P2I_BP_DONNEES_ENGINE.reference(id,variant);if(!s?.production||s.manquants?.length){notCalculated++;continue}r=c.P2I_BP_SIMULATION_COMMUNE.calculer(s);calculated++}catch(e){notCalculated++;continue}
 const alerts=c.P2I_ECONOMIC_ANOMALY_GUARD.inspect(s,r);if(!alerts.length)continue;
 const a=r.annuel[0],alert=alerts[0],price=Number(s.prix?.[0]),cost=Number(s.cout_production_kg?.[0]);
 let diagnosis=alert.reasons.join('; ');
 if(alert.margin_a1<.05&&alert.margin_a1>=0&&cost<price)diagnosis+='; écart brut positif mais absorbé par charges fixes, amortissements, intérêts et/ou fiscalité';
 if(id==='biscuiterie'&&variant==='crackers')diagnosis='prix de vente P2I sans source départ usine/gros; coût unitaire construit à partir d’hypothèses, emballage et distribution non ventilés; volumes annuels sans commandes documentées';
 anomalies.push({up_id:id,up_name:u.nom||u.up_nom||id,variant,margin_a1:alert.margin_a1,revenue_a1_usd:a.chiffre_affaires,net_income_a1_usd:a.resultat_net,price_a1_usd_per_unit:price,unit_cost_a1_usd:cost,price_source_level:alert.price_documented?'source déclarée à qualifier':'prix dans la simulation, sans référence séparée de prix net canal/départ usine',volume_source_level:alert.volume_documented?'preuve commerciale déclarée':'programme P2I simulé, sans commande ou étude de volume jointe',source_scenario:s.source||'non renseignée',cause:diagnosis,action:id==='biscuiterie'?'Geler le scénario comme indicatif; documenter prix net usine/gros, unité du prix, nomenclature/emballage/distribution et volumes puis versionner avant recalcul.':'Examiner séparément prix net, coût unitaire, volume vendable et absorption des charges; ne pas modifier avant justification.'});
}
if(failures.length)throw Error(failures.join('\n'));
const report={schema:'p2i.economic-anomaly-scan.v1',date:'2026-11-14',read_only:true,financial_inputs_modified:false,engine_modified:false,scenario_count:scenarioCount,calculated_count:calculated,not_calculated_count:notCalculated,alert_count:anomalies.length,policy:{margin_above_20_percent:'alerte de revue uniquement; aucun plafond automatique',margin_below_5_percent:'alerte de fragilité',negative_net_income:'alerte prioritaire',unreferenced_price_or_volume:'alerte documentaire',sales_above_production:'alerte de cohérence',equivalent_hours_above_6000:'alerte de capacité'},anomalies};
const out=path.join(root,'docs/DIAGNOSTIC_ECONOMIQUE_LOT132.json');fs.writeFileSync(out,JSON.stringify(report,null,2)+'\n');
const q=x=>'"'+String(x??'').replaceAll('"','""')+'"';
const rows=[['up_id','up_name','variant','margin_a1','net_income_a1_usd','cause','price_source_level','volume_source_level','action'],...anomalies.map(x=>[x.up_id,x.up_name,x.variant,(x.margin_a1*100).toFixed(2)+'%',x.net_income_a1_usd.toFixed(2),x.cause,x.price_source_level,x.volume_source_level,x.action])];
fs.writeFileSync(path.join(root,'docs/DIAGNOSTIC_ECONOMIQUE_LOT132.csv'),rows.map(r=>r.map(q).join(',')).join('\n')+'\n');
console.log(JSON.stringify({...report,anomalies:anomalies.map(x=>({up_id:x.up_id,variant:x.variant,margin_a1:x.margin_a1,cause:x.cause}))},null,2));
