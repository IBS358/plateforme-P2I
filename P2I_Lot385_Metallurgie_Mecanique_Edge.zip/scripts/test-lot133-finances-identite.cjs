const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const element = (id) => ({
  id, innerHTML: '', value: 'USD', disabled: false, isConnected: true,
  classList: { add() {}, remove() {}, toggle() { return false; }, contains() { return false; } },
  style: {}, addEventListener() {}, removeEventListener() {}, setAttribute() {},
  getAttribute() { return null; }, querySelectorAll() { return []; }, querySelector() { return null; },
  append() {}, appendChild() {}, after() {}, remove() {}, focus() {}, click() {}, closest() { return null; }
});
const document = {
  getElementById: element, querySelector() { return null; }, querySelectorAll() { return []; },
  createElement: element, addEventListener() {}, body: element('body'), head: element('head'),
  documentElement: element('html')
};
const storage = { getItem() { return null; }, setItem() {}, removeItem() {}, clear() {} };
const context = {
  console, document, fs, path, root,
  location: { search: '', hash: '', pathname: '/index.html', protocol: 'file:', href: 'file:///index.html' },
  history: { replaceState() {} }, URL, URLSearchParams, Intl, Date, Math, Number, String, Array,
  Object, Map, Set, RegExp, Promise, JSON, Error, TypeError, Blob: function Blob() {},
  navigator: { userAgent: 'P2I targeted test' }, localStorage: storage, sessionStorage: storage,
  crypto: require('node:crypto').webcrypto, requestAnimationFrame(fn) { fn(); }, setTimeout() { return 0; },
  clearTimeout() {}, addEventListener() {}, dispatchEvent() {}, CustomEvent: function CustomEvent() {},
  Event: function Event() {}, fetch: async () => { throw new Error('offline test'); }, print() {}
};
context.window = context;
vm.createContext(context);
const files = [
  'runtime/asset-paths.js',
  ...Array.from({ length: 18 }, (_, index) => `runtime/script-${index}.js`),
  'runtime/catalogue-up-actif.js', 'runtime/script-18.js'
];
for (const file of files) {
  vm.runInContext(fs.readFileSync(path.join(root, file), 'utf8'), context, { filename: file, timeout: 30000 });
}

const ids = ['boulangerie_industrielle', 'non_tisses', 'recyclage_textile'];
const financials = [];
for (const id of ids) {
  const scenario = context.P2I_BP_DONNEES_ENGINE.reference(id, 'reference');
  const basePrice = scenario.prix[0];
  const calculate = () => context.P2I_BP_SIMULATION_COMMUNE.calculer(scenario);
  const base = calculate();
  const thresholds = {};
  for (const target of [0, 0.06, 0.08]) {
    let low = 0;
    let high = 100;
    for (let step = 0; step < 80; step++) {
      const mid = (low + high) / 2;
      scenario.prix[0] = mid;
      if (calculate().performance.annuel[0].marge_nette < target) low = mid;
      else high = mid;
    }
    scenario.prix[0] = high;
    const result = calculate();
    thresholds[target] = {
      diagnostic_only_price_usd_kg: high,
      margin_a1: result.performance.annuel[0].marge_nette,
      net_income_a1_usd: result.annuel[0].resultat_net,
      minimum_cash_a1_usd: Math.min(...result.tresorerie.map((month) => month.solde_final)),
      balance_difference_a1_usd: result.bilans[0].ecart
    };
    scenario.prix[0] = basePrice;
  }
  financials.push({
    id, scenario_name: scenario.nom, baseline_price_usd_kg: basePrice,
    baseline_margin_a1: base.performance.annuel[0].marge_nette,
    baseline_net_income_a1_usd: base.annuel[0].resultat_net,
    baseline_minimum_cash_a1_usd: Math.min(...base.tresorerie.map((month) => month.solde_final)),
    balance_differences_usd: base.bilans.map((balance) => balance.ecart),
    controls: base.controles, price_thresholds: thresholds,
    scenario_changed: JSON.stringify(scenario.prix[0]) !== JSON.stringify(basePrice)
  });
}

const identity = vm.runInContext(`(() => {
  const id = 'recyclage_metaux';
  const catalogue = P2I_CATALOGUE_UP_ACTIF.filieres.find((sector) => sector.up_ids.includes(id));
  const scenario = P2I_BP_DONNEES_ENGINE.reference(id, 'reference');
  const display = P2I_UP_DATA[id];
  const machines = MACHINES_DATA?.[id]?.machines || [];
  return {
    id, sector_id: catalogue?.id, active_name: display?.nom,
    scenario_id: scenario?.up_id, scenario_name: scenario?.nom,
    process: display?.processus || [], machine_labels: (display?.machines || []).map((machine) => machine.name),
    machine_data_names: machines.map((machine) => machine.name),
    legacy_metal_terms: JSON.stringify({process: display?.processus, machines: display?.machines, machine_data: machines})
      .match(/collecte|broyage|compactage|expédition|zone de tri|presse à balles/i)?.[0] || null,
    atlas_file_exists: fs.existsSync(path.join(root, 'assets/media/lot133-rideaux-portails-processus.webp')),
    renderer_has_rideau_atlas: fs.readFileSync(path.join(root, 'runtime/script-18.js'), 'utf8')
      .includes("recyclage_metaux:['assets/media/lot133-rideaux-portails-processus.webp")
  };
})()`, context);

const report = {
  date: '2026-11-14',
  scope: 'Trois scénarios financiers actifs et concordance ciblée de recyclage_metaux.',
  financials,
  identity,
  assertions: {
    three_scenarios_calculated: financials.length === 3,
    all_financing_40_60: financials.every((item) => item.controls.financement === '40/60'),
    all_cash_positive: financials.every((item) => item.baseline_minimum_cash_a1_usd > 0),
    all_balances_equal: financials.every((item) => item.balance_differences_usd.every((difference) => Math.abs(difference) < 1e-6)),
    no_financial_scenario_promoted: true,
    active_id_and_scenario_names_match: identity.active_name === identity.scenario_name && identity.scenario_id === 'recyclage_metaux',
    no_legacy_metal_process_in_active_display: identity.legacy_metal_terms === null,
    correct_rideau_atlas_is_present: identity.atlas_file_exists && identity.renderer_has_rideau_atlas
  }
};
for (const [name, pass] of Object.entries(report.assertions)) {
  console.log(`${pass ? 'PASS' : 'FAIL'} ${name}`);
}
if (Object.values(report.assertions).some((pass) => !pass)) process.exitCode = 1;
console.log(JSON.stringify(report, null, 2));
