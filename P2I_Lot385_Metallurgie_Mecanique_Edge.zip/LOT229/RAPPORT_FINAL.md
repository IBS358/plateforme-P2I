# P2I — Lot 229 — Synthèse de clôture de l’étude du mobilier

- 17 rubriques et visuel IA produit dans le dossier LOT229.
- Moteur commun v107 exécuté sur trois trajectoires; scripts et résultats conservés.
- A1 retenue: 139,9 M FCFA de CA, marge nette **3,11 %**, contre 3,98 % extrapolés dans le lot 228. A2 7,80 %, A3 8,13 % sous hypothèses.
- Personnel et rémunération additionnelle dirigeant 300 000 FCFA/mois séparés des coûts variables.
- Crédit client: modèle de flux complémentaire, **non intégré au v107**. Réserve partielle ne vaut pas besoin total de financement.
- Catalogue actif 96 UP non modifié: une migration isolée ferait échouer ses contrôles de cohérence; le dossier est accessible depuis l’index des huit BP.
- Le BP est **rédigé et simulé mais non économiquement validé**: CAPEX, prix, commandes et capacité industrielle non vérifiés.
- L’illustration IA n’est pas une photographie d’usine.
- Les sept autres BP et les archives restent inchangés.
