# P2I — Lot 216 — Test économique v107 du mobilier scolaire (NON VALIDÉ)

## Périmètre
Base : archive Lot 215 (388 fichiers). Aucun fichier existant modifié. Catalogue des 96 UP, irrigation et sept BP historiques inchangés. Le mobilier reste un **candidat hors catalogue**. Le présent test ne constitue pas un BP Découverte.

## Hypothèses du stress test, non validées
- Table-banc scolaire biplace semi-métallique, 33 000 FCFA de prix de vente indicatif historique, non confirmé comparable.
- Matières acier et panneaux : 18 200 FCFA/unité, prix conditionnels hérités des lots 213–215.
- Autres coûts variables : 4 000 / 7 000 / 10 000 FCFA/unité, **hypothèses de sensibilité, non des prix sourcés**.
- Volumes annuels : 300, 600, 900, 1 200, **sans commandes établies**.
- CAPEX 15 000 USD dont machines 10 000 USD, personnel 12 000 USD/an, charges fixes 8 000 USD/an : **hypothèses exploratoires non documentées**. Ces chiffres ne doivent pas être repris comme données réelles.
- Change 595 FCFA/USD ; 40 % apport / 60 % dette ; intérêt 8 %, dette 60 mois ; TVA 18 %, IS 25 % ; coût matière +3 %/an, personnel +4 %/an, charges fixes +3 %/an.

## Résultats effectifs du moteur commun v107
12 scénarios exécutés par `LOT216_RUN.cjs` (rejouable avec Node.js depuis `P2I_Edge`). **12/12 déficitaires en année 1 et en année 3**.

| Autres coûts FCFA/unité | Ventes/an | Résultat net A1 (USD) | Résultat net A3 (USD) |
|---:|---:|---:|---:|
| 4 000 | 300 | -17 008,62 | -18 858,14 |
| 4 000 | 600 | -11 863,24 | -14 383,88 |
| 4 000 | 900 | -6 717,87 | -9 909,62 |
| 4 000 | 1 200 | -1 572,49 | -5 435,36 |
| 7 000 | 300 | -18 521,23 | -20 458,97 |
| 7 000 | 600 | -14 888,45 | -17 585,54 |
| 7 000 | 900 | -11 255,68 | -14 712,10 |
| 7 000 | 1 200 | -7 622,91 | -11 838,67 |
| 10 000 | 300 | -20 033,83 | -22 059,80 |
| 10 000 | 600 | -17 913,66 | -20 787,19 |
| 10 000 | 900 | -15 793,50 | -19 514,59 |
| 10 000 | 1 200 | -13 673,33 | -18 241,98 |

## Tests techniques
- Moteur commun chargé depuis les scripts `runtime/script-0.js` à `script-11.js`.
- 12 scénarios produits ; trésorerie : 12 mois/scénario ; BFR : 36 mois/scénario ; 3 bilans équilibrés/scénario (écart numérique < 1e-8 USD) ; financement 40/60.
- La trésorerie minimale affichée autour de 1 500 USD découle du coussin initial de 10 % du modèle. **Elle ne prouve pas la viabilité économique** et ne doit pas masquer les pertes.

## Décision et suite
**Ne pas activer le mobilier scolaire comme huitième UP à ce stade.** Une optimisation du débit matière ne suffit pas à assurer un résultat net positif. Priorités : documenter le CAPEX, la main-d'œuvre, les consommables et les prix de vente réellement comparables ; qualifier une demande commerciale ; étudier une autre configuration de production ou un autre produit industriel si la marge reste insuffisante. Aucun visuel de BP final n'est produit tant que la configuration n'est pas validée ; les visuels sont prévus après validation, comme demandé.

## Fichiers ajoutés
- `LOT216_RUN.cjs` : exécution reproductible du moteur v107 ;
- `LOT216/STRESS_TESTS_MOBILIER_V107_NON_VALIDES.json` : entrées, sorties et contrôles ;
- `LOT216/STRESS_TESTS_MOBILIER_V107_NON_VALIDES.csv` : synthèse des 12 scénarios ;
- `LOT216/RAPPORT_TESTS_V107_MOBILIER.md` : présent rapport.
