# P2I — Dossier technique de consultation groupée — remorque agricole 3 tonnes

**Objet :** fourniture de composants et prestations pour une remorque à châssis et benne fabriqués localement à partir de tôles et profilés. Il ne s’agit **pas** d’acheter un kit de remorque complète.

## Périmètre à préciser avant commande

La charge utile cible est 3 tonnes ; le PTAC, la masse à vide, les dimensions, la vitesse d’utilisation et le type de tracteur restent à valider par l’ingénierie. Les prix existants des essieux (FOB) ne valent pas preuve de compatibilité. Aucune commande de pièces critiques ne doit être lancée avant validation des plans et charges.

## Informations à demander aux fournisseurs

- Fiche technique, modèle, fabricant, pays d’origine, certificats et dessins cotés.
- Capacité nominale et limites d’usage, charge admissible, vitesse, interfaces de fixation et dimensions.
- Prix unitaire et quantité minimale, devise, Incoterm EXW/FOB/CIF, port d’expédition, validité du prix.
- Masse et dimensions d’expédition, délai, garantie, pièces de rechange et disponibilité SAV.
- Pour les composants critiques : références compatibles entre essieux, moyeux, roues, freinage, suspension et attelage ; documents de sécurité.

## Postes à chiffrer — une seule configuration de référence

- **MEC-02 — Roues, jantes et pneus** (4 ensembles, à confirmer). Justificatif : Compatibilité moyeux, charge et vitesse.
- **MEC-03 — Suspension et supports** (1 jeu complet). Justificatif : Compatibilité essieux et châssis.
- **MEC-04 — Timon, anneau et attelage** (1 ensemble). Justificatif : Charge verticale, efforts et compatibilité tracteur.
- **MEC-05 — Freinage et signalisation** (1 ensemble). Justificatif : Réglementation et essais fonctionnels.
- **FAB-01 — Renforts, charnières, boulonnerie** (selon plans validés). Justificatif : Plans de fabrication, tolérances et fixations.
- **FAB-02 — Gaz, fil, abrasifs** (par remorque). Justificatif : Gamme de soudage et temps de cycle.
- **FAB-03 — Primaire et peinture anticorrosion** (par remorque). Justificatif : Surface traitée et procédé.
- **FAB-04 — Main-d’œuvre directe** (heures par poste). Justificatif : Temps de découpe, pliage, soudage, montage, peinture.
- **FAB-05 — Énergie, pertes et rebuts** (par remorque). Justificatif : Consommation réelle, taux de chute et récupération.
- **LOG-01 — Transport, assurance, douane essieux** (par lot puis par remorque). Justificatif : Harmoniser FOB avec coût rendu atelier.
- **FIN-01 — Amortissements et charges indirectes** (par remorque). Justificatif : Parc machines, capacité annuelle et frais fixes.
- **COM-01 — Prix de vente Côte d’Ivoire** (par remorque). Justificatif : Prix comparable et conditions commerciales.
- **COM-02 — Volume annuel vendable** (unités/an). Justificatif : Commandes, capacité et distribution.

## Décision de lancement

Le coût de revient ne sera calculé que lorsque les coûts manquants, la nomenclature des composants, les heures de fabrication et le prix local seront justifiés. Les charges fixes et amortissements seront calculés à partir du parc de machines existant et d’une cadence validée. Le calcul v107 sera effectué **une fois** pour la configuration retenue, avec 3 années et 12 mois de trésorerie. Les prix historiques documentés ne doivent pas être remplacés par des estimations non sourcées.
