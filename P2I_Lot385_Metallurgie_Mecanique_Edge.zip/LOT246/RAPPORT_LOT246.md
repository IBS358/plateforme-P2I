# P2I — LOT 246 : qualification documentaire consolidée des huit BP Recyclage

**Base intégrale : lot 245 (531 fichiers).** Aucun dossier ni moteur existant n'est modifié. Le lot 246 ajoute un registre structuré, une matrice et un plan de preuves traçable.

## Constats
- 8/8 BP Découverte présents dans le lot 245 ; 17 rubriques chacun selon sa matrice de réception.
- 33 postes historiques, sans preuve de ligne complète vérifiée.
- 7 références candidates historiques : plastique 3, pneus 3, métaux 1 (cette dernière sans fabricant ni prix exploitable).
- Toutes les étapes de contrôle industriel archivées restent NON_VERIFIE ; leur nombre est détaillé dans la matrice.
- Aucune des huit UP ne dispose d'un jeu complet de preuves pour un résultat financier v107 défendable. **Aucun chiffre financier n'a été inventé.**

## Décisions de périmètre
- Plastique : PEHD/PP rigides ; lavage, séchage, extrusion, filtration, granulation et traitement des eaux ; éviter doublon avec UP granulés.
- Papier : cartons usagés triés et mis en balles ; ne pas intégrer le pulpage/séchage dans le même scénario.
- Métaux : ferrailles ferreuses triées, cisaillées et densifiées ; exclure la fusion.
- Compost : biodéchets non dangereux ; dimensionner maturation, surface, lixiviats et nuisances.
- Verre : calcin trié/calibré ; exclure la refusion.
- Pneus : granulats avec séparation acier/textile ; vérifier énergie réelle, usure et sécurité poussières.
- Huiles : huiles lubrifiantes usagées uniquement, traitement et autorisations à définir ; ne pas confondre avec huiles alimentaires.
- DEEE : dépollution avant démantèlement et séparation ; sécuriser exutoires dangereux.

## Énergie : méthode obligatoire avant validation
Pour chaque machine : puissance nominale (kW), facteur de charge documenté, heures en charge, auxiliaires (aspiration, eau, air, froid), tarif effectif et coûts fixes. Calcul de travail : **kWh/mois = somme [kW × facteur de charge × heures/mois]**, puis **FCFA/mois = kWh/mois × tarif FCFA/kWh + frais fixes + groupe/carburant**. Le coût par tonne vendable exige rendement matière et volume net vendable. Une puissance nominale n'est pas une consommation mesurée.

Dans les preuves historiques, EcoShred ESG-1000 mentionne **290,9 kW installés et 204 kWh/h annoncés**, sous réserve de confirmation fabricant et du régime réel. Il ne faut pas appliquer cette valeur à toutes les lignes pneus ni en déduire une rentabilité.

## Passage à la simulation v107
Avant calcul : (1) périmètre et capacité nette compatibles par machine, (2) prix catalogues rattachés à des modèles et Incoterms, (3) CAPEX installé incluant transport et mise en service, (4) électricité et autres utilités, (5) gisement et rendement, (6) prix/volumes de vente documentés, (7) personnel et charges fixes, (8) BFR et financement. Ensuite seulement : compte de résultat 3 ans, bilan, trésorerie mensuelle 12 mois, seuils de rentabilité et contrôles de cohérence.

**Limite explicite :** ce lot est un contrôle documentaire et une préparation opérationnelle. Il ne constitue ni la qualification commerciale des huit lignes, ni la validation de leurs BP financiers. Aucun accès web ni fournisseur n'a été utilisé pour prétendre valider les références.
