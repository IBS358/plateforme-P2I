const assert=require('node:assert/strict');const fs=require('fs');const vm=require('vm');const path=require('path');
const code=fs.readFileSync(path.join(__dirname,'../runtime/lot167-selection-guard.js'),'utf8');
function run(){
 let url='http://localhost/index.html?unit_id=smartphones';let nodes={};let callbacks={};
 const document={readyState:'complete',body:{prepend(n){nodes[n.id]=n;}},createElement(){return {setAttribute(){},style:{},remove(){delete nodes[this.id]}}},getElementById(id){return nodes[id]||null}};
 const history={replaceState(a,b,u){url=new URL(u,url).href},pushState(a,b,u){url=new URL(u,url).href}};
 const window={addEventListener(name,cb){callbacks[name]=cb}};
 const location=new Proxy({}, {get(_,key){return new URL(url)[key]}});
 vm.runInNewContext(code,{document,window,history,location,URLSearchParams});
 assert.match(nodes['p2i-lot167-warning'].textContent,/NON VALIDÉ/);
 history.replaceState(null,'','?unit_id=velos');assert.equal(nodes['p2i-lot167-warning'],undefined);
 history.replaceState(null,'','?unit_id=tablettes');assert.match(nodes['p2i-lot167-warning'].textContent,/SKD/);
 history.pushState(null,'','?unit_id=remorques_agricoles');assert.match(nodes['p2i-lot167-warning'].textContent,/750 kg/);
 history.replaceState(null,'','?up_id=stockage_manutention');assert.match(nodes['p2i-lot167-warning'].textContent,/rayonnage/);
 history.replaceState(null,'','?unit_id=cuisines_pro_chambres_froides');assert.equal(nodes['p2i-lot167-warning'],undefined);
 url='http://localhost/index.html?unit_id=smartphones';callbacks.popstate();assert.ok(nodes['p2i-lot167-warning']);
 console.log('PASS: 7 transitions SPA et affichage/masquage');
}
run();
