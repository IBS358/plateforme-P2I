# Lot 167 — Correction navigation des quatre UP non validées

Base : archive Lot166. Modification effective de `index.html` et ajout de `runtime/lot167-selection-guard.js`.

Le garde-fou suit maintenant les appels `history.replaceState` et `history.pushState`, en plus de `popstate` et `hashchange`. Le garde-fou Lot166 a été remplacé dans le chargement HTML ; son fichier historique demeure dans l'archive.

## Tests exécutés
- Syntaxe JavaScript du nouveau module : OK.
- 7 transitions simulées avec Node.js (quatre UP bloquées, deux UP non bloquées, navigation arrière) : OK.
- Recalcul historique Lot164 / v107 : exécuté, résultats historiques inchangés.
- Test historique Lot155 : exécuté, résultats historiques conservés.
- Test Lot166 : **échec attendu**, car il vérifie explicitement le chargement du script Lot166 qui est désormais remplacé ; il n'est pas adapté au nouveau garde-fou. Le test Lot167 le remplace pour cette fonctionnalité.

## Limites
- Aucun BP supplémentaire calculé ; aucune nouvelle nomenclature ou hypothèse commerciale vérifiée.
- Navigation testée en environnement Node simulé, **pas dans Microsoft Edge**.
- Pas de changement de `main`, pas d'appel à GitHub.
