# Lot 276 — huit BP en 17 rubriques, version de consolidation

Ce lot **ne certifie aucun BP** et ne prétend pas avoir exécuté le moteur v107. Il rassemble, pour chaque UP, une page unique structurée en 17 rubriques avec les données effectivement disponibles dans les lots 270 et 275, et met en évidence les divergences entre CA des produits et CA des projections financières.

**À terminer** : prix catalogues documentés, lignes complètes, débouchés contractuels, contrôle des bilans matières, BFR mensuel, bilan 3 ans équilibré, fiscalité ivoirienne, intégration v107 et illustrations originales. Les boutons d'impression utilisent le navigateur Edge ; il ne s'agit pas de l'export PDF natif P2I.

Les fichiers précédents ont été conservés octet pour octet. Aucune des autres filières ou neuf UP déjà validées n'a été éditée.
