# P2I — Lot 210 : qualification de l’UP Mobilier scolaire et professionnel

## Décision technique
Candidat : fabrication locale de tables-bancs biplaces semi-métalliques, avec mobilier professionnel en variantes hors calcul. **Aucune migration du catalogue actif n’a été faite.** L’UP irrigation et les sept autres BP sont inchangés. L’ancien ID `meubles` redirige actuellement vers `stockage_manutention` ; ne pas le réutiliser sans stratégie de migration.

## Vérification des sources historiques
- `runtime/script-1.js`, bloc `meubles` : scie à panneaux, CNC, pose de chants, pointeuse, chaîne d’assemblage, presse et emballage. Ces capacités sont des mentions historiques non validées, sans prix fournisseurs.
- `runtime/script-0.js`, bloc `meubles` : ancienne activité « Assemblage meubles » en kits, CAPEX indicatif 70 000 USD ; montant non justifié et **non réutilisé**.
- `runtime/catalogue-up-actif.js` : 96 UP actives, `meubles` redirigé vers `stockage_manutention` ; l’UP `mobilier` du secteur médical est distincte.

## Demande commerciale constatée (sans préjuger de ventes P2I)
- DGMP Côte d’Ivoire : appels d’offres 2026 pour tables-bancs (ex. 1 500 à Marcory et 410 à Kolia). https://www.marchespublics.ci/appel_offre
- Programme de marchés 2026 : opération annoncée de 1 275 tables-bancs semi-métalliques dans le Tchologo. https://marchespublics.ci/uploads/doc/02_PPM_Juin_Octobre_2026_Organise-v2.pdf
- Programme 2025 : fabrication et distribution de tables-bancs semi-métalliques. https://cipme.ci/wp-content/uploads/2025/03/Liste-des-marches_2025_CIPME.pdf
Ces annonces ne sont ni des commandes attribuées à P2I ni des garanties de vente.

## Prix de matières observés (à ne pas injecter sans spécification)
- AZ Industrie CI : tubes carrés acier noir en barres de 6 m, variantes tarifées par section/épaisseur ; exemple 30×30×2 présenté avec supplément de 7 000 FCFA sur une base affichée de 9 400 FCFA, interprétation du prix final à confirmer. https://azindustrie.com/shop/tube-carre-acier-noir-barre-de-6ml-1975
- Abidjan Solution : tubes carrés 30×30×1,5 affichés à 7 300 FCFA, dimensions et conditions de fourniture à confirmer. https://abidjansolution.biz/barre-tube-carre-fer-plat-et-corniere-prix-de-base-en-ferronnerie
**Aucun prix de panneau, peinture, visserie ou machine de fabrication suffisamment qualifié n’a été trouvé dans les sources du lot 209.**

## Processus industriel proposé
01 Réception acier/panneaux ; 02 Débit tubes sur liste de coupe ; 03 Cintrage si plan retenu ; 04 Perçage et soudage sur gabarits ; 05 Ébavurage/contrôle géométrique ; 06 Préparation et usinage panneaux ; 07 Traitement anticorrosion/peinture ; 08 Fixation plateaux et assises ; 09 Essais de stabilité, arêtes, fixations et charge ; 10 Emballage et livraison.

## Portes de validation avant v107
1. Plan coté de référence et épaisseurs validées, liste de débit et taux de chute.
2. BOM quantitative et prix de chaque composant ; ne pas remplacer les absences par zéro.
3. Machine/outillage chiffrés, capacité effective, main-d’œuvre directe, pertes, énergie, sécurité.
4. Prix de vente réellement comparable (cahier des charges, transport, garanties, taxes) et volumes défendables.
5. Calcul v107 A1–A3, trésorerie 12 mois, bilans, BFR, financement, contrôles de cohérence.

**Statut du lot 210 : qualification technique et commerciale initiale ; BP non calculable et non validé.** Aucun résultat net ni rentabilité inventés. Ce lot ne remplace pas le lot 209.
