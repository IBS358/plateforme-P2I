# P2I — Lot 260 — Seuils économiques et volumes de vente des huit UP

Ce lot est une **analyse de décision supplémentaire**, pas une livraison de BP finalisés. Les données de départ proviennent du lot 258 et demeurent illustratives. Aucun prix catalogue ni tarif de marché ivoirien nouveau n'a été vérifié dans ce lot.

## Calculs nouveaux
- 24 scénarios : 8 UP × vente de 80 %, 100 % et 120 % du volume produit (120 % est uniquement un test théorique de carnet de commandes et suppose des stocks/achats complémentaires non modélisés ; **ne pas interpréter comme production physique possible**).
- Seuil de taux d'utilisation opérationnel, lorsque la contribution unitaire est positive.
- Coût maximal de collecte/achat de déchets entrants pour un EBITDA nul au scénario central.
- Seuil de prix de vente pour le volume réellement commercialisé.
- Registre des fractions commercialisables à documenter pour éviter les prix moyens artificiels.

## Formules
Entrées = capacité nominale (t/h) × heures nominales/an × taux d'utilisation.
Vendable = entrées × rendement massique de référence.
EBITDA = tonnes effectivement vendues × prix de vente − tonnes entrantes × (achat/collecte + électricité + autres variables) − charges fixes.
Seuil utilisation = charges fixes / [capacité × heures nominales × (rendement × prix − coût variable par tonne entrante)] si contribution positive.
Collecte maximale = rendement × prix de vente − électricité − autres variables − charges fixes / tonnes entrantes.

## Limites importantes
- L'écart production/vente n'est pas encore modélisé comme stock valorisé au bilan. Le test de 120 % n'est pas un scénario de production validable.
- Les prix, rendements, coûts et capacités ne sont pas des cotations de marché validées.
- Aucun investissement total, financement, amortissement, dette, impôt, BFR, trésorerie mensuelle ni résultat net n'est calculé.
- La valorisation des coproduits et les coûts de traitement des résidus restent à établir par procédé.
- Une utilisation opérationnelle minimale inférieure à 70 % n'assure pas la solvabilité ni le remboursement de dette.
- Ne pas injecter ces valeurs dans les BP comme hypothèses vérifiées. Ne pas modifier le moteur v107.

## Suite industrielle
Qualifier pour chacune des huit UP : une ligne complète avec prix EXW/FOB et débit du poste limitant ; contrats de collecte rendus site ; fractions vendables, prix et volumes par produit ; puissance/énergie et coûts environnementaux ; puis seulement lancer v107 (CR/bilan 3 ans, trésorerie 12 mois).
