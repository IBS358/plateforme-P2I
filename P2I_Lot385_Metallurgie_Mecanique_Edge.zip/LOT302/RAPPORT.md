# Lot 302 — Qualification des prix catalogues

Règle de sélection : modèle précis + capacité + périmètre inclus + prix public attribuable au modèle + devise + incoterm lorsqu'indiqué. Pas de devis officiel. Les cinq annonces examinées ne remplissent pas l'ensemble des conditions pour la configuration industrielle de référence 4 t/h pneus ou 6 t/h verre. Aucune n'a été intégrée au CAPEX.

Les six autres UP restent non documentées dans ce lot. Le chantier de qualification n'est donc pas terminé. Les anciens chiffres restent hypothétiques, sans modification des calculs historiques. Les fiches du registre citent les pages fournisseurs consultées le 18 novembre 2026.
