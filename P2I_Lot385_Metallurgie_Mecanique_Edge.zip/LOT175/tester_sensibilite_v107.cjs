'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.resolve(__dirname,'..'),rt=path.join(root,'runtime');
const c={console,Math,Number,String,Array,Object,Map,Set,JSON,Error,TypeError,Date,Intl,URL,URLSearchParams};c.window=c;c.location={search:'',href:'file:///P2I_Edge/index.html'};c.history={replaceState(){}};vm.createContext(c);
const files=['script-0.js','script-1.js','script-2.js','script-3.js','script-4.js','script-5.js','script-6.js','script-7.js','script-8.js','script-9.js','script-10.js','script-11.js','script-12.js','script-13.js','script-14.js','script-15.js','script-16.js','lot147-data.js','lot149-data.js','lot150-assemblage-data.js','lot152-assemblage-finances.js','lot153-assemblage-finances.js','catalogue-up-actif.js','script-17.js','lot152-assemblage-visuels.js','lot153-assemblage-visuels.js','lot154-remorques.js','lot154-remorque-finances.js','lot155-assemblage-finances.js'];
for(const f of files)vm.runInContext(fs.readFileSync(path.join(rt,f),'utf8'),c,{filename:f});
const clone=x=>JSON.parse(JSON.stringify(x));

const source=JSON.parse(fs.readFileSync(path.join(root,'LOT173','960_SCENARIOS_CORRIGES.json'),'utf8'));
const selected=source.scenarios.filter(s=>s.passes_3year_6pct);
const stresses=[
 {name:'reference',volume:1,price:1,materials:1},
 {name:'prix_moins_5pct',volume:1,price:.95,materials:1},
 {name:'ventes_moins_10pct',volume:.9,price:1,materials:1},
 {name:'matieres_plus_10pct',volume:1,price:1,materials:1.1},
 {name:'combine_prix_5_ventes_10_matieres_10',volume:.9,price:.95,materials:1.1}
];
const all=[],summary={source:'LOT173',selection:'118 scenarios with margin >=6% all 3 years',stress_assumptions:stresses,by_up:{},warning:'Sensitivity tests on historical models; no supplier or market validation'};
for(const s of selected){
 const base=clone(c.P2I_LOT152_FINANCES.units[s.id].input),cap=base.capacite*250*8;
 const cases=[];
 for(const t of stresses){
  const x=clone(base),vol=Math.min(cap,Math.round(s.vol*t.volume));
  for(let y=0;y<3;y++){
   const factor=vol/base.ventes[0];
   x.ventes[y]=Math.min(cap,Math.round(base.ventes[y]*factor));
   x.production[y]=Math.min(cap,Math.round(base.production[y]*factor));
   x.prix[y]=base.prix[y]*s.pf*t.price;
   x.matieres_kg_annuel[y]=base.matieres_kg_annuel[y]*s.mf*t.materials;
   x.cout_production_kg[y]=base.cout_production_kg[y]-(base.matieres_kg_annuel[y]-x.matieres_kg_annuel[y]);
  }
  x.charges_fixes=base.charges_fixes*s.ff;
  try{
   const r=c.P2I_BP_SIMULATION_COMMUNE.calculer(x);
   const margin=r.annuel.map(z=>z.chiffre_affaires?z.resultat_net/z.chiffre_affaires:null);
   const rn=r.annuel.map(z=>z.resultat_net);
   const cash_min=Math.min(...r.tresorerie.map(z=>z.solde_final));
   const ok=margin.every(v=>v!==null&&v>=.06)&&cash_min>=0&&r.controles.bilans_equilibres===true&&r.controles.financement==='40/60';
   cases.push({stress:t.name,units_A1:vol,price_A1:x.prix[0],material_A1:x.matieres_kg_annuel[0],rn,margin,cash_min,balances:r.controles.bilans_equilibres,passes:ok});
  }catch(e){cases.push({stress:t.name,error:String(e),passes:false});}
 }
 all.push({id:s.id,vf:s.vf,pf:s.pf,mf:s.mf,ff:s.ff,original_units:s.vol,stress:cases,robust:cases.every(t=>t.passes)});
}
for(const id of [...new Set(selected.map(s=>s.id))]){
 const subset=all.filter(s=>s.id===id);
 summary.by_up[id]={selected:subset.length,robust:subset.filter(s=>s.robust).length,passes_by_stress:Object.fromEntries(stresses.map(t=>[t.name,subset.filter(s=>s.stress.find(v=>v.stress===t.name)?.passes).length]))};
}
summary.selected=all.length;summary.robust=all.filter(s=>s.robust).length;summary.tests=all.length*stresses.length;
fs.writeFileSync(path.join(__dirname,'SENSIBILITE_118_V107.json'),JSON.stringify({summary,scenarios:all},null,2));
const rows=['UP;VentesA1;PrixFacteur;MatieresFacteur;ChargesFixesFacteur;MargeA1_reference;MargeA2_reference;MargeA3_reference;PrixMoins5;VentesMoins10;MatieresPlus10;ChocCombine;Robuste'];
for(const s of all){const c=s.stress;rows.push([s.id,s.original_units,s.pf,s.mf,s.ff,...c[0].margin.map(v=>(v*100).toFixed(3)),...c.slice(1).map(v=>v.passes?'OUI':'NON'),s.robust?'OUI':'NON'].join(';'));}
fs.writeFileSync(path.join(__dirname,'SENSIBILITE_118_V107.csv'),rows.join('\n')+'\n');
console.log(JSON.stringify(summary,null,2));
