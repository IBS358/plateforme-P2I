# P2I — Lot 175 — Tests de résistance des scénarios financiers

Base de départ : archive Lot 174, simulations Lot 173. Moteur v107 non modifié. Aucune modification de GitHub main.

## Exécution

- 118 scénarios qualifiés au Lot 174 relancés avec le moteur commun v107.
- 5 conditions par scénario, soit **590 exécutions** : référence, prix −5 %, ventes −10 %, coût matière +10 %, et combinaison des trois.
- Critère : marge nette >=6 % en A1, A2, A3 ; trésorerie minimale >=0 ; bilans équilibrés ; financement 40/60.
- Résultat : **50/118** résistent aux trois chocs simultanés, tous dans l'UP Smartphones ; **0/3** Remorques.
- **0/50** scénarios résistants conservent le coût matière historique sans réduction : les 50 exigent une baisse non justifiée de ce coût.

## Portée

Les chocs sont des hypothèses de stress et non des prévisions. Les coûts matières, les prix de vente, les volumes, les fournisseurs et les capacités commerciales des nouvelles configurations ne sont pas vérifiés. Les 50 scénarios ne sont **pas des BP validés**. Les modèles Tablettes et Stockage n'ont aucun scénario de départ franchissant les seuils.

## Fichiers

- `tester_sensibilite_v107.cjs` : calcul reproductible sur le moteur v107 historique.
- `SENSIBILITE_118_V107.json` : 590 résultats détaillés.
- `SENSIBILITE_118_V107.csv` : synthèse des 118 scénarios.
- `TESTS_LOT175.json` : contrôles d'intégrité et de cohérence.

## Suite nécessaire

Priorité : obtenir un coût matière vérifiable pour un scénario Smartphones viable et qualifier la demande ivoirienne. Pour Remorques, Tablettes et Stockage, reconstruire les nomenclatures et les prix, sans réutiliser les seuils théoriques comme tarifs.

Aucun test visuel manuel Microsoft Edge effectué.
