# P2I — Remorque agricole 3 t — métrage de matière de référence

Source : nomenclature du Lot 154, reprise dans le BP du Lot 183.

## Résultat calculé

- Masse théorique des tubes et masse catalogue des tôles achetés : **635.90 kg**.
- Prix documenté de ces matières : **614,04 USD**, soit **0.966 USD/kg** en moyenne pondérée.
- Essieux (deux) : **438,60–543,00 USD FOB** ; non inclus dans les 614,04 USD.
- Sous-total documentaire acier + essieux : **1 052,64–1 157,04 USD**, non homogène en Incoterms.

## Méthode

Masse théorique des tubes carrés = longueur × 7 850 kg/m³ × [côté extérieur² − (côté extérieur − 2 × épaisseur)²]. Les rayons d'angle et les tolérances de fabrication ne sont pas modélisés. Pour les tôles, reprise des masses catalogue 108 kg et 50 kg par tôle du Lot 154.

## Limites bloquantes

Le métrage correspond aux quantités **achetées**, non à la masse nette incorporée. Il ne démontre ni la charge utile 3 t, ni le PTAC, ni la résistance des soudures, ni la stabilité, ni la conformité du freinage et de l'attelage. Il manque également les organes roulants, les consommables, la main-d'œuvre, les frais import, les amortissements, la capacité annuelle et le prix local. Aucun résultat v107 ne peut être établi pour cette nouvelle configuration sans ces éléments.

## Décision de fabrication

Retenir la transformation locale de tôles et profilés en châssis et benne, avec composants mécaniques achetés séparément. Ne pas commander les matières ou lancer la production avant validation des plans et des efforts. Une seule remorque de référence, sans multiplication des scénarios.
