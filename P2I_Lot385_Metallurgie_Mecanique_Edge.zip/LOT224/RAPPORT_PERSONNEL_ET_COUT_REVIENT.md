# P2I — Lot 224 : personnel intégré aux coûts de revient, sans double comptabilisation

## Correction de fond
Le lot 217 retient **24 000 USD de personnel** et **15 000 USD d'autres frais fixes**, au taux de **595 FCFA/USD** : soit **14 280 000 FCFA** de personnel et **8 925 000 FCFA** d'autres frais fixes. Le lot 219 additionne correctement ces deux postes (23 205 000 FCFA) dans son solde global, mais ne les affecte pas aux produits.

**Erreur à éviter** : ajouter 14,28 M FCFA de salaires aux 50,24 M FCFA de coûts variables, puis maintenir les 23,205 M FCFA de charges fixes/personnel. Cela compterait deux fois les salaires. Deuxième risque : les coûts variables unitaires historiques ne sont pas ventilés ; ils pourraient déjà inclure de la main-d’œuvre, auquel cas la ventilation exige de retrancher préalablement cette composante. Cette présence n'est ni confirmée ni exclue.

## Méthode retenue
- Coûts variables historiques : **50 240 000 FCFA**, non modifiés, non validés.
- Personnel total : **14 280 000 FCFA**, enveloppe de simulation et non masse salariale issue de postes documentés.
- Hypothèse illustrative de classement : **65 %** affectés à la fabrication, **35 %** au support/administratif/commercial.
- Clés relatives de temps de production **1 : 3 : 4** (table-banc, bureau, armoire), **hypothèses de démonstration** et non chronométrages.
- Le personnel de fabrication est ventilé selon `volume × temps relatif` ; le personnel indirect reste en charge de période. La somme est toujours égale à 14,28 M FCFA.

## Résultats illustratifs à 65 % de personnel direct
| Produit | Quantité A1 | Coût variable historique | Personnel direct imputé/unité | Coût industriel provisoire/unité | Prix de vente testé |
|---|---:|---:|---:|---:|---:|
| Table-banc scolaire | 1,200 | 25,200 | 4,641 | 29,841 | 33,000 |
| Bureau professionnel | 160 | 71,000 | 13,923 | 84,923 | 110,000 |
| Armoire métallique | 80 | 108,000 | 18,564 | 126,564 | 160,000 |

Ces coûts ne sont **pas** des coûts de revient complets : ils excluent la répartition des frais généraux, les amortissements et les frais financiers, et les coûts variables sources sont incomplets/non vérifiés. **Attention** : la ligne « personnel direct imputé » n'est valide que si les coûts variables historiques sont hors main-d’œuvre ; c'est une condition à contrôler.

## Réconciliation globale
CA 70 000 000 − coûts variables 50 240 000 − personnel direct 9 282 000 − personnel indirect 4 998 000 − autres charges fixes 8 925 000 = **−3 445 000 FCFA** avant amortissements, intérêts et impôts. Le reclassement n'améliore pas artificiellement le résultat ; il permet seulement de voir la marge par produit.

## Données bloquantes
1. Effectifs et rémunérations par fonction, charges patronales, heures productives, congés et absentéisme.
2. Temps de fabrication réels par produit et taux de rebuts.
3. Nomenclatures et factures/devis par gamme, pour déterminer si les coûts variables historiques incluent déjà du travail.
4. Frais indirects industriels à affecter par heures machine et heures de travail ; coût complet avec amortissements.
5. Recalcul du moteur v107, BFR 36 mois et trésorerie 12 mois après validation des sources.

**Statut : audit de classification et d'imputation terminé ; BP mobilier non validé ; catalogue inchangé ; 7 BP préservés.**
