'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path');
const app=path.resolve(__dirname,'..'),rt=path.join(app,'runtime');
const c={console,Math,Number,String,Array,Object,Map,Set,JSON,Error,TypeError,Date,Intl,URL,URLSearchParams};c.window=c;c.location={search:'',href:'file:///P2I_Edge/index.html'};c.history={replaceState(){}};vm.createContext(c);
const files=['script-0.js','script-1.js','script-2.js','script-3.js','script-4.js','script-5.js','script-6.js','script-7.js','script-8.js','script-9.js','script-10.js','script-11.js','script-12.js','script-13.js','script-14.js','script-15.js','script-16.js','lot147-data.js','lot149-data.js','lot150-assemblage-data.js','lot152-assemblage-finances.js','lot153-assemblage-finances.js','catalogue-up-actif.js','script-17.js','lot152-assemblage-visuels.js','lot153-assemblage-visuels.js','lot154-remorques.js','lot154-remorque-finances.js','lot155-assemblage-finances.js'];
for(const f of files)vm.runInContext(fs.readFileSync(path.join(rt,f),'utf8'),c,{filename:f});
const ids=['smartphones','tablettes','remorques_agricoles','stockage_manutention'];
const output={lot:161,engine:'v107',type:'frontieres_de_cout_conditionnelles_au_scenario_historique',note:'Pas de nouveau prix fournisseur ni de configuration validée. Résolution de coût maximal matières à volume et prix de vente historiques constants.',units:{}};
for(const id of ids){
 const prior=c.P2I_LOT152_FINANCES.units[id].input;
 const calc=(cost)=>{const x=JSON.parse(JSON.stringify(prior));x.matieres_kg=cost;x.matieres_kg_annuel=[cost,cost*1.02,cost*1.04];const delta=prior.cout_production_kg[0]-prior.matieres_kg;x.cout_production_kg=[cost+delta,(cost+delta)*1.02,(cost+delta)*1.04];const r=c.P2I_BP_SIMULATION_COMMUNE.calculer(x);return {r,margin:r.annuel[0].resultat_net/r.annuel[0].chiffre_affaires};};
 const base=calc(prior.matieres_kg);
 const thresholds={};
 for(const target of [0,0.06]){
  let lo=0,hi=prior.matieres_kg*4+1000;
  for(let i=0;i<60;i++){const mid=(lo+hi)/2;if(calc(mid).margin>=target)lo=mid;else hi=mid;}
  const at0=calc(0).margin;
  thresholds[target===0?'equilibre':'marge_6pct']=at0<target?{feasible_with_zero_materials:false,margin_at_zero_materials:at0}:{feasible_with_zero_materials:true,max_materials_usd_per_unit:lo,required_reduction_usd_per_unit:prior.matieres_kg-lo,required_reduction_pct:100*(prior.matieres_kg-lo)/prior.matieres_kg,verified_margin:calc(lo).margin};
 }
 output.units[id]={product:prior.nom,volume_A1:prior.ventes[0],price_usd:prior.prix[0],historical_material_cost_usd_per_unit:prior.matieres_kg,other_conversion_usd_per_unit:prior.cout_production_kg[0],historical_net_A1_usd:base.r.annuel[0].resultat_net,historical_margin_pct:100*base.margin,thresholds};
}
const dir=path.join(app,'LOT161');fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'FRONTIERES_COUTS_V107.json'),JSON.stringify(output,null,2));
console.log(JSON.stringify(Object.fromEntries(Object.entries(output.units).map(([k,v])=>[k,v.thresholds])),null,2));
