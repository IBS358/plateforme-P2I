# P2I — Lot 161 : diagnostic quantitatif des leviers économiques

Base : ZIP Lot160. Aucun BP historique modifié. Aucun nouveau prix fournisseur inventé.

## Méthode
Le moteur v107 est appelé en conservant les ventes, prix, frais fixes, effectifs, CAPEX et conversion unitaire des scénarios historiques Lot152. Seul le coût matières unitaire varie, et le coût industriel varie d’autant pour conserver l’écart de conversion initial. Résolution numérique des coûts matières maximaux pour une marge A1 de 0% et 6%.

## Résultats
- Smartphones : coût matière historique 98 USD/unité ; plafond équilibre 45,97 USD ; plafond 6% 34,37 USD.
- Tablettes : historique 178 USD/unité ; plafond équilibre 33,09 USD ; plafond 6% 24,13 USD.
- Remorques historiques 750kg : marge A1 toujours -35,94% avec matières ramenées à zéro.
- Rayonnages : marge A1 toujours -53,94% avec matières ramenées à zéro.

## Interprétation et limites
Ces résultats sont des tests de sensibilité conditionnels, pas des configurations viables. Pour les remorques et rayonnages, même une réduction intégrale des matières ne suffit pas à l’équilibre : il faut revoir au moins les charges fixes, volumes, gamme, prix ou CAPEX. Pour les smartphones et tablettes, les plafonds calculés ne sont pas des prix fournisseurs vérifiés et ne justifient pas leur adoption. La remorque de 3 tonnes n'est pas évaluée par ce calcul : la configuration testée est la remorque historique de 750 kg.

## Contrôles
Calcul v107 exécuté et résultats enregistrés dans FRONTIERES_COUTS_V107.json ; archive ZIP contrôlée. Aucun test visuel Microsoft Edge. Aucun BP déclaré finalisé.
