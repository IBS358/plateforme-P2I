# Lot 309 — Arbitrage de clôture du travail machines

Ce lot remplace quatre registres séparés par une matrice consolidée de consultation. Il ne valide aucun investissement de référence : une offre partielle n'est pas une ligne complète.

## Règle ferme

- BP Découverte : une configuration générique, non modifiable ; chaque machine doit avoir un prix catalogue public vérifiable, capacité et modèle identifiés. Une ligne intégrée à prix catalogue ou une somme de postes catalogués sont toutes deux acceptables, dès lors que la nomenclature couvre le processus complet.
- Ne jamais attendre de devis officiels ; exclure du calcul les machines sans prix public et leur trouver des alternatives.
- BP Pro : configuration personnalisable et demandes de devis via P2I.
- Une fourchette affichée pour une famille de modèles ne permet pas d'attribuer arbitrairement son point médian au débit visé.
- Les coûts complémentaires EXW/FOB-vers-site doivent être estimés et affichés séparément.

## Constat

Les huit UP sont illustrées et disposent de BP, mais aucune nomenclature complète d'équipements à prix catalogue précis et débit cohérent n'a été établie dans les registres consultés. Le lot 309 n'est donc pas une clôture industrielle. La suite doit cibler exclusivement les équipements manquants, sans nouveau cycle de simulation ni refonte visuelle.
