# Lot 336 — Visuels IA photoréalistes

Huit scènes illustratives générées par IA, recadrées et intégrées dans les rubriques 2 et 17 des huit BP. Ces scènes représentent des personnels africains dans des contextes industriels plausibles ; leur nationalité réelle ne peut être établie sur une image. Les marquages P2I visibles sont illustratifs et ne se substituent pas au logo officiel. Les images des modèles de machines spécifiques restent à qualifier. Aucun calcul financier modifié.
