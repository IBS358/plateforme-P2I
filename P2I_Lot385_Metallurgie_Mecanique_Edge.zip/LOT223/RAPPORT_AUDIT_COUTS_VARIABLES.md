# P2I — LOT 223 — Audit des coûts variables par produit

Base : archive complète Lot 222 (424 fichiers), conservée. Aucun changement du catalogue, du moteur v107, ni des sept BP.

## 1. Reconstitution exacte des 50 240 000 FCFA

- Tables-bancs : 1 200 × 25 200 = **30 240 000 FCFA**, soit **60,19 %** du coût variable total.
- Bureaux : 160 × 71 000 = **11 360 000 FCFA**, soit **22,61 %**.
- Armoires : 80 × 108 000 = **8 640 000 FCFA**, soit **17,20 %**.
- Total : **50 240 000 FCFA**, sur CA 70 000 000 FCFA.

Les 25 200 / 71 000 / 108 000 FCFA sont des hypothèses globales de simulation du Lot 219, et **non des BOM chiffrées et vérifiées**. On ne peut donc pas prétendre les réduire de 10 % comme si les gains étaient acquis.

## 2. Diagnostic prioritaire

Le coût table-banc explique 60,19 % des coûts variables. Dans ses 25 200 FCFA, **18 200 FCFA** sont affectés provisoirement à l'acier optimisé (10 950) et au bois (7 250) d'après les lots 213–214. Les **7 000 FCFA restants ne sont pas ventilés**. Cela ne prouve pas qu'ils suffisent à payer visserie, peinture, soudage, énergie, main-d’œuvre directe, pertes, emballage et transport. Le prix de l'acier est conditionnel; les débits et la résistance restent à vérifier. **Attention : ne pas additionner les 18 200 FCFA aux 25 200 FCFA**, car ils sont supposés en faire partie.

Bureaux et armoires : **aucune nomenclature complète** ne justifie les coûts unitaires de 71 000 et 108 000 FCFA. Avant toute optimisation, établir plans, débits, accessoires, temps opératoires et frais logistiques. Vérifier si le personnel direct est déjà inclus dans les charges fixes de 23 205 000 FCFA afin d'éviter le double compte.

## 3. Seuils et leviers

Solde d'exploitation testé avant amortissements, intérêts et impôts : **−3 445 000 FCFA**. À CA et charges fixes constants, économie globale minimale de **3 445 000 FCFA (6,856 % des coûts variables)** pour atteindre zéro sur ce seul solde. Ce n'est **ni un résultat net nul, ni une marge nette de 10 %**.

- Gain de 1 000 FCFA/table-banc = 1 200 000 FCFA/an (si volumes inchangés).
- Gain de 5 000 FCFA/bureau = 800 000 FCFA/an.
- Gain de 10 000 FCFA/armoire = 800 000 FCFA/an.
- Combinaison illustrative 2 000/table-banc + 5 000/bureau + 5 000/armoire = **3 600 000 FCFA**, soit solde **+155 000 FCFA avant amortissements, intérêts et impôts**. Les gains ne sont pas documentés et ne doivent pas être intégrés comme acquis au BP.

## 4. Plan industriel d'économies sans réduction arbitraire

1. Prototype table-banc : plan coté, contrôle mécanique, débit réel sur séries de 2/10/50, rebuts et réemploi de chutes; ne pas affaiblir les structures.
2. Comparer achats de profilés et panneaux par lots, prix rendus atelier, en distinguant économies d'achat et consommation physique.
3. Chronométrer soudage, préparation, peinture et montage; utiliser gabarits et contrôle qualité en amont; vérifier temps-machine et charge atelier.
4. Bureau : standardiser structure, panneau, passe-câbles, quincaillerie, gamme standard/premium avec tablette sécurisée; chiffrer les options séparément.
5. Armoire : optimiser débit tôles, épaisseurs validées, charnières/serrures standard, finition; étudier sous-traitance tôlerie si investissement excessif.
6. Livraison : commandes groupées, emballage et chargement optimisés, frais de transport par destination, sans dégrader service.
7. Vérifier le classement comptable : personnel direct, personnel fixe, consommables, amortissements, stocks et TVA pour éviter omissions et doubles comptes.

## 5. Décision

**Ne pas changer le coût variable v107 sans pièces justificatives.** Le tableau interactif du lot 223 est une analyse de sensibilité, pas un nouveau BP validé. Le mobilier reste candidat, l'irrigation reste active et les sept BP restent inchangés. Pour valider le BP, collecter les nomenclatures, prix et temps de production des trois produits, puis refaire les tests v107, BFR 36 mois, trésorerie 12 mois et financement 40/60.
