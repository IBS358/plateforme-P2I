# Lot 230 — Extension de gamme mobilier professionnel

Ajout au BP Découverte existant, rubriques 2, 5 et 17 :
- Armoire basse verrouillable, dossiers et classeurs A4 ;
- Caisson mobile à deux ou trois tiroirs pour bureaux.

Ces deux variantes restent hors calcul. Le scénario financier v107 du lot 229 est inchangé (trois produits chiffrés : table-banc, bureau, grande armoire métallique). Aucun prix, coût, volume, subvention ou marge n’a été ajouté.

Avant chiffrage : établir plans cotés, capacité de charge, stabilité anti-basculement, nomenclature tôle/quincaillerie, coûts de découpe/pliage, fournisseurs, prix de vente et SAV.

Les sept autres BP et le catalogue actif ne sont pas modifiés.
