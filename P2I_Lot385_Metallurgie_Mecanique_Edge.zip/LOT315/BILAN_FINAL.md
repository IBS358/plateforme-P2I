# P2I Lot 315 — Clôture documentaire de la filière Recyclage & Valorisation

**Livré :** 8 BP Découverte accessibles localement, 17 rubriques et visuels conservés, fiches récapitulatives des 54 postes, registre de candidats à prix publics, scénarios financiers historiques accessibles, aucune attente de devis officiels.

**Non réalisé :** validation catalogue modèle-capacité-prix pour chacun des équipements indispensables, investissement complet recalculé sur ces catalogues, validation du moteur financier v107, cohérence complète des prix de vente et des débouchés. Les marges positives antérieures ne constituent pas une validation.

**Décision de gestion recommandée :** clore les recherches répétitives sur cette filière et passer aux deux UP Découverte restantes. La mise à niveau définitive des huit CAPEX ne doit être annoncée comme faite qu'une fois les prix catalogue correspondants réellement établis. Ne pas faire dépendre le BP Découverte de devis officiels, réservés au BP Pro.

**Attention :** les 8 BP sont consultables et regroupés, mais ne doivent pas être présentés comme 8 investissements industriels validés. Les données anciennes sont conservées pour traçabilité.
