# P2I Lot 263 — Restructuration multiflux des huit UP

Ce lot ajoute huit pages autonomes de comparaison et de calcul au lot 262, sans écraser les pages existantes ni le moteur v107. Il ne constitue pas la finalisation des huit BP.

## Méthode
- Deux équipes de 8 h, 22 jours/mois, 12 mois, utilisation 70 %.
- Cinq UP restructurées en plusieurs fractions vendables, avec fractions à revenu nul si pertinent.
- Trois UP précédemment positives : hypothèses inchangées pour éviter une amélioration artificielle.
- Tous les prix des fractions, rendements, CAPEX, consommations, coûts de collecte et charges sont des hypothèses illustratives NON vérifiées sur catalogue ni marché ivoirien.
- Résultat net A1 simplifié : EBITDA − CAPEX/10 − intérêts (60 % CAPEX × 10 %) − 25 % d'impôt sur résultat positif.
- Dette 60 % / apport 40 % ; service annuel de dette indicatif sur 7 ans, sans échéancier mensuel.
- Pas de BFR, bilan, TVA, trésorerie validée, flux de déchets contractuels, assurance ni conformité environnementale qualifiée.
- Les coproduits ne sont comptés que dans les hypothèses explicites, sans garantir leur vente.

## À faire pour les véritables BP Découverte
Prix catalogue vérifiables EXW/FOB et capacités des postes ; coûts de transport et d'installation ; volumes et qualité de collecte contractualisables ; prix de vente et débouchés ivoiriens vérifiés ; tableaux financiers v107, 17 rubriques intégrées, visuels IA, PDF, BP Pro.
