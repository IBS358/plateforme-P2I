# P2I — Lot 213 : premiers prix publics et débit des panneaux

## Travail effectivement réalisé
- Reprise intégrale du lot 212, sans toucher au catalogue actif ni aux sept BP historiques.
- Prix public local de contreplaqué feuillus **18 mm, 2440 × 1220 mm : 14 500 FCFA/panneau** (Produitbat). Produit générique, aptitude scolaire non validée.
- Plan de débit géométrique : pour une table-banc, plateau 1200 × 400, assise 1200 × 250, dossier 1200 × 180 mm. Les trois bandes totalisent 830 mm en largeur; deux jeux peuvent tenir dans 2400 mm de longueur d'un panneau 2440 × 1220 mm, **hors jeu de coupe, orientation des fibres et défauts**. Le coût d'achat réparti est donc **7 250 FCFA/table-banc** sous cette hypothèse de deux jeux par panneau. La découpe réelle et les chutes réutilisables doivent être validées.
- Acier : deux barres de 6 m pour une unité. Le prix **7 300 FCFA/barre 30×30×1,5** figure dans les sources historiques du lot 210; il reste conditionnel à confirmation du vendeur. **14 600 FCFA/table-banc** au prix historique, sans double comptage de l'acier consommé.
- **Sous-total indicatif acier + bois : 21 850 FCFA/table-banc**, excluant fixations, peinture, consommables, main-d’œuvre, énergie, livraison, pertes, charges fixes et taxes. **Ce n'est pas un coût de revient.**
- Un poste à souder MMA 180A INGCO INGMMA1805 est affiché à **100 000 FCFA** chez INGCO-TLB; simple candidat CAPEX, pas une ligne complète.

## Décision
Aucun résultat financier v107 n'est produit : des postes essentiels restent sans prix, et le sous-total matières ne peut être utilisé comme coût complet. Aucun changement de l'UP active irrigation.

## Sources
- https://www.produitbat.ci/boutiques?sous_sous_categorie=Contre-Plaqu-s
- https://abidjansolution.biz/barre-tube-carre-fer-plat-et-corniere-prix-de-base-en-ferronnerie
- https://www.ingcotlb.com/
- Demande institutionnelle 2026 (75 000 tables-bancs annoncés) : https://gouv.ci/actualite/annee-scolaire-2026-2027-5081262-kits-scolaires-seront-distribues-dans-les-epp-et-75000-tables-bancs-prevus-pour-les-ecoles-primaires-et-secondaires-publiques-6837

## Étapes manquantes avant validation
Vérifier le plan coté, la stabilité, l'épaisseur des tubes, la qualité des panneaux, les achats effectifs, la peinture, les temps opératoires, l'investissement complet, les prix de vente comparables et les volumes. Ensuite seulement exécuter v107. Les visuels P2I devront être ajoutés après qualification industrielle et financière, conformément à la demande.
