# Lot 328 — Galeries de variantes P2I

- Huit BP du lot 327 conservés, chacun enrichi de quatre illustrations de variantes issues de LOT293 (32 affichages d’images existantes).
- Galerie insérée avant les postes numérotés du bloc 17.
- Aucune modification des chiffres, hypothèses, configurations ou moteurs v107.
- Ces visuels sont des illustrations IA de variantes, pas des photographies de machines.
- Les photos des machines restent à produire ou qualifier, ainsi que la revue éditoriale complète des 17 rubriques.
- Marge verre 3,20 % maintenue. DEEE conditionnel.
