# Lot 168 — Construction de nouvelles configurations v107

Base : Lot 167. Ajout d’un formulaire de simulation indépendant des hypothèses financières historiques pour les quatre UP déficitaires. Les prix, coûts et volumes sont volontairement vides ; aucune donnée nouvelle non vérifiée n’est introduite. Le moteur commun v107 reste inchangé.

Le formulaire contrôle la présence des 13 champs, les tableaux A1–A3, le plafond ventes/production, le coût industriel supérieur ou égal aux matières et le CAPEX machines inférieur au CAPEX total. Il affiche CR 3 ans et trésorerie 12 mois, puis exporte un JSON complet portant le statut « non validée ». Un lien depuis l’atelier historique permet d’ouvrir cette nouvelle interface.

**Ce qui n’est pas fait :** aucune des quatre nouvelles configurations n’est chiffrée ou validée, aucune preuve fournisseur n’est ajoutée, aucun test Microsoft Edge réel. Les résultats historiques ne sont pas modifiés.

Tests : {"new_file_exists": true, "old_inputs_not_embedded": true, "required_fields": true, "shared_engine": true, "three_year_validation": true, "nonvalidated_label": true, "backlink": true, "catalogue_96": true, "catalogue_registry_present": true, "new_js_syntax": true, "LOT155/test_lot155_integration.cjs": true, "LOT164/test_limites_v107.cjs": true, "LOT167/test_selection_guard.cjs": true}
