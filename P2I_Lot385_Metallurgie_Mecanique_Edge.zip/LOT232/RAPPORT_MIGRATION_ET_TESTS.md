# Lot 232 — Migration contrôlée du catalogue Assemblage & Montage

## Réalisé
- Source : lot 231 (464 fichiers).
- Identifiant actif remplacé : `irrigation_kits_surface` → `mobilier_scolaire_professionnel` ; catalogue conserve exactement 12 filières et 96 UP distinctes.
- Ancien identifiant irrigation et remorques redirigés vers le mobilier; fichiers historiques conservés.
- Overlay de données injecté avant la vérification du registre actif; moteur v107 non modifié.
- Index des huit BP et bilan de filière mis à jour.
- 17 rubriques mobilier conservées; sept autres BP non modifiés.
- 3 liens locaux de l'index vérifiés : aucun manquant.

## Réserves substantielles
- Simulation v107 lot 229 : 3,11 % / 7,80 % / 8,13 %, non validée sur commandes, machines, capacités ou prix réels.
- Crédit client, acomptes, BFR et dette non réconciliés dans un même calcul v107; trésorerie complète non validée.
- Visuel principal IA conservé; photographies et références des postes industriels incomplètes.
- L'overlay catalogue affiche volontairement les champs économiques inconnus comme `null`, plutôt que d'inventer des chiffres.
- Migration testée statiquement; test complet dans navigateur et test fonctionnel des 96 parcours non réalisés.
- Les anciennes données de l'irrigation demeurent accessibles dans les archives, mais ne sont plus référencées par le registre actif.

**Statut : catalogue migré et huit BP accessibles; validation bancaire/financière définitive NON acquise.**
