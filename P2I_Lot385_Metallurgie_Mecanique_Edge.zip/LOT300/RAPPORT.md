# Lot 300 — Audit de qualification croisée
72 contrôles sur huit UP (neuf par UP). Contrôles de rapprochement physique/commercial, identité du RN, cohérence des marges, répartition CAPEX et preuves documentaires.
Le statut « bloqué » signifie qu'aucune marge bénéficiaire n'est considérée validée sans rapprochement des volumes, prix, coûts, financement du BFR, preuves fournisseur et test du moteur v107.
L'archive conserve les anciens lots et les bandeaux IA. Aucun recalcul artificiel, aucun prix catalogue inventé, aucun fichier des autres filières modifié.
