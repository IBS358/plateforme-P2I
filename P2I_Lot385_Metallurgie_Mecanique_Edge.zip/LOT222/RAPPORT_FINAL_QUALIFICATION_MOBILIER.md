# P2I — Lot 222 — Clôture de l'étude de qualification « Fabrication de mobilier scolaire et professionnel »

**Date : 17 novembre 2026.** **Base exacte : Lot 221, archive complète Core (418 fichiers).** **Décision : candidature industrielle recevable, BP Découverte financier NON VALIDÉ.** Cette étude clôt le cycle de qualification sur les informations disponibles; elle n'est pas un BP industriel bancable.

## 1. Conclusion exécutive et arbitrage
Le mobilier scolaire et professionnel est une véritable activité de transformation industrielle, avec demande scolaire institutionnelle attestée, possibilité de fabrication locale et gamme B2B. Il est préférable à une simple activité d'installation pour l'objectif industriel de la P2I. **Mais les données existantes ne permettent pas de conclure à une marge nette A1 positive ni à une marge nette >10 % A2–A3.** Le catalogue actif reste inchangé. L'UP irrigation n'est pas remplacée dans cette archive; les sept autres BP sont conservés.

## 2. Preuves de marché
Le gouvernement ivoirien indique avoir obtenu le financement d'environ **75 000 tables-bancs semi-métalliques pour 2026**, avec une durée de vie annoncée d'au moins cinq ans. Un financement de 20 milliards FCFA pour 166 660 tables-bancs en 2027 est **sollicité**, et non acquis. Source : https://gouv.ci/actualite/annee-scolaire-2026-2027-5081262-kits-scolaires-seront-distribues-dans-les-epp-et-75000-tables-bancs-prevus-pour-les-ecoles-primaires-et-secondaires-publiques-6837 . Ce sont des indicateurs de demande, pas des commandes garanties à P2I. Le reconditionnement de mobilier existant est également une activité concurrente/complémentaire.

## 3. Gamme et positionnement retenus
- **Référence scolaire** : table-banc biplace semi-métallique robuste, sans électronique.
- **Référence professionnelle** : bureau métal/bois avec passe-câbles et compartiment de rangement; dimensions et BOM non validées.
- **Référence rangement** : armoire métallique verrouillable; dimensions, épaisseurs et BOM non validées.
- **Variantes hors calcul** : table-banc secondaire avec emplacement tablette sécurisé, pupitre universitaire, bureau avec rangement tablette, lampe LED rechargeable/amovible. Aucun surcoût ou chiffre d'affaires attribué sans nomenclature et prix.
- **Ne pas inclure d'hypothèse de subvention ou d'attribution publique.**

## 4. Prix et concurrence
Une offre historique candidate de table-banc mentionne 33 000 FCFA, sans démontrer le prix d'un marché attribué. Des prix de détail publics pour les armoires vont de 110 000 à 189 000 FCFA selon les modèles. Un bureau 120 cm en bois est affiché à 94 000 FCFA chez RAQO; il n'est pas comparable sans adaptation au modèle P2I. Les 110 000 FCFA/bureau et 160 000 FCFA/armoire utilisés au lot 217 étaient **des hypothèses**, pas des prix fournisseurs vérifiés. Voir CSV joint. **Les prix publics concurrents ne sont pas automatiquement des prix de vente sortie d'usine.**

## 5. Configuration industrielle de référence proposée, NON encore chiffrée
Réception acier/panneaux → débit tubes/profilés → préparation/soudage des cadres → découpe et perçage des panneaux → tôlerie (armoires) → ébavurage/traitement de surface → peinture/séchage → assemblage et fixation → contrôle stabilité, résistance, arêtes, serrures → emballage et livraison. Équipements à qualifier : scie acier, postes MIG/MAG adaptés, gabarits, scie panneaux, perceuses, plieuse/cisaille si tôlerie intégrée, compresseur, cabine/ventilation peinture, outillage, manutention et EPI. **Aucun achat machine ni capacité industrielle ne sont validés par cette liste.** Prévoir une variante de sous-traitance tôlerie/peinture, mais ne pas prétendre à la fabrication complète si les opérations sont externalisées.

## 6. Contrôle de la nomenclature scolaire
Acier optimisé 10 950 FCFA et bois 7 250 FCFA par table-banc = 18 200 FCFA de matières partielles, sous réserve du plan de débit et des prix. Les autres consommables, les pertes réelles, la main-d'œuvre, le transport et les charges sont à documenter. Le ratio 3 barres pour 2 tables-bancs n'est pas une preuve de conformité mécanique.

## 7. Résultat financier réellement démontré
Scénario exploratoire lot 219 : CA A1 70,000,000 FCFA; coûts variables 50,240,000; personnel + fixes 23,205,000; contribution 19,760,000; solde avant amortissements/intérêts/impôts **-3,445,000 FCFA**. Les coûts et prix de bureaux/armoires restent hypothétiques. À structure et contribution unitaires constantes, le CA théorique d'équilibre de ce seul solde serait 82,203,947 FCFA (x1.17 les volumes de base). Pour un surplus **avant amortissements/intérêts/impôts** de 10 % du CA, seuil 127,300,157 FCFA (x1.82), si les frais fixes ne croissent pas. **Ces seuils ne sont pas des marges nettes et ignorent la saturation de l'atelier.** Voir SENSIBILITE_ECONOMIQUE_NON_VALIDEE.csv.

## 8. Crédit clients, commandes et trésorerie
Le scénario du lot 221 : 60 % des ventes à crédit, acompte 30 % sur celles-ci, solde à 60 jours, matières achetées un mois avant livraison, ventes A1 70 M FCFA. Besoin maximal de trésorerie opérationnelle **partiel** : **16,217,290 FCFA**; créances fin A1 **7,546,560 FCFA**. Les avances sont des dettes clients jusqu'à livraison, pas du CA. Le besoin exclut CAPEX, stocks de sécurité, dette, TVA, IS, retards et SAV; il ne peut être pris pour un plan de financement complet. Pour éviter les retards de règlement : limites d'encours, acomptes contractuels, facturation à réception, suivi d'échéances, et éventuellement affacturage sous réserve de coûts vérifiés.

## 9. Capacité et montée en puissance
Accélération à M6 retenue comme **hypothèse commerciale**. Pour démontrer la capacité : relever temps de coupe, soudure, finition, montage, contrôles et temps machine par produit; tester les cadences en heures utiles, les rebuts et l'indisponibilité. Les volumes A2/A3 ne sont pas des ventes acquises. Toute croissance de capacité doit être accompagnée de CAPEX, personnel et BFR supplémentaires.

## 10. Innovations : cahier des charges
**Emplacement tablette** : tablette posée en position sûre, sans câble exposé, sans arêtes vives, dimensions adaptées aux appareils usuels; système antivol facultatif à évaluer; éviter de fixer des accessoires fragiles au mobilier d'école sans tests. **Lampe LED amovible** : option de bureau, charge USB-C, protection batterie, garantie et disponibilité des pièces; vérifier les exigences de conformité applicables. Ne pas engager d'achat par conteneur avant volumes de commande démontrés; distinguer prix EXW/FOB et coût rendu atelier.

## 11. Politique commerciale
Scolaire : appels d'offres et réseaux d'établissements privés, sous réserve de conformité au cahier des charges et de capacité financière. Professionnel : PME, cabinets, administrations, universités, entreprises, distributeurs et installateurs. Prévoir échantillons, garanties, livraison, SAV et politique de crédit. Ne pas compter de ventes non contractualisées comme commandes.

## 12. Financement et risques
Financement de référence 40 % apport / 60 % dette sur l'investissement, réserve de BFR séparée. Risques : encours clients, matières acier, qualité des soudures, stabilité des bancs, corrosion, défauts de peinture, concurrence importée, commandes publiques irrégulières, délais de paiement, sécurité électrique des accessoires. Contrôles : essais prototypes, traçabilité des lots, garanties, gestion du crédit, scénarios de retards, stocks et trésorerie.

## 13. Décision de validation
**Feux :** opportunité de marché DOCUMENTÉE; principe industriel PLAUSIBLE; conception technique PARTIELLE; CAPEX INCOMPLET; marge nette NON VALIDÉE; trésorerie financée NON VALIDÉE. **Décision : conserver la candidature dans le dossier d'étude, sans publication comme BP Découverte validé.** Il n'est pas acceptable de publier des 17 rubriques comme BP chiffré complet en l'état.

## 14. Conditions de passage à l'UP active
1. Plans cotés et nomenclatures quantifiées pour table-banc, bureau, armoire, variantes hors calcul distinguées.
2. Prix EXW/FOB publics vérifiables et prix matières ivoiriens, quantités, pertes et compatibilités des équipements.
3. Temps standard, capacité poste par poste, effectifs et charges, investissement rendu/posé, coûts commerciaux.
4. Prix de vente justifiés par produits comparables, volumes A1–A3 avec hypothèses de pénétration explicites.
5. Moteur commun v107 : CR 3 ans, trésorerie 12 mois, BFR 36 mois, bilan équilibré, dette 40/60, scénarios retards clients; aucune trésorerie négative non financée.
6. Ensuite seulement : migration du catalogue 96 UP, BP 17 rubriques, visuels cohérents blocs 2 et 17, logo original, PDF/Edge et tests.

## 15. Contrôles et intégrité
Tous les fichiers du lot 221 ont été repris sans modification; les nouveaux fichiers sont uniquement dans LOT222 et les archives antérieures restent intactes. Le moteur v107 et les sept BP précédents ne sont pas modifiés. Aucune intervention GitHub. Les prix et données externes sont cités par URL, sans prétendre à une vérification de stock fournisseur.
