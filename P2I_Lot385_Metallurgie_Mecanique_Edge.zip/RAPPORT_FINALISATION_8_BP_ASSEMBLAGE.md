# P2I — Consolidation finale Assemblage & Montage

Date : 17 novembre 2026 · moteur commun v107 conservé · huit BP dans un index commun. Les sept scénarios positifs/historiques ont été conservés; seule la remorque a reçu une unique révision de gamme puis un recalcul v107. Aucun statut ci-dessous ne vaut validation commerciale ou technique.

## Résultats des trois scénarios suivis

| UP | Plan A1 (hypothèses) | Résultat net A1 | A2 | A3 | État |
|---|---:|---:|---:|---:|---|
| Remorques agricoles 3 tonnes | 72 × 4 650 USD | -14 149.68 USD (-4.23%) | -17 193.37 USD | -21 017.24 USD | Déficitaire; non validé économiquement |
| Petites machines de conditionnement | 36 × 6 200 USD | 35 102.10 USD (15.73%) | 34 713.93 USD | 34 089.72 USD | Positif sous hypothèses; non validé commercial/technique |
| Stockage & manutention — rayonnages B2B | 120 × 1 250 USD | 9 784.50 USD (6.52%) | 9 043.48 USD | 8 148.93 USD | Positif sous hypothèses; non validé commercial/technique |

## Remorque agricole : configuration finale retenue

Une seule optimisation de gamme : fabriquer en lots à gabarits fixes, utiliser une nomenclature standard, grouper les achats et continuer à sous-traiter la découpe et le pliage. Le tandem, les quatre pneus, la suspension, le freinage hydraulique et l’attelage restent au BOM. Prix de scénario de 4 650 USD et plan de 72 unités/an inchangés. La baisse de 50 à 42 h directes par unité est une estimation de planification (8 h gagnées, non chronométrées), valorisée à 6 USD/h. Elle économise 48 USD/unité, soit 3 456 USD/an au plan conservé; le résultat A1 reste **−14 149,68 USD (−4,23 %)**. Cette productivité doit être mesurée en atelier.

| Coût / hypothèse unitaire | USD | Qualification |
|---|---:|---|
| Matières et composants | 3 402,84 | BOM inchangée : acier Lot 184, tandem, roues, freinage, attelage et accessoires |
| Coupe et pliage sous-traités | 250,00 | Estimation |
| Main-d’œuvre directe | 252,00 | 42 h × 6 USD/h estimées |
| Soudage, gaz, abrasifs, énergie | 220,00 | Estimation |
| Peinture et préparation | 120,00 | Estimation |
| Contrôle, reprises et essais | 140,00 | Estimation |
| Coût de fabrication | **4 384,84** | Entrée du scénario v107 |
| Distribution | 150,00 | Entrée v107 |
| Contribution avant frais annuels, amortissements et intérêts | **115,16** | 4 650 − 4 384,84 − 150 |

**Cause du déficit :** la contribution unitaire ne couvre pas le personnel (12 000 USD/an), les charges fixes (8 000 USD/an), la distribution annuelle de 10 800 USD, les amortissements (1 700 USD) et les intérêts A1 (741,20 USD). v107 inclut la distribution dans ses charges fixes publiées; le compte de résultat la présente à part, sans double comptage. L’ancien déficit de référence annoncé à −31 752 USD ne peut pas être reconstitué poste par poste, car les entrées originales correspondantes ne figurent pas dans l’archive. La baisse de coût calculée ici ne corrige que la gamme de main-d’œuvre; elle ne suffit pas à rendre l’activité rentable. Les catalogues publics indiquent une remorque Weito 3 t quatre roues non basculante à 1 550–1 750 USD FOB et un modèle YTO 3 t basculant affiché en Côte d’Ivoire à 2 783 000 FCFA. Ce sont des comparateurs de configurations différentes, pas un prix de vente constaté pour la remorque P2I. Un revendeur local affiche aussi tubes et tôles, mais l’acier du BP garde la donnée du Lot 184; les tarifs catalogue servent à contrôler l’ordre de grandeur, pas à substituer un coût d’achat réel.

**Sécurité non validée :** la charge publiée des pneus retenus n’est pas une certification de l’ensemble. La tare complète, le PTAC, les essieux/moyeux/jantes, la compatibilité d’attelage et de freinage, la stabilité et la résistance des soudures demandent plans, calcul mécanique et essais de charge/freinage. La capacité utile de 3 tonnes ne peut pas être déclarée certifiée à partir des données actuellement disponibles.

## Machines de conditionnement : scénario préservé et identifiant migré

Le résultat positif du scénario existant demeure inchangé : 36 unités/an et prix hypothétique de 6 200 USD. La configuration est une doseuse/remplisseuse à vis pour poudres sèches avec pesée et thermoscelleuse continue. Le coût des composants (2 610 USD/unité) plus la conversion (840 USD) égale le coût de fabrication de 3 450 USD. Dans le compte A1, 36 × 3 450 = 124 200 USD de coût des produits vendus; cette somme inclut les 93 960 USD de composants et 30 240 USD de conversion. Les 4 320 USD de distribution apparaissent séparément. Le CAPEX atelier de 27 000 USD est un investissement, pas une charge récurrente et n’est pas ajouté au BOM. Il n’y a donc pas de double comptage entre nomenclature, fabrication et charges d’exploitation dans le scénario v107. Le prix et le volume restent des hypothèses, pas un tarif ou des ventes observées.

L’identifiant actif du catalogue est désormais `machines_conditionnement_pme`; l’ancien `tablettes` redirige vers lui, comme l’alias `ordinateurs`. L’ancienne donnée Tablet SKD reste dans l’archive historique et n’est pas comptée comme UP active. Le groupe Assemblage & Montage conserve huit identifiants, sans neuvième UP ni doublon avec l’UP emballages.

## Rayonnages industriels B2B

Le scénario v107 existant est conservé : 120 baies/an à 1 250 USD/baie, résultats nets A1–A3 ci-dessus. Il décrit un mode sur commande avec standardisation des profils, perçages, lisses et connecteurs, achat après ordre, finition lourde sous-traitée, fabrication finale et installation locales. Les prix, volumes, coûts unitaires, acomptes, charges admissibles, note de calcul et ancrages restent à vérifier; le résultat est positif sous hypothèses, et non une validation commerciale/technique.

## Contrôles v107 et états réellement disponibles

| UP | RN A1 | BFR maximal (36 mois) | Trésorerie min. (12 mois) | Réserve initiale | Écart bilan max. |
|---|---:|---:|---:|---:|---:|
| Remorque | -14 149.68 USD | 39 076.58 USD | 1 700.00 USD | 55 012.99 USD | 9.82e-11 USD |
| Machine | 35 102.10 USD | 19 917.65 USD | 3 675.06 USD | 20 299.33 USD | 1.46e-11 USD |
| Rayonnages | 9 784.50 USD | 12 470.93 USD | 1 771.79 USD | 13 299.13 USD | 3.64e-11 USD |

Financement : 40 % d’apport et 60 % de dette; compte de résultat sur 3 ans; trésorerie sur 12 mois; bilans équilibrés par le moteur. BFR publié sur 36 mois dans le modèle commun. Les contrôles ne valident pas les entrées commerciales/techniques. Les sept scénarios positifs restent inchangés; les cinq BP historiques sont préservés.

## Index et rubriques

L’index commun est `LOT192/INDEX_8_BP_ASSEMBLAGE.html`. Les huit liens ouvrent les BP; chaque page comporte 17 rubriques numérotées. Les illustrations, ressources locales et scripts historiques demeurent dans l’archive complète. Les anciens liens `unit_id=tablettes` et `unit_id=ordinateurs` sont redirigés vers la machine de conditionnement.

## Réserves empêchant les validations finales

- **Remorque :** devis/local landed cost des composants et sous-traitants; temps mesuré; prix et commandes; plans/tare/PTAC; compatibilités roue/essieu/freinage; calcul de résistance et essais de sécurité. Économiquement non validée en A1–A3.
- **Machine :** BOM fournisseur détaillée et coût rendu; répétabilité et débit par poudre/sachet; sécurité et conformité; ventes annuelles et prix local. Le BP financier est calculé, positif selon les hypothèses retenues, mais pas validé commercialement ou techniquement.
- **Rayonnages :** prix et commandes B2B; devis locaux de matière/pose; dimensions et charges réelles; calcul de résistance/stabilité/ancrages; validation d’essai. Positif sous hypothèses, non validé commercialement ou techniquement.

## Références publiques

- [Ferabeton — catalogues publics de tôles à Abidjan](https://ferabeton.com/tole-en-acier-abidjan-cote-d-ivoire/) ; [AZ Industrie CI — tubes carrés 6 m avec prix affichés](https://azindustrie.com/shop/tube-carre-acier-noir-barre-de-6ml-1975) ; [SAS CI — parc acier, nuances et découpe locale](https://www.sas-civ.com/).
- [Weito — remorque 3 t quatre roues non basculante, 1 550–1 750 USD FOB](https://sd-weito.en.made-in-china.com/product-catalog/Farm-Trailer-1.html) ; [YTO CI — remorque basculante 3 t affichée à 2 783 000 FCFA](https://globalgros.com/agriculture/outils-and-equipements/machines-agricoles/yto-remorque-7cx-3-3-tonnes/).
- [Sinoped — doseuse semi-automatique, 3 500–5 500 USD FOB affichés](https://www.made-in-china.com/video-channel/sinoped5577_vTSRKdzwfirY_Semi-Automatic-Auger-Filler-for-Small-Scale-Powder-Packaging.html) ; [US Solid — thermoscelleuses continues](https://ussolid.com/collections/continuous-band-sealer).
- [AME Rack — guide tarifaire FOB indicatif](https://amerack.com/racking-price/) ; [Momentum — prix de composants de rack](https://www.momentumracks.com/prices) ; [ELBM CI — conception, fourniture et pose](https://elbmci.com/pgeRack.php).

Calcul final remorque : `LOT193/recalculer_remorque_finale_v107.cjs`; moteur : `runtime/script-0.js` à `runtime/script-11.js`; sorties des trois BP : `LOT193/SCENARIOS_FINANCIERS_V107.json`.
