# P2I — Lot 257 — Coût de collecte et seuil économique, grandes unités plastique

Source de travail : archive intégrale lot 256, conservée sans modification.

## Méthode
- 16 h/jour, 22 jours/mois, 70 % d'utilisation, 82 % de rendement lavage et 97 % de rendement granulation, selon le lot 256.
- Coût énergie hypothétique : 180 kWh/t entrante × 90 FCFA/kWh.
- Autres charges variables hypothétiques : 65 000 FCFA/t entrante. Charges fixes illustratives : 120 millions FCFA/an, **non sourcées**.
- Collecte : 100 000, 150 000 ou 267 000 FCFA/t entrante ; le dernier est un repère sectoriel historique pour collecte et tri sans tri à la source, **pas** un tarif contractuel 2026.
- Prix de vente : 350 000, 450 000, 550 000 FCFA/t granulés, hypothèses non vérifiées.
- Les paillettes non granulées ne génèrent ici aucun chiffre d'affaires : prudence volontaire, mais leurs coûts sont compris.
- Résultat calculé : EBITDA simplifié ; **pas** un compte de résultat v107 (hors CAPEX, amortissements, dette, impôt, BFR et trésorerie).

## Sources publiques
- Étude GIZ / AIVDP, enquête 2021 : https://aivdp.ci/wp-content/uploads/2026/01/Site-InternetEtudes-et-Rapports20210902_GIZ-Gestion-valorisation-des-dechets_vFINAL-GIZ-1-.pdf
- Ministère Environnement, stratégie plastique : https://environnement.gouv.ci/index.php/actualite/626
- Portefeuille PPP PND 2026, économie circulaire : https://ppp.gouv.ci/public/index.php/portefeuille-projet/download/programme-doperationnalisation-de-leconomie-circulaire-pnd-2026

## Interprétation
La capacité de granulation, et non la seule capacité de lavage, détermine le volume de granulés vendables. Une hausse de collecte de 100 000 à 267 000 FCFA/t augmente le coût annuel de 167 000 FCFA par tonne entrante, indépendamment du prix de vente. Aucun scénario n'est validé industriellement ou commercialement. Les sept autres UP sont préservées, sans simulations inventées.
