# Lot 281 — Consolidation des huit BP

Ce lot ajoute huit BP actualisés en 17 rubriques et un tableau de rapprochement financier directement intégré dans chacun.

**Aucune marge restructurée n'est validée.** Les recettes des cinq UP restructurées ne sont pas commercialement prouvées. Le BFR n'est pas financé et le moteur v107 n'a pas été exécuté.

Les 806 fichiers du lot 280 sont conservés sans altération ; les nouveaux fichiers se trouvent uniquement dans LOT281.
