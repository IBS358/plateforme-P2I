# P2I — Lot 183 — BP Remorque 3 t, fabrication acier

Source : Lot 182. Livrable : BP de travail en 17 rubriques, structuré autour de la fabrication locale de châssis et de bennes à partir de tôles et profilés, avec 9 postes industriels.

## Données conservées
- Acier : 614,04 USD livré Abidjan, quantités provisoires.
- Deux essieux : 438,60–543 USD FOB.
- Sous-total partiel : 1 052,64–1 157,04 USD ; bases de prix non homogènes.
- Machines : QD-1325, WC67Y 100T/3200, MIG250DC-1 (fourchettes historiques, options à qualifier).

## Limites
Pas de coût complet, prix local vérifié, capacité effective ni résultat financier v107 pour la remorque 3 t. Aucune marge n'est inventée. Aucun test manuel Edge. Le dossier historique 750 kg reste archivé et n'est pas écrasé.

## Tests
Contrôle automatisé des 17 ancres, des 9 postes, des fichiers source et de l'intégrité du ZIP. Aucun fichier GitHub modifié.
