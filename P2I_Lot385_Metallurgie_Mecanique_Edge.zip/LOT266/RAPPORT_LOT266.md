# Lot 266 — UP Verre : décision financière et risques

**Base vérifiée dans l’archive** : `P2I_Edge/LOT264/finances/verre.json`. Aucune autre UP n’a été modifiée. Les prix et coûts de cette base ne sont pas validés sur le marché ivoirien.

## Production et modèle
Tri, séparation des indésirables, broyage, criblage, conditionnement de calcin par couleur ; éventuel sable/granulats uniquement si débouchés qualifiés. Pas de refonte. Capacité de référence 6 t/h, 16 h/j, 22 j/mois, 70 % d’utilisation, 85 % de rendement hypothétique : ~17 741 t/an entrants et ~15 080 t/an vendables.

## Ce qui a été effectivement recalculé
75 combinaisons : 5 CAPEX × 5 utilisations × 3 niveaux de prix de vente, avec 3 ans de résultat, dette 60 % à 10 % et remboursement linéaire 7 ans, amortissement linéaire 10 ans, impôt illustratif 25 % des bénéfices positifs, trésorerie lissée sur 12 mois avec provision BFR initiale distincte. Les coûts variables évoluent avec l’utilisation, les charges fixes restent celles de la base, et le prix varie indépendamment.

**Attention :** une marge nette positive issue de ces hypothèses n’est pas une validation. La trésorerie lissée ne modélise ni délais d’encaissement/décaissement ni saisonnalité ni investissements de renouvellement. Le bilan n’est pas construit ; le moteur v107 n’a pas été exécuté.

## Conditions de décision
- Ligne complète 5–8 t/h : devis ou catalogue EXW/FOB et détail poste par poste, consommations électriques, traitement des poussières, refus et contrôle qualité.
- CAPEX rendu site : transport, douanes, génie civil, bâtiment, installation, raccordements, formation, pièces et réserve BFR.
- Contrats d’approvisionnement correspondant à ~17 700 tonnes/an de verre entrant à 70 % d’utilisation.
- Contrats d’achat pour ~15 100 tonnes/an de produits vendables, avec spécifications et prix nets par fraction, sans double comptage.
- Recalcul BFR réel, bilan A1–A3 équilibré, trésorerie M1–M12 et v107.

**Décision** : garder l’UP Verre à qualifier, sans substituer un CAPEX de 800 M FCFA non documenté à une offre fournisseur. Ne pas modifier les autres BP.
