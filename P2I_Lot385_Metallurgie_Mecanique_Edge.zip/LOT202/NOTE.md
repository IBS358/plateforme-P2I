# Lot 202 — Références industrielles de pré-étude

Deux périmètres techniques uniques ont été formalisés et liés aux BP et à l’index des huit UP. Ils restent des hypothèses de conception, non des configurations validées. Aucune donnée financière créée.
