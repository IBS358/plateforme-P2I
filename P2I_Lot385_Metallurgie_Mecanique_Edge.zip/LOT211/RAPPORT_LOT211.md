# P2I — Lot 211 — Quantification du mobilier scolaire

## Résultat
Une nomenclature quantitative provisoire de **13 postes** a été créée pour un **table-banc biplace semi-métallique**. Les longueurs, dimensions et quantités sont des **hypothèses de conception P2I**, non un plan homologué ni un cahier des charges ministériel. Les prix non vérifiés restent **vides**, jamais remplacés par zéro.

## Base de travail
- Tube carré 30×30 mm : **8,40 m** par unité, avec découpe à optimiser; deux barres commerciales de 6 m seraient nécessaires sans mutualisation des chutes. Le taux de chute de 30 % est un maximum théorique sur cette découpe simplifiée, non une perte industrielle retenue.
- Surfaces théoriques de panneaux : plateau 0,480 m², assise 0,300 m², dossier 0,216 m², soit **0,996 m² hors pertes**.
- 18 fixations et 4 embouts : hypothèses provisoires de dimensionnement.
- Les épaisseurs acier/bois, renforts, charges d'essai, traitements de surface et temps opératoires doivent être validés.

## Point bloquant pour v107
Les prix publics déjà repérés ne suffisent pas à déterminer le coût matière total. Manquent : prix comparables des panneaux et de la quincaillerie, consommation peinture, coût machine/outillage et investissement, heures directes, frais de transport, prix de vente comparables à spécification identique, volume défendable. **Aucun calcul v107 n'a été exécuté pour le mobilier** et aucun résultat financier n'est revendiqué.

## Continuité et intégrité
- Catalogue des 96 UP et redirections inchangés ; irrigation reste active à titre provisoire.
- Sept BP historiques inchangés ; aucun remplacement irréversible.
- L'ancienne configuration `meubles` est conservée dans les sources historiques.
- Le cœur du lot 210 est conservé, sans visuels des parties 2–5 non reçues.

## Prochaine porte technique
Choisir un plan coté compatible avec le cahier des charges scolaire, puis relever les prix de toutes les lignes. Une simulation ne sera justifiée qu'après complétude du coût industriel et des hypothèses commerciales.
