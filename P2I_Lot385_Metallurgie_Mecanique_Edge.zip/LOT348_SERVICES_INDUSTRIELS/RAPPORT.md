# P2I — Lot 348 — Services industriels

Huit BP historiques conservés et huit annexes documentaires ajoutées.

Quatre lignes de prix publics, concernant quatre UP : maintenance, qualité, énergie, sécurité. Une même référence Fluke 117 est utilisée dans trois contextes distincts ; il ne s’agit pas de trois modèles différents. Les autres UP conservent leur statut de prix non documentés.

Les montants d’investissement, revenus, marges, trésoreries et résultats du lot 347 sont **strictement inchangés**. Moteur v107 **non exécuté**. Prix publics de distributeurs étrangers, ni EXW/FOB ni rendus CI. Aucune configuration intégrale validée.

L'objectif du lot est la traçabilité des premières références, non la validation des BP.
