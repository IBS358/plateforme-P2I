# Lot 225 — Marge contributive, personnel et dirigeant

## Rectification de présentation
Les coûts variables unitaires (25 200 / 71 000 / 108 000 FCFA) restent distincts des frais de personnel. La ventilation analytique du lot 224 n'est pas appliquée au tableau principal. La masse salariale annuelle historique de 14 280 000 FCFA est déduite une seule fois, en charges de période.

## Situation A1 — scénario exploratoire du lot 219
- CA : 70 000 000 FCFA ; coûts variables : 50 240 000 FCFA ; marge sur coûts variables : 19 760 000 FCFA (28,23 % du CA).
- Frais fixes hors personnel : 8 925 000 FCFA.
- Solde disponible pour le personnel ET une rémunération du dirigeant éventuellement supplémentaire : **10 835 000 FCFA** avant amortissements, intérêts et impôts.
- Personnel historique : 14 280 000 FCFA. **Écart : -3 445 000 FCFA** avant amortissements, intérêts et impôts.
- On ignore si la rémunération du dirigeant est déjà incluse dans les 14 280 000 FCFA. Deux cas sont donc explicitement distingués. Si elle y est incluse, le déficit demeure -3 445 000 FCFA. Si elle s'ajoute, le déficit augmente d'autant.

## Économies minimales pour couvrir le personnel et les frais fixes
- Dirigeant déjà compris : réduction des coûts variables de **6,86 %** (3 445 000 / 50 240 000).
- Dirigeant supplémentaire 2,4 M FCFA/an : **11,63 %**.
- Dirigeant supplémentaire 3,6 M FCFA/an : **14,02 %**.
- Dirigeant supplémentaire 4,8 M FCFA/an : **16,41 %**.
Ces seuils couvrent uniquement les charges de période retenues, AVANT amortissements, intérêts et impôts. Ce ne sont pas des seuils de résultat net nul ni des économies démontrées.

## Marge nette
Le résultat net de 6 % ou 10 % ne peut être attesté à partir de ce tableau : amortissements, financement, fiscalité et coût de crédit client doivent être calculés dans v107, avec des données industrielles documentées. L'évolution du CA à partir de M6 et en A2-A3 doit être testée avec la capacité réelle de l'atelier et le BFR.

## Statut
Correction du cadre de présentation et simulations de sensibilité effectuées ; aucune rentabilité validée ; catalogue actif, 7 BP précédents et moteur commun inchangés.
