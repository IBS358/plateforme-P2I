# P2I — Lot 252 — Sensibilité financière plastique PEHD (non validée)

Archive cumulative du lot 251 conservée. Les neuf UP historiques et les sept autres UP Recyclage ne sont pas modifiées.

## Résultat quantitatif

- Tonnage entrant A1 : 739.2 t ; tonnage vendable : 606.1 t.
- Seuil prix de vente EBITDA nul (intrant 150 FCFA/kg) : 351.2 FCFA/kg.
- Seuil prix de vente résultat avant impôt simplifié nul : 378.4 FCFA/kg.
- 21 scénarios croisant sept prix de vente de 250 à 550 FCFA/kg et trois coûts intrants de 130, 150 et 165 FCFA/kg.

## Précautions

Tous les prix de sortie testés sont des hypothèses, non des cours constatés. Le repère historique 500-600 FCFA/kg de PEHD régénéré ne valide pas le prix des paillettes lavées. Les charges énergétiques, investissements et coûts de transformation restent hypothétiques. Aucun IS, TVA, BFR, échéancier de remboursement, bilan ni trésorerie 12 mois n'a été simulé. Le moteur v107 n'a pas été exécuté.

La sensibilité sert à identifier le prix minimum à confirmer auprès d'acheteurs ivoiriens, et non à valider le BP.
