﻿# P2I — Lot 214 : optimisation de débit et décision économique préalable

## Périmètre
Base lot 213 conservée octet pour octet. Sept BP historiques et catalogue actif inchangés. Ce lot ne crée ni scénario v107 fictif ni remplacement anticipé de l’UP Irrigation.

## Contrôle de la nomenclature
La liste du lot 212 représente 12 pièces, 8 400 mm nets par table-banc (2 × 1150 + 4 × 720 + 4 × 600 + 2 × 410), hors 12 traits de scie de 3 mm. L’achat isolé nécessite deux barres de 6 m, soit 14 600 FCFA au prix historique conditionnel de 7 300 FCFA/barre.

**Résultat nouveau vérifiable : pour deux tables-bancs fabriquées en lot, un algorithme de placement dans des barres de 6 m trouve un débit en trois barres au lieu de quatre.** Le coût d’acier imputé devient 10 950 FCFA par table-banc, soit une économie potentielle de 3 650 FCFA par unité. Le plan de placement correspondant est livré. Cette optimisation suppose le regroupement des découpes, la stabilité du plan de pièces et le prix historique de l’acier ; elle n’est pas une réduction du prix fournisseur.

Le coût acier + panneau, à 2 tables-bancs/panneau et 2 tables-bancs/3 barres, serait alors de **18 200 FCFA/table-banc**, contre 21 850 FCFA en fabrication isolée. Ce montant reste strictement un **sous-total matières**, pas un coût de revient.

## Épreuve commerciale : repère historique à 33 000 FCFA
Une décision de marché public citée dans les recherches précédentes rapportait un coût déclaré de 26 400 FCFA et une marge déclarée de 6 600 FCFA, soit 33 000 FCFA pour cette offre particulière. **Ce montant n’est pas un prix P2I confirmé, ni une comparaison de spécifications validée.**

Si, à titre d’illustration uniquement, on prenait 33 000 FCFA comme prix de référence, le budget disponible après acier et panneaux optimisés serait 14 800 FCFA/unité. Il doit encore couvrir fixations, embouts, peinture, soudage, main-d’œuvre, énergie, pertes, emballage, transport, garantie, charges fixes, amortissements, financement et fiscalité. Aucun résultat net ne peut être inféré de ce solde.

## Point de vigilance technique
Le contreplaqué feuillus 18 mm n’est pas nécessairement conforme aux exigences de durabilité du mobilier scolaire. Le châssis en tube 30×30×1,5 mm et le plan des soudures doivent être dimensionnés et testés. La peinture anticorrosion et les arrêtes de sécurité sont indispensables. Le poste MMA 180 A à 100 000 FCFA est un équipement candidat, non une ligne de fabrication complète.

## Décision
La mutualisation du débit améliore sensiblement la matière, mais ne suffit pas à qualifier économiquement le mobilier scolaire. **Ne pas migrer le catalogue tant que le coût complet, le prix réellement comparable, le CAPEX et les volumes n’ont pas été vérifiés.**

## Sources conservées
- P2I_Edge/LOT212/PLAN_DEBIT_ACIER_30X30.csv
- P2I_Edge/LOT213/PRIX_MATIERES_ET_CAPEX.csv
- P2I_Edge/LOT213/RAPPORT_LOT213.md
- https://www.produitbat.ci/boutiques?sous_sous_categorie=Contre-Plaqu-s
- https://abidjansolution.biz/barre-tube-carre-fer-plat-et-corniere-prix-de-base-en-ferronnerie
