# P2I — Lot 259 — Sensibilité économique des huit UP de recyclage

## Objet
Ce lot ajoute 216 simulations de sensibilité (8 UP × 3 utilisations × 3 prix de vente × 3 coûts de collecte). Il conserve les 579 entrées du lot 258. Il ne modifie aucun BP, moteur v107 ou dossier historique.

## Hypothèses de calcul
- Capacités et rendements du lot 258, sans nouvelle validation fournisseur.
- 16 heures/jour, 22 jours/mois, 12 mois/an (4 224 heures nominales).
- Taux d'utilisation 50 %, 70 %, 85 %.
- Prix de vente : 80 %, 100 %, 110 % du prix illustratif du lot 258.
- Coût d'achat/collecte : 100 %, 120 %, 140 % du coût illustratif du lot 258.
- Énergie : prix de simulation 90 FCFA/kWh, consommations spécifiques hypothétiques du lot 258.
- Les autres coûts variables sont proportionnels aux tonnes entrantes, charges fixes inchangées.
- EBITDA simplifié = ventes – collecte – électricité – autres variables – fixes.
- Aucun calcul de BFR, amortissement, intérêts, fiscalité, service de dette, bilan ou trésorerie n'est inclus. Ce n'est PAS un calcul v107.
- Tous les prix et volumes de ce lot sont exploratoires ; ne pas les publier comme des valeurs ivoiriennes observées.

## Résultats (millions FCFA/an)

| UP | Central | Défavorable | Favorable | Scénarios EBITDA négatif / 27 |
|---|---:|---:|---:|---:|
| Plastique PEHD/PP | 1004.1 | -150.8 | 1630.6 | 3/27 |
| Papier-carton | 447.6 | -217.7 | 801.9 | 6/27 |
| Métaux ferreux | 1227.8 | -647.7 | 2099.2 | 6/27 |
| Compost | 33.2 | -306.1 | 213.6 | 18/27 |
| Verre | 25.6 | -224.1 | 164.0 | 19/27 |
| Pneus usagés | -16.8 | -331.4 | 159.8 | 21/27 |
| Huiles usagées | 186.2 | -332.7 | 462.8 | 14/27 |
| DEEE | -83.9 | -774.3 | 225.6 | 24/27 |

## Réserves de faisabilité à lever avant tout BP final
1. **Plastique** : capacité réelle de granulation versus lavage, contrat d'approvisionnement de plusieurs milliers de tonnes et débouchés granulés, coût de traitement de l'eau.
2. **Papier-carton** : distinguer tri/pressage de fabrication de pâte ou de papier ; produits, équipements et énergie très différents.
3. **Métaux** : trier/broyer versus refondre ; ne pas assimiler leurs CAPEX et leurs consommations.
4. **Compost** : durée de maturation, surfaces, pertes de masse, analyses et débouchés agricoles.
5. **Verre** : calcin versus refusion, tri couleur et qualité.
6. **Pneus** : bilan matière séparant caoutchouc, acier et textile ; marché par fraction et conformité.
7. **Huiles** : régénération versus filtration ; autorisations, rejets et contrôle qualité.
8. **DEEE** : démontage, fractions valorisables, composants dangereux, traçabilité et marchés.

## Conditions pour le BP Découverte v107
Prix catalogues EXW/FOB datés et vérifiables, devis de transport et installation estimatifs, réseau de collecte, débouchés et prix ivoiriens documentés, CAPEX complet, masse salariale, financement 40/60, compte de résultat et bilan 3 ans, trésorerie mensuelle 12 mois, contrôles RN et trésorerie. Ne pas « corriger » artificiellement des marges défavorables.
