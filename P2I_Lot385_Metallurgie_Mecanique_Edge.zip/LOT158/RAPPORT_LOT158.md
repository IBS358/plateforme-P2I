# P2I — Lot 158 : outil de production des scénarios alternatifs

## Livrable réalisé
Création d'un atelier local de simulation financière pour les quatre UP non finalisées : smartphones, tablettes, remorques historiques 750 kg, rayonnages. Ouvrir `LOT158/ATELIER_SCENARIOS_V107.html` dans Edge après extraction de l'archive complète. L'atelier charge directement `runtime/script-11.js`, moteur financier commun v107, sans en modifier le code. Il permet de modifier prix, quantités, coûts directs, personnel, frais fixes, distribution, CAPEX et machines, de calculer les trois années, douze mois de trésorerie, 36 mois de BFR et les bilans, et d'exporter un JSON de simulation.

## Limites majeures
Il ne crée pas de prix fournisseurs ni de ventes vérifiées. Les valeurs initiales sont celles du Lot 152, y compris la remorque **750 kg**, qui n'est pas le produit 3 t étudié au Lot 154. Les changements de volumes sont extrapolés à partir des hypothèses initiales et ne prouvent pas une capacité réelle. Le moteur est conservé tel quel et aucune simulation utilisateur n'est enregistrée dans les BP actifs. Les quatre BP ne sont pas déclarés achevés.

## Contrôles
Le test `LOT158/test_lot158.cjs` vérifie les quatre scénarios historiques avec le moteur commun, les trois CR, 12 mois de trésorerie, 36 mois de BFR, trois bilans équilibrés et financement 40/60. Vérification HTML statique du branchement et des champs. Aucun test visuel Edge ou test de clic navigateur effectué.

## Conservation
Les 96 UP, 12 filières, huit UP Assemblage, 17 rubriques et les trois scénarios positifs du Lot 155 sont inchangés. GitHub main et archives historiques non modifiés.
