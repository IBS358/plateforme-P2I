'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path');
const root=__dirname,c={console,Math,Number,String,Array,Object,Map,Set,JSON,Error,TypeError,Date,Intl,URL,URLSearchParams};c.window=c;c.location={search:'?unit_id=assemblage_montage'};vm.createContext(c);
for(let n=0;n<=11;n++)vm.runInContext(fs.readFileSync(path.join(root,'runtime',`script-${n}.js`),'utf8'),c,{filename:`script-${n}.js`});
const engine=c.P2I_BP_SIMULATION_COMMUNE;if(!engine?.calculer)throw Error('Moteur v107 absent');
const fx=595, products=[{id:'table_banc',price:33000,variable:25200},{id:'bureau',price:110000,variable:71000},{id:'armoire',price:160000,variable:108000}];
const plans=[
{id:'base_70m',qs:[[1200,160,80],[2800,400,200],[4200,600,300]]},
{id:'croissance_a1',qs:[[1600,220,110],[3200,460,230],[4400,640,320]]},
{id:'forte_croissance_a1',qs:[[2000,280,140],[3600,520,260],[4800,700,350]]}
];
const out=[];
for(const plan of plans){
const yearly=plan.qs.map((qs,y)=>{const n=qs.reduce((a,b)=>a+b,0);return {annee:y+1,qs,n,ca:qs.reduce((s,q,i)=>s+q*products[i].price,0),cv:qs.reduce((s,q,i)=>s+q*products[i].variable*Math.pow(1.03,y),0)};});
for(const director of [0,300000]){
 const input={up_id:'mobilier_scolaire_CANDIDAT_NON_ACTIF',configuration_id:'test_croissance',nom:'Mobilier scolaire et professionnel — NON VALIDE',unite:'articles/an',capacite:6000,production:yearly.map(x=>x.n),ventes:yearly.map(x=>x.n),prix:yearly.map(x=>x.ca/x.n/fx),matieres_kg:yearly[0].cv/yearly[0].n/fx,matieres_kg_annuel:yearly.map(x=>x.cv/x.n/fx),cout_production_kg:yearly.map(x=>x.cv/x.n/fx),personnel:24000+director*12/fx,croissance_personnel:.08,charges_fixes:15000,croissance_charges:.05,cout_distribution_unite:2,investissement:45000,machines:30000,part_apport:.4,part_dette:.6,taux_interet:.08,duree_dette_mois:60,duree_amortissement_ans:10,taux_tva:.18,taux_is:.25,coussin_tresorerie:.1,stock_matieres_jours:30,lot_achat_matieres_equivalent_produit:1,source:'EXPLORATOIRE. Prix, coûts bureaux/armoires, CAPEX, effectifs, volumes non vérifiés. Directeur en supplément ou déjà compris.'};
try{const r=engine.calculer(input);out.push({plan:plan.id,director_extra_month_xof:director,yearly,annual:r.annuel.map(a=>({annee:a.annee,ca_usd:a.chiffre_affaires,rn_usd:a.resultat_net,marge:a.resultat_net/a.chiffre_affaires})),checks:{cash_months:r.tresorerie.length,min_cash_usd:Math.min(...r.tresorerie.map(x=>x.solde_final)),bfr_months:r.bfr.length,balance_diffs:r.bilans.map(x=>x.ecart)},controls:r.controles});}catch(e){out.push({plan:plan.id,director_extra_month_xof:director,error:String(e)});}
}}
const dir=path.join(root,'LOT227');fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'SIMULATIONS_V107.json'),JSON.stringify({statut:'NON VALIDE',fx,products,plans,results:out},null,2));
const rows=['plan,dirigeant_supplement_fcfa_mois,ca_a1_fcfa,ca_a2_fcfa,ca_a3_fcfa,rn_a1_usd,rn_a2_usd,rn_a3_usd,marge_a1,marge_a2,marge_a3,tresorerie_min_usd,mois_tresorerie,mois_bfr,ecart_bilan_max'];for(const r of out)rows.push([r.plan,r.director_extra_month_xof,...r.yearly.map(y=>y.ca),...(r.annual||[]).map(y=>y.rn_usd),...(r.annual||[]).map(y=>y.marge),r.checks?.min_cash_usd,r.checks?.cash_months,r.checks?.bfr_months,Math.max(...(r.checks?.balance_diffs||[0]).map(Math.abs))].join(','));fs.writeFileSync(path.join(dir,'SYNTHESE_V107.csv'),rows.join('\n'));
console.log(JSON.stringify(out.map(r=>({plan:r.plan,dir:r.director_extra_month_xof,ca:r.yearly.map(x=>x.ca),rn:r.annual?.map(x=>Math.round(x.rn_usd)),margin:r.annual?.map(x=>(x.marge*100).toFixed(1)+'%'),mincash:r.checks?.min_cash_usd,err:r.error})),null,2));
