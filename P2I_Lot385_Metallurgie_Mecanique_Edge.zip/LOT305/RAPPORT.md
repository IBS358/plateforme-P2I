# Lot 305 — qualification des machines et prix catalogues publics

Règle ferme : un prix catalogue public, modèle identifiable, capacité et périmètre définis. Ne pas attendre de devis officiel. Ne pas transformer une fourchette large en prix exact.

Le registre du lot 304 contient 54 postes; ce lot examine six références, concentrées sur les pneus et le verre. Aucune ligne complète nouvelle n'est acceptée : les annonces pneus sont partielles, et les machines Andela n'affichent pas de prix.

Les sources sont des annonces publiques consultées le 18 novembre 2026. Les prix peuvent changer. Les fiches d'annonces ne garantissent pas que tous les accessoires soient inclus. Les BP historiques sont conservés sans recalcul trompeur.

Prochain travail : rechercher des lignes complètes avec tarif affiché pour les six autres UP, puis consolider les postes restants.
