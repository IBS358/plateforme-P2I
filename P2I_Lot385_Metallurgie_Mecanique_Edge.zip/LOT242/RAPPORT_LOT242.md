# P2I — Lot 242 : huit dossiers industriels de qualification

Source : archive Lot 241. Huit pages HTML consultables localement dans Edge, un index et une feuille de style.

- Recyclage de plastiques rigides : 4 postes historiques, 3 références candidates.
- Valorisation du papier et du carton : 4 postes historiques, 0 références candidates.
- Préparation et valorisation des métaux : 4 postes historiques, 1 références candidates.
- Compost et amendements organiques : 5 postes historiques, 0 références candidates.
- Valorisation du verre : 4 postes historiques, 0 références candidates.
- Recyclage des pneus hors d’usage : 4 postes historiques, 3 références candidates.
- Traitement des huiles lubrifiantes usagées : 4 postes historiques, 0 références candidates.
- Valorisation des déchets électriques et électroniques : 4 postes historiques, 0 références candidates.

Aucun chiffre financier inventé; aucune configuration définitivement qualifiée. Moteur, catalogue, archives historiques et BP antérieurs non modifiés. Tests : intégrité ZIP, existence et liens relatifs, cohérence des postes. Pas de test graphique Edge.
