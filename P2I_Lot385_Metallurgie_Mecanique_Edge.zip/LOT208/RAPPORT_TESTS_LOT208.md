# Lot 208 — contrôles synthétiques

Date : 17 novembre 2026

| Contrôle | Résultat |
|---|---|
| Exécution du moteur commun | Réussie; sorties identifiées v107, calculées par `P2I_BP_SIMULATION_COMMUNE.calculer` et ré-exécutées par `run_irrigation_v107.cjs` |
| A1–A3 | Présents; nets −2 588,49 / −4 247,81 / −6 053,98 USD |
| Trésorerie | 12 mois, présente; solde minimum A1 800 USD après réserve |
| BFR | 36 périodes moteur, présente |
| Bilans | 3 présents et équilibrés; écarts absolus < 0,01 USD |
| Structure de dette et fiscalité | 40/60; taux intérêt 8 %; IS 25 %; TVA 18 %; amortissement 10 ans |
| Rubriques BP statiques | 17 identifiants `p2i-r1` à `p2i-r17` trouvés; navigation correspondante intégrée |
| Liens locaux BP/index | Vérifiés par script : index, rapport, matrice, BOM, image et dossier BP |
| Visuel local | SVG XML valide et image cible présente |
| Ouverture interactive en environnement de contrôle | Non concluante : le Chromium de l’environnement applique une politique qui bloque les URL `file://`; vérification statique des chemins locaux, des ancres et des ressources réussie. Cette restriction ne vient pas du ZIP. |
| Rejeu JavaScript du scénario actif | Réussi en VM Node avec les scripts du moteur commun v107 et le script d’intégration Lot 208 |
| Protection des sept autres dossiers | Hachages SHA-256 égaux aux références avant Lot 208; données financières historiques Lot 193 inchangées |
| Catalogue actif | Identifiant remplacé `irrigation_kits_surface`; ancien dossier/remorques conservé; index huit lignes |
| Branche GitHub | `main` non modifiée / aucun push réalisé |

## Réserve de validation

Le moteur calcule des états sous hypothèses de planification, mais les ventes ne sont pas observées, le scénario est déficitaire, la trésorerie A2/A3 devient négative et la courbe Q-H / le test du système ne sont pas disponibles. La nouvelle UP n’est donc pas annoncée comme commercialement ou techniquement validée. Détail des manquants et sources : `RAPPORT_LOT208.md`.
