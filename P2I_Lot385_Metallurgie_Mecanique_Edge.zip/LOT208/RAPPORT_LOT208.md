# P2I — Lot 208 | Assemblage & Montage — Irrigation de surface

## Résultat de la mission

Le BP actif `irrigation_kits_surface` a été complété autour d’une configuration unique de kit Laser Spray de 0,5 ha. La BOM est chiffrée, le scénario a été exécuté avec le moteur commun P2I v107 et les sorties A1–A3, la trésorerie A1, le BFR et les bilans sont intégrés dans les rubriques 09–13 du BP. Il s’agit d’une **simulation indicative déficitaire**, pas d’une validation financière, commerciale ni d’une validation technique de la pompe/réseau.

## Configuration de référence et contrôles techniques

- Parcelle de référence : 50 × 100 m (0,5 ha); 20 latérales de 50 m, entraxe nominal 5 m; 10 zones manuelles de deux latérales chacune.
- Débit nominal de dimensionnement : 175 L/h/m publié pour Laser Spray, soit 8,75 m³/h par latérale et 17,5 m³/h par secteur; pression nominale publiée 0,7 bar (≈7 mCE). Ces valeurs ne remplacent pas des mesures au champ.
- Pompe candidate : INGCO GWP202 essence, 7 HP, 208 cc, 2 pouces, maxima catalogue 550 L/min, HMT 32 m et aspiration 8 m. Les maxima ne sont pas simultanés. Le fabricant n’a pas fourni la courbe Q-H exploitable au point de travail visé; le débit de 17,5 m³/h sous environ 20–22 m HMT est donc **non vérifié**. La compatibilité hydraulique finale demeure bloquée jusqu’au test/courbe.
- Réseau : 50 m PEHD Ø63 mm PN10; 7 m d’aspiration 2 pouces; transitions pompe 2 pouces/filtre 3 pouces/conduite 63 mm, collecteur, clapet, manomètre, vannes et bouchons. Filtre à disques 3 pouces, 30 m³/h maximum, 10 bar; capacité nominale supérieure au débit de zone, pertes de charge et maille à choisir selon l’eau et les sorties.
- Conditions d’installation : source existante fournissant au moins 17,5 m³/h en saison sèche; aspiration courte, parcelle peu pentue et source à 50 m au plus. Vérifier sable/turbidité, niveau d’eau, uniformité, pression aux extrémités, débit réel, risque de marche à sec, protections, ventilation/carburant, conformité locale et notice/garantie avant mise en service.

Le point de travail de la pompe, l’uniformité, les pertes de charge (notamment filtre propre/encrassé) et la performance réelle du réseau ne sont pas certifiés. La valeur HMT de présélection inclut une marge indicative de pertes et doit être remplacée par une note de calcul et les mesures du prototype.

## BOM et coûts (prix publics et estimations séparés)

| Poste par kit | Quantité | FCFA | Qualification |
|---|---:|---:|---|
| Gaine Laser Spray Ø40 mm | 10 rouleaux de 100 m débités en 20 longueurs de 50 m | 400 000 | prix public local affiché 40 000/unité; longueur de vente à confirmer avant commande |
| Vannes/départs Ø40 mm | 20 | 60 000 | prix public local affiché 3 000/unité |
| Motopompe INGCO GWP202 | 1 | 110 000 | prix public local; courbe Q-H absente |
| PEHD Ø63 PN10 | 50 m | 112 500 | prorata prix public 225 000 FCFA/100 m |
| Flexible aspiration 2 pouces | 7 m | 42 000 | repère catalogue ancien, à repricer |
| Filtre à disques 3 pouces | 1 | 150 000 | prix public local; 30 m³/h max |
| Collecteur/manomètre/raccords/clapet/adaptateurs | 1 lot | 30 000 | estimation P2I |
| **Composants** |  | **904 500** | 1 520,17 USD au taux de planification 595 FCFA/USD |
| Assemblage/installation | 24 h équipe | 59 500 | estimation, 100 USD/unité |
| Essais, carburant et consommables | 1 provision | 11 900 | estimation, 20 USD/unité |
| Emballage et notice | 1 provision | 8 925 | estimation, 15 USD/unité |
| Provision garantie/SAV | 2 % des matières | 19 492 | estimation P2I, taux de sinistre inconnu |
| **Coût de fabrication/pose** |  | **1 004 317** | 1 687,93 USD/unité, coûts directs dans v107 |
| Transport/mise en livraison et commercial | 1 provision | 59 500 | estimation, 100 USD/unité, séparée de la fabrication |
| **Coût variable complet** |  | **1 063 817** | 1 787,93 USD/unité avant charges annuelles fixes |

Le prix public du kit DIY de 0,5 ha (530 000 FCFA) figure dans le catalogue marchand; la page d’offre plus récente ne donne pas une variante DIY de 0,5 ha détaillée, et les listes génériques divergent sur l’inclusion de la pompe. Longueur précise des gaines, contenu/accessoires et modèle de motopompe restent à établir pour le substituer à la BOM. Les prix unitaires locaux composant par composant ne sont pas cumulés avec le prix du kit DIY. Cette forte différence est un risque d’approvisionnement et une opportunité à vérifier par packing list; elle n’est pas utilisée comme remise d’achat présumée. Aucun prix FOB n’a été retenu, car les composants de la référence sont disponibles auprès de vendeurs locaux et aucun coût rendu import cohérent (transport/assurance/douane/port) n’est mieux établi.

CAPEX estimatif du moteur : 8 000 USD, dont 5 000 USD machines/outillage (banc de contrôle 2 500; coupe/outillage 1 000; établis/gabarit/rangement 800; manutention/sécurité 700), puis aménagement/site 1 800, informatique/traçabilité 700 et petit équipement 500. Il n’existe pas de prix catalogue vérifié pour le banc d’essai; ce CAPEX est une hypothèse à confirmer, pas une offre fournisseur. Charges annuelles A1 : personnel indirect 9 000 USD et charges fixes 6 000 USD; coûts directs de main-d’œuvre, essais, emballage et garantie inclus une seule fois dans le coût unitaire.

## Marché et hypothèses v107

Le recensement agricole 2024 indique que 3,0 % des parcelles sont équipées d’infrastructures d’irrigation; ce constat démontre une faible couverture, mais ne donne pas le nombre d’acheteurs solvables ou de ventes potentielles. Green Agro Valley publie 1 400 000 FCFA pour le kit standard 0,5 ha comprenant gaines, départs, tuyauterie PVC, motopompe et installation, avec une source d’eau à 50 m. Ce prix public sert de comparateur et de base de planification; il ne s’agit ni d’une transaction vérifiée ni d’un prix net P2I.

Le plan retient 24 kits/an (deux installations mensuelles) avec capacité d’équipe estimée à 48/an (quatre/mois). Ce rythme est un scénario de planification, pas une prévision commerciale validée ni un carnet de commandes. Le prix est constant à 1 400 000 FCFA A1–A3; les ventes sont constantes; matières +3 %/an, personnel +4 %, charges fixes +3 %. Taux de conversion : 595 FCFA/USD. Financement : 40 % apport et 60 % dette sur CAPEX, 8 % sur 60 mois; réserve de trésorerie initiale déterminée par le moteur et financée en apport; amortissement 10 ans; TVA 18 %, IS 25 %.

## Résultats effectivement calculés par v107

| USD | A1 | A2 | A3 |
|---|---:|---:|---:|
| CA | 56 470,59 | 56 470,59 | 56 470,59 |
| Coût des produits vendus | 40 510,27 | 41 634,39 | 42 883,40 |
| Personnel indirect | 9 000,00 | 9 360,00 | 9 734,40 |
| Charges fixes + distribution | 8 400,00 | 8 652,00 | 8 911,56 |
| Amortissements | 800,00 | 800,00 | 800,00 |
| Intérêts | 348,80 | 272,00 | 195,20 |
| Impôt sur bénéfice | 0,00 | 0,00 | 0,00 |
| **Résultat net** | **−2 588,49** | **−4 247,81** | **−6 053,98** |
| **Marge nette** | **−4,58 %** | **−7,52 %** | **−10,72 %** |

La marge contributive est d’environ 565,01 USD/kit avant coûts fixes, amortissements et intérêts; le seuil simple de rentabilité A1 est d’environ 29 kits, au-dessus des 24 kits du plan et sans demande démontrée à ce volume. Aucune augmentation artificielle du prix ou de la demande n’a été appliquée. Le déficit progresse parce que le tarif et les ventes sont constants alors que les coûts augmentent.

- Trésorerie v107 : 12 mois affichés dans la rubrique 13; solde final mensuel minimum A1 800 USD après la réserve initiale de 9 620,79 USD.
- BFR v107 : 36 mois, stock matière 30 jours, 40 % encaissement comptant et 60 % à 30 jours, crédit fournisseur 0 faute de terme établi; maximum repris dans le BP à partir de la sortie moteur.
- Bilans A1–A3 équilibrés par v107 avec écarts numériques inférieurs à 0,01 USD. Banque : +800,00 USD A1, −3 715,41 USD A2, −10 040,24 USD A3. La trésorerie déficitaire A2/A3 révèle le besoin de financement si le scénario n’est pas amélioré.
- Financement du CAPEX : apport 3 200 USD, dette 4 800 USD; apport total incluant la réserve initiale 12 820,79 USD.

Les bilans équilibrés et états moteur ne démontrent pas la solvabilité ou le caractère bancable. Le résultat négatif est la conclusion du scénario de référence, et non un statut de validation.

## Données restantes empêchant la validation

1. Courbe Q-H constructeur du GWP202, ou pompe de remplacement documentée, confirmant le point 17,5 m³/h @ HMT calculée; pression aux extrémités et débit saison sèche de la source.
2. Longueur/dimension des gaines Laser Spray vendues par unité, quantité et packing list exacte du kit groupé, modèle de pompe inclus, filtre et raccords inclus/exclus.
3. Devis public actuel actualisé pour le flexible d’aspiration et prix quantitatifs/remises; choix et prix d’un banc de test spécifié.
4. Essai réel d’installation sur parcelle représentative, pertes de charge et uniformité; temps de chantier, garantie/SAV et retours.
5. Données de commandes/ventes et validation des 24 unités/an; prix concurrents détaillés par inclusions, zone et installation; acompte et modalités clients/fournisseurs.
6. Confirmation des charges de site/personnel et du budget de démarrage; scénario A2/A3 à trésorerie négative nécessite financement additionnel ou amélioration industrielle validée.

## Préservation plateforme

Le remplacement actif garde l’identifiant `irrigation_kits_surface` et les 96 UP, archive l’ancienne UP Remorques agricoles, conserve les 17 rubriques, et s’intègre à l’index commun. Les sept autres dossiers BP et le fichier historique des scénarios v107 n’ont pas été modifiés. La branche GitHub `main` n’a pas été modifiée.

## Sources publiques consultées le 17 novembre 2026

- Ministère de l’Agriculture, recensement/MC-REEA 2024 — [3,0 % des parcelles équipées](https://www.agriculture.gouv.ci/uploads/publications/177556586029.pdf).
- Green Agro Valley CI — [tarifs Laser Spray](https://greenagrovalley.org/offre-laser-spray.html), standard 0,5 ha à 1 400 000 FCFA, DIY indiqué par tailles; [références boutique de composants](https://greenagrovalley.org/boutique-article.html?id=8) comprenant gaines Laser Spray à 40 000 FCFA, vannes Ø40 à 3 000 FCFA et motopompes.
- INGCO — [fiche constructeur GWP202](https://www.ingco.com/fr/product/gasoline-water-pump/GWP202); prix local affiché par [Ivoirelite](https://ivoirelite.net/categories/4349-motopompe-a-essence-2-50-mm-7-cv-550-lmin-hmt-32-m.html) à 110 000 FCFA.
- CI Irrigation — [catalogue public](https://www.ci-irrigation.com/boutique), PEHD Ø63, filtre à disques 3 pouces / 30 m³/h à 150 000 FCFA; les tarifs sont indicatifs et dégressifs.
- 2iE — [notice du mémoire Laser Spray](https://documentation.2ie-edu.org/cdi2ie/opac_css/index.php?id=30929&amp;lvl=notice_display), référence de contexte sur les paramètres techniques et besoin de caractérisation.
- Catalogue/annonces Green Agro Valley précédents — [détails historiques](https://annonces.abidjan.net/achat-vente/8209/details/systeme-d-irrigation-laser-spray), utilisés seulement comme repères historiques.
