# P2I — Audit complémentaire du Lot 208 (cœur technique)

**Base :** `P2I_Edge_Lot208_Part_1_Core.zip`, archive partielle transmise par l'utilisateur. Les archives visuelles Part 2 à Part 5 ne sont pas incluses.

## Exécution réelle du moteur v107

Le script `LOT208/audit_sensibilite_v107.cjs` charge les 12 scripts de `runtime`, reprend exactement les paramètres du `SCENARIO_V107_IRRIGATION.json` et recalcule les volumes 24, 29, 30, 36 et 48 installations par an. **Les paramètres unitaires et financiers du scénario de référence sont inchangés.** Le scénario de 24 installations est reproduit à l'arrondi près.

| Installations/an | RN A1 (USD) | Marge A1 | RN A2 (USD) | RN A3 (USD) |
|---:|---:|---:|---:|---:|
| 24 | -2 588,49 | -4,58 % | -4 247,81 | -6 053,98 |
| 29 | +177,44 | +0,26 % | -1 645,34 | -3 726,36 |
| 30 | +601,19 | +0,85 % | -1 133,96 | -3 270,23 |
| 36 | +3 143,75 | +3,71 % | +1 450,72 | -533,46 |
| 48 | +8 228,87 | +7,29 % | +6 087,29 | +3 740,29 |

**Interprétation :** la rentabilité sur trois ans n'est obtenue dans cette grille qu'à 48 installations/an, capacité d'équipe *estimée* du BP. Ce n'est pas une prévision de ventes. Aucune hausse de prix, remise fournisseur ou commande fictive n'a été introduite. La conformité hydraulique et la réalité commerciale ne sont pas démontrées. Ne pas substituer ces sensibilités à la référence 24/an.

## Tests et conservation

- L'archive source est lisible (`unzip -t`).
- 367 entrées d'origine contrôlées : **aucun fichier original modifié** (comparaison SHA-256 de chaque entrée).
- Pour les cinq simulations de volume : bilans A1–A3 équilibrés à l'arrondi de calcul; moteur v107 exécuté et sorties sauvegardées dans le JSON de sensibilités.
- Un test historique `LOT207/test_lot207.cjs` échoue sur l'attente du texte « Non calculable » dans l'index : cette assertion est **obsolète depuis le calcul du Lot 208**. Ce n'est pas une preuve de panne du moteur ; le test doit être actualisé si on l'intègre à la suite de tests de régression.
- Les parties visuelles 2 à 5 n'étant pas fournies, **aucune complétude visuelle ni affichage Edge n'est certifié**.

## Décision de production recommandée

Conserver le BP Irrigation calculé, avec son déficit et ses réserves, sans bloquer les autres UP. Les données à chercher en priorité sont la courbe Q-H et la nomenclature réelle du kit groupé, puis des éléments commerciaux attestant le volume. Poursuivre la production des autres BP à partir du moteur existant, sans forcer un résultat positif.
