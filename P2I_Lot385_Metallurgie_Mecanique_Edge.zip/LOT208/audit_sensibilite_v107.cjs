'use strict';
// Lot 209 — analyses de sensibilite, sans modifier la configuration de reference.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.resolve(__dirname,'..');
const c={console,Math,Number,String,Array,Object,Map,Set,JSON,Error,TypeError,Date,Intl,URL,URLSearchParams};c.window=c;c.location={search:'?unit_id=assemblage_montage'};vm.createContext(c);
for(let n=0;n<=11;n++){const f=`script-${n}.js`;vm.runInContext(fs.readFileSync(path.join(root,'runtime',f),'utf8'),c,{filename:f});}
const engine=c.P2I_BP_SIMULATION_COMMUNE;
if(!engine?.calculer)throw Error('Moteur v107 indisponible');
const reference=JSON.parse(fs.readFileSync(path.join(__dirname,'SCENARIO_V107_IRRIGATION.json'),'utf8'));
const rows=[];
for(const volume of [24,29,30,36,48]){
  const input=JSON.parse(JSON.stringify(reference.input));input.production=[volume,volume,volume];input.ventes=[volume,volume,volume];
  const result=engine.calculer(input);
  rows.push({volume,prix_unitaire_fcfa:1400000,statut:'sensibilite_non_validee',annees:result.annuel.map(a=>({annee:a.annee,ca_usd:+a.chiffre_affaires.toFixed(2),resultat_net_usd:+a.resultat_net.toFixed(2),marge_nette_pct:+(100*a.resultat_net/a.chiffre_affaires).toFixed(2)})),bilans_ecarts:result.bilans.map(b=>+b.ecart.toFixed(6)),tresorerie_mois:result.tresorerie.length,bfr_mois:result.bfr.length});
}
const out={description:'Sensibilites de volume a prix, couts unitaires et charges fixes constants selon les parametres du Lot 208. Ne prouvent aucune demande, aucune faisabilite hydraulique, ni aucun resultat garanti.',moteur:'v107 reel',reference_volume:24,reference_inchangee:true,scenarios:rows};
fs.writeFileSync(path.join(__dirname,'SENSIBILITES_VOLUME_V107_NON_VALIDEES.json'),JSON.stringify(out,null,2));
console.log(JSON.stringify(rows.map(r=>({volume:r.volume,net_a1:r.annees[0].resultat_net_usd,net_a2:r.annees[1].resultat_net_usd,net_a3:r.annees[2].resultat_net_usd,margin_a1:r.annees[0].marge_nette_pct})),null,2));
