'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path');
const root=__dirname,c={console,Math,Number,String,Array,Object,Map,Set,JSON,Error,TypeError,Date,Intl,URL,URLSearchParams};c.window=c;c.location={search:'?unit_id=assemblage_montage'};vm.createContext(c);
for(let n=0;n<=11;n++)vm.runInContext(fs.readFileSync(path.join(root,'runtime',`script-${n}.js`),'utf8'),c,{filename:`script-${n}.js`});
const engine=c.P2I_BP_SIMULATION_COMMUNE;if(!engine?.calculer)throw Error('Moteur v107 absent');
const fx=595;
// Valeurs de travail hypothétiques : seul le couple 33k/18.2k pour la table-banc vient des lots précédents, avec réserves.
const products=[
 {id:'table_banc',label:'Table-banc scolaire biplace',price:33000,variable:25200,source:'Prix 33k historique non comparable; 18.2k matières conditionnelles + 7k autres hypothétiques'},
 {id:'bureau',label:'Bureau professionnel simple',price:110000,variable:71000,source:'Prix et coûts entièrement hypothétiques : sensibilité, non catalogue'},
 {id:'armoire',label:'Armoire métallique professionnelle',price:160000,variable:108000,source:'Prix et coûts entièrement hypothétiques : sensibilité, non catalogue'}
];
const plans=[
 {id:'progressif',label:'Montée progressive',quantities:[[600,80,40],[1400,180,90],[2100,280,140]]},
 {id:'ambitieux',label:'Montée A2 forte',quantities:[[800,100,50],[2400,300,150],[3600,480,240]]},
 {id:'prudent',label:'Montée prudente',quantities:[[400,40,20],[850,100,50],[1300,150,75]]}
];
const scenarios=[];
for(const plan of plans)for(const factor of [0.9,1,1.1]){
 const yearly=plan.quantities.map((qs,y)=>{
  const sales=qs.reduce((a,b)=>a+b,0);
  const revenue=qs.reduce((s,q,i)=>s+q*products[i].price*factor,0);
  const variable=qs.reduce((s,q,i)=>s+q*products[i].variable*Math.pow(1.03,y),0);
  return {year:y+1,quantities:qs,sales,revenue_xof:revenue,variable_xof:variable,avg_price_usd:revenue/sales/fx,avg_variable_usd:variable/sales/fx};
 });
 const input={up_id:'mobilier_scolaire_CANDIDAT_NON_ACTIF',configuration_id:'test_de_contrainte',nom:'Mobilier scolaire et professionnel — TEST NON VALIDE',unite:'articles/an',capacite:5500,production:yearly.map(x=>x.sales),ventes:yearly.map(x=>x.sales),prix:yearly.map(x=>x.avg_price_usd),matieres_kg:yearly[0].avg_variable_usd,matieres_kg_annuel:yearly.map(x=>x.avg_variable_usd),cout_production_kg:yearly.map(x=>x.avg_variable_usd),personnel:24000,croissance_personnel:.08,charges_fixes:15000,croissance_charges:.05,cout_distribution_unite:2,investissement:45000,machines:30000,part_apport:.4,part_dette:.6,taux_interet:.08,duree_dette_mois:60,duree_amortissement_ans:10,taux_tva:.18,taux_is:.25,coussin_tresorerie:.1,stock_matieres_jours:30,lot_achat_matieres_equivalent_produit:1,source:'STRESS TEST NON VALIDÉ : bureau/armoire sans prix vérifiés, volumes sans commandes, personnel 24k USD, charges fixes 15k USD, CAPEX 45k USD entièrement hypothétiques.'};
 try {const r=engine.calculer(input);scenarios.push({plan:plan.id,price_factor:factor,yearly,annual:r.annuel.map(a=>({year:a.annee,ca_usd:a.chiffre_affaires,net_usd:a.resultat_net,net_margin:a.resultat_net/a.chiffre_affaires})),cash_months:r.tresorerie.length,min_cash_usd:Math.min(...r.tresorerie.map(x=>x.solde_final)),bfr_months:r.bfr.length,balance_diffs:r.bilans.map(x=>x.ecart),controls:r.controles});}catch(e){scenarios.push({plan:plan.id,price_factor:factor,error:String(e)});}
}
const out={status:'EXPLORATOIRE NON VALIDÉ — NE PAS PUBLIER COMME BP',fx,products,plans,assumptions:{personnel_usd_a1:24000,charges_fixes_usd_a1:15000,capex_usd:45000,machines_usd:30000,personnel_growth:.08,charges_growth:.05,variable_growth:.03,price_factors:[.9,1,1.1],financing:'40/60'},scenarios};
const dir=path.join(root,'LOT217');fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'SIMULATIONS_MULTIGAMME_V107_NON_VALIDEES.json'),JSON.stringify(out,null,2));
const rows=['plan,facteur_prix,ventes_a1,ventes_a2,ventes_a3,ca_a1_usd,ca_a2_usd,ca_a3_usd,rn_a1_usd,rn_a2_usd,rn_a3_usd,marge_a1,marge_a2,marge_a3,tresorerie_min_usd,mois_tresorerie,mois_bfr,ecart_bilan_max'];
for(const s of scenarios)rows.push([s.plan,s.price_factor,...(s.yearly||[]).map(x=>x.sales),...(s.annual||[]).map(x=>x.ca_usd),...(s.annual||[]).map(x=>x.net_usd),...(s.annual||[]).map(x=>x.net_margin),s.min_cash_usd,s.cash_months,s.bfr_months,Math.max(...(s.balance_diffs||[0]).map(Math.abs))].join(','));
fs.writeFileSync(path.join(dir,'SYNTHESE_MULTIGAMME_V107_NON_VALIDEE.csv'),rows.join('\n'));
console.log(JSON.stringify(scenarios.map(s=>({plan:s.plan,factor:s.price_factor,nets:s.annual?.map(x=>Math.round(x.net_usd)),err:s.error})),null,2));
