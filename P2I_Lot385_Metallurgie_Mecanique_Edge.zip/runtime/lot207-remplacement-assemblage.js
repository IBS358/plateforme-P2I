/* Lot 207 replacement retained; Lot 208 completes the irrigation configuration and finance overlay. */
(()=>{'use strict';
 const w=window,base=w.P2I_BP_DONNEES,up=typeof P2I_UP_DATA!=='undefined'?P2I_UP_DATA:null;
 if(!base?.unites||!up) throw Error('Lot 207: référentiel P2I absent');
 const id='irrigation_kits_surface',name='Assemblage d’ensembles de pompage et d’irrigation de surface';
 if(base.unites[id]||up[id]) throw Error('Lot 207: identifiant déjà utilisé '+id);
 const clone=x=>JSON.parse(JSON.stringify(x));
 const source=base.unites.forage,sourceUp=up.forage;
 if(!source||!sourceUp) throw Error('Lot 207: source eau/forage introuvable pour le clonage sans mutation');
 const products=[{nom:'Kit Laser Spray de surface pour 0,5 ha avec motopompe essence INGCO GWP202 2 pouces, filtre et installation locale',qualification:'Configuration Lot 208; v107 calculé indicatif, débit-point Q-H et performances à valider sur prototype.'}];
 const process=['Relevé de la ressource en eau, de la culture et de la parcelle','Contrôle réception des pompes et composants du réseau','Préparation des collecteurs et longueurs de conduite','Montage pompe, filtration, régulation et raccords','Test d’étanchéité, pression et débit','Kitting, traçabilité, notice et emballage','Installation, mise en service et formation'];
 const machines=[
  {nom:'Établi de préparation et gabarit de collecteur',role:'Assemblage local et préparation des dérivations',capacite_texte:'À dimensionner par équipe et gamme',utilites_texte:'Éclairage / outillage manuel',fabricant:null,modele:null,prix_fournisseur_verifie_usd:null,qualification:'besoin fonctionnel, modèle et prix non documentés'},
  {nom:'Coupe-tube PE, poinçon et outillage de raccordement',role:'Coupe et préparation du réseau',capacite_texte:'À mesurer par chronométrage',utilites_texte:'Manuel',fabricant:'CI Irrigation (outil local listé)',modele:'Poinçon Ø16; référence à confirmer',prix_fournisseur_verifie_usd:null,qualification:'prix local public 6 000 FCFA pour le poinçon; coût USD et gamme d’outils incomplets'},
  {nom:'Banc d’essai pression/débit et manomètres',role:'Test étanchéité et mise en service de la pompe/réseau',capacite_texte:'À définir après gamme et pression nominale',utilites_texte:'Eau / alimentation selon instrument',fabricant:null,modele:null,prix_fournisseur_verifie_usd:null,qualification:'prix, modèle et capacité non documentés; blocage de CAPEX'},
  {nom:'Instruments de mesure et sécurité carburant',role:'Contrôle pompe diesel, débit, pression et essais sûrs',capacite_texte:'À établir selon pompe retenue',utilites_texte:'Électricité / ventilation / rétention',fabricant:null,modele:null,prix_fournisseur_verifie_usd:null,qualification:'référence et coût non documentés'},
  {nom:'Motopompe essence INGCO GWP202 2 pouces — produit incorporé au kit',role:'Pompage depuis une source existante; pompe achetée complète, non fabriquée localement',capacite_texte:'7 HP/208 cc; max 550 L/min et max HMT 32 m; point de service non établi',utilites_texte:'Essence / eau',fabricant:'INGCO',modele:'GWP202',prix_fournisseur_verifie_usd:null,qualification:'prix public local indicatif 110 000 FCFA; courbe Q-H au point de service absente'}
 ];
 const d=clone(source);
 d.up_id=id;d.nom=name;d.filiere_id='assemblage';d.filiere_nom='Assemblage & Montage';d.type_activite='assemblage';
 d.variantes={reference:{configuration_id:'reference',nom:'Kit Laser Spray 0,5 ha — INGCO GWP202 2 pouces, filtre à disques, conduites et installation',qualification:'simulation_v107_indicative_deficitaire_non_validee',reference:null,visuels:{qualification:'Schéma vectoriel de principe joint au BP; non contractuel.'}},autres_variantes:'hors_calcul'};
 d.produits=products;d.processus=process;d.machines=machines;
 d.redaction={...(d.redaction||{}),projet:name,positionnement:products[0].nom,procede:process.join(' → '),marche:'Besoin d’irrigation agricole documenté; la statistique 2024 sur les parcelles équipées ne constitue pas un volume de commandes.',commercial:'Référence locale standard installée affichée à 1 400 000 FCFA/0,5 ha; scénario aligné sur ce tarif, 24/an hypothétiques, ventes non observées.',approvisionnement:'Composants acquis au détail local; BOM chiffrée dans LOT208, estimations de conversion distinctes. Aucun prix FOB étranger ajouté aux prix rendus locaux.',risques:'Courbe Q-H, essai de parcelle, packing list du kit groupé, achat en volume, ventes, temps d’installation, garantie et coût réel du banc de test restent à confirmer.'};
 d.economie={qualification:'non_calculable_donnees_commerciales_et_bom_manquantes',budget_minimum_historique:{valeur:null,unite:'USD',qualification:'a_documenter'},ca_annuel_historique:{valeur:null,unite:'USD',qualification:'a_documenter'},fourchette_ca_historique:null,production:[null,null,null],ventes:[null,null,null],prix_vente_usd:[null,null,null],couts_directs_usd:[null,null,null],charges_exploitation_usd:[null,null,null],capex_consolide_usd:null,financement:{apport:0.4,dette:0.6,qualification:'règle de référence; aucun montant calculé faute de CAPEX retenu'},aucune_repartition_fictive_des_charges:true};
 d.statut='lot208_v107_calcule_indicatif_deficitaire';d.economy_status='scenario_v107_deficitaire_non_valide';
 d.sources_documentaires=[
  'https://www.agriculture.gouv.ci/uploads/publications/177556586029.pdf',
  'https://web.agriculture.gouv.ci/index.php/actualite/128',
  'https://forage-express-ci.lovable.app/blog-sur-les-forages-en-cote-d-ivoire/prix-kit-irrigation-cote-ivoire',
  'https://www.ci-irrigation.com/boutique',
  'https://sunrisingmachinery.en.made-in-china.com/product-group/tocTUmpHIDWi/Diesel-Engine-Pump-1.html'
 ].map(url=>({url,qualification:'source publique consultée; base de prix/périmètre explicités dans BP et note de choix'}));
 d.manquants=[
  'Plan quantitatif d’un kit normalisé et dimensionnement pompe/pertes de charge',
  'Appariement exact du modèle, de la courbe de pompe et du prix FOB',
  'Coûts rendus Abidjan des composants et accessoires avec quantités',
  'Modèles, prix et capacité du banc pression/débit et de l’outillage d’assemblage',
  'Temps de gamme, personnel, charges, garantie, transport et installation',
  'Prix net P2I comparable et preuve de commandes/volumes vendables par an',
  'Bilan d’ouverture, CAPEX, échéancier de dette, délais fournisseurs et clients pour v107'
 ];
 d.sources=[{fichier:'LOT207/CHOIX_NOUVELLE_UP.md',champ:'comparaison des options et références web',qualification:'recherche documentaire; offre n’est pas transaction observée'}];
 base.unites[id]=d;
 up[id]={...clone(sourceUp),id,nom:name,filiereNom:'Assemblage & Montage',description:products[0].nom,estimated_revenue:null,chiffre_affaires_estime:null,gross_margin:null,marge_brute:null,capex_min:null,processus:process,target_markets:['Maraîchers et pépinières','Coopératives et exploitations de petite surface','Distributeurs agricoles et centres de services agricoles'],machines:machines.map(m=>({name:m.nom,role:m.role,capacity:m.capacite_texte,manufacturer:m.fabricant,model:m.modele,price_usd:m.prix_fournisseur_verifie_usd,qualification:m.qualification}))};
 const f=(base.filieres||[]).find(x=>x.id==='assemblage');if(!f)throw Error('Lot 207: filière assemblage absente');
 f.up_ids=['smartphones','machines_conditionnement_pme','cuisines_pro_chambres_froides','tricycles_utilitaires','velos','equipements',id,'stockage_manutention'];
 const active=f.up_ids;
 base.migrations_identifiants={...(base.migrations_identifiants||{}),lot207:{replace:'remorques_agricoles',with:id,history_preserved:true,active_ids:active,financial_status:'lot208_v107_indicative_deficit_no_market_or_hydraulic_validation'}};
 w.P2I_LOT207_REPLACEMENT=Object.freeze({id,name,status:'v107_indicative_deficit_lot208',active_ids:[...active],historical_trailer_preserved:true});
})();
