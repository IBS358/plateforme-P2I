/* P2I Lot167 : synchronisation de l'alerte avec la navigation SPA.
   Ne change ni les données industrielles ni les résultats financiers. */
(()=>{'use strict';
const statuses=Object.freeze({
 smartphones:'Ancien modèle rejeté ; reconditionnement et maintenance B2B non encore chiffrés',
 machines_conditionnement_pme:'Résultat v107 positif sous hypothèses; ventes, prix local et validation technique à établir',
 remorques_agricoles:'Identifiant historique archivé; l’ancienne configuration de remorque n’est plus une UP active',
 irrigation_kits_surface:'Scénario v107 indicatif Lot 208 exécuté; résultats A1–A3 déficitaires, technique et marché à confirmer',
 stockage_manutention:'Ancien rayonnage léger rejeté ; stockage industriel B2B non encore chiffré'
});
const names=Object.keys(statuses);
const keys=['unit_id','up_id','id','up'];
let previous='';
function current(){
 const q=new URLSearchParams(location.search);
 for(const key of keys){const value=q.get(key);if(Object.prototype.hasOwnProperty.call(statuses,value))return value;}
 // Aucune déduction à partir d'un libellé libre : risque de faux positif.
 return '';
}
function update(){
 if(!document.body)return;
 const id=current();
 const existing=document.getElementById('p2i-lot167-warning');
 if(!id){if(existing)existing.remove();previous='';return;}
 if(id===previous&&existing)return;
 const node=existing||document.createElement('aside');
 node.id='p2i-lot167-warning';
 node.setAttribute('role','alert');
 node.setAttribute('aria-live','polite');
 node.style.cssText='position:sticky;top:0;z-index:2147483001;background:#fff3dc;color:#432b06;border:3px solid #b66c00;padding:14px 20px;font:600 16px/1.5 system-ui,sans-serif;box-shadow:0 2px 9px #0002';
 node.textContent=id==='irrigation_kits_surface'?'P2I — SIMULATION V107 INDICATIVE DÉFICITAIRE : '+statuses[id]+'. La configuration hydraulique et les hypothèses de marché doivent être confirmées.':'P2I — BP DÉCOUVERTE NON VALIDÉ : '+statuses[id]+'. Les résultats affichés sont indicatifs et soumis aux hypothèses et réserves documentées dans le BP.';
 if(!existing)document.body.prepend(node);
 previous=id;
}
// Les contrôles internes utilisent history.replaceState : popstate ne se déclenche pas.
for(const method of ['pushState','replaceState']){
 const original=history[method];
 if(typeof original!=='function')continue;
 history[method]=function(...args){const result=original.apply(this,args);update();return result;};
}
window.addEventListener('popstate',update);
window.addEventListener('hashchange',update);
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',update,{once:true});else update();
window.P2I_LOT167_SELECTION_GUARD=Object.freeze({version:'167',blocked:names,refresh:update});
})();
