/* Diagnostic commun des anomalies économiques — n'altère jamais les entrées
   ni les résultats du moteur. Les seuils déclenchent une revue, pas un plafond. */
(function(root){'use strict';
 function inspect(input,result){
  if(!input||!result||!Array.isArray(result.annuel)||!result.annuel[0])return [];
  const a=result.annuel[0],reasons=[],warnings=[];
  const ca=Number(a.chiffre_affaires),rn=Number(a.resultat_net),margin=ca>0?rn/ca:null;
  const source=String(input.source||'');
  const qualification=String(input.qualification||'')+' '+String(input.statut_exploitation||'');
  const unverified=/hypoth|indicatif|non.v[eé]rifi|a.valider|a.documenter|P2I/i.test(source+' '+qualification);
  const hasPriceSource=Boolean(input.prix_vente_source||input.sources_prix_vente||input.prix_source_documentee===true);
  const hasVolumeEvidence=Boolean(input.commandes_confirmees||input.sources_volumes||input.volume_commercial_documente===true);
  const selling=Number(input.prix?.[0]),unitCost=Number(input.cout_production_kg?.[0]);
  const materials=Number(input.matieres_kg);
  if(margin!==null&&margin>.20){
   if(unverified||!hasPriceSource)reasons.push('prix de vente non corroboré par une source commerciale ou un prix net départ usine');
   if(!hasVolumeEvidence)reasons.push('volumes vendables issus d’un programme P2I, sans commandes ou preuve de débouché');
   if(Number.isFinite(selling)&&Number.isFinite(unitCost)&&unitCost/selling<.5)reasons.push('coût de production modélisé inférieur à la moitié du prix; vérifier nomenclature, emballage, distribution et frais commerciaux');
   if(!Number.isFinite(materials)||materials<=0)reasons.push('coût matière unitaire non exploitable');
   warnings.push('Marge nette A1 supérieure à 20 % : revue économique requise, seuil indicatif sans plafond universel.');
  }
  if(margin!==null&&margin<.05){
   const loss=margin<0;
   if(Number.isFinite(selling)&&Number.isFinite(unitCost)&&unitCost>=selling)reasons.push('coût de production unitaire supérieur ou égal au prix de vente');
   if(Array.isArray(input.production)&&Array.isArray(input.ventes)&&input.ventes[0]<input.production[0])reasons.push('production non vendue/invendus à rapprocher des charges fixes et du BFR');
   if(!hasPriceSource)reasons.push('prix de vente non documenté au niveau net du canal commercial');
   if(!Number.isFinite(materials)||materials<=0)reasons.push('nomenclature matière ou coût unitaire à compléter');
   warnings.push(loss?'Résultat net A1 négatif : scénario à redresser ou à requalifier.':'Marge nette A1 inférieure à 5 % : forte sensibilité aux hypothèses et aux charges.');
  }
  if(Number.isFinite(selling)&&Number.isFinite(unitCost)&&unitCost>=selling){
   if(!warnings.some(x=>x.includes('coût de production unitaire')))warnings.push('Coût unitaire au niveau ou au-dessus du prix net : marge de contribution absente ou négative.');
   if(!reasons.some(x=>x.includes('coût de production unitaire')))reasons.push('coût unitaire de production supérieur ou égal au prix net retenu');
  } else if(Number.isFinite(selling)&&Number.isFinite(unitCost)&&selling>0&&unitCost/selling>=.85){
   warnings.push('Marge de contribution unitaire inférieure à 15 % avant charges fixes, amortissements, intérêts et impôts.');
   reasons.push('marge de contribution étroite; les charges fixes et le financement peuvent faire basculer le résultat');
  }
  if(Array.isArray(input.production)&&Array.isArray(input.ventes)&&input.ventes[0]>input.production[0]){
   warnings.push('Ventes A1 supérieures à la production A1 : cohérence des stocks et des flux à vérifier.');
   reasons.push('ventes financées par un stock initial non précisé ou volumes incohérents');
  }
  const cap=Number(input.capacite),prod=Number(input.production?.[0]);
  if(cap>0&&prod>cap*6000) { warnings.push('Programme A1 supérieur à 6 000 heures équivalentes de capacité nominale.'); reasons.push('régime de travail, arrêts, rendements et capacité effective à documenter'); }
  if(!warnings.length)return [];
  return [{severity:margin<0?'high':'review',margin_a1:margin,unverified,price_documented:hasPriceSource,volume_documented:hasVolumeEvidence,warnings,reasons}];
 }
 root.P2I_ECONOMIC_ANOMALY_GUARD=Object.freeze({inspect,version:'1.0.0'});
})(typeof window!=='undefined'?window:globalThis);
