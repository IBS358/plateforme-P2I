/* Lot166 — garde-fou visuel des simulations non validées. Aucun chiffre n'est modifié. */
(()=>{'use strict';
const blocked={
 smartphones:'Reconditionnement multimarque et maintenance B2B',
 machines_conditionnement_pme:'Machine semi-automatique de conditionnement; validation commerciale et technique en attente',
 remorques_agricoles:'Remorques agricoles et utilitaires spécialisées',
 stockage_manutention:'Stockage industriel B2B avec installation'
};
const keys=['unit_id','up_id','unit','up'];
function activeId(){const p=new URLSearchParams(location.search);for(const k of keys){const v=p.get(k);if(v&&blocked[v])return v;}return null;}
function render(){
 const id=activeId();let el=document.getElementById('p2i-lot166-warning');
 if(!id){if(el)el.remove();return;}
 if(!el){el=document.createElement('aside');el.id='p2i-lot166-warning';el.setAttribute('role','status');el.style.cssText='position:sticky;top:0;z-index:2147483000;background:#fff3dc;color:#432b06;border:3px solid #b66c00;padding:14px 20px;font:600 16px/1.5 system-ui,sans-serif;box-shadow:0 2px 9px #0002';document.body.prepend(el);}
 el.textContent='P2I — CONFIGURATION NON VALIDÉE : '+blocked[id]+'. Les chiffres affichés correspondent à une ancienne simulation historique rejetée ; ils ne constituent pas un BP Découverte validé. Aucune rentabilité de la nouvelle configuration n’a été calculée.';
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',render,{once:true});else render();
window.addEventListener('popstate',render);
window.P2I_LOT166_GARDE_FOU={blocked:Object.keys(blocked),version:'166'};
})();
