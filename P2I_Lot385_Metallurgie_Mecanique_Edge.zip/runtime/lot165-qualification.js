/* Lot165 — garde-fou de qualification; ne remplace pas les données financières. */
(()=>{'use strict';
const units=window.P2I_BP_DONNEES?.unites;if(!units)throw Error('Lot165: registre indisponible');
const decisions={"smartphones": ["Reconditionnement multimarque et maintenance B2B", "Configuration économique historique rejetée ; nomenclature, prix des prestations et charge atelier à établir."], "machines_conditionnement_pme": ["Petites machines de conditionnement pour PME", "Doseuse semi-automatique poudres sèches et thermoscellage; résultat v107 positif sous hypothèses, sans validation des ventes."], "remorques_agricoles": ["Remorques agricoles et utilitaires spécialisées", "Ancienne remorque 750 kg rejetée ; nouveau modèle sans BOM complète ni prix net local documenté."], "stockage_manutention": ["Stockage industriel B2B et installation", "Ancien rayonnage léger rejeté ; coûts de fabrication, pose et prix clients non démontrés."]};
for(const [id,decision] of Object.entries(decisions)){
 const d=units[id];if(!d)throw Error('Lot165: UP absente '+id);
 d.lot165={status:'ancienne_configuration_rejetee_nouveau_bp_non_calcule',orientation:decision[0],motif:decision[1],engine:'v107_non_execute_sur_nouvelle_configuration'};
 d.redaction={...(d.redaction||{}),qualification:(d.redaction?.qualification||'')+' AVERTISSEMENT LOT165 : '+decision[1]+' Les chiffres historiques, s’ils apparaissent, ne décrivent pas le nouveau projet.',economie:(d.redaction?.economie||'')+' AVERTISSEMENT LOT165 : simulation historique uniquement; ne pas interpréter comme rentabilité de la nouvelle configuration.'};
}
window.P2I_LOT165_QUALIFICATION={schema:'p2i.lot165.qualification.v1',status:'non_calcule',units:decisions};
})();
