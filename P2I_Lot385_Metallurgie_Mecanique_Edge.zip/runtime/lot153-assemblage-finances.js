/* Lot 153 — targeted economic re-evaluation; keeps Lot 152 immutable in the archive. */
(()=>{'use strict';
 const w=window, prior=w.P2I_LOT152_FINANCES, engine=w.P2I_BP_SIMULATION_COMMUNE;
 if(!prior?.units||!engine?.calculer)throw Error('Lot 153: calculs historiques Lot 152 ou moteur v107 absent');
 const ids=['smartphones','tablettes','tricycles_utilitaires','velos','equipements','remorques_agricoles','stockage_manutention'];
 const alternatives={
  smartphones:{name:'Pleine capacité théorique (test de plafond, non retenue)',reason:'À coût, prix et charges inchangés, les 1 800 appareils/an représentent 100 % de la capacité nominale; les ventes réelles ne sont pas documentées. Test de limite, pas scénario commercial central.',input:{production:[1800,1800,1800],ventes:[1800,1800,1800]}},
  tablettes:{name:'Configuration Lot 152 — kit Smartlink conservé uniquement en comparaison',reason:'Le FOB publié (154,47 USD) dépasse le prix net P2I de 112 USD avant rendu, contrôle et distribution. Le scénario reste calculé pour comparaison mais aucune configuration de référence viable n’est retenue.',input:null},
  tricycles_utilitaires:{name:'JLM31001 — borne basse publiée de la fourchette FOB',reason:'La plage FOB publiée de 420–460 USD permet de tester 420 USD sans inventer de prix. Les 175 USD de rendu et 80 USD de conversion Lot 152 restent des estimations; la fiche/packing list doit confirmer que la borne basse correspond au kit exact.',input:{matieres_kg:595,matieres_kg_annuel:[595,606.9,618.8],cout_production_kg:[675,688.5,702]}},
  velos:{name:'Volume A1 = 1 000 unités (sensibilité commerciale)',reason:'1 000 unités correspond au volume A2 déjà modélisé au Lot 152, déplacé en A1 pour tester le seuil. Ce n’est pas une vente acquise; le kit CKD et la BOM restent non cotés.',input:{production:[1000,1050,1100],ventes:[1000,1050,1100]}},
  equipements:{name:'Atelier chargé à 80 % (sensibilité, sans revenu de chantier)',reason:'Test à 120 unités A1, puis 135 et 150, sur un plafond nominal de 150. Les installations de terrains et prestations restent sans chiffre d’affaires; la demande de 120 buts/an n’est pas démontrée.',input:{production:[120,135,150],ventes:[120,135,150]}},
  remorques_agricoles:{name:'Atelier à pleine capacité nominale (sensibilité)',reason:'Test à 120 remorques/an, capacité nominale, avec prix et coûts Lot 152 inchangés. PTAC/charge utile, plan de résistance et débouché commercial restent à établir; volume maximal non assimilé à une vente.',input:{production:[120,120,120],ventes:[120,120,120]}},
  stockage_manutention:{name:'Prix de comparaison local, sans modification du produit de référence',reason:'La comparaison locale la plus proche accessible affiche 64 000 FCFA pour une étagère WADFOW 180×160×60 cm, 4 niveaux et 500 kg/niveau. Elle n’est pas dimensionnellement identique à la baie Lot 152; prix utilisé seulement comme borne de sensibilité, jamais comme prix net P2I.',input:{prix:[97.56,97.56,97.56]}}
 };
 const summarized=(id,name,input,result)=>({id,name,up_name:w.P2I_BP_DONNEES.unites[id].nom,input,result,status:'indicatif_non_valide'});
 const results={schema:'p2i.lot153.evaluation.v1',engine:'v107',status:'comparaison_indicative_non_validation',historical:{lot:152,immutable:true},units:{}};
 for(const id of ids){
  const h=prior.units[id], a=alternatives[id]; if(!h)throw Error('Lot 153: scénario historique absent '+id);
  let input=JSON.parse(JSON.stringify(h.input));
  if(a.input)Object.assign(input,JSON.parse(JSON.stringify(a.input)));
  if(id==='tricycles_utilitaires'){
   input.description='Scénario Lot 153 indicatif : borne basse de la fourchette FOB publiée (420 USD); transport/douane/assurance et conversion restent estimatifs.';
   input.source='Fiche catalogue Jolmolangma publiée à 420–460 USD FOB, à confirmer par offre détaillée; coûts rendus/conversion P2I estimés. '+input.source;
  }
  const result=engine.calculer(input);
  results.units[id]={historical:summarized(id,'Lot 152 — scénario historique conservé',h.input,h.result),sensitivity:summarized(id,a.name,input,result),reason:a.reason,adopted:'non_adoptee',
    capex:input.investissement,reserve:result.reserve_initiale,total_financing_need:input.investissement+result.reserve_initiale,equity_capex:input.investissement*input.part_apport,debt_capex:input.investissement*input.part_dette,equity_reserve:result.reserve_initiale,
    annual:result.annuel.map(x=>({year:x.annee,revenue:x.chiffre_affaires,operating_result:x.ebit,net_result:x.resultat_net,net_margin:x.chiffre_affaires?x.resultat_net/x.chiffre_affaires:null,roi:result.performance.annuel[x.annee-1].roi_annuel})),
    min_monthly_cash:Math.min(...result.tresorerie.map(x=>x.solde_final)),bfr_max:Math.max(...result.bfr.map(x=>x.bfr)),cash12:result.tresorerie,bfr36:result.bfr,balance_checks:result.bilans.map(x=>({year:x.annee,gap:x.ecart})),controls:result.controles,
    payoff_year:result.annuel.reduce((s,x)=>{s.sum+=x.resultat_net;if(s.sum>=input.investissement&&s.at===null)s.at=x.annee;return s;},{sum:0,at:null}).at,
    exact_inputs:input
  };
  const d=w.P2I_BP_DONNEES.unites[id];
  d.lot153={status:'sensibilite_non_adoptee',scenario:a.name,reason:a.reason,engine:'v107',result:results.units[id].annual};
  d.redaction={...d.redaction,
   economie:(d.redaction.economie||'')+' Lot 153 : scénario Lot 152 conservé comme historique. Sensibilité v107 exécutée : '+a.name+'. '+a.reason+' Les résultats détaillés, le financement, le BFR et les réserves figurent dans LOT153/RESULTATS_COMPARATIFS_V107.json. Aucun seuil de marge n’est forcé.',
   qualification:(d.redaction.qualification||'')+' Lot 153 : '+(id==='tricycles_utilitaires'?'référence provisoire au FOB bas publié, reste non validée économiquement.':'aucun redressement économiquement démontré; résultat historique et sensibilité restent indicatifs.')};
 }
 w.P2I_LOT153_FINANCES=results;
})();
