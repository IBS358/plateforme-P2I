
/* P2I — Moteur BFR mensuel : 36 mois, ventes 40 % comptant / 60 % à 30 jours.
 * Stocks cibles : matières premières 30 jours, produits finis 15 jours.
 * Les coûts de matières et de production sont fournis par les moteurs amont,
 * jamais déduits d'un chiffre d'affaires ni inventés.
 * Convention explicite : mois normalisé de 30 jours ; stock final mensuel.
 */
(function(root){
"use strict";
const number=x=>typeof x==="number"&&Number.isFinite(x)&&x>=0;
const close=(a,b)=>Math.abs(a-b)<=Math.max(.01,Math.abs(a)*1e-8);
function calculate(input){
 const problems=[];
 const data=input&&typeof input==="object"?input:{};
 const months=Array.isArray(data.mois)?data.mois:[];
 if(months.length!==36)problems.push("36 mois de données d'exploitation sont obligatoires");
 const options=data.hypotheses||{};
 const expected={part_clients_comptant:0.4,part_clients_30_jours:0.6,
  stock_produits_finis_jours:15,
  delai_fournisseurs_jours:0,jours_mois:30};
 for(const [key,value] of Object.entries(expected))
  if(!number(options[key])||!close(options[key],value))
   problems.push("Hypothèse absente ou différente du scénario P2I : "+key);
 if(!number(options.stock_matieres_jours)||options.stock_matieres_jours>180)problems.push("Stock matières : entre 0 et 180 jours");
 if(!number(data.creances_ouverture_usd))problems.push("Créances clients à l’ouverture manquantes");
 if(problems.length)return Object.freeze({valide:false,blocages:Object.freeze(problems),bfr_mensuel:null});
 const rows=[];
 let previousReceivable=data.creances_ouverture_usd;
 for(let i=0;i<36;i++){
  const m=months[i]||{};
  const keys=["ventes_usd","consommation_matieres_usd","cout_production_vendue_usd"];
  const invalid=keys.filter(k=>!number(m[k]));
  for(const k of invalid)problems.push("Mois "+(i+1)+" : "+k+" manquant ou invalide");
  if(invalid.length)continue;
  // Si des stocks physiques de fin de mois sont disponibles, leur valorisation
  // remplace les stocks cibles 30/15 jours : jamais de cumul des deux méthodes.
  const physical=["stock_matieres_quantite","cout_unitaire_matieres_usd",
   "stock_finis_quantite","cout_unitaire_finis_usd"];
  const hasPhysical=physical.some(k=>m[k]!==undefined&&m[k]!==null);
  if(hasPhysical&&physical.some(k=>!number(m[k]))){
   problems.push("Mois "+(i+1)+" : stock physique incomplet ou invalide");
   continue;
  }
  const rawStock=hasPhysical?m.stock_matieres_quantite*m.cout_unitaire_matieres_usd:
   m.consommation_matieres_usd*options.stock_matieres_jours/30;
  const finishedStock=hasPhysical?m.stock_finis_quantite*m.cout_unitaire_finis_usd:
   m.cout_production_vendue_usd*.5;
  const packKeys=['stock_emballages_quantite','cout_unitaire_emballages_usd'];
  const hasPack=packKeys.some(k=>m[k]!==undefined);
  if(hasPack&&packKeys.some(k=>!number(m[k]))){problems.push('Mois '+(i+1)+' : stock emballages incomplet ou invalide');continue;}
  const packagingStock=hasPack?m.stock_emballages_quantite*m.cout_unitaire_emballages_usd:0;
  const receivable=m.ventes_usd*.6;
  // Les fournisseurs sont payés comptant : aucune dette fournisseur.
  // Les stocks sont des encours distincts : ne pas ajouter la consommation
  // du mois une deuxième fois dans le BFR.
  const stocks=rawStock+packagingStock+finishedStock;
  const hasPayroll=m.dettes_sociales_usd!==undefined||m.dettes_fiscales_salariales_usd!==undefined;
  if(hasPayroll&&(!number(m.dettes_sociales_usd)||!number(m.dettes_fiscales_salariales_usd))){problems.push('Mois '+(i+1)+' : dettes de paie invalides');continue;}
  const payrollDebts=hasPayroll?m.dettes_sociales_usd+m.dettes_fiscales_salariales_usd:0;
  const bfr=stocks+receivable-payrollDebts;
  rows.push(Object.freeze({mois:i+1,stocks_matieres:rawStock,
   stocks_emballages:packagingStock,stocks_produits_finis:finishedStock,stocks,creances_clients:receivable,
   dettes_exploitation:payrollDebts,...(hasPayroll?{dettes_sociales:m.dettes_sociales_usd,dettes_fiscales_salariales:m.dettes_fiscales_salariales_usd}:{}),bfr,
   methode_stock:hasPhysical?"stock_physique_valorise":"stock_cible_"+options.stock_matieres_jours+"_15_jours",
   encaissements_clients:m.ventes_usd*.4+previousReceivable}));
  previousReceivable=receivable;
 }
 if(problems.length)return Object.freeze({valide:false,blocages:Object.freeze(problems),bfr_mensuel:null});
 return Object.freeze({valide:true,blocages:Object.freeze([]),bfr_mensuel:Object.freeze(rows)});
}
root.P2I_BP_BFR_MENSUEL=Object.freeze({calculate});
})(typeof window!=="undefined"?window:globalThis);

