# P2I — Lot 159 — Contrôles de faisabilité des simulations v107

## Modifications réellement effectuées
Nouvelle version de l’atelier Lot158, sans modifier le moteur commun ni les BP actifs. Le calcul v107 reste identique, mais l’interface affiche désormais : (1) dépassement du volume de production historique A1, (2) contribution unitaire négative, (3) pertes nettes, (4) trésorerie négative, (5) distinction remorque 750 kg/3 t, (6) réserves sur le prix, les machines et les débouchés. Les alertes sont ajoutées à l’export JSON.

## Limites
Aucune nouvelle configuration fournisseur ni aucun prix local confirmé. Les quatre UP ne sont pas redressées. Les seuils et scénarios historiques ne sont pas modifiés. Ouvrir LOT159/ATELIER_SCENARIOS_V107_CONTROLES.html dans Edge après extraction.

## Contrôles
Tests automatisés v107 Lot158 et Lot159, contrôle structurel des alertes, contrôle ZIP. Aucun clic ni rendu visuel Edge effectué.
