# P2I — Lot 240 : qualification énergétique et seuil d’exploitation

Source : archive complète Lot239, sans modification des fichiers historiques. 96 UP, 12 filières et moteur v107 conservés.

## Livrables
- `QUALIFICATION_8UP_EDGE.html` : outil local pour huit UP, trois capacités par UP, trois scénarios d’utilisation et coût de l’énergie par tonne vendable.
- `MATRICE_QUALIFICATION_8UP.csv` : champs nécessaires pour transformer les configurations en BP v107.
- `RAPPORT_LOT240.md` : traçabilité.

## Contrôles économiques
- Gisement limite le tonnage entrant ; rendement matière appliqué au tonnage traité.
- Coût énergétique = puissance moyenne réellement consommée × heures effectives × tarif variable + frais fixes de fourniture + secours énergétique.
- Charges fixes hors énergie séparées des coûts variables et des frais électriques.
- Aucun prix de machine, tarif électrique, rendement ou chiffre d’affaires inventé.
- Le résultat d’exploitation simplifié n’est pas un résultat net et ne remplace pas v107.

## Limites et prochaine action
Qualifer prix fournisseurs, puissance réelle de chaîne complète, contrat électrique ivoirien, gisement contractualisable et débouchés avant d’intégrer dans le moteur v107. Ne pas retenir une taille industrielle sur la seule base de la capacité catalogue.
