# LOT306 — Recherche multi-UP de prix publics (18 novembre 2026)

Six annonces additionnelles ont été examinées sur trois UP (plastique, compost, métaux). Le registre contient la source URL, le prix affiché, le périmètre, la capacité et le motif de réserve. Aucun prix ne doit être interprété comme un CAPEX complet de ligne ; aucun investissement historique n’est remplacé. Aucun devis officiel requis.

Limites : les prix et capacités proviennent des fiches commerciales publiques, sans validation contractuelle. Les autres UP restent en attente de références catalogue adaptées.
