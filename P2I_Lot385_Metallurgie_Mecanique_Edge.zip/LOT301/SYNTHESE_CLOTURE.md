# P2I — Lot 301 : clôture provisoire des huit BP Découverte Recyclage & Valorisation

## Décision
Fin des itérations d'audit sur la filière. Les huit BP sont regroupés et consultables. Ce lot n'est PAS une validation économique ni une exécution du moteur commun v107. Les résultats financiers antérieurs non cohérents avec les flux physiques ne doivent pas être utilisés comme référence.

## Calcul retenu
Entrées = capacité t/h × heures annuelles × utilisation. Sorties vendables = entrées × rendement. CA = sorties × prix. Coûts variables = entrées × (collecte + énergie × tarif + autres variables). EBITDA = CA − variables − fixes. Résultat avant impôt = EBITDA − amortissement A1 historique − intérêts A1 historiques. Impôt indicatif = 25 % du résultat positif. RN = résultat avant impôt − impôt. Les postes historiques de financement sont conservés à titre estimatif.

## Limites
Pas de fournisseurs machines/prix EXW/FOB documentés, pas de prix de vente contractuels, pas de contrôle réglementaire, pas de bilan équilibré, pas de trésorerie v107 validée, pas de financement de BFR démontré. Les 17 rubriques et les illustrations restent consultables ; leurs anciens chiffres peuvent diverger de la nouvelle synthèse et doivent être interprétés comme historiques, non définitifs. Ne pas afficher ces huit BP comme bancables.

## Priorité de projet
Passer aux deux dernières UP Découverte. Reporter les qualifications documentaires lourdes à la phase Pro et ne pas reprendre les huit BP pour des micro-ajustements.
