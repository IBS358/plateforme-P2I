# P2I — Lot 181 : frontière de compétitivité Remorque 3 t

## Source et périmètre
Copie complète du Lot 180. Les données proviennent exclusivement de `LOT154/ADDENDUM_ARCHITECTURES_ET_ESSIEUX.md` et des BOM conservées. Aucun nouveau prix fournisseur n'est présenté comme vérifié. Moteur v107, BP historiques et archives inchangés.

## Résultats vérifiés
- Acier indicatif livré Abidjan : **614,04 USD**.
- Deux essieux Darong : **438,60–543,00 USD FOB**.
- Sous-total incomplet : **1 052,64–1 157,04 USD**.
- Remorque Weito 7C-3, 4 roues, 2 essieux, complète : **1 550–1 750 USD FOB Qingdao**.
- Au comparateur Weito bas 1 550 USD, différence arithmétique résiduelle **392,96–497,36 USD** pour les postes non inclus. Au comparateur haut 1 750 USD, **592,96–697,36 USD**.
- Yijia 7C-3 : **1 131–1 188 USD FOB**, mais architecture **2 roues / 1 essieu**. Le résultat arithmétique avec la BOM 2 essieux est **non comparable** et ne doit pas guider une décision.

## Décision
**Ne pas qualifier la fabrication locale 3 t comme rentable** et ne pas intégrer de résultat net v107 de cette nouvelle configuration tant que la nomenclature complète et la parité *rendu Abidjan / spécifications égales* ne sont pas établies. Ne pas confondre une comparaison de coûts directs partiels et une marge nette.

## Données manquantes
Roues/pneus compatibles, suspension, freinage, timon/attelage, peinture, consommables, main-d'œuvre, chutes, import des essieux, allocation des frais fixes, prix de vente encaissable, volumes vendables, PTAC et tare validés. La BOM acier n'est pas validée par un plan de résistance.

## Tests réellement effectués
`node P2I_Edge/LOT181/calcul_parite.cjs` : contrôles arithmétiques exécutés avec succès. Contrôle de l'intégrité ZIP réalisé à la création. Aucun test graphique Edge. Aucun nouveau BP v107 3 t calculé. `main` non modifiée.
