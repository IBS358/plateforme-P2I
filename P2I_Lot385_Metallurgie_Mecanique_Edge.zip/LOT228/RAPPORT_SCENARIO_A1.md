# P2I — Lot 228 — Accélération A1 et flexibilité de qualification

**Statut : scénario de sensibilité, non validé et non recalculé par v107.** Base de calcul : sortie v107 réelle du lot 227, avec rémunération supplémentaire du dirigeant de 300 000 FCFA/mois.

## Scénario à éprouver
- 2 300 tables-bancs, 320 bureaux et 180 armoires en A1. CA **139,900,000 FCFA**; coûts variables historiques **100,120,000 FCFA** hors personnel.
- Résultat net A1 **extrapolé** : **5,562,284 FCFA**, marge **3.98 %**. Ce résultat **n'est pas** une nouvelle sortie du moteur v107 et n'est pas validé.
- Répartition de capacité envisagée : 30 % du volume en M1–M5, 70 % en M6–M12; les unités mensuelles figurent dans le CSV.
- Hypothèse de financement à vérifier : ventes à crédit, acomptes, matières payées avant livraison et trésorerie initiale; ne pas reprendre la trésorerie positive du moteur comme preuve.
- **Aucune subvention, commande publique ni économie de coût supposée** dans le chiffre d'affaires. Une subvention d'investissement éventuelle est un scénario séparé, soumis à attribution et à son traitement comptable.

## Méthode de calcul
Interpolation/extrapolation de la pente marginale du RN A1 entre les scénarios « croissance » et « forte croissance » du lot 227, à dirigeant supplémentaire identique : 0.258916 FCFA de RN pour 1 FCFA de CA additionnel. C'est un **test de sensibilité**, pas une relation démontrée au-delà de l'intervalle initial.

## Arbitrage P2I
Le critère de 6–10 % de marge ne doit pas constituer une exclusion automatique des UP à forte utilité sociale. On peut retenir un statut **« stratégique — viabilité à confirmer »** et montrer les risques sans masquer les pertes. Cela ne remplace pas la validation du BP Découverte.

## À vérifier avant validation
1. Plan de charge et machines réellement capables de livrer ~2 800 meubles A1, particulièrement M6–M12.
2. Coûts unitaires complets hors personnel des bureaux/armoires, rémunération du dirigeant et évolution des effectifs.
3. Prix et contrats clients, crédit client et acomptes, trésorerie M1–M12 avec stocks et TVA.
4. Exécution v107 sur les volumes retenus, puis visuels des blocs 2 et 17 et intégration catalogue.

Les sept autres BP, le moteur et le catalogue actif sont conservés.
