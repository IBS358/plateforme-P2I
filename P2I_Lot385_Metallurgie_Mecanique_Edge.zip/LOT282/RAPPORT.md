# Lot 282 — Huit simulateurs intégrés aux BP historiques

Livraison substantielle : huit pages interactives utilisables hors connexion pour modifier volumes vendus par fraction, prix, coûts variables et fixes, CAPEX, intérêts, durée d’amortissement et taux d’impôt indicatif. Recalcul instantané des CA, EBITDA, résultat indicatif, marge et équilibre matières. Liens vers les BP à 17 rubriques du lot 281.

**Limites :** données des lots 275/281 non validées ; aucun devis catalogue, aucune illustration photoréaliste ajoutée, aucun moteur v107 exécuté, aucun bilan ni trésorerie définitifs. Ne pas utiliser les marges pour solliciter un financement.

Fichiers précédents copiés sans changement.
