# LOT 303 — Sélection documentaire d’une référence tarifée pour l’UP Pneus

## Avancée
Une référence tarifée et identifiée a été trouvée : Optima 2 000 kg/h, 250 000 USD FOB affichés pour 1–2 ensembles. Le fabricant annonce broyeur 2 × 55 kW, rasper 220 kW, granulateur 90 kW, séparation des fibres. Il s’agit d’un **candidat**, et non d’une ligne complète certifiée ou d’un CAPEX retenu.

## Dimensionnement 4 t/h
Deux modules de 2 t/h donneraient une capacité nominale arithmétique de 4 t/h pour un **prix catalogue brut indicatif de 500 000 USD FOB**, à condition que les modules soient complets, compatibles et puissent fonctionner simultanément. Ce montant exclut transport, douanes, raccordement, installation, convoyage commun, manutention, réserve de pièces, génie civil et BFR. **Il ne remplace pas le CAPEX du BP** ; aucun devis officiel requis.

## Point technique majeur
La fiche ne prouve pas que chaque ensemble comprend tous les postes nécessaires ni que 2 t/h de pneus entrants donnent 2 t/h de granulats commercialisables. La séparation acier, la granulométrie, les poussières, les filtres et le rendement réel doivent être documentés sur les fiches publiques. Les autres UP demeurent à qualifier.

## Arbitrage
Ne pas prendre un broyeur isolé pour une ligne complète ; ne pas réduire arbitrairement la taille industrielle pour afficher une rentabilité. Poursuivre la qualification des machines à prix public. Ne pas bloquer les BP Découverte sur un devis.
