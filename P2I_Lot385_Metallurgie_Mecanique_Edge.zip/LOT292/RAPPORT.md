# Lot 292 — Huit illustrations IA intégrées
Huit cadrages distincts extraits d'une planche IA originale générée pour la filière Recyclage & Valorisation. Chaque visuel est intégré au bloc 2 de son BP, et à la galerie du lot 292. Fichiers WebP locaux utilisables sans réseau sous Microsoft Edge.
Il ne s'agit pas de photographies d'installations existantes, ni de machines identifiées, ni d'une garantie de rendement ou de conformité. Aucun logo P2I n'a été régénéré ou modifié. Les BP restent provisoires, sans qualification fournisseurs ni validation v107.
