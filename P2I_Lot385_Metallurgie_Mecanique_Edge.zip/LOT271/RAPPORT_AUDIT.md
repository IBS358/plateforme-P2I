# P2I — Lot 271 — Audit contradictoire des huit scénarios BP

## Objet
Conserver sans altération les 687 fichiers du lot 270, puis documenter **les écarts entre le modèle opérationnel initial (lot 258) et le modèle financier consolidé (lot 270)**. Aucun des huit BP n'est déclaré validé.

## Constats
- Les données de production, volumes et prix de base du lot 258 sont conservées dans `production` des JSON lot 270, alors que certains chiffres d'affaires et EBITDA A1 du lot 270 proviennent de scénarios multi-flux non vérifiés.
- Pour chaque UP, le tableau fournit les deux bases et une marge **contre-factuelle** recalculée à partir du modèle initial, avec le CAPEX du lot 270, amortissement sur 10 ans, dette 60 % à 10 % et impôt illustratif 25 %.
- Une marge supérieure à 6 % dans le lot 270 ne signifie pas validation du modèle industriel, et une marge négative contre-factuelle n'invalide pas à elle seule un modèle multi-flux documenté ultérieurement.
- Pour le verre, le modèle de production donne un EBITDA de 25,6 M FCFA et un CA de 829,4 M FCFA, tandis que le financier donne 191,7 M FCFA et 792,3 M FCFA. La différence d'EBITDA de 166,1 M FCFA ne doit pas être acceptée sans nomenclature détaillée des produits et coûts.
- Le BFR, les échéances clients/fournisseurs, le bilan équilibré et les tests v107 restent absents.

## Plan de résolution industrielle
1. Définir pour chaque UP une nomenclature physique des flux : tonnes entrantes, taux de refus, produits, coproduits, pertes et résidus dangereux. Vérifier somme des masses.
2. Documenter chaque ligne d'équipement : fabricant, modèle, capacité effective, puissance, prix EXW/FOB, transport, installation, douanes, maintenance.
3. Établir pour chaque fraction vendue un prix local sourcé, une qualité technique et un volume commercialement absorbable.
4. Recalculer les huit BP dans le moteur v107, avec 3 ans de compte de résultat et bilan, 12 mois de trésorerie, BFR explicite et 40/60.
5. Terminer les 17 rubriques et intégrer les illustrations produits, machines et postes, sans remplacer le logo P2I original.

## Périmètre
Ce lot n'écrase aucun fichier historique : les neuf UP déjà avancées et les autres filières restent byte-identiques dans l'archive cumulative. Il s'agit d'un contrôle de qualité et d'une base de correction, pas d'une livraison finale des huit BP.
