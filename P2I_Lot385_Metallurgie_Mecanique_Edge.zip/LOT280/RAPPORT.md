# Lot 280 — Cahiers des charges intégrés dans les huit BP

Huit BP HTML cumulatifs, 17 rubriques, avec spécifications techniques et critères de réception ajoutés au bloc 8. 33 fonctions industrielles détaillées.

**Non terminé :** fournisseurs, prix catalogues vérifiés, CAPEX rendu site, contrats d’approvisionnement et débouchés, bilan financier équilibré, calcul v107 et illustrations IA. Aucun résultat net antérieur n’a été modifié. Les originaux et autres filières sont préservés.

Ouvrir `P2I_Edge/LOT280/index.html` dans Edge.
