# P2I — Lot 361 : postes de chaudronnerie à prix FOB publics

Trois fonctions disposent maintenant de **candidats avec prix FOB affichés** : pliage 12 700 USD, cisaillage 15 500 USD, roulage 21 500 USD, soit **49 700 USD de prix machines indicatifs cumulés**. Les références de cisaillage et de roulage ont été relevées dans des catalogues fournisseurs publics en novembre 2026.

Ce total n'est **ni le CAPEX de l'atelier, ni un devis, ni un prix rendu Côte d'Ivoire**. Le roulage et le cisaillage doivent être vérifiés sur les épaisseurs, longueurs et capacités nécessaires ; les autres équipements (plasma, soudage, levage, sécurité, manutention, métrologie) ne sont pas encore individuellement qualifiés. Les postes d'installation, fret, assurance, douanes et BFR restent séparés.

**Contrôle financier :** aucune modification des montants du moteur v107 n'a été faite. La perte historique de 56 260 USD ne peut être remplacée par une marge positive sur la seule base de ces trois références.

**Conservation :** l'archive du lot 360 est intégralement préservée, les 88 autres UP ne sont pas modifiées et `main` n'est pas touchée.
