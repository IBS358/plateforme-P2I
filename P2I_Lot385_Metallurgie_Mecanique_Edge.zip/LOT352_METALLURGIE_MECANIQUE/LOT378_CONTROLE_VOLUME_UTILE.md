# Lot 378 — Contrôle du volume utile et correction du dimensionnement de la cuve historique

## Base conservée
Cuve cylindrique inox 304L, fond plat, couvercle posé, diamètre intérieur exploratoire 1 000 mm, épaisseur exploratoire 3 mm, tôles prédécoupées achetées. Aucun des huit BP publics ni aucun calcul financier actif n'est remplacé.

## Anomalie technique déterminante
La hauteur historique de 1 273 mm correspond à **999.8 L de volume géométrique**, avant espace libre, piquages, tolérances et contraintes d'exploitation. À 90 % de remplissage, le volume utile est seulement **899.8 L**. L'appellation « cuve 1 000 L » doit préciser si elle désigne la capacité nominale géométrique ou le volume utile garanti. Cette question doit être résolue dans la fiche commerciale avant publication.

## Dimensionnement comparatif (hypothèses, pas plans de fabrication)
| Taux de remplissage maximal | Hauteur intérieure pour 1 000 L utiles | Marge sur largeur rouleuse 1 500 mm | Masse inox estimée avec 15 % de chutes |
|---|---:|---:|---:|
| 100% | 1273 mm | 227 mm | 153.8 kg |
| 95% | 1340 mm | 160 mm | 159.6 kg |
| 90% | 1415 mm | 85 mm | 166.0 kg |
| 85% | 1498 mm | 2 mm | 173.2 kg |

**Calculs** : V = π × (D/2)² × H ; surface de tôle simplifiée = π × D × H + 2 × π × (D/2)² (virole, fond et couvercle plat). Densité de calcul 8 000 kg/m³, épaisseur 3 mm, chutes 15 %. Ce modèle ne comprend pas les renforts, soudures, brides, piquages, charnières, accessoires, fonds réels, épaisseurs de recouvrement ou déformations. La masse n'est pas une nomenclature de tôles vérifiée.

## Décision de configuration
- **Ne pas déclarer** que la cuve historique de H = 1 273 mm offre 1 000 L utiles : elle atteint seulement ~1 000 L géométriques.
- À titre de variante d'étude, 90 % de remplissage demande H ≈ 1 415 mm. La W12-6×1500 offre alors une marge nominale de largeur de seulement ~85 mm, **avant marges d'extrémité et prise machine**. La conformité géométrique et métallurgique n'est donc pas démontrée.
- À 85 %, H ≈ 1 498 mm, presque toute la largeur nominale ; configuration **non retenue** sans justification de la largeur utile réelle et des tolérances.
- La hauteur plus grande augmente la surface et la masse d'inox ; elle doit entraîner une révision de la matière, du temps de soudage, du coût de revient et du transport, pas seulement du titre du BP.
- **Option la plus prudente à court terme :** conserver explicitement la « cuve atmosphérique de capacité géométrique nominale 1 000 L » et ne pas promettre 1 000 L utiles. Si le marché exige 1 000 L utiles, requalifier la conception et la rouleuse, puis recalculer le BP.

## Cadence réaliste
Avec la cadence historique 0,2166667 cuve/h, 2 000 h théoriques et une disponibilité de 85 %, le plafond est ~368 cuves/an (et non 420). À 80 %, ~347 cuves/an. Il faut un plan d'organisation démontrant les temps par poste, les opérations parallélisables et les arrêts. Ces plafonds ne constituent pas des capacités garanties.

## Statut et suite nécessaire
Aucune source de prix catalogue nouvelle n'est fournie par ce lot. Les postes non chiffrés des lots 375–377 restent ouverts. Les simulations historiques sont **indicatives** et ne sont pas publiables comme BP validé. La matrice 96 UP et les huit BP HTML restent inchangés.
