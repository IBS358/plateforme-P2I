 'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const here=__dirname,root=path.resolve(here,'..'),ctx={console,Math,Number,String,Array,Object,Map,Set,JSON,Error,TypeError,Date,Intl,URL,URLSearchParams};ctx.window=ctx;ctx.location={search:'?unit_id=chaudronnerie'};vm.createContext(ctx);
for(let i=0;i<=11;i++)vm.runInContext(fs.readFileSync(path.join(root,'runtime',`script-${i}.js`),'utf8'),ctx,{filename:`script-${i}.js`});
const engine=ctx.P2I_BP_SIMULATION_COMMUNE;const original=JSON.parse(fs.readFileSync(path.join(here,'LOT371_CUVES_INTRANTS_HISTORIQUES_SOURCE.json')));
const cases=[
['historique_original',9736.7907,75146.155,559.9557428756428,[300,360,420],[294,360,420]],
['investissement_130k_matiere_historique',61486,130000,559.9557428756428,[300,330,360],[294,324,354]],
['investissement_160k_matiere_historique',61486,160000,559.9557428756428,[300,330,360],[294,324,354]],
['investissement_160k_matiere_700',61486,160000,700,[300,330,360],[294,324,354]],
['investissement_160k_matiere_850',61486,160000,850,[300,330,360],[294,324,354]]
];
let out=[];for(const [id,machines,investissement,matiere,production,ventes] of cases){let x=JSON.parse(JSON.stringify(original));Object.assign(x,{machines,investissement,matieres_kg:matiere,production,ventes});x.cout_production_kg=original.cout_production_kg.map(v=>v+(matiere-original.matieres_kg));let r=engine.calculer(x);out.push({id,hypotheses:{machines,investissement,matiere_usd_cuve:matiere,production,ventes,prix:x.prix,cout_production_kg:x.cout_production_kg},statut:r.statut,annuel:(r.annuel||[]).map(y=>({annee:y.annee,ca:y.chiffre_affaires,rn:y.resultat_net,marge_pct:y.chiffre_affaires?100*y.resultat_net/y.chiffre_affaires:null})),tresorerie_min:Math.min(...(r.tresorerie||[]).map(y=>y.solde_final)),bilans_ecart:(r.bilans||[]).map(y=>y.ecart),controles:r.controles});}
fs.writeFileSync(path.join(here,'LOT373_SENSIBILITES_CUVES_V107.json'),JSON.stringify({avertissement:'Scenarios de sensibilite uniquement; BOM et investissement non valides. Cout de production augmente du meme montant que la matiere pour maintenir la conversion historique constante.',resultats:out},null,2));console.log(JSON.stringify(out.map(x=>({id:x.id,a1:x.annuel[0],cash_min:x.tresorerie_min})),null,2));
