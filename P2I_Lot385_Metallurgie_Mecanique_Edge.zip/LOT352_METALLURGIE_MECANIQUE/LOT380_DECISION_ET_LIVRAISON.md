# Lot 380 — Décision consolidée et page testable

## Décision unique
Conserver l'UP spécialisée **cuves atmosphériques inox 304L de 1 000 L nominaux**, tôles prédécoupées, sans réexaminer les équipements exclus. Prévisualisation de 17 rubriques créée et moteur v107 réexécuté sur 280/320/340 productions, 274/314/334 ventes, 700 USD de matière/cuve.

## Ce qui est réellement livré
- Page HTML autonome de prévisualisation avec 17 rubriques, navigation, tableaux financiers sur 3 ans, trésorerie 12 mois et impression PDF via navigateur.
- JSON intégral du calcul v107 et script de reproduction.
- Les huit pages BP publiques du lot 352 et la matrice 96 UP sont inchangées.

## Limite de publication
Le coût machines du moteur (61 486 USD) reste un panier polyvalent **incompatible avec la nomenclature spécialisée de 24 500 USD FOB partiels**. L'investissement de 160 000 USD comprend une réserve non ventilée. Les coûts des auxiliaires, le coût inox livré et le prix de vente restent non documentés. Il serait trompeur d'annoncer ce BP finalisé. La page est donc explicitement marquée NON PUBLIABLE. Aucune nouvelle étude comparative n'a été lancée.
