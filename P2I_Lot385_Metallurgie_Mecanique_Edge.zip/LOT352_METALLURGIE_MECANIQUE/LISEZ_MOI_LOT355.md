# P2I — Lot 355 : contrôle de capacité de la Chaudronnerie

Reprise sans modification des 88 autres UP ni des scénarios originaux.

Moteur commun v107 relancé sur le scénario lot 352, volumes A1–A3 60/65/70/75/80, autres hypothèses constantes.

À 80 ensembles/an, RN A1 = -8 260 USD; le scénario n'est pas viable sur ses propres hypothèses, même à capacité déclarée. Ce test n'établit pas la faisabilité commerciale d'un taux d'utilisation de 100 %.

Les prix machines ne sont pas requalifiés comme prix catalogues vérifiés. La configuration de référence reste à corriger avec références publiques vérifiables.

Les fichiers sources des lots 352–354 sont conservés.
