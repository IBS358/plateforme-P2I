# P2I — Lot 368 : raccordement au moteur, sans faux recalcul

**Source : lot 367.** Modification effective du tableau `eq` de la Chaudronnerie dans `recalculer_lot352_v107.cjs` : suppression des trois anciennes lignes CORMAK / UmproTech / enveloppe 160 000 USD, remplacement par sept références déjà identifiées aux lots 359–366. Le fichier de simulation a été régénéré en exécutant le moteur Node v107, avec les 8 scénarios conservés.

## Contrôle du scénario actif
- CA A1 : 390,000 USD
- RN A1 : -56,260 USD (inchangé)
- Budget machines du moteur : 250 000 USD (inchangé, non justifié par la nouvelle liste)
- Sous-total des 7 familles de machines, avec **4 postes MIG** : 61,486 USD FOB annoncés.
- Différence budget machines / FOB annoncé : 188,514 USD, **ne constitue pas une économie** : frais d'import, outillages, aspiration, consommables, installation, manutention, mise en service et équipements absents.

## Limites bloquantes
- Références candidates, prix FOB annoncés dans les dossiers antérieurs, non revérifiés à cette étape ; capacités inox, dimensions et nombre de postes à confirmer.
- Le CSV historique `CONFIGURATION_EQUIPEMENTS_CI_LOT352.csv` est conservé à titre d'historique, mais **n'est plus la nomenclature à utiliser** pour la Chaudronnerie.
- Le HTML du BP n'a pas été transformé en simulation rentable fictive : les finances actives restent déficitaires.
- L'ancien scénario `recyclage_metaux` reste dans le moteur ; son résultat ne doit pas être attribué à l'UP Mobilier métallique.

## État réel
**Correction source réalisée et moteur exécuté ; BP non validé.** Aucun prix de vente, coût de production, capacité ou marge n'a été artificiellement modifié. Les 88 autres UP et la branche GitHub main ne sont pas touchées.
