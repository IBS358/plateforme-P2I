# Lot 371 — Raccordement des données historiques aux BP actifs (sans reconstruction)

## Sources effectivement reprises
- Archive historique `P2I_Metallurgie_Intrants_Historiques_Retrouves.zip`, fichier `chaudronnerie_intrants_historiques.json`, chemin historique `LOT352/runtime/script-16.js`.
- Archive complète du lot 370 et son script source `recalculer_lot352_v107.cjs`.
- Le fichier `LOT371_CUVES_INTRANTS_HISTORIQUES_SOURCE.json` est une copie des intrants historiques exacts, sans réinterprétation.

## Configuration historique exacte
Cuves cylindriques en inox **304L** de **1 000 litres**, **fond plat et couvercle posé**, pour stockage technique à pression atmosphérique; **tôles découpées achetées**, roulage et soudage en atelier. Production A1 **300**; ventes A1 **294**; prix **1535.73 USD**; machines **9736.79 USD**; investissement **75146.15 USD**; coût variable renseigné **860.62 USD**; personnel **8640 USD/an**; charges fixes **18000 USD/an**. Ce sont les valeurs du fichier historique, pas une validation.

## Point bloquant de définition matière
L'ancien moteur indique `matieres_kg = 559.956`. Le lot 370 propose **152,4 kg** de tôle par cuve après chutes pour une cuve fermée à deux fonds plats, 3 mm. Ratio brut **3.67**; sur 294 unités, **164.6 tonnes** contre **44.8 tonnes**. Le modèle historique décrit pourtant un *couvercle posé* et non deux fonds soudés. La valeur `matieres_kg` doit être reliée à sa signification dans le moteur; il est interdit de la traiter automatiquement comme une masse physique ou de la remplacer par 152,4.

## Décisions techniques déjà présentes à préserver
- Matière 304L et absence de pression; ne pas requalifier en cuve sous pression.
- Approvisionnement en tôles **prédécoupées** : vérifier si une cisaille/plasma CNC est indispensable à la configuration spécialisée ou constitue une polyvalence hors référence.
- Roulage, soudage inox, finition, étanchéité, manutention, contrôles et sécurité doivent être couverts.
- Le budget historique de machines **9 736,79 USD** n'est pas prouvé par une nomenclature complète; les 61 486 USD de candidats des lots 359–369 ne doivent pas non plus être automatiquement retenus en totalité.
- Le prix de vente et les 294 ventes historiques sont des hypothèses à étayer, pas des commandes fermes.

## Statut et prochaine opération réellement bloquante
**AUCUNE SUBSTITUTION FINANCIERE** : les huit simulations v107 restent inchangées, notamment le RN A1 actuel de −56 260 USD. Le tableau CSV précise champ par champ les incompatibilités. Il faut maintenant reconstruire la nomenclature **à partir des opérations du produit historique** (et non de l'atelier polyvalent), chiffrer les coûts réellement manquants, puis exécuter un scénario séparé du moteur. Ne pas déclarer l'UP validée avant ce raccordement.
