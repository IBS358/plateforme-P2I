# Lot 382 — Continuité et état réel des huit BP

Objectif : éviter toute nouvelle boucle de qualification des mêmes machines. Aucune recherche de fournisseurs ni nouvelle simulation de sensibilité.

## Réalisations vérifiables

- Création d'une matrice de **96 lignes**, séparateur `;` correct et encodage UTF-8 BOM, avec cinq colonnes de statut courant. Les 88 autres UP restent sans modification des données historiques.
- Création d'une page HTML de navigation vers les huit BP actifs, et vers la prévisualisation spécialisée de la Chaudronnerie.
- **Chaudronnerie** : scénario lot 381 conservé séparément, RN A1 indicatif 46 881,04 USD ; ne remplace pas le BP actif du lot 352 déficitaire de 56 260 USD.
- **Mobilier métallique** : statut `NON_CALCULE` conservé ; interdiction d'attribuer les résultats de l'ancienne UP Recyclage métaux au mobilier.
- Les résultats des six autres UP calculées proviennent exclusivement du lot 352. Aucun résultat n'est présenté comme validation technique ou commerciale.

## Décision opérationnelle

**Cesser de relancer les mêmes comparatifs de machines pour la Chaudronnerie.** La configuration cuves est arrêtée comme référence de travail. Pour publier, il faut un budget auxiliaires/équipements complet, des sources catalogue pour les machines sélectionnées, et la vérification des prix de vente et des matières. Sans ces éléments, publier la marge de 11,14 % serait trompeur.

Priorité de développement immédiatement exploitable : **Mobilier métallique**, seul BP de la filière sans simulation v107 de son propre produit. Ensuite correction des marges très faibles Serrurerie et Structures, puis vérification finale des UP calculées. Cette priorisation n'autorise aucun chiffre inventé.
