# P2I — Lot 357 : correction de navigation du BP Mobilier

Base intégrale : lot 356, sans recalcul financier ni modification des autres BP.

## Corrections effectuées

- Le BP Mobilier du lot 229 comportait deux liens vers la filière Assemblage (LOT192), incohérents après son intégration en Métallurgie & Mécanique. Ces deux liens renvoient désormais à l’index de Métallurgie & Mécanique.
- Le lien « Retour au dashboard » du Mobilier pointait sur l’index de filière ; il pointe désormais sur l’accueil P2I local à la racine de l’archive.
- L’en-tête de l’index de filière identifie la reprise lot 357.
- Les 17 ancres du BP Mobilier ont été conservées et vérifiées.

## Limites

Aucune nouvelle machine ou prix catalogue n’a été qualifié. La simulation Mobilier reste provisoire et les anomalies financières du lot 352 restent ouvertes. Ce lot corrige la navigation et ne constitue pas la validation industrielle ou financière de la filière.
