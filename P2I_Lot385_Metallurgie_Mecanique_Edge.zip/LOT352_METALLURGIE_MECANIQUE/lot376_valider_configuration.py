#!/usr/bin/env python3
import json,csv,pathlib,sys
root=pathlib.Path(__file__).resolve().parent
s=json.loads((root/'LOT376_ETAT_CONTROLES.json').read_text(encoding='utf-8'))
rows=list(csv.DictReader((root/'LOT376_POSTES_ET_PREUVES.csv').open(encoding='utf-8-sig',newline=''),delimiter=';'))
assert len(rows)==s['mandatory_functions']
assert sum(float(r['prix_fob_usd']) for r in rows if r['prix_fob_usd'])==s['machine_candidates_fob_usd']
missing=[r['poste'] for r in rows if r['validation']!='OUI']
print('CANDIDATS FOB:',s['machine_candidates_fob_usd'],'USD')
print('POSTES NON VALIDES:', ', '.join(missing))
print('PUBLICATION:', 'AUTORISEE' if not missing and s['machine_complete'] else 'BLOQUEE')
sys.exit(0 if not missing and s['machine_complete'] else 2)
