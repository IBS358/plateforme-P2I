# P2I — Lot 356 : correction ciblée de conformité des BP existants

Base : archive complète du lot 355, conservée dans cette livraison.

Corrections réelles : la rubrique 16 de sept BP actifs (serrurerie, outillage, chaudronnerie, mécanosoudure, structures, pièces, quincaillerie) a été corrigée. Le texte précédent était un copier-coller identique mentionnant à tort recyclage de ferraille et pièces automobiles dans toutes les UP. Chaque BP présente maintenant les risques spécifiques à son procédé.

Chaudronnerie : avertissement de qualification dans la rubrique équipements. La référence CORMAK 100T est insuffisamment qualifiée comme presse plieuse ; le lot complémentaire 160 000 USD n'est pas un prix catalogue détaillé. Les résultats financiers historiques du lot 355 sont conservés, sans falsification. La configuration n'est pas validée.

Limites : aucune source catalogue nouvelle n'a été vérifiée en ligne dans ce lot ; aucun recalcul financier nouveau ; pas de clôture des huit BP. Les 88 autres UP ne sont pas modifiées. La version historique du Mobilier et l'ancienne page Recyclage sont conservées sans modification. Aucun fichier GitHub n'a été modifié.
