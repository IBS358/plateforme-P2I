'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm');
const root=path.resolve(__dirname,'..'),ctx={console,Math,Number,String,Array,Object,Map,Set,JSON,Error,TypeError,Date,Intl,URL,URLSearchParams};ctx.window=ctx;ctx.location={search:'?unit_id=chaudronnerie'};vm.createContext(ctx);
for(let n=0;n<=11;n++)vm.runInContext(fs.readFileSync(path.join(root,'runtime',`script-${n}.js`),'utf8'),ctx);
const original=JSON.parse(fs.readFileSync(path.join(__dirname,'SIMULATIONS_V107_LOT352.json'),'utf8')).scenarios.find(s=>s.up_id==='chaudronnerie').input;
const rows=[];
for(let v of [60,65,70,75,80]){
 const input={...original,production:[v,v,v],ventes:[v,v,v]};const r=ctx.P2I_BP_SIMULATION_COMMUNE.calculer(input);
 const y={annuel:r.annuel,performance:r.performance,tresorerie:r.tresorerie};
 rows.push({ventes_a1:v,CA_attendu_a1:v*original.prix[0],resultat_brut:y,cles_resultat:Object.keys(r)});
}
fs.writeFileSync(path.join(__dirname,'SENSIBILITE_CHAUDRONNERIE_V107.json'),JSON.stringify(rows,null,2));
console.log(JSON.stringify(rows.map(x=>({volume:x.ventes_a1,keys:x.cles_resultat})),null,2));
