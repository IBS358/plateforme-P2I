# Lot 369 — contrôle opposable du chiffrage Chaudronnerie

Source intégrale : lot 368, sans modification des 8 scénarios de production ni du moteur commun.

- **7 familles de machines / 10 unités** : **61,486 USD FOB candidats**.
- **Budget machines du moteur** : **250,000 USD**. Écart non justifié : **188,514 USD**.
- **10 postes industriels et logistiques non chiffrés** : consulter le CSV.
- **Résultat A1 moteur inchangé : −56 260 USD**, CA 390 000 USD.
- **Décision de contrôle : NON VALIDÉ.** Une somme de prix FOB candidats ne peut pas remplacer un investissement installé.
- **Incohérence de périmètre persistante** : le scénario actif produit 60 ensembles polyvalents; la piste historique produit des cuves inox 1 000 L. Ne pas mélanger leurs volumes, prix ou coûts.
- Le script `verifier_chiffrage_chaudronnerie_lot369.py` recalcule les totaux, vérifie les valeurs actives et écrit un rapport JSON.
- Les sept autres scénarios sont préservés, y compris le scénario historique `recyclage_metaux`, qui ne doit pas être présenté comme celui du mobilier.

**Pour débloquer le BP** : arrêter un produit de référence unique, documenter le dimensionnement et le coût des postes manquants, puis seulement recalculer le moteur et le BP HTML.
