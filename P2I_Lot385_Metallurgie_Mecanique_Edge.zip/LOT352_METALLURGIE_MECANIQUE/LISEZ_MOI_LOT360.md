# P2I — Lot 360 : qualification croisée de la presse plieuse

Correction substantielle du lot 359 : la fiche B2Brazil publiée au nom d’Anhui LIFU affiche explicitement un **prix FOB de 12 700 USD** pour une presse plieuse **WE67K-100T/3200 avec commande DA41**. La fiche Made-in-China du fabricant affiche également 12 700 USD pour une WE67K 100T/3200, sans Incoterm explicite. Les deux références commerciales sont rapprochées, sans présumer qu'elles ont exactement le même contrôleur et le même outillage.

**Décision de qualification :** retenir LIFU comme *candidat prioritaire* pour le poste pliage, plutôt que le prix de presse CORMAK mal identifié. Le prix FOB est documenté par une source publique, mais les caractéristiques exactes, épaisseurs admissibles, matrices et alimentation restent à valider pour la configuration industrielle.

**Pas de substitution silencieuse :** le moteur v107 et les montants financiers actifs restent inchangés. Aucun résultat net nouveau n’est déclaré. Les 160 000 USD d'autres équipements estimés ne deviennent pas des prix catalogues vérifiés.

Sources :
- https://es.b2brazil.com/hotsite/anhuilifu/plegadora-hidraulica-cnc-de-alta-calidad
- https://lifumachinery.en.made-in-china.com/product/qTHrGsdolcWw/China-100t-3200-CNC-Hydraulic-Press-Brake-Machine-with-Low-Price-and-High-Quality.html

Le lot 360 ne clôture pas les huit BP. Il améliore la traçabilité de l’équipement sans fausser les calculs.
