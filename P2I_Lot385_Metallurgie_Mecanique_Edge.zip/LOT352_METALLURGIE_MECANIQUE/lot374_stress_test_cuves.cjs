 'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');const here=__dirname,root=path.resolve(here,'..');const ctx={console,Math,Number,String,Array,Object,Map,Set,JSON,Error,TypeError,Date,Intl,URL,URLSearchParams};ctx.window=ctx;ctx.location={search:'?unit_id=chaudronnerie'};vm.createContext(ctx);
for(let i=0;i<=11;i++)vm.runInContext(fs.readFileSync(path.join(root,'runtime',`script-${i}.js`),'utf8'),ctx,{filename:`script-${i}.js`});
const engine=ctx.P2I_BP_SIMULATION_COMMUNE;const original=JSON.parse(fs.readFileSync(path.join(here,'LOT371_CUVES_INTRANTS_HISTORIQUES_SOURCE.json')));
const results=[];
for(const ventes of [180,210,240,270,294]) for(const matiere of [560,700,850]) for(const prixFactor of [0.9,1,1.1]){
 const x=JSON.parse(JSON.stringify(original));x.machines=61486;x.investissement=160000;x.matieres_kg=matiere;x.cout_production_kg=original.cout_production_kg.map(v=>v+(matiere-original.matieres_kg));
 x.production=[Math.ceil(ventes/0.98),330,360];x.ventes=[ventes,324,354];x.prix=original.prix.map(v=>v*prixFactor);
 const r=engine.calculer(x),a=r.annuel?.[0]||{};
 results.push({ventes_A1:ventes,matiere_usd_cuve:matiere,prix_pct:Math.round(prixFactor*100),prix_usd_cuve:x.prix[0],investissement_usd:160000,ca_A1:a.chiffre_affaires,rn_A1:a.resultat_net,marge_A1_pct:a.chiffre_affaires?100*a.resultat_net/a.chiffre_affaires:null,statut:r.statut,tresorerie_min:Math.min(...(r.tresorerie||[]).map(y=>y.solde_final)),bilan_ecart_max:Math.max(...(r.bilans||[]).map(y=>Math.abs(y.ecart||0)))});
}
fs.writeFileSync(path.join(here,'LOT374_STRESS_TEST_CUVES_V107.json'),JSON.stringify({note:'45 scenarios de sensibilite, non validation industrielle ou commerciale; annees 2-3 conservees pour comparaison seulement',resultats:results},null,2));
fs.writeFileSync(path.join(here,'LOT374_STRESS_TEST_CUVES_V107.csv'),[Object.keys(results[0]).join(','),...results.map(r=>Object.values(r).join(','))].join('\n'));
console.log(JSON.stringify({n:results.length,baseline:results.find(r=>r.ventes_A1===294&&r.matiere_usd_cuve===700&&r.prix_pct===100),stress:results.find(r=>r.ventes_A1===240&&r.matiere_usd_cuve===850&&r.prix_pct===100)},null,2));
