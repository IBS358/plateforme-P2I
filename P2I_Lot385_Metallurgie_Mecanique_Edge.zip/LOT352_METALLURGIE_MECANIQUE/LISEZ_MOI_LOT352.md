# P2I — Lot 352 | Métallurgie & Mécanique

## Contenu livré

- 8 BP Découverte enrichis avec 17 rubriques, navigation locale, impression PDF, variantes et étapes de production numérotées.
- Configurations uniques de référence, tarifs/catalogues publics lorsqu’ils sont disponibles et enveloppes d’équipements complémentaires estimées.
- Calculs relancés par le moteur commun P2I v107 : résultat sur trois ans, financement 40 % apport / 60 % dette, bilan et trésorerie mensuelle 12 mois.
- Matrice des 96 UP actualisée; les 88 lignes hors lot sont conservées sans changement de statut. Les huit BP Services industriels du lot 351 sont conservés intégralement.
- Identifiants de liaison aux futurs modules réservés; BP Pro, tutoriels, formation, conseil et comptabilité ne sont pas développés dans ce lot.

## Résultats financiers A1 (USD)

| UP | CA | Résultat net | Marge nette | Trésorerie minimale mensuelle | Réserve de démarrage |
|---|---:|---:|---:|---:|---:|
| Serrurerie industrielle | 240,000 | 1,053 | 0.44% | 11,029 | 30,944 |
| Fabrication d’outillage manuel | 187,500 | 12,245 | 6.53% | 9,340 | 22,193 |
| Préparation et recyclage des métaux | 385,560 | 8,042 | 2.09% | 18,223 | 56,391 |
| Chaudronnerie industrielle | 390,000 | -56,260 | -14.43% | 35,000 | 131,940 |
| Mécanosoudure industrielle | 828,000 | 94,302 | 11.39% | 26,620 | 97,942 |
| Structures métalliques | 1,021,440 | 30,816 | 3.02% | 32,856 | 139,286 |
| Pièces détachées automobiles | 756,000 | 148,875 | 19.69% | 29,135 | 72,546 |
| Quincaillerie industrielle métallique | 420,000 | 47,556 | 11.32% | 23,321 | 46,881 |

Les résultats déficitaires et les marges étroites sont laissés apparents. Un solde mensuel positif dépend de la réserve d’ouverture calculée; ce n’est pas une preuve de rentabilité. Le bilan est équilibré par le moteur sur trois exercices; cela ne vaut pas audit comptable.

## Réserves prioritaires

- **Chaudronnerie** : résultat A1 négatif; investissement non recommandable avant un chiffrage par commandes/types de pièces et charge atelier.
- **Serrurerie, recyclage ferreux, structures** : marges trop faibles pour conclure à la viabilité; confirmer les prix nets, les matériaux, chantiers et volumes contractés.
- **Outillage** : marge de 6,53 %; confirmer coût de forge, traitement thermique, matrices et prix de gros.
- **Mécanosoudure** : marge de 11,39 % avec un repère CYPE de prix d’ouvrage (et non tarif sortie atelier); vérifier pose, heures et consommables.
- **Pièces auto** : marge élevée mais panier composite indicatif; périmètre limité aux pièces non critiques.
- **Quincaillerie** : tarif et coût unitaire de panier restent des hypothèses faute de cotation locale publiée.
- Les prix machines catalogue sont européens ou budgétaires publics, généralement hors transport. Les enveloppes complémentaires et l’import sont des estimations P2I; les prélèvements sont provisoires jusqu’au classement SH.
- Le logo maître original ne figurait pas dans l’archive source. Les BP n’inventent pas un logo de remplacement et affichent une icône schématique en médaillon.

## Ouvrir localement sous Edge

Décompresser l’archive puis ouvrir `OUVRIR_LOT352.html`. Aucun serveur ni connexion internet n’est nécessaire pour ouvrir les BP et résultats; les liens de sources catalogue nécessitent Internet.
