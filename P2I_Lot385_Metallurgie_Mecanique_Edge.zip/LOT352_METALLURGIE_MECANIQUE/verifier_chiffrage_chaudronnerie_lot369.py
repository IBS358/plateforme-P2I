#!/usr/bin/env python3
import json,re,csv,pathlib,sys
p=pathlib.Path(__file__).resolve().parent
s=(p/'recalculer_lot352_v107.cjs').read_text(encoding='utf-8')
match=re.search(r"\{key:'chaudronnerie'.*?(?=\n\{key:'mecanosoudure')",s,re.S)
if not match:raise SystemExit('ERREUR: scénario chaudronnerie absent')
block=match.group(0)
values={k:float(re.search(r'\b'+k+r':([0-9.]+)',block).group(1)) for k in ('capacity','vol','price','cost','distribution','staff','fixed','capex','machines')}
with (p/'LOT369_NOMENCLATURE_ET_LACUNES.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f,delimiter=';'))
subtotal=sum(float(r['Sous-total USD']) for r in rows if r['Fonction'] not in ('TOTAL CANDIDATS',) and r['Sous-total USD'])
missing=[r['Fonction'] for r in rows if r['Base']=='À documenter']
with (p/'SIMULATIONS_V107_LOT352.json').open(encoding='utf-8') as f:data=json.load(f)
scenario=next((x for x in data['scenarios'] if x['up_id']=='chaudronnerie'),None)
if scenario is None:raise SystemExit('ERREUR: résultat moteur manquant')
a1=scenario['result']['annuel'][0]
assert abs(a1['resultat_net']-(-56260))<2,'ERREUR: base A1 a changé sans validation'
assert abs(a1['chiffre_affaires']-390000)<2,'ERREUR: CA A1 a changé sans validation'
report={'scenario_actif':values,'cout_FOB_candidats':subtotal,'budget_machines_moteur':values['machines'],'ecart_non_justifie':values['machines']-subtotal,'postes_non_chiffres':missing,'resultat_net_A1':a1['resultat_net'],'chiffre_affaires_A1':a1['chiffre_affaires'],'conclusion':'NON VALIDÉ — prix candidats et nomenclature incomplète; interdiction de publier une marge bénéficiaire comme résultat actif'}
(p/'LOT369_CONTROLE_EXECUTABLE_RESULTAT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
if not missing:raise SystemExit('ALERTE: aucune lacune identifiée, revoir le contrôle')
