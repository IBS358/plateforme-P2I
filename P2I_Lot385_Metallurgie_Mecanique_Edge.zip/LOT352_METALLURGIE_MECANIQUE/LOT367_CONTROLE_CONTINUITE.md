# P2I — Contrôle de continuité opérationnelle du lot 367

Base : archive intégrale du lot 366, conservée sans remplacement des hypothèses financières.

## Modifications effectivement appliquées

- BP actif `BP_FINALISES/chaudronnerie.html` : correction de la note périmée CORMAK, qui disait encore que la presse plieuse devait être remplacée alors que la candidate LIFU était déjà inscrite au tableau.
- Suppression des liens externes cliquables vers les catalogues fournisseurs dans ce BP public, conformément à la règle P2I. Les références techniques et leurs prix restent visibles ; les URL des sources restent conservées dans les fichiers internes de qualification.
- Ajout d'un avertissement financier dans le BP actif : résultat net A1 **−56 260 USD**, CAPEX **350 000 USD**, machines **250 000 USD**. La sensibilité à **170 000 USD** n'est pas le scénario officiel.
- Création d'une matrice de contrôle des huit simulations actives, sans altérer les autres unités.

## Points bloquants non résolus

1. La configuration de référence reste un atelier polyvalent de 60 commandes/an, et non la configuration historique des 294 cuves inox. **Ne pas les fusionner** : nomenclatures, cadences et marchés distincts.
2. Le moteur v107 garde l'enveloppe forfaitaire de 250 000 USD de machines. Les candidats catalogues ne suffisent pas encore à constituer une BOM complète et compatible.
3. La matrice financière du recyclage des métaux reste présente dans le JSON v107, alors que le remplacement de cette UP par Mobilier métallique a été décidé historiquement. Cela nécessite une vraie reconfiguration du scénario ; ne pas transférer les chiffres du recyclage au mobilier.
4. Le résultat négatif de la Chaudronnerie n'est pas corrigé. Aucun prix de vente, cadence ou marge n'a été modifié artificiellement.

## Contrôles de conservation

- Archive complète du lot 366 reprise ; fichiers non visés recopiés sans modification.
- Les 8 scénarios v107 d'origine sont conservés et leurs résultats A1 inchangés.
- Les 17 sections du BP Chaudronnerie sont conservées.
- Aucun accès ni modification à GitHub `main`.

**Statut : correctif de cohérence du BP actif, pas validation industrielle ni financière.**
