# P2I — Lot 358 | Qualification documentaire des équipements

Source : copie intégrale du lot 357. Aucun changement des chiffres financiers ni des 88 autres UP.

- Registre des équipements : classification des prix publics déclarés, enveloppes estimatives et incompatibilité de référence.
- Chaudronnerie : la CORMAK 100T n'est pas démontrée comme presse plieuse. Avertissement ajouté au BP; aucune machine de remplacement ni prix n'a été inventé.
- Outillage et quincaillerie : contrôle de compatibilité procédé de la presse CORMAK 100T signalé dans les BP.
- 17 rubriques et visuels préservés; archives historiques préservées.

ATTENTION : prix « déclarés » dans l'archive et non revérifiés en ligne dans ce lot. Ce lot n'est pas une validation industrielle ni une correction de rentabilité.
