# P2I — Lot 383 : récupération du calcul mobilier existant (pas de nouveau BP)

## Correction de continuité démontrée
Le lot 382 qualifiait le mobilier de `NON_CALCULE` dans son champ de suivi actif. Cette étiquette est **incomplète** : le BP historique `LOT229/BP_MOBILIER_SCOLAIRE_PROFESSIONNEL_17_RUBRIQUES.html`, repris comme `LOT352_METALLURGIE_MECANIQUE/BP_FINALISES/mobilier_metallique.html`, contient déjà un résultat du moteur v107. Aucun résultat de l'ancien recyclage des métaux n'est transféré.

## Référence historique réellement présente dans le BP du lot 229
- Gammes : table-banc 33 000 FCFA (variable 25 200), bureau 110 000 (variable 71 000), armoire 160 000 (variable 108 000).
- Volumes A1 : 2 300 tables-bancs, 320 bureaux, 180 armoires. CA = 75 900 000 + 35 200 000 + 28 800 000 = **139 900 000 FCFA**.
- Coûts variables directs théoriques : 57 960 000 + 22 720 000 + 19 440 000 = **100 120 000 FCFA** ; contribution brute 39 780 000 FCFA avant frais fixes, salaires, amortissements et intérêts.
- Résultats v107 consignés dans le BP historique : A1 RN **4 348 583 FCFA**, marge **3,11 %** ; A2 RN **18 594 436 FCFA**, marge **7,80 %** ; A3 RN **25 449 378 FCFA**, marge **8,13 %**.
- Hypothèse CAPEX historique : **45 000 USD**, dont machines **30 000 USD**, explicitement exploratoire et sans nomenclature catalogue complète.
- Capacité historique : **5 810 heures directes A1**, sans validation de capacité effective ni temps d'arrêt.
- Risque de trésorerie historique : crédit client réel non répercuté dans le calendrier standard v107 ; besoin de couverture opérationnelle indicatif jusqu'à **16 502 570 FCFA**.

## Décision sans nouvelle boucle
**Conserver la configuration et les calculs du lot 229 comme acquis historiques ; ne pas qualifier le BP de finalisé.** La marge A1 de 3,11 % ne franchit pas la cible P2I et la nomenclature machines reste exploratoire. Ne pas artificiellement augmenter les prix de vente ou réduire les coûts pour afficher 10 %. Ne pas relancer les 12 stress tests du lot 216.

Le champ `lot382_etat_reel=NON_CALCULE` est laissé intact pour la traçabilité de la décision du lot 382 ; le nouvel état `lot383_preuve_v107_historique=OUI_LOT229_NON_REEXECUTE` rétablit la vérité historique. La colonne `scenarios_calcules=0` héritée du lot 352 est conservée et ne doit pas être lue comme absence totale de calcul historique.

**Priorité suivante** : poursuivre la filière sur Serrurerie et Structures avec leurs données existantes, sans inventer de rentabilité ni refaire la Chaudronnerie.
