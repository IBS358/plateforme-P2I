# P2I — Lot 363 : soudage, prix FOB publics — qualification partielle

Deux candidats de soudage industriel ont été documentés à partir du catalogue public de Beijing Aland Welding. Le poste NB350D (350 A) affiche une fourchette FOB 999–1 163 USD; le poste MIG 500 A affiche 1 150–1 350 USD. MOQ 1 ensemble selon le catalogue.

Ces postes sont des CANDIDATS, pas des machines intégrées à la configuration définitive. La sélection exige une nomenclature de produits (acier/inox, épaisseurs), le procédé adapté (MIG/MAG/TIG), le facteur de marche, la puissance électrique, le gaz, la sécurité et le nombre de postes.

Les quatre postes précédemment identifiés (pliage 12 700; cisaillage 15 500; roulage 21 500; plasma 4 790 USD) totalisent 54 490 USD, sous réserve des prix et spécifications documentés dans les registres des lots 360–362. Avec UN poste NB350D au prix bas, la somme illustrative est 55 489 USD, hors équipements restants, importation, installation et BFR. Cette somme N'EST PAS un CAPEX complet ni un scénario v107.

Aucun résultat financier, capacité, hypothèse commerciale ou BP HTML n'a été modifié dans ce lot. L'ancien résultat déficitaire reste inchangé. Aucun équipement sans prix public ne doit être présenté comme machine retenue dans le BP Découverte final.

Source publique : https://alandwelding.en.made-in-china.com/productList?selectedSpotlightId=eEWGwndAYpVI
