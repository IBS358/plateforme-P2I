# Lot 359 — qualification ciblée de la presse plieuse Chaudronnerie

La presse CORMAK 100T du lot 358 ne doit pas être assimilée sans preuve à une presse plieuse. Deux références de presses plieuses réelles, avec prix publics affichés pour une unité, sont désormais documentées dans CANDIDATS_PRESSES_PLIEUSES_LOT359.csv.

Ces prix sont des prix publics de fiches fournisseurs, **pas encore des prix EXW/FOB attestés**. Les machines ne sont donc pas substituées automatiquement dans le BP et aucun résultat financier n'a été recalculé. La fiche Hudong présente aussi une incohérence entre son intitulé 100T et la valeur 1600 kN; cela impose une confirmation technique.

Il faut vérifier la force utile, l'épaisseur des tôles, le rayon de pliage, la largeur, les outillages, les consommations, les délais et la compatibilité avec la configuration de référence. Les 160 000 USD d'équipements complémentaires du BP restent une enveloppe non ventilée et non validée par des prix catalogues individuels.

**Périmètre :** ajout de preuves documentaires; aucun changement des 96 UP, des BP HTML, des résultats v107 ou de GitHub.
