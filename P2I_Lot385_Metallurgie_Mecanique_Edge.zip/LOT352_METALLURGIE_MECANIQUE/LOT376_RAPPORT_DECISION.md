# P2I — Lot 376 : verrouillage de la configuration des cuves inox 1 000 L

## Décision de continuité
Le produit reste **cuve atmosphérique inox 304L 1 000 L, fond plat et couvercle posé, tôles prédécoupées achetées**. Aucune machine nouvelle n'est inventée, aucun résultat financier historique n'est remplacé. Le BP public et les sept autres BP restent inchangés.

## Nomenclature fonctionnelle vérifiée
Les 8 opérations conservées par le lot 375 incluent **5 postes sans prix** et **3 machines candidates dont les compatibilités ne sont pas démontrées**. Le sous-total FOB des trois candidates est **24,500 USD**, dont 2 000 USD de pont roulant conditionnel. Ce n'est pas un budget complet. Les 36 986 USD d'équipements écartés de l'atelier polyvalent ne sont pas une économie nette démontrée.

## Capacité : contrôle quantifié
La capacité historique saisie dans le moteur est 0.216667 cuve/heure, soit 4.62 heures/cuve (valeur paramétrique, non mesure chronométrée). Pour 300, 360, 420 cuves produites en A1-A3, cela représente 1384.6, 1661.5, 1938.5 heures de capacité nominale. Sur une base exploratoire de 2 000 heures/an, l'A3 utilise 96.9% du temps disponible avant arrêts et rebuts : la croissance A3 n'est pas démontrée.

## Écarts empêchant la publication
1. Plan dimensionnel et fabrication complet, épaisseur, piquages, fonds et couvercle.
2. Capacité de la rouleuse W12 à diamètre 1 m et inox 304L à épaisseur retenue; fiche constructeur.
3. Nombre de postes TIG, facteur de marche, temps de soudage et essais de procédé.
4. Outillages, gabarits, tables, bridages, finition, passivation, ventilation et contrôle d'étanchéité : modèles et prix publics.
5. Pont roulant : nécessité et intégration au bâtiment, ou alternative de manutention chiffrée.
6. FOB vers coût rendu-installé (fret, douanes, assurance, installation, électricité, formation, pièces), fonds de roulement et financement.
7. Prix d'achat de tôles inox prédécoupées livrées en Côte d'Ivoire, accessoires et consommables; débouchés commerciaux et prix unitaire.
8. Mesure réelle du cycle de production et du taux d'utilisation; ne pas assimiler 420 cuves à une capacité validée.

## Règle d'intégration
Les simulations v107 des lots 372 à 374 sont conservées comme **sensibilités**, sans transfert dans le BP public. Le statut `VALIDÉ` n'est autorisé que lorsque chaque fonction indispensable possède une solution technique et un coût vérifiables, et que les contrôles financiers v107 passent sur cette nomenclature. Aucun devis officiel n'est requis pour le BP Découverte : seuls des prix catalogues publics documentés le sont.
