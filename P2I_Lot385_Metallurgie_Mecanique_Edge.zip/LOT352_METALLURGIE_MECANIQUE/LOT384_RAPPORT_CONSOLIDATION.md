# P2I — Lot 384 : récupération des acquis et arrêt des recalculs répétitifs

## Découverte déterminante
Le fichier historique `P2I_Metallurgie_Recalcul_Historique_V107.csv` contient **sept simulations v107 réellement réexécutées** (lot 126), dont :
- Serrurerie industrielle (cylindres européens assemblés) : **12,37 %** de marge A1, RN +62 496,13 USD.
- Structures métalliques (éléments IPE travaillés en atelier, deux équipes) : **8,04 %** de marge A1, RN +87 071,49 USD.
- Mécanosoudure (portillons grillagés) : **11,05 %** ; outillage (pelles carrées) : **10,67 %**.
- Usinage pièces maintenance : **9,71 %** ; quincaillerie pointes : **6,39 %** ; chaudronnerie historique : **19,24 %** (avant les corrections de cadence, matière et investissement des lots 373–381).

Le Mobilier (lot 229) a un calcul v107 historique : **3,11 % A1**, sans validation du crédit client et de la nomenclature.

## Interprétation impérative
Les faibles marges 0,44 % (Serrurerie) et 3,02 % (Structures) proviennent de **configurations actives du lot 352 différentes** des configurations historiques corrigées. Elles ne démontrent pas que les anciennes corrections ont été perdues : elles montrent une **rupture de périmètre**. Ne pas réexécuter le moteur pour « corriger » ces marges sans choisir d'abord la configuration produit retenue.

## Livrables effectifs
- Une matrice 8 UP CSV + JSON avec preuve et divergence explicites.
- Une page HTML autonome de navigation vers les huit BP actifs existants, affichant les marges historiques **et** les marges actives sans les confondre.
- Conservation des fichiers des 383 lots précédents présents dans l'archive source.

## Limites et décision
**Aucun des huit BP n'est nouvellement déclaré finalisé** : la preuve des prix catalogues, la compatibilité des machines, les 17 rubriques visuelles et les flux financiers consolidés ne sont pas tous établis pour les configurations retenues. Les marges historiques ne sont pas substituées aux marges actives. Aucun nouveau calcul n'a été lancé. Les huit BP actifs et les 88 autres UP sont conservés.

**Priorité opérationnelle** : intégrer dans le BP actif les configurations historiques lorsqu'elles correspondent au produit réellement retenu, et achever le BP Mobilier en utilisant ses résultats existants. Éviter de produire de nouveaux scénarios sans résoudre le changement de périmètre.
