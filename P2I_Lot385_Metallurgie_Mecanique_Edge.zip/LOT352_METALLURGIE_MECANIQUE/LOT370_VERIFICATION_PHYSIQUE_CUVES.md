# Lot 370 — Retour à la configuration historique, vérification de cohérence physique

## Acquis préservés
Source : lot 369 complet. Les 8 simulations v107, les 17 rubriques des BP, les 7 machines candidates et les 88 autres UP sont conservés sans modification. Aucun résultat net n'est changé et aucun prix catalogue nouveau n'est inventé.

## Incompatibilité majeure constatée
Le BP financier actif parle de **60 commandes polyvalentes/an**, à **2,5 tonnes de tôles/profilés par commande** (texte du script v107), soit **150 tonnes/an** de matière annoncée. La configuration historique mentionnée dans les travaux antérieurs porte sur **294 cuves atmosphériques inox de 1 000 L/an**. Ces volumes et coûts ne peuvent pas être fusionnés.

## Test physique reproductible : cuve verticale cylindrique 1 000 L
Hypothèses exploratoires (NON validées): cuve cylindrique fermée avec deux fonds plats; volume intérieur nominal 1 m³, densité inox 7 930 kg/m³; épaisseur uniforme 2–4 mm; sans pieds, renforts, piquages, couvercle complexe ni soudure additionnelle. Ce ne sont pas des spécifications de fabrication.

Pour **diamètre 1,0 m, épaisseur 3 mm** : hauteur cylindrique 1.273 m; surface de tôle 5.571 m²; masse géométrique 132.5 kg, ou 152.4 kg avec 15 % de chutes. À 294 cuves/an et 250 jours de production : **1,18 cuve/jour**; masse matière théorique avec chutes ~44.8 t/an (hors accessoires).

**Conséquence** : la consommation annoncée de 2,5 tonnes par commande polyvalente ne doit pas être reportée sur une cuve inox de 1 000 L. Ce serait un mélange de deux produits et deux gammes de coûts.

## Blocages industriels explicites
- Définir si cuve ouverte ou fermée, fonds plats ou bombés, épaisseur mécanique, nuances 304/316, finition et exigences alimentaires; vérifier charge hydrostatique, flambage, stabilité, nettoyage et contrôles.
- Vérifier rouleuse (diamètre mini, épaisseur inox), découpe et dimensions des tôles, soudures TIG/MIG inox et facteur de marche, levage et sécurité.
- Reconstituer les **prix matière inox**, les heures de fabrication, les consommables, les pertes et le prix de vente local de la cuve. Les 294 cuves/an ne sont pas une preuve de commandes commerciales.
- Raccorder seulement ensuite cette nomenclature et la capacité à un nouveau scénario v107, sans modifier le scénario polyvalent tant que le remplacement n'est pas justifié.

## Statut
**ÉTUDE TECHNIQUE EXPLORATOIRE — BP NON VALIDÉ.** La simulation active demeure RN A1 = −56 260 USD. Ce lot apporte une base physique chiffrée et reproductible, pas un nouveau BP bénéficiaire.
