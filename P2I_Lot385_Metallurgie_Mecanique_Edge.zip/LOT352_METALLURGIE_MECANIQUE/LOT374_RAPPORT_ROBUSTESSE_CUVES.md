# Lot 374 — Test de robustesse commercial des cuves 1 000 L

Source : lot 373 et intrants historiques du lot 371. Moteur v107 exécuté sur 45 combinaisons de volume A1, coût matière et prix de vente.

**Attention :** les 160 000 USD d’investissement et les 61 486 USD de machines restent des hypothèses et candidats non validés. Les volumes de vente et le prix de marché ne sont pas démontrés. Les années 2–3 ne sont pas recalibrées pour refléter une éventuelle faiblesse durable des ventes.

| Ventes A1 | Matière 560 USD | Matière 700 USD | Matière 850 USD |
|---:|---:|---:|---:|
| 180 | 22,918 USD (8.3 %) | 4,018 USD (1.5 %) | -21,642 USD (-7.8 %) |
| 210 | 37,347 USD (11.6 %) | 15,297 USD (4.7 %) | -11,104 USD (-3.4 %) |
| 240 | 51,753 USD (14.0 %) | 26,553 USD (7.2 %) | -596 USD (-0.2 %) |
| 270 | 66,181 USD (16.0 %) | 37,831 USD (9.1 %) | 7,456 USD (1.8 %) |
| 294 | 77,709 USD (17.2 %) | 46,839 USD (10.4 %) | 13,764 USD (3.0 %) |

Les valeurs ci-dessus conservent le prix historique de vente. Les 45 résultats et les contrôles de trésorerie et bilan figurent dans les fichiers CSV/JSON.

## Limites à lever avant publication
- Prix de vente vérifié en Côte d’Ivoire et carnet de commandes permettant les volumes projetés.
- Nomenclature de fabrication complète : rouleuse compatible 304L 3 mm, postes TIG, soudure des fonds, bridage, épreuves et contrôle, finitions, accessoires, manutention.
- Prix catalogues FOB individuels et coûts complets rendus-installés; ne pas interpréter le différentiel avec l’enveloppe initiale comme une économie.
- Masse de tôle, plans de cuve, couvercle, pertes matière et coût réel d’inox découpé.
- Cadence, qualité, temps de soudure, reprises et disponibilité atelier.

**Statut :** simulation de sensibilité, pas BP Découverte finalisé. Aucun BP HTML actif modifié, aucune autre UP changée.
