# Lot 377 — Qualification technique ciblée de la rouleuse, sans remise à zéro

## Base historique conservée
Cuve inox 304L atmosphérique de 1 000 L, fond plat, couvercle posé, tôles prédécoupées achetées (lot 371). Diamètre exploratoire 1 000 mm, hauteur de virole 1 273 mm, épaisseur exploratoire 3 mm. Les chiffres sont des hypothèses de conception, non un plan d'exécution validé.

## Vérification externe de la famille W12
Le catalogue WMT CNC, W12, pages 61–62, documente une W12-6×1500 : épaisseur de roulage max 6 mm, pré-cintrage 4 mm, largeur max 1 500 mm, diamètre minimal sous pleine charge 300 mm, vitesse 4 m/min, moteur 4 kW. Cela fournit une **correspondance géométrique préliminaire** pour une virole de 1 273 mm de haut, 3 mm d'épaisseur, diamètre 1 000 mm. La réserve principale demeure la limite d'élasticité indiquée pour la machine (catalogues de famille souvent fondés sur 245 MPa), les propriétés réelles du 304L et les marges de travail, le plan de soudure et les chutes.

Source : https://cncwmt.com/wp-content/uploads/2023/10/New-WMT-CNC-CATA-2023-Conventional-machines1.pdf

Un autre fabricant publie des exemples de roulage d'inox 304 sur une machine à quatre rouleaux, mais **cela ne qualifie pas la machine WMT précise** : https://etwinternational.co.uk/3-4-roll-plate-bending-machine-c6051j16203.html

## Décision
1. **W12-6×1500 = variante technique à étudier**, et non machine validée. Le modèle exact associé au prix de 21 500 USD FOB des lots précédents n'est pas identifié. Il est interdit d'affecter ce prix à la W12-6×1500 sans source de prix correspondant à ce modèle précis.
2. Conserver 21 500 USD dans le registre historique en tant que **prix candidat non attribuable**, hors budget de référence validé.
3. Vérifier prix public EXW/FOB de la variante exacte, capacité sur 304L 3 mm et largeur utile avec tolérances, puis procéder au choix final.
4. Aucun changement des calculs v107, des 8 BP HTML ni de la matrice des 96 UP : la configuration n'est pas encore validée.

## Autres points industriels à ne pas masquer
La cadence historique 420 cuves/an demande ~1 938 h au rythme de 0,21667 cuve/h, soit ~96,9 % de 2 000 h théoriques. Cette capacité n'intègre pas les arrêts. Le coût complet de l'atelier et les 5 opérations non chiffrées du lot 376 restent ouverts.
