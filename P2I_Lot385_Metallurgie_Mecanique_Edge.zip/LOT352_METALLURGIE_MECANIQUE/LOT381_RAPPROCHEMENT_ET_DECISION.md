# Lot 381 — Rapprochement immédiat du budget avec la nomenclature spécialisée

Configuration inchangée : cuve inox 304L nominale 1 000 L, tôles prédécoupées, 280/320/340 productions et 274/314/334 ventes.

- Panier machines polyvalent 61 486 USD : **retiré du calcul spécialisé**.
- Machines candidates retenues : rouleuse 21 500 USD, TIG 1 000 USD, levage 2 000 USD = **24 500 USD FOB** (prix/modeles à confirmer).
- Autres postes d'investissement déjà estimés : **65,409.36 USD**.
- Investissement total de travail recalculé : **89,909.36 USD**, sans réserve artificielle pour atteindre 160 000 USD.
- RN A1/A2/A3 : **46,881.04 / 61,342.85 / 66,535.42 USD**.
- Minimum de trésorerie mensuelle : **10,293.19 USD**.

**Limite impérative** : ce recalcul ne signifie pas que la nomenclature est complète. Les gabarits, supports, équipements de contrôle, sécurité, finition et utilités nécessaires restent à rattacher aux postes et à chiffrer. Les coûts annexes existants sont des estimations et ne valent pas prix catalogues. Le BP public original et les 88 autres UP ne sont pas modifiés. La page HTML est une prévisualisation.
