'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const here=__dirname,root=path.resolve(here,'..'),runtime=path.join(root,'runtime');
const ctx={console,Math,Number,String,Array,Object,Map,Set,JSON,Error,TypeError,Date,Intl,URL,URLSearchParams};ctx.window=ctx;ctx.location={search:'?unit_id=chaudronnerie'};vm.createContext(ctx);
for(let i=0;i<=11;i++){let name=`script-${i}.js`;vm.runInContext(fs.readFileSync(path.join(runtime,name),'utf8'),ctx,{filename:name});}
const engine=ctx.P2I_BP_SIMULATION_COMMUNE;
if(!engine?.calculer)throw Error('Moteur v107 non disponible');
const source=JSON.parse(fs.readFileSync(path.join(here,'LOT371_CUVES_INTRANTS_HISTORIQUES_SOURCE.json'),'utf8'));
const result=engine.calculer(source);
const output={schema:'p2i.lot372.simulation-historique-separee.v1',avertissement:'Simulation sur intrants historiques bruts, sans validation de BOM, du champ matieres_kg, de la capacité ni des prix; ne remplace pas le BP actif.',source:'LOT371_CUVES_INTRANTS_HISTORIQUES_SOURCE.json',intrants:source,sortie:result};
fs.writeFileSync(path.join(here,'LOT372_SIMULATION_CUVES_HISTORIQUES_V107.json'),JSON.stringify(output,null,2));
const a=result.annuel||[];const cash=result.tresorerie||[];
const summary={statut:result.statut,version:result.version,annees:a.map(x=>({annee:x.annee,ventes:x.ventes,ca:x.chiffre_affaires,rn:x.resultat_net,marge_pct:x.chiffre_affaires?x.resultat_net/x.chiffre_affaires*100:null})),cash_min:cash.length?Math.min(...cash.map(x=>x.solde_final)):null,bilans:(result.bilans||[]).map(x=>({annee:x.annee,ecart:x.ecart})),controles:result.controles};
fs.writeFileSync(path.join(here,'LOT372_RESUME_SIMULATION_CUVES.json'),JSON.stringify(summary,null,2));
console.log(JSON.stringify(summary,null,2));
