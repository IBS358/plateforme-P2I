# Lot 373 — Sensibilités financières réexécutées sur les cuves historiques

## Périmètre
Source inchangée : `LOT371_CUVES_INTRANTS_HISTORIQUES_SOURCE.json`. Moteur commun v107 (`runtime/script-0.js` à `script-11.js`). Script exécutable : `lot373_sensibilites_cuves.cjs`. Aucun changement au BP HTML actif, aux autres UP, ni à `main`.

## Résultats
| Scénario | RN A1 USD | Marge A1 |
|---|---:|---:|
| historique_original | 86,857.27 | 19.24 % |
| investissement_130k_matiere_historique | 80,949.51 | 17.93 % |
| investissement_160k_matiere_historique | 77,718.51 | 17.21 % |
| investissement_160k_matiere_700 | 46,838.75 | 10.37 % |
| investissement_160k_matiere_850 | 13,763.75 | 3.05 % |

## Méthode
- Scénarios à 130k/160k USD : budgets d'investissement **hypothétiques**, et machines à 61 486 USD FOB **candidates non validées**. Le coût complet rendu-installé n'est pas prouvé.
- La cadence alternative est de 300, 330 et 360 cuves fabriquées, avec 294, 324 et 354 vendues. Elle est plus prudente que 420 cuves en A3, mais reste à valider en atelier et sur le marché.
- À chaque variation du coût matière, le coût industriel par cuve est augmenté du même montant pour conserver les autres coûts de conversion historiques. Il ne s'agit pas d'une nouvelle étude des coûts de main-d'œuvre et d'énergie.
- Les scénarios de prix matière à 700 et 850 USD/cuve ne sont pas des cotations fournisseurs. La donnée historique de 559,96 USD/cuve est un montant monétaire, pas une masse.
- Le dimensionnement exploratoire du lot 370 (152,4 kg de tôles avec chutes) permet d'établir un prix implicite historique de 3,67 USD/kg **rendu atelier**, mais la conception du couvercle, les épaisseurs, les renforts, le coût des tôles prédécoupées et la masse définitive ne sont pas validés.
- Le contrôle du moteur peut produire des bilans équilibrés sans démontrer la faisabilité industrielle, le financement bancaire ni les ventes.

## Références publiques complémentaires, non substituées aux devis ni aux données P2I
- Saky Steel, bulletin de septembre 2026 : tôles 304L No.1 autour de 2,393 USD/kg (prix indicatif, hors transport et prestations) : https://www.sakysteel.com/news/china-stainless-steel-market-price-update-september-9-2026
- Omega Steel, bande indicative FOB Istanbul septembre 2026, 304L 2B de 3,05 à 3,60 USD/kg : https://omegasteelco.com/products/stainless/304l-stainless-steel-sheet/
Ces fourchettes ne constituent ni un prix rendu Côte d'Ivoire ni un prix confirmé pour des tôles prédécoupées aux dimensions requises.

## Décision de continuité
**Ne pas substituer ces simulations au BP public**. Étape suivante unique et substantielle : BOM spécialisée pour cuves 1 000 L, avec prix catalogues par équipement, compatibilité de la rouleuse, TIG, bridages, finition, contrôle, frais logistiques et atelier; puis coûts complets, validation cadence et marché. Préserver les autres UP.
