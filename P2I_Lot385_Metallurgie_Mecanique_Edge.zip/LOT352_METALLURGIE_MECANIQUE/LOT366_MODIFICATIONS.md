# P2I — Lot 366 : correction effective de la fiche Chaudronnerie

- Correction dans le tableau du BP HTML : suppression de CORMAK 100T comme presse plieuse retenue ; mention d’une référence candidate Anhui LIFU WE67K-100T/3200 à 12 700 USD FOB, déjà documentée au lot 360.
- Ajout d’un candidat TIG pour l’inox, avec source fournisseur et prix FOB public de 1 000 USD par poste.
- Les deux références demeurent à vérifier techniquement avant sélection définitive.
- Le moteur v107 et le résultat financier n’ont pas été recalculés. La perte de la Chaudronnerie et l’enveloppe estimée de 160 000 USD demeurent ; ne pas présenter le BP comme validé.
- Aucun autre BP modifié ; aucune action GitHub.
