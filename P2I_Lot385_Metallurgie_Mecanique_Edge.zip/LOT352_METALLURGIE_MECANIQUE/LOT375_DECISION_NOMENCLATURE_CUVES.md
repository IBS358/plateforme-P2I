# Lot 375 — Nomenclature spécialisée issue du produit historique, sans nouveau dimensionnement financier

## Décision de continuité
La référence reste **cuve inox 304L atmosphérique de 1 000 litres, fond plat et couvercle posé, tôles prédécoupées achetées** (intrants historiques du lot 371). Les 61 486 USD de candidats du lot 369 correspondent à un **atelier polyvalent** et ne sont pas automatiquement nécessaires à cette référence.

## Tri industriel effectif
- **Roulage W12 : 21 500 USD FOB candidat** — fonction nécessaire, mais diamètre minimum et capacité réelle inox non confirmés.
- **TIG Aland 200 A : 1 000 USD FOB candidat** — soudage inox nécessaire, mais puissance, facteur de marche et nombre de postes non démontrés.
- **Pont roulant Leitai 2 t : 2 000 USD FOB candidat** — manutention à prévoir, mais modèle et bâtiment non qualifiés; choix conditionnel.
- **Presse LIFU 12 700, cisaille WMT 15 500, plasma Senke 4 790, quatre MIG/MAG Aland 3 996 USD** : **36 986 USD de candidats écartés du périmètre de référence**, faute d'opération indispensable démontrée. Ils restent dans les dossiers historiques et pourront être requalifiés si besoin technique établi; ils ne sont pas supprimés de l'archive.

Sous-total **24 500 USD FOB candidats conditionnels**, à ne **jamais** confondre avec le budget machines ou le coût rendu-installé. Le coût de tables/bridages, contrôle, passivation, aspiration, électricité, outillage, accessoires, fret, installation, sécurité et manutention adaptée est **inconnu**. Les prix candidats proviennent des dossiers historiques et n'ont pas été revalidés auprès des fournisseurs dans ce lot.

## Blocages réels
1. Définir un plan de fabrication avec fond, couvercle, piquages, accessoires et tolérances, et confirmer les épaisseurs.
2. Vérifier la W12 pour inox 304L à 3 mm et diamètre de 1 m; vérifier la capacité TIG et les heures par cuve. La cadence de 300 unités/an n'est pas acquise.
3. Compléter et chiffrer la nomenclature **avec prix publics vérifiables pour chaque machine retenue**, frais logistiques et installation; exclure tout équipement non justifié.
4. Recalculer le moteur v107 sur un investissement **documenté**, pas sur les 160 000 USD arbitraires des sensibilités.
5. Étayer coût inox livré et prix de vente ivoirien; conserver les 45 sensibilités comme analyses, non comme BP actif.

## Intégrité et non-régression
Les huit BP HTML, les simulations actives, les 17 rubriques, les autres UP et les fichiers sources sont **inchangés**. Cette livraison tranche un choix de périmètre industriel mais **ne valide pas** encore le BP Découverte.
