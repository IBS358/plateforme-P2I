#!/usr/bin/env python3
"""Géométrie indicative d'une cuve atmosphérique cylindrique de 1000 L; ne remplace pas le calcul de résistance ni les vérifications sanitaires."""
import math,csv,sys
V=1.0; rho=7930; jours=250; volume=294
writer=csv.writer(sys.stdout);writer.writerow(['diametre_m','hauteur_m','epaisseur_mm','surface_m2','masse_kg','masse_avec_chutes_kg','cuves_par_jour'])
for d in (0.9,1.0,1.1,1.2):
 h=4*V/(math.pi*d*d)
 for e in (2,3,4):
  a=math.pi*d*h+math.pi*d*d/2;m=a*e/1000*rho
  writer.writerow([d,round(h,3),e,round(a,3),round(m,1),round(m*1.15,1),round(volume/jours,2)])
