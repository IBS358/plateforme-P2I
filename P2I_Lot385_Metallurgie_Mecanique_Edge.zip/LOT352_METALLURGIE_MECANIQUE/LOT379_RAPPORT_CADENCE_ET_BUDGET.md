# Lot 379 — Cadence exploitable et cohérence du budget investissement

**Étude de sensibilité, pas validation industrielle.** Configuration de cuves inox 304L nominales 1 000 L conservée. Aucune modification des huit BP publics ni de la matrice 96 UP.

## Résultats v107

| Scénario | Production A1/A2/A3 | Ventes A1/A2/A3 | Matière USD/cuve | RN A1 | RN A3 | Trésorerie minimale |
|---|---|---|---:|---:|---:|---:|
| baseline_lot373 | 300/330/360 | 294/324/354 | 700 | 46,839 | 67,413 | 17,301 |
| cadence_80pct_avec_stocks | 280/320/340 | 274/314/334 | 700 | 39,332 | 59,996 | 17,093 |
| cadence_85pct_avec_stocks | 290/330/360 | 284/324/354 | 700 | 43,085 | 67,413 | 17,197 |
| cadence_80pct_matiere_850 | 280/320/340 | 274/314/334 | 850 | 8,507 | 22,421 | 16,236 |
| cadence_85pct_matiere_850 | 290/330/360 | 284/324/354 | 850 | 11,135 | 27,588 | 16,309 |

## Contrôles et limites
- Le scénario de 340 cuves A3 demande 1 569 h à la cadence historique, soit 78,4 % des 2 000 h théoriques ; 360 cuves demandent 1 662 h, soit 83,1 %. Les opérations parallèles et la disponibilité machine restent à confirmer.
- Le budget de 160 000 USD est un test de sensibilité, pas un investissement validé. Une ligne de réserve non ventilée réconcilie les postes détaillés et le total pour éviter une incohérence arithmétique.
- Le montant machines de 61 486 USD est le panier polyvalent historique, et non une nomenclature finale spécialisée.
- Le prix de vente historique, les commandes, les tôles inox, les consommables, le coût du travail et les opérations auxiliaires doivent être validés.
- Ne pas publier les résultats dans les BP HTML avant validation industrielle et commerciale.
