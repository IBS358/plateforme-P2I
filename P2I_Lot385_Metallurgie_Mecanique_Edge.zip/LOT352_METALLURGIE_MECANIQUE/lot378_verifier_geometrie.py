# Script autonome de vérification du dimensionnement exploratoire.
import math
D=1.0
for f in [1.0,.95,.90,.85]:
 h=1/(math.pi*(D/2)**2*f)
 print(f"Remplissage {f:.0%}: hauteur {h*1000:.1f} mm, marge W12-1500 {1500-h*1000:.1f} mm")
