 'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');const here=__dirname,root=path.resolve(here,'..');const ctx={console,Math,Number,String,Array,Object,Map,Set,JSON,Error,TypeError,Date,Intl,URL,URLSearchParams};ctx.window=ctx;ctx.location={search:'?unit_id=chaudronnerie'};vm.createContext(ctx);
for(let i=0;i<=11;i++)vm.runInContext(fs.readFileSync(path.join(root,'runtime',`script-${i}.js`),'utf8'),ctx,{filename:`script-${i}.js`});
const engine=ctx.P2I_BP_SIMULATION_COMMUNE, original=JSON.parse(fs.readFileSync(path.join(here,'LOT371_CUVES_INTRANTS_HISTORIQUES_SOURCE.json')));
const cases=[
 {id:'baseline_lot373',prod:[300,330,360],sales:[294,324,354],material:700,capex:160000},
 {id:'cadence_80pct_avec_stocks',prod:[280,320,340],sales:[274,314,334],material:700,capex:160000},
 {id:'cadence_85pct_avec_stocks',prod:[290,330,360],sales:[284,324,354],material:700,capex:160000},
 {id:'cadence_80pct_matiere_850',prod:[280,320,340],sales:[274,314,334],material:850,capex:160000},
 {id:'cadence_85pct_matiere_850',prod:[290,330,360],sales:[284,324,354],material:850,capex:160000}
];
const out=[];
for(const c of cases){const x=JSON.parse(JSON.stringify(original));x.production=c.prod;x.ventes=c.sales;x.matieres_kg=c.material;x.cout_production_kg=original.cout_production_kg.map(v=>v+c.material-original.matieres_kg);x.machines=61486;x.investissement=c.capex;
// Preserve coherent detailed investment table by treating difference from historical as a single unverified equipment-and-auxiliaries adjustment.
const details=x.investissements_detail.postes;const equipment=details.find(p=>p.id==='equipements');equipment.montant_usd=61486;equipment.qualification='Budget machines de sensibilité non vérifié pour cuves spécialisées';
const sum=details.reduce((s,p)=>s+p.montant_usd,0);details.push({id:'reserve_investissement_sensibilite',categorie:'Réserve non ventilée',libelle:'Écart non documenté à ventiler avant publication',montant_usd:Math.round((c.capex-sum)*100)/100,qualification:'Hypothèse uniquement, ni devis ni prix catalogue'});
const r=engine.calculer(x);out.push({id:c.id,production:c.prod,ventes:c.sales,prix:x.prix,matiere:c.material,investissement:c.capex,postes_total:details.reduce((s,p)=>s+p.montant_usd,0),statut:r.statut,annees:(r.annuel||[]).map(a=>({annee:a.annee,ca:a.chiffre_affaires,rn:a.resultat_net,marge_pct:100*a.resultat_net/a.chiffre_affaires})),cash_min:Math.min(...(r.tresorerie||[]).map(a=>a.solde_final)),bilans_ecart:(r.bilans||[]).map(a=>a.ecart),controles:r.controles});}
fs.writeFileSync(path.join(here,'LOT379_SCENARIOS_CADENCE_CUVES_V107.json'),JSON.stringify({avertissement:'Scenarios indicatifs. Ne remplacent aucun BP public. Les postes de reserve et les prix machines ne sont pas qualifies.',scenarios:out},null,2));console.log(JSON.stringify(out.map(x=>({id:x.id,annees:x.annees,cash_min:x.cash_min,postes_total:x.postes_total})),null,2));
