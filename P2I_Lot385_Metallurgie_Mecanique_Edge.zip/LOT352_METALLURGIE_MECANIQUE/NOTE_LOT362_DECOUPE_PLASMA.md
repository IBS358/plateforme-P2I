# P2I — Lot 362 : découpe plasma, Chaudronnerie

Reprise intégrale du lot 361. Ajout de deux références publiques de découpe plasma CNC 1530 avec prix FOB affichés, sans substituer arbitrairement un équipement au BP actif.

- Senke CNC 1530 : 4 790 USD FOB affichés.
- Starma 1530 : fourchette 4 500–6 000 USD FOB affichée, variante non figée.

Ces montants sont des prix d'annonce publique, non des devis. Les capacités réelles pour l'inox, l'alimentation, les consommables, l'aspiration et les utilités ne sont pas établies. Les références restent candidates, hors investissement et hors calcul v107.

**À ne pas confondre :** quatre postes ont désormais des références publiques candidates (pliage, cisaillage, roulage, découpe), mais l'atelier n'est pas complet. La soudure, le levage, le contrôle, l'installation, le BFR et la capacité doivent être justifiés. Le résultat A1 déficitaire de la Chaudronnerie n'est pas corrigé dans ce lot.

Aucun changement des 88 autres UP, de la branche GitHub main ni des résultats financiers.
