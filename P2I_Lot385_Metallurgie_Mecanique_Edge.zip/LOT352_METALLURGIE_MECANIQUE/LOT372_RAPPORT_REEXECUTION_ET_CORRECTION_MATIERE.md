# Lot 372 — Réexécution historique et correction de l’interprétation du champ matières

## Résultat exécuté
Le script `lot372_simuler_cuves_historiques.cjs` charge le moteur commun `runtime/script-0.js` à `script-11.js` (version 107), lit **sans modification** `LOT371_CUVES_INTRANTS_HISTORIQUES_SOURCE.json` et produit deux sorties JSON. Il n’altère ni le script v107 des huit UP, ni le BP HTML actif, ni les autres filières.

| Exercice | Ventes | CA USD | Résultat net USD | Marge |
|---|---:|---:|---:|---:|
| A1 | 294 | 451 503,35 | 86 857,27 | 19,24 % |
| A2 | 360 | 552 861,24 | 117 841,95 | 21,31 % |
| A3 | 420 | 645 004,78 | 143 838,01 | 22,30 % |

Contrôles calculés : trésorerie minimale 9 927,32 USD, bilans équilibrés à l'arrondi près, 12 mois de trésorerie, financement 40/60. **Statut du moteur : `simulation_indicative_non_documentee`.** Ces bénéfices ne sont pas validés et ne remplacent pas le scénario actif polyvalent déficitaire de 56 260 USD.

## Correction majeure — `matieres_kg` n’est pas une masse physique dans ce moteur
Dans `runtime/script-11.js`, vers les lignes 165–184, le champ `s.matieres_kg` est affecté à la variable `material`, comparé à `s.cout_production_kg[y]` (`if(cost<material) ...`) et multiplié par `prod` pour former des **achats/consommations en USD**. Dans ce chemin de calcul, **559,9557428756428 représente un coût matière unitaire en USD par cuve, malgré son nom trompeur**, et **860,6224095423095 est un coût de production unitaire en USD**, non un prix par kilogramme. La comparaison du lot 371 entre 559,96 « kg » et 152,4 kg physiques est donc invalide ; le ratio 3,67 ne doit plus servir de justification industrielle. Il faut distinguer :
- masse physique théorique de tôle, à confirmer par plans et épaisseur : 132,5 kg hors accessoires, 152,4 kg avec chutes, selon les hypothèses exploratoires du lot 370 ;
- budget matière historique du moteur : **559,96 USD par cuve** ;
- coût industriel historique : **860,62 USD par cuve**.

Le rapprochement matière demande le prix d'achat inox 304L USD/kg, la masse réelle (couvercle posé, accessoires, épaisseur, pertes), puis le prix matière total. Les 559,96 USD ne démontrent pas le coût réel d'une cuve.

## Vérification de cadence
La capacité historique 0,2166667 pièce/heure implique 4,6154 heures par cuve : 300 cuves = 1 384,6 heures A1 ; 360 = 1 661,5 heures A2 ; 420 = 1 938,5 heures A3. À 250 jours × 8 h = 2 000 h/an, A3 représente 96,9 % du temps théorique, avant arrêts, maintenance et aléas. Le scénario A3 est donc particulièrement fragile et exige des temps de cycle vérifiés.

## Statut
Reconstitution financière historique **réussie**, validation industrielle **non acquise**. Machines, outillages, soudures inox, manutention, sécurité, achats de tôles prédécoupées et marché des cuves à documenter sans repartir de zéro. Ne pas substituer automatiquement le bénéfice historique au BP public.
