# Lot 364 — Qualification du levage de la Chaudronnerie

Le BP Chaudronnerie est effectivement enrichi d'une référence de levage issue d'un catalogue FOB public.

Référence : Shaoxing Leitai Machinery, pont roulant monopoutre 2 t ; fourchette FOB 2 000–3 000 USD/ensemble ; minimum 1. Source : https://leitaicrane.en.made-in-china.com/product-group/VbWEDLPOCRpd/Overhead-Crane-catalog-1.html

Cette plage concerne une famille de configurations et non une configuration technique figée. Ne pas l'utiliser comme prix unique du moteur financier sans validation de la portée, hauteur et charge réelle. Les rails, la structure porteuse, l'installation, la sécurité et la manutention complémentaire restent à qualifier.

Aucune marge n'a été modifiée. Les machines et les résultats financiers historiques restent inchangés. Ce lot n'est pas une validation économique.
