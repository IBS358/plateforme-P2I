# Lot 385 — intégration des références sans recalcul

## Travail réellement effectué
- BP historique complet **Mobilier scolaire et professionnel** (lot 229, 17 rubriques) copié dans le dossier Métallurgie, accessible localement depuis le tableau de bord de filière.
- Tableau de bord consolidé reliant huit UP aux documents effectivement présents, et affichant séparément marges historiques et marges du lot 352.
- Les huit fichiers `BP_FINALISES` existants restent inchangés. Le scénario Chaudronnerie cuves du lot 381 est pointé en prévisualisation, sans être faussement déclaré validé.
- Aucune simulation, aucun changement de machine et aucune modification des 88 autres UP.

## Décisions conservées
- Serrurerie: cylindre européen, marge historique 12,37 %, non transférable à une configuration active différente.
- Structures: éléments IPE, marge historique 8,04 %, non transférable à une configuration active différente.
- Chaudronnerie: cuves inox 1000 L, prévisualisation lot 381; budget et auxiliaires incomplets.
- Mobilier: tables-bancs, bureaux et armoires; calcul lot 229 à 3,11 % A1, non déclaré validé.
- Autres UP: maintenir leurs résultats v107 historiques et les BP actifs séparés tant que le périmètre diffère.

## Limite de publication
Cette livraison est une **intégration documentaire effective**, pas une validation technique/financière complète. Il serait inexact de qualifier les huit BP de finalisés sans disposer de preuves concordantes sur les machines, leur prix catalogue et le calcul attaché à chaque configuration active. Aucune marge n'a été artificiellement améliorée.
