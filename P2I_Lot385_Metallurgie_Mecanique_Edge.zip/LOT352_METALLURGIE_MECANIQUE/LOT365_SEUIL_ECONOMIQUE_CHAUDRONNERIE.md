# P2I — Lot 365 : seuil économique de la Chaudronnerie (étude de décision)

Source: lot 364 et scénario actif lot 352. Aucune machine ni aucun prix catalogue n'a été modifié. Le moteur v107 conserve son résultat officiel de **−56 260 USD en A1** à 60 ensembles. Ce document n'est pas un BP finalisé.

## Démonstration économique
- Capacité déclarée : **80 ensembles/an** ; ventes A1 : **60 ensembles**.
- Prix unitaire : **6 500 USD** ; coût variable de production : **3 900 USD** ; distribution : **200 USD**.
- Contribution unitaire avant frais fixes : **2 400 USD**.
- À 80 ensembles, contribution supplémentaire maximale : **48 000 USD** (20 × 2 400 USD), insuffisante pour combler la perte initiale de 56 260 USD, toutes choses égales par ailleurs.
- Pour combler mécaniquement la perte A1 à 80 ensembles, sans changement des charges fixes, il faudrait un prix moyen d'environ **6,603.25 USD/ensemble**, avant tout ajustement de fiscalité, BFR, financement et coût de capacité. **Ce n'est pas un prix de marché validé**.

## Décision technique
La prochaine correction financière ne doit pas consister à accroître arbitrairement le volume ou le prix. Il faut remplacer les 160 000 USD d'enveloppes machines non individualisées par une nomenclature complète à prix catalogues publics, vérifier les fonctions TIG/MIG, levage et manutention, puis recalculer le CAPEX, la dette, l'amortissement, la trésorerie et le résultat A1–A3 dans le moteur v107. Les postes publics candidats précédemment enregistrés ne constituent pas encore une configuration intégralement compatible.

## Note sur le soudage inox
Pour des cuves atmosphériques et assemblages inox, les procédés TIG et MIG/MAG peuvent répondre à des usages différents ; les choix dépendent de l'épaisseur, de la qualité de joint et des contrôles. Référence technique : https://www.worldstainless.org/Files/issf/non-image-files/PDF/welding-handbook-v68.pdf

## Continuité
Tous les fichiers historiques, les huit BP et les 88 autres UP sont conservés byte pour byte. Ce lot n'altère ni la matrice ni les simulations actives ; il fournit un seuil de décision reproductible, pas une marge artificiellement positive.
