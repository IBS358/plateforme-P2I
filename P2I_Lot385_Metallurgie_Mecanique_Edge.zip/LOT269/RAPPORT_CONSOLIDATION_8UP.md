# Lot 269 — Contrôle de cohérence et fiches de qualification des huit UP

**Constat vérifié dans les fichiers historiques** : le lot 261 et le lot 264 utilisent parfois des CAPEX et résultats différents pour une même UP. Ils sont deux prototypes distincts, **pas une seule version financière cohérente**. Il est incorrect de reprendre leur marge sans préciser la version.

**Règle de consolidation** : conserver les originaux inchangés ; ne pas injecter les chiffres historiques dans v107 avant réconciliation des CAPEX, volumes, prix, amortissements, financement et BFR. Les montants des lots 261 à 268 ne sont pas des devis industriels.

**Le présent lot n'ajoute pas de prix catalogues fictifs ni de marges artificielles.** Il fournit les huit fiches de qualification et une matrice d'écarts financiers pour préparer une intégration sérieuse. Les bilans v107 et illustrations IA finales ne sont pas encore produits.

## Plastique PEHD/PP
- Matière entrante : Balles de PEHD/PP triées; contrôle PVC, humidité et contaminants.
- Produit vendable : Paillettes lavées ou granulés, ne pas confondre.
- Ligne à qualifier : Broyage, lavage, séchage, extrusion/filtration, coupe, conditionnement.
- CAPEX lot261 : 1,800,000,000 FCFA ; lot264 : 1,800,000,000 FCFA ; **écart : 0 FCFA**.
- RN A1 lot261 : 537,109,344 FCFA ; lot264 : 537,109,344 FCFA.
- Validation obligatoire : fabricant et modèle, prix EXW/FOB vérifiable, puissance et débit du maillon limitant, rendements par produit, coût de collecte rendu site, engagements de vente, traitement des refus, personnel, CAPEX complet, fiscalité et BFR.

## Papier-carton
- Matière entrante : Cartons commerciaux et industriels triés.
- Produit vendable : Balles de papier-carton par qualité.
- Ligne à qualifier : Réception, tri, presse à balles, pesage, expédition.
- CAPEX lot261 : 850,000,000 FCFA ; lot264 : 850,000,000 FCFA ; **écart : 0 FCFA**.
- RN A1 lot261 : 233,716,800 FCFA ; lot264 : 233,716,800 FCFA.
- Validation obligatoire : fabricant et modèle, prix EXW/FOB vérifiable, puissance et débit du maillon limitant, rendements par produit, coût de collecte rendu site, engagements de vente, traitement des refus, personnel, CAPEX complet, fiscalité et BFR.

## Métaux ferreux
- Matière entrante : Ferrailles ferreuses triées et dépolluées.
- Produit vendable : Ferrailles compactées/cisaillées par grade.
- Ligne à qualifier : Tri magnétique, découpe/cisaillage, compactage, chargement.
- CAPEX lot261 : 950,000,000 FCFA ; lot264 : 950,000,000 FCFA ; **écart : 0 FCFA**.
- RN A1 lot261 : 806,839,200 FCFA ; lot264 : 806,839,200 FCFA.
- Validation obligatoire : fabricant et modèle, prix EXW/FOB vérifiable, puissance et débit du maillon limitant, rendements par produit, coût de collecte rendu site, engagements de vente, traitement des refus, personnel, CAPEX complet, fiscalité et BFR.

## Compost
- Matière entrante : Déchets organiques propres et traçables.
- Produit vendable : Compost mûr vrac et ensaché sous contrôle qualité.
- Ligne à qualifier : Prétri, broyage, mélange, compostage, maturation, criblage.
- CAPEX lot261 : 1,200,000,000 FCFA ; lot264 : 1,200,000,000 FCFA ; **écart : 0 FCFA**.
- RN A1 lot261 : -158,784,640 FCFA ; lot264 : 416,353,296 FCFA.
- Validation obligatoire : fabricant et modèle, prix EXW/FOB vérifiable, puissance et débit du maillon limitant, rendements par produit, coût de collecte rendu site, engagements de vente, traitement des refus, personnel, CAPEX complet, fiscalité et BFR.

## Verre
- Matière entrante : Verre d’emballage collecté et prétri.
- Produit vendable : Calcin transparent/vert/brun; granulats secondaires sous contrat.
- Ligne à qualifier : Tri couleurs, extraction indésirables, broyage, criblage, dépoussiérage.
- CAPEX lot261 : 650,000,000 FCFA ; lot264 : 1,500,000,000 FCFA ; **écart : 850,000,000 FCFA**.
- RN A1 lot261 : -78,366,080 FCFA ; lot264 : -48,279,616 FCFA.
- Validation obligatoire : fabricant et modèle, prix EXW/FOB vérifiable, puissance et débit du maillon limitant, rendements par produit, coût de collecte rendu site, engagements de vente, traitement des refus, personnel, CAPEX complet, fiscalité et BFR.

## Pneus usagés
- Matière entrante : Pneus hors d’usage, enlèvement et traçabilité.
- Produit vendable : Granulats de caoutchouc, acier; fibres seulement si débouché.
- Ligne à qualifier : Déjantage, prébroyage, granulation, séparation magnétique et textile.
- CAPEX lot261 : 1,450,000,000 FCFA ; lot264 : 1,800,000,000 FCFA ; **écart : 350,000,000 FCFA**.
- RN A1 lot261 : -248,784,640 FCFA ; lot264 : 195,376,800 FCFA.
- Validation obligatoire : fabricant et modèle, prix EXW/FOB vérifiable, puissance et débit du maillon limitant, rendements par produit, coût de collecte rendu site, engagements de vente, traitement des refus, personnel, CAPEX complet, fiscalité et BFR.

## Huiles usagées
- Matière entrante : Huiles lubrifiantes usagées avec traçabilité et contrôle PCB/contaminants.
- Produit vendable : Fractions traitées selon procédé; huile de base uniquement si véritable régénération.
- Ligne à qualifier : Contrôle, stockage sécurisé, prétraitement, régénération, laboratoire, rejets.
- CAPEX lot261 : 2,200,000,000 FCFA ; lot264 : 2,300,000,000 FCFA ; **écart : 100,000,000 FCFA**.
- RN A1 lot261 : -165,830,400 FCFA ; lot264 : 340,149,600 FCFA.
- Validation obligatoire : fabricant et modèle, prix EXW/FOB vérifiable, puissance et débit du maillon limitant, rendements par produit, coût de collecte rendu site, engagements de vente, traitement des refus, personnel, CAPEX complet, fiscalité et BFR.

## DEEE
- Matière entrante : DEEE triés par famille, dépollution réglementée.
- Produit vendable : Cuivre, aluminium, fer, cartes, plastiques par grade.
- Ligne à qualifier : Réception, dépollution, démontage, séparation, stockage sécurisé.
- CAPEX lot261 : 1,600,000,000 FCFA ; lot264 : 2,400,000,000 FCFA ; **écart : 800,000,000 FCFA**.
- RN A1 lot261 : -339,880,960 FCFA ; lot264 : 963,159,360 FCFA.
- Validation obligatoire : fabricant et modèle, prix EXW/FOB vérifiable, puissance et débit du maillon limitant, rendements par produit, coût de collecte rendu site, engagements de vente, traitement des refus, personnel, CAPEX complet, fiscalité et BFR.

## Cas particulier verre
Le lot 264 présente 1,5 Md FCFA d'investissement, 792,3 M FCFA de CA et une marge A1 de -6,09 %. Le lot 261 présente un investissement de 650 M FCFA et une autre marge négative. Les scénarios 265–268 abaissent hypothétiquement le CAPEX et changent les marges : **aucun prix catalogue de ligne complète ni contrats de collecte/vente n'établissent la faisabilité du scénario favorable**. La décision de 6 t/h reste conditionnelle à 17 741 t/an d'entrées et environ 15 080 t/an de sorties à 70 % d'utilisation, et à la qualité du calcin.

## Livrables manquants avant validation
- Prix fournisseurs vérifiables par machine, installation et transport, documents sources datés.
- Comptes de résultat, bilans équilibrés et trésorerie mensuelle v107, 40 % fonds propres / 60 % dette, BFR distinct.
- Illustrations IA, logo P2I original, rubriques finales et export PDF conformes.
