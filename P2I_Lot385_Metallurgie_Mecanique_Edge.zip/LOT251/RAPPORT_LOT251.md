# P2I — Lot 251 — PREMIER CHIFFRAGE FINANCIER (NON VALIDÉ)

Périmètre: filière Recyclage & Valorisation uniquement. Archive du lot 250 intégralement conservée.

## Plastique : scénario exploratoire de lavage PEHD (500 kg/h)

- Catalogue fabricant : ligne lavage 500 kg/h FOB 55 000 à 125 000 USD. Hypothèse de simulation 90 000 USD, hors investissements complémentaires.
- Étude ivoirienne (prix février 2023) : PEHD régénéré 500 à 600 FCFA/kg; déchets PEHD 130 à 165 FCFA/kg chez les intermédiaires. Ces produits et qualités ne sont PAS nécessairement équivalents aux paillettes lavées.
- Tarif CIE MT général heures pleines : 74,06 FCFA/kWh HT, hors prime de puissance et taxes. Hypothèse prudente simplifiée de simulation : 90 FCFA/kWh (à recalculer par profil horaire).

## Hypothèses non vérifiées et résultats A1 (FCFA)

Capacité 0,5 t/h, 8 h/jour, 22 jours/mois, utilisation 70%, rendement vendable 82%. Prix de vente 550 FCFA/kg **à confirmer pour paillettes lavées**. Coût matière 150 FCFA/kg entrant. Consommation 180 kWh/t entrante. Coût variable hors énergie et matière 65 000 FCFA/t entrante. Charges fixes 42 M FCFA/an. CAPEX annexes +65%; taux indicatif 600 FCFA/USD.

- Entrées annuelles : 739.2 t; sorties vendables : 606.1 t.
- Chiffre d'affaires : 333,379,200 FCFA.
- Achat matière : 110,880,000 FCFA; énergie : 11,975,040 FCFA; autres variables : 48,048,000 FCFA.
- Charges fixes : 42,000,000 FCFA; EBITDA : 120,476,160 FCFA.
- Investissement indicatif : 89,100,000 FCFA; amortissement linéaire simplifié : 11,137,500 FCFA/an.
- Intérêts A1 approximatifs sur 60% dette à 10% : 5,346,000 FCFA.
- Résultat avant impôt simplifié : 103,992,660 FCFA. **Ce n'est PAS le résultat net v107.**

## Bloquants explicites

Le prix des paillettes lavées ne peut pas être assimilé sans preuve au prix des granulés régénérés. Les coûts du lavage, de l'eau, du traitement des effluents, du personnel et du transport doivent être vérifiés. Pas de BFR, d'IS, de TVA, de tableau de dette ni de trésorerie 12 mois calculés à ce stade. Ne pas valider la rentabilité sur ce scénario.

Les sept autres UP restent en attente de prix de sortie et de machines correspondants: ne pas injecter de chiffres arbitraires.

## Sources
- https://jorbin.en.made-in-china.com/product-group/jMNQbuIDbYcn/plastic-recycling-and-washing-line-catalog-1.html
- https://admin.un-page.org/wp-content/uploads/2024/06/opportunites-et-options-pour-soutenir-et-renforcer-le-secteur-du-recyclage-des-plastiques.pdf
- https://www.cie.ci/index.php/entreprise/tarifs-electricite
