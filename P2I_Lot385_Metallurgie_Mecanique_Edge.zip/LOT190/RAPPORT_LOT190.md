# Lot 190 — trois BP Assemblage & Montage

Trois dossiers HTML de 17 rubriques issus exclusivement du JSON v107 Lot 155 : tricycles, vélos et équipements sportifs. Comptes de résultat A1-A3, financement CAPEX 40/60, réserve et trésorerie 12 mois repris sans recalcul. Aucun prix machine ou résultat inventé. Les trois BP restent conditionnels, faute de nomenclature industrielle et de validation de marché. Les autres UP et fichiers historiques ne sont pas modifiés. Test manuel Edge non effectué.
