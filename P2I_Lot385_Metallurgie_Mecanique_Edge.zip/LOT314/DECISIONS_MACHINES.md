# LOT 314 — DÉCISION MACHINES : DEEE ET PNEUS

La recherche publique permet de retenir des **candidats** mais pas de leur attribuer un CAPEX complet compatible avec les BP historiques.

**DEEE** : la ligne PCB 500 kg/h Gomine affiche 23 800 USD FOB. Une UP DEEE de 4 t/h de flux mélangés ne peut pas être représentée par huit machines PCB en parallèle : seuls certains déchets contiennent des cartes électroniques. La ligne PCB est donc un sous-atelier ; réception, dépollution, démontage, tri, broyage sélectif et gestion des fractions dangereuses demeurent hors périmètre.

**Pneus** : les lignes publiées vont jusqu’à 3 t/h dans les annonces comparables ; les prix sont des fourchettes sans correspondance ferme à 4 t/h. Ne pas affecter la borne basse au débit maximal, ni prétendre qu'une seule ligne 3 t/h remplit le scénario 4 t/h.

**Décision** : conserver les huit BP et leurs visuels. Aucun devis officiel demandé. Aucun prix arbitraire injecté. Le moteur financier reste inchangé ; ne pas présenter les BP comme bancables ou entièrement validés.

**Priorité de clôture** : pour chaque UP, privilégier une seule ligne complète tarifée à capacité identifiée ; en cas d'absence de prix exploitable, adapter la capacité *et recalculer* plutôt que créer un faux CAPEX. Les deux dernières UP de la plateforme doivent être abordées sans attendre.
