# P2I — Lot 218 : diversification, accélération commerciale et crédit client

**Statut : étude de sensibilité, NON validée, NON intégrée au catalogue.** Les 396 fichiers du lot 217 sont conservés sans modification. Les sept BP déjà avancés restent intacts.

## Décisions de conception
- Gamme calculée provisoire : table-banc scolaire, bureau professionnel, armoire métallique.
- Développement hors calcul jusqu’à nomenclature et prix documentés : tables-bancs secondaire/supérieur avec rangement de tablette, bureau professionnel avec emplacement tablette, éclairage LED rechargeable/amovible.
- Ne jamais présenter les lampes importées comme fabriquées localement : accessoires achetés, contrôle qualité, garantie, SAV et immobilisation du stock à chiffrer.
- Pas de soutien public ni subvention dans le CA, la trésorerie ou le résultat.

## Test d'accélération dès M6
Quantités annuelles **purement hypothétiques** : A1 1 200 tables-bancs, 160 bureaux, 80 armoires ; A2 2 800/400/200 ; A3 4 200/600/300. La répartition mensuelle A1 accélère à partir de M6. **Ni commandes ni capacité réelle démontrées.**

Les prix de test restent ceux du lot 217 : 33 000 / 110 000 / 160 000 FCFA et coûts variables 25 200 / 71 000 / 108 000 FCFA. Les prix et coûts des bureaux et armoires ne sont pas sourcés.

## Sensibilité de crédit client
Scénarios : 0 %, 30 %, 60 % des ventes à crédit, paiement à 30, 60 ou 90 jours. Les ventes au comptant sont encaissées le mois courant, celles à crédit après 1/2/3 mois. Ce modèle **ne calcule pas** le BFR complet, la TVA, les décaissements réels, les retards ni les impayés ; il isole les créances clients. Il ne remplace pas la trésorerie mensuelle v107.

Au scénario 60 % à crédit / 60 jours : CA A1 70,000,000 FCFA ; créances clients de fin A1 11,150,400 FCFA (~18,740 USD). Ces créances ne sont pas du bénéfice et doivent être financées.

## Contrôles et conditions d'activation
1. Plan coté, sécurité et robustesse des emplacements pour tablettes (anti-pincement, anti-vol, nettoyage, charge admissible, ergonomie).
2. Prix publics vérifiables et nomenclatures pour bureaux, armoires et accessoires LED ; éviter les marges inventées.
3. Vérifier la capacité de l'atelier, les besoins de personnel, le coût des matières et la montée en cadence M6.
4. Modéliser les acomptes clients, facturation, délais contractuels, risque de non-paiement, fournisseurs et stock dans le moteur commun v107.
5. Ne pas afficher une marge nette de 10 % comme acquise ; c'est une cible de sensibilité, pas un résultat.
6. Produire les 17 rubriques et visuels des blocs 2/17 **après** validation des configurations et calculs.

## Test effectué
Neuf combinaisons crédit/délai générées ; créances réconciliées par CA moins encaissements ; aucune modification du catalogue ni de GitHub main.
