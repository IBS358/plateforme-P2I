# Lot 296 — Recalcul des cinq UP après impôt et trésorerie
- Reprise des hypothèses du lot 295 sans les considérer comme validées.
- Impôt indicatif de 25 % appliqué seulement aux bénéfices positifs ; résultat net après impôt et marge recalculés.
- Projection A1-A3 et trésorerie sur 12 mois pour les quatre scénarios ; 30 jours de délai clients, 15 jours fournisseurs, stock initial 15 jours.
- La réserve BFR historique est supposée financée séparément ; besoin de financement supplémentaire explicité.
- Prix minimum ou économie de coûts supplémentaire nécessaires à 6 % de marge après impôt.
- Hypothèses de prix, énergie, coûts, qualité et approvisionnement non vérifiées ; pas de v107, TVA complète, fiscalité détaillée, ou devis fournisseurs.
- Les visuels du lot 294 et les 17 rubriques sont conservés.
