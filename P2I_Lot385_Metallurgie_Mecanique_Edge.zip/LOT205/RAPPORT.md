Lot 205 — Base Lot 204.

Livré : table de prix existants, séparation coût matière / investissement, rappel explicite des périmètres non comparables; correction des deux liens de chiffrage de l’index vers les modules ventilés Lot 198.

Tests : 7 références reprises, 2 additions vérifiées, tous liens de l’index présents. Aucun nouveau prix ni résultat v107. Aucun test manuel Edge.
