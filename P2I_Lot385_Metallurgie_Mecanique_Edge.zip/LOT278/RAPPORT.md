# P2I — Lot 278 : schémas industriels intégrés aux huit BP

Ce lot est cumulatif et ne modifie pas les BP des autres filières.

## Réalisations
- Huit schémas industriels SVG **vectoriels** (un par UP), 54 postes représentés, compatibles Edge hors connexion et impression.
- Huit pages de BP Découverte enrichies avec le schéma et une liste des équipements fonctionnels sans référence fournisseur fictive.
- Une page de navigation pour ouvrir les huit dossiers.
- Un registre explicite des preuves manquantes (catalogues, prix, contrats de collecte, débouchés, énergie, bilans v107).

**Les SVG sont des schémas techniques générés, pas des photos ni des illustrations IA photoréalistes.** Aucun visuel de produit fini n’a été créé. Les marges historiques restent non validées.

- Plastique PEHD/PP : 7 postes, SVG et BP HTML ajoutés.
- Papier-carton : 6 postes, SVG et BP HTML ajoutés.
- Métaux ferreux : 6 postes, SVG et BP HTML ajoutés.
- Compost : 7 postes, SVG et BP HTML ajoutés.
- Verre : 7 postes, SVG et BP HTML ajoutés.
- Pneus usagés : 7 postes, SVG et BP HTML ajoutés.
- Huiles usagées : 7 postes, SVG et BP HTML ajoutés.
- DEEE : 7 postes, SVG et BP HTML ajoutés.