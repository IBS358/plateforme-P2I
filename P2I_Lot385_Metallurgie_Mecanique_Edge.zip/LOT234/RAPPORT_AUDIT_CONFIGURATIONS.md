# Lot 234 — Audit des configurations historiques des huit UP

**Base :** Lot 233. Aucun changement du moteur, des 96 UP, ni des sept BP Assemblage.

## Résultat vérifiable

Les machines ci-dessous proviennent de `runtime/script-0.js` (historique). Les capacités « Standard », « Option » et « Selon flux » ne sont pas des données de dimensionnement. Les montants `capex_min` sont des champs historiques non justifiés, **pas des prix fournisseurs**.

| UP | Machines historiques | CAPEX historique non validé (USD) |
|---|---:|---:|
| plastique | 4 | 110000 |
| papier | 4 | 120000 |
| metaux | 4 | 130000 |
| compost | 5 | 55000 |
| verre | 4 | 150000 |
| pneus | 4 | 150000 |
| huiles | 4 | 85000 |
| deee | 4 | 160000 |

## Décision de conception

1. **Plastique :** conserver une chaîne complète et vérifier les frontières avec l’UP « granulés » ; aucun débit ou prix machine fiable n’a été retrouvé dans cette source.
2. **Métaux :** vérifier le périmètre de l’UP Métallurgie et le caractère industriel de la transformation.
3. **Pneus :** vérifier le bilan matière caoutchouc/acier/textile et les équipements anti-poussières.
4. **Compost :** intégrer la durée de séjour et le foncier, pas seulement la capacité horaire du broyeur.
5. **Papier/carton :** la configuration historique inclut pulpeur et séchoir, contrairement au scénario de simple mise en balles du lot 233. **Arbitrage technique requis** avant toute simulation.
6. **Verre :** définir la granulométrie du calcin et confirmer un débouché.
7. **Huiles :** séparer les flux et vérifier autorisations et procédé.
8. **DEEE :** dépollution et traçabilité indispensables avant broyage.

## Verrous communs
Les 8 UP sont **non calculables de façon défendable** avec les seuls champs historiques : aucun débit nominal confirmé, prix fournisseur vérifié, rendement, tonnage de collecte contractualisable ou prix de vente vérifié. Ne pas transformer les anciennes valeurs CAPEX/CA/marge brute en résultats v107.

## Tests
Extraction des huit configurations historiques, comptage des machines, comparaison au catalogue du lot 233, validation CSV et ZIP. Aucun test financier v107 n’a été exécuté.