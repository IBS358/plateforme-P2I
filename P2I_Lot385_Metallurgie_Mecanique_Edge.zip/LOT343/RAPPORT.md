# Lot 343 — Papier-carton : six vues de postes distinctes

- Six illustrations IA distinctes extraites d’une planche 3×2, intégrées aux six cartes de postes du BP Papier-carton.
- Les sept vues de postes du BP Plastique sont conservées : 13 postes illustrés individuellement sur 54.
- Les 41 postes des six autres UP conservent leurs illustrations contextuelles et schémas.
- Les huit BP, les 17 rubriques et les calculs financiers précédents restent inchangés.
- Images IA indicatives, pas de photos fournisseurs authentifiées.
