# Rapport d’audit — conformité des BP Découverte P2I

**Date : 13 novembre 2026 · Lot 123**

## Base examinée

Base locale : Lot 117 consolidé, avec le correctif visuel Lot 122 déjà intégré. Le dépôt GitHub et `main` n’ont pas été modifiés. L’audit porte sur le référentiel de données, les chemins visuels, le gabarit des 17 rubriques et la matrice. Il ne prétend pas remplacer une recette d’affichage Microsoft Edge.

## Point de reprise

- **96 UP / 12 filières** présentes. Les 17 intitulés sont déclarés par le rendu.
- **0/96** marqué comme BP terminé et vérifié dans la matrice source. Les 96 restent donc à auditer avant toute annonce de conformité.
- Matrice Lot 117 : 27 UP `PARTIEL_CALCULABLE`, 69 `PARTIEL_NON_CALCULABLE`.
- Données moteur : 73 scénarios de référence ont des séries de production, ventes et prix sur trois ans, dans 64 UP. **La matrice ne comptabilise que 34 scénarios dans 27 UP** : cet écart doit être réconcilié avant de publier un taux d’avancement financier. Avoir des entrées ne prouve pas que les états ont été testés.

## Constats de conformité du gabarit existant

- Visuel d’atelier/fond empruntable dans le rendu : **62/96** selon les champs visuels et les exceptions codées; 34 n’ont pas de route d’arrière-plan référencée. Le test par UP est détaillé dans la matrice.
- Visuel principal produit explicite dans le registre : **62/96**; les autres fiches doivent être contrôlées pour les visuels hérités ou absents.
- Variantes de référence : **143**, dont **138** avec une image dans le registre. Cinq variantes restent sans image dans les UP Sparadraps/Pansements/Compresses et Antiseptiques.
- Mentions de rédaction interne provisoire : **81 UP**; données de rédaction clés manquantes dans **14 UP**.
- Postes industriels structurés avec chemin image : **51/51**, concentrés dans les huit dossiers médicaux; cela ne valide ni l’authenticité fournisseur ni la conformité visuelle de chaque image.
- Le nom d’UP du screenshot, « Centre intégré d’emballage personnalisé » (`sacs`), n’a ni image produit principale, ni fond d’atelier déclaré dans son entrée visuelle. Le défaut montré est donc confirmé par les sources.

## Décisions du modèle type

Le modèle d’acceptation détaillé est dans `docs/BP_DECOUVERTE_TYPE_P2I.md`. Il fixe les 17 titres, les textes attendus, la zone produit, le fond d’usine flouté, la réutilisation de l’image d’atelier en rubrique 17, l’ordre variantes → postes industriels, les sources d’images et les contrôles financiers.

## Limites du contrôle effectué

- Vérifications statiques uniquement : données, matrice, présence des champs et chemins d’images.
- Le test automatisé de rendu Edge n’a pas pu démarrer dans l’environnement de travail; aucune conformité visuelle native n’est annoncée.
- Le rapport Lot 117 et la matrice ne concordent pas sur le nombre de scénarios; ce point sera corrigé dans la matrice après réconciliation des sorties réelles du moteur.

## Prochaine séquence

1. Corriger le rendu commun des titres/cartes et le contrat visuel atelier/produit/bloc 17.
2. Résoudre d’abord les UP déjà travaillées, avec leurs données et assets propres; ne pas utiliser une image générique d’un autre procédé.
3. Retester les scénarios financiers à partir des sorties du moteur et réconcilier matrice/rapport.
4. Faire une recette locale Edge représentative sur toutes les UP corrigées; ne qualifier de conforme que ce qui a été ouvert et contrôlé.
5. Te fournir ensuite une plateforme ZIP complète à vérifier avant toute prévisualisation GitHub sur branche de travail. Aucun changement direct à `main`.
