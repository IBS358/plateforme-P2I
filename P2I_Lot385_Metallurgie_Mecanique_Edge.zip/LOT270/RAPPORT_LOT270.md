# P2I — Lot 270 : référentiel de scénarios réconciliés pour huit UP

## Avancement substantiel
- Huit pages de lecture financière (3 ans et 12 mois), huit JSON, une synthèse CSV/JSON, une page d'entrée.
- Chaque scénario utilise une seule base d'investissement au lieu de mélanger les CAPEX des lots 261 et 264.
- Les charges et chiffres d'affaires proviennent du lot 264 et restent non qualifiés. CAPEX du verre 800 M FCFA = hypothèse conditionnelle de redimensionnement des lots 265–268 ; CAPEX des sept autres UP = lot 264.
- Calculs homogènes : amortissement linéaire 10 ans ; dette 60 % du CAPEX ; taux nominal indicatif 10 % ; principal égal sur sept ans ; impôt indicatif 25 % si résultat avant impôt positif ; DSCR=(EBITDA−impôt)/(intérêts+principal).
- BFR : réserve héritée du lot 264, séparée du CAPEX, financement non déterminé. Trésorerie 12 mois illustrative, sans délais de paiement.

## Limites bloquantes
1. Les CAPEX ne sont pas des prix catalogues documentés et les marges ne sont pas validées.
2. Les revenus multi-produits du lot 263 ne sont pas des contrats d'achat.
3. Les flux d'approvisionnement et les consommations énergétiques ne sont pas confirmés.
4. Aucun bilan comptable équilibré ni test du moteur v107 n'est fourni.
5. Les pages sont des outils de travail et non des BP Découverte finaux en 17 rubriques avec visuels IA.
6. Les autres UP historiques sont conservées sans changement dans l'archive cumulative.
