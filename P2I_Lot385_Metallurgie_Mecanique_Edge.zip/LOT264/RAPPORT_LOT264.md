# Lot 264 — Consolidation financière transversale des huit UP

## Travaux effectivement réalisés
- 8 comptes de résultat indicatifs sur 3 ans (CA +4 %/an, charges variables +4 %/an, fixes +3 %/an), intérêts dégressifs.
- Financement CAPEX : 40 % fonds propres, 60 % dette, remboursement du principal sur 7 ans, intérêt 10 % sur solde initial de chaque année.
- Provision de BFR illustrative : 1 mois de ventes + 0,25 mois de charges variables ; financée **en supplément** des 40 % d'apport au CAPEX.
- 12 mois de trésorerie par UP, répartis linéairement, avec BFR initialement provisionné ; pas de saisonnalité ni évolution mensuelle du BFR.
- DSCR approximatif = EBITDA / (principal + intérêts), ne vaut pas CFADS bancaire.
- Stress : taux utilisation 50 % (au lieu de 70 %), prix de vente -20 %, coût variable unitaire +15 %.

## Limites importantes
Les données industrielles et commerciales proviennent exclusivement des scénarios **illustratifs et non sourcés** du lot 263. Ces chiffres ne sont pas des prix catalogue ni des données ivoiriennes validées. Les marges nettes sont calculées sur une base simplifiée et ne sont pas certifiées. Absence de TVA, BFR réel, bilans équilibrés, contrats de collecte, autorisations environnementales, équipements chiffrés et visuels IA. Le moteur v107 n'a pas été exécuté. Les neuf UP antérieurement validées ne sont pas modifiées.

## Travail encore nécessaire avant livraison définitive
Pour chaque UP : nomenclature des machines et prix EXW/FOB vérifiables, coûts rendus site, vérification des débouchés et des matières, modèles techniques multi-fractions, recalcul dans v107, bilan équilibré et trésorerie dynamique, images P2I et intégration aux 17 rubriques originales.
