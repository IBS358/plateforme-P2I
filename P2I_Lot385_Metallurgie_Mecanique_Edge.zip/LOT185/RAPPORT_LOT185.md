# Lot 185 — Consolidation de fabrication, sans scénarios artificiels

Base : copie locale du Lot 184. Ajout d'une nomenclature de 19 lignes couvrant matière, composants mécaniques, fabrication, logistique, structure et débouchés. Coût de l'acier : 614,04 USD pour 635,90 kg; deux essieux : 438,60–543,00 USD FOB. Les prix sont hérités des lots antérieurs, non vérifiés de nouveau.

11 postes de coûts (hors commercial) ne disposent d'aucun montant. Aucune valeur manquante n'a été mise à zéro. Aucune nouvelle marge n'est publiée. La page BP du Lot 183 renvoie à la nomenclature.

Tests : présence de 19 lignes, somme des cinq postes acier égale à 614,04 USD, présence de la page, contrôle d'intégrité ZIP. Pas de test manuel Edge, pas de nouveau calcul v107, aucune modification GitHub.
