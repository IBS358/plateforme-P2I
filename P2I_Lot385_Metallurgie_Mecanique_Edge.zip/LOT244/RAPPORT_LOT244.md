# P2I — Lot 244 : intégration des contrôles industriels dans les huit BP

**Source :** lot 243 complet. Les huit projets de BP existants sont enrichis dans leurs fichiers originaux, sans modification du moteur v107 ni du catalogue des 96 UP.

- 8 BP × 17 rubriques conservés.
- 38 contrôles de chaîne fonctionnelle propres aux procédés, non présentés comme des données fournisseur.
- Protocole énergie spécifique dans chaque BP, y compris le calcul conditionnel pneus ESG-1000 (35 904 kWh/mois).
- Précisions BFR, trésorerie et traçabilité des preuves.
- Aucune valeur commerciale, coût ou rentabilité inventée.

**Non terminé :** machines et prix vérifiés pour lignes complètes, rendements, gisements, acheteurs, données fiscales et v107. Les contrôles industriels ne remplacent pas les tests de réception.

Ouvrir `LOT244/INDEX_LOT244.html` après extraction.
