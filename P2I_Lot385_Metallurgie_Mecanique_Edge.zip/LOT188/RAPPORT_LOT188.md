# P2I — Lot 188 : correction du calcul de coût industriel

Base : archive complète Lot 187. Aucun changement du moteur v107, des archives historiques ou de GitHub main.

## Correction appliquée

- Les 19 lignes restent visibles et documentées.
- Les 16 lignes MAT, MEC, FAB et LOG alimentent uniquement le coût direct.
- FIN-01 (amortissements et charges indirectes) est isolée pour éviter un double compte avec le moteur v107.
- COM-01 (prix de vente) et COM-02 (volume annuel) sont des hypothèses commerciales et ne sont jamais additionnées au coût industriel.
- L'investissement, le prix de vente et le volume sont saisis séparément. Les coûts manquants ne sont jamais remplacés par zéro.
- Le calcul ne prétend pas produire un résultat net ni une marge nette sans les données complètes et le moteur v107.

## Limites

Les coûts directs manquants, l'investissement complet, les prix commerciaux documentés et la capacité vendable empêchent toujours un nouveau BP financier validé. Les tests automatisés ne remplacent pas une vérification visuelle dans Microsoft Edge.
