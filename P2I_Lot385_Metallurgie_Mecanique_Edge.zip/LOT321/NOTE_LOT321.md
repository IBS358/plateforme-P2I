# Lot 321

Ajout de schémas de valorisation concrets aux cinq BP compost, verre, pneus, huiles, DEEE. Huit BP complets recopiés depuis le lot 320. Les résultats v107 ne sont pas modifiés. Les recettes DEEE génériques sont explicitement invalidées pour la ligne réfrigérateurs.
