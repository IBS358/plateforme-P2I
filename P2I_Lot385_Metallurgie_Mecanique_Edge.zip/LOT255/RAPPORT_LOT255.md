# P2I Lot 255 — Dimensionnement industriel renforcé

Base: Lot 254. Aucune modification du moteur v107, des neuf UP déjà traitées, ou des autres filières.

Le plastique est étudié à 1, 2 et 3 t/h, deux équipes de 8h, 22 jours/mois, utilisations 50 %, 70 %, 85 %, prix 350/450/550 FCFA/kg. Les 27 combinaisons sont recalculées sur les hypothèses du Lot 251. Le coût fixe est extrapolé avec un exposant de 0,65 : pure hypothèse d'échelle.

Les autres sept UP reçoivent des plages d'étude plus élevées, sans prétendre disposer de prix catalogues vérifiés.

LIMITES : pas de CAPEX qualifié pour grandes lignes, pas de validation de marché, pas de BFR, TVA, IS, dette, bilan, trésorerie v107; les économies d'échelle ne sont pas prouvées.

Prochaine étape : qualification fournisseur de lignes complètes, volumes disponibles de déchets, contrats d'enlèvement, débouchés et énergie mesurée.
