from pathlib import Path

root=Path(__file__).resolve().parent.parent

machine=root/'LOT193/BP_MACHINES_NOUVELLE_CONFIGURATION_17_RUBRIQUES.html'
s=machine.read_text()
s=s.replace('Candidat de remplacement de « Tablettes SKD » — décision non encore validée</b>. Ce dossier est consultable mais non publiable comme BP calculé. Aucun résultat v107 n’est attribué à cette configuration.','Scénario v107 calculé à titre indicatif; remplacement proposé de l’ancienne UP Tablettes, sous réserve de décision catalogue. Prix, composants et ventes sont des hypothèses, non des données de marché confirmées.')
s=s.replace('<b>Statut :</b> Candidat de remplacement de « Tablettes SKD » — décision non encore validée','<b>Statut :</b> Calcul v107 positif sous hypothèses; validation technique et commerciale à poursuivre')
s=s.replace('Le principe d’une configuration de référence est proposé, mais son débit, sa plage de dosage et ses interfaces restent à qualifier.','Configuration de référence chiffrée : vis doseuse et pesée semi-automatiques, remplissage manuel de sachet préformé, thermoscellage continu séparé. Plage de conception 100–500 g; cadence de budget 8 sachets/min, à confirmer par essais.')
s=s.replace('https://www.made-in-china.com/showroom/shanghai-mooha/product-detail.html','https://www.madeinchina.com/mall/show-Semi-Automatic-Talc-Nutrition-Milk-Protein-Spice-Powder-Auger-Filler-with-Load-Cell_935544.html')
s=s.replace('https://www.itmac-ci.com/','https://www.itmac-ci.com/')
machine.write_text(s)

rack=root/'LOT193/BP_STOCKAGE_NOUVELLE_CONFIGURATION_17_RUBRIQUES.html'
s=rack.read_text()
s=s.replace('Scénario v107 calculé, résultat déficitaire.</b> Le dossier inclut une première estimation de coût par baie et installation; l’activité n’est pas financièrement validée sous les hypothèses retenues. Les profils et charges restent à calculer et tester.', 'Scénario v107 calculé : résultat positif sous hypothèses estimatives, non validé commercialement ou techniquement.</b> L’organisation sur commande réduit le CAPEX et les coûts fixes; prix, volume et coût local de pose restent à vérifier. Les profils et charges restent à calculer et tester.')
s=s.replace('Calcul v107 exécuté; résultat négatif sous les hypothèses de volume, prix, coûts et financement détaillées ci-dessous.', 'Calcul v107 exécuté; résultat positif sous les hypothèses de volume, prix, coûts et financement détaillées ci-dessous, sans validation de marché ni de résistance structurelle.')
s=s.replace('https://amerack.com/racking-price/','https://amerack.com/racking-price/')
s=s.replace('https://amerack.com/pallet-rack-pricing/','https://amerack.com/racking-price/')
s=s.replace('https://www.premiumci.com/','https://elbmci.com/pgeRack.php')
s=s.replace('https://www.momentumracks.com/pricing','https://www.momentumracks.com/prices')
rack.write_text(s)

trailer=root/'LOT189/BP_REMORQUE_3T_COUTS_ET_SOURCES.html'
s=trailer.read_text()
s=s.replace('https://globalgros.com/agriculture/yto-remorque-7cx-3-3-tonnes/','https://globalgros.com/agriculture/outils-and-equipements/machines-agricoles/yto-remorque-7cx-3-3-tonnes/')
trailer.write_text(s)

# Correct source links in generated pages and preserve them as public source references.
for p in [machine,rack]:
    t=p.read_text()
    t=t.replace('https://www.cie.ci/tarifs-electricite','https://www.cie.ci/index.php/entreprise/tarifs-electricite')
    t=t.replace('https://www.momentumracks.com/pricing','https://www.momentumracks.com/prices')
    p.write_text(t)

print('Updated stale statuses, product reference wording, and public-source URLs.')
