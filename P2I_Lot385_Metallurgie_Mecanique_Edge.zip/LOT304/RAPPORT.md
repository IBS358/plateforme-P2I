# Lot 304 — Galerie IA du bloc 17 et inventaire des postes

8 illustrations IA distinctes intégrées, 54 postes industriels fonctionnels, 8 BP complets à partir du lot 301. Les visuels du bloc 2 des lots précédents sont préservés.

Les visuels IA illustrent les installations de façon générale, **pas chaque machine individuelle**. Aucune photographie de fabricant n'est attribuée sans source. Le bloc 17 comporte désormais des cartes numérotées et leur correspondance avec les équipements fonctionnels.

La sélection commerciale des machines reste à faire : 0 prix catalogue nouveau vérifié dans ce lot ; la référence candidate du lot 303 pour les pneus reste à confirmer en périmètre. Ne pas attendre de devis officiels pour le BP Découverte.
