# P2I — Lot 212 : vérification technique et prévention des doubles comptes

## Résultat effectif
Le lot 211 a été conservé. Un plan de débit calculé pour les **12 segments** du châssis 30×30 mm a été ajouté : **8 400 mm de longueurs utiles**, **36 mm de traits de scie hypothétiques** (3 mm par coupe), et **3 564 mm de chutes cumulées** sur deux barres de 6 000 mm. La faisabilité géométrique du débit est démontrée sous ces seules hypothèses; les coupes, les jonctions et la résistance du châssis ne sont pas validées.

**Contrôle financier majeur :** les 8,40 m de tube consommés et les deux barres de 6 m achetées sont deux représentations du même acier. Il est interdit de les additionner dans le coût matière. La nomenclature réconciliée distingue achat, consommation, conversion et investissement.

La quantité nette de panneaux est **0,996 m²**, sans pertes de découpe. Les épaisseurs de tubes et de panneaux, les renforts, le procédé de soudage, les caractéristiques de peinture, les temps standards et les prix fournisseurs sont toujours manquants. Aucun montant manquant n'est remplacé par zéro.

## Décision
**Pas de lancement du moteur v107** : un résultat numérique serait trompeur. **Pas de migration du catalogue** : `irrigation_kits_surface` reste actif provisoirement; les sept autres BP et les historiques ne sont pas modifiés.

## Contrôles
- Vérification automatique des quantités : 8,40 m d'acier et 0,996 m² de panneaux.
- Vérification de la répartition de toutes les pièces sur deux barres de 6 m, avec traits de scie hypothétiques.
- Contrôle de séparation des lignes d'achat et de consommation.
- Aucune modification des fichiers des lots précédents.

## Priorités indispensables
1. Plan coté et exigences mécaniques du table-banc biplace.
2. Prix vérifiables et comparables pour acier, panneaux, visserie et finition.
3. Machines et investissement documentés, temps de fabrication et prix de vente ivoirien comparable.
4. Hypothèses de volume défendables avant simulation v107.
