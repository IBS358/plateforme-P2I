# P2I — Lot 160 : cahiers de consultation ciblés et verrouillage des hypothèses

## Base de départ
Lot 159, sans modification du moteur v107, des BP actifs ni des archives. Les quatre UP restantes ne sont toujours pas finalisées.

## Livrable nouveau
Un cahier de consultation normalisé pour chacune des quatre UP, avec les spécifications minimales nécessaires pour obtenir un devis comparable, une nomenclature complète et un prix rendu calculable. Il est regroupé dans `CAHIER_CONSULTATION_4_UP.csv`.

## Décisions opérationnelles
- Smartphones : demander des prix d'approvisionnement par grade et un rendement réparables, plutôt que comparer un iPhone reconditionné fini à un prix de détail.
- Tablettes : écarter du scénario actif toute promotion du kit 154,47 USD FOB sans nouveau modèle économique ; comparer un kit strictement équivalent à une tablette finie et documenter les certifications.
- Remorques : demander un **train roulant complet**, non deux prix d'essieux isolés ; valider les charges et le freinage avant chiffrage.
- Rayonnages : établir la BOM matière et le temps opératoire d'une gamme de charge définie ; comparer prix B2B et charges certifiées, non un produit de détail différent.

## Conditions pour un recalcul v107
Ne renseigner un prix fournisseur qu'avec sa source, sa devise, son incoterm et sa date. Distinguer les coûts de production documentés des estimations P2I. Recalculer uniquement après cohérence de la BOM, de la capacité, des charges et des prix de vente. Conserver les pertes historiques jusqu'à remplacement démontré.

## Contrôles
Le ZIP et les tests des lots 155, 156 et 159 sont contrôlés à la génération. Aucun navigateur Edge réel ni prix fournisseur nouveau vérifié. Aucun nouveau BP déclaré rentable.
