# Lot 325 — DEEE froid : recalculs économiques effectifs

Source : ZIP Lot324, configuration DEEE Lot317, moteur commun runtime/script-11.js et dépendances runtime/script-2 à 5.js.

Débit : 0,6 t/h ; investissement 302 000 USD ; entrée A1 1774.1 t ; sortie vendable de référence 1099.9 t.

Le modèle générique historique est remplacé, dans les scénarios séparés, par un bilan matière hypothétique et une éventuelle prestation de dépollution. Aucun prix n'est présenté comme vérifié. Fractions hypothétiques : [('Acier et métaux ferreux', 0.4, 170), ('Aluminium', 0.04, 850), ('Cuivre', 0.015, 3200), ('Plastiques séparés', 0.14, 160), ('Autres matières valorisables', 0.025, 0), ('Résidus et fractions à traiter', 0.38, 0)].

Résultats recalculés v107 (marge nette A1) :
- Prestation 0 USD/t : -108.07%
- Prestation 100 USD/t : -31.69%
- Prestation 200 USD/t : 2.76%
- Prestation 300 USD/t : 18.05%
- Prestation 400 USD/t : 28.00%
- Prestation 500 USD/t : 34.99%

Ne pas traiter les tarifs de prestation comme acquis. Les résultats historiques des sept autres UP et du BP DEEE original restent conservés pour audit ; l'annexe 325 distingue clairement les nouvelles simulations.
