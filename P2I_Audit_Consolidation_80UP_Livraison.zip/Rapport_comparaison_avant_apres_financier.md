# Rapport de comparaison avant/après — intégrité financière

## Résultat

- Archive Lot385 : SHA-256 `d36945c2e7d486ba406f1e39598a64919a27168d492136c627b17029afd5a1ae`.
- Fichiers extraits hachés avant audit : **1745**.
- Fichiers extraits contrôlés après audit : **1745**.
- Différences : **0 modifiés**, **0 absents**, **0 ajoutés** dans le périmètre d’origine.
- Fichiers de finances, équipements, configurations, moteur v107 et matrices hachés : **271**; toutes les empreintes du sous-ensemble protégé sont restées identiques.
- Verdict intégrité : **IDENTIQUE — PASS**.

## Contrôle des valeurs affichées

Les résultats ci-dessous ne proviennent que des champs préexistants des sources retenues. Aucun moteur ni calcul financier n’a été lancé. La matrice CSV distingue les valeurs A1 attachées aux configurations Lot317/323/326 et Lot352 des anciens RN de la matrice racine. Le fichier de contrôle Lot385 documente déjà 8 pages métallurgie, leurs 17 rubriques, impression/retour et le contrôle avant/après; les sources Lot317/323/325/326 et les pages Lot330/Lot344 documentent les 8 résultats recyclage.

Pour 64 UP, aucune valeur n’est étiquetée « dernier résultat v107 vérifié » faute de fichier de résultat récent directement rattaché à la configuration retenue parmi les pièces accessibles. Leurs anciens RN de matrice restent reproduits séparément, sans suppression ni reprise comme résultat actuel.

**Aucune modification financière constatée. Aucune simulation relancée.**
