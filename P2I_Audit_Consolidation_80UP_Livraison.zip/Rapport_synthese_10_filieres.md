# Rapport de synthèse — audit et consolidation documentaire des 80 UP

**Date : 19 novembre 2026.** Contrôle statique/lecture seule sur l’archive Lot385 et les pièces historiques retrouvées. Aucun BP ou calcul n’a été relancé.

## Résultat chiffré

| Statut | Nombre d’UP |
|---|---:|
| CONFORME | 0 |
| CONFORME AVEC RÉSERVES | 8 |
| À CORRIGER | 8 |
| NON VÉRIFIABLE | 64 |

Ces statuts s’appliquent aux preuves obtenues, non à une présomption d’inachèvement. Les lignes NON VÉRIFIABLES ne sont pas assimilées à des BP inexistants. Aucun BP n’est déclaré CONFORME sans preuve sur la page effectivement retenue, ses résultats rattachés, les visuels requis et les fonctions.

## Par filière

| Filière | UP | Conforme | Avec réserves | À corriger | Non vérifiable |
|---|---:|---:|---:|---:|---:|
| Agro-alimentaire & Boissons | 8 | 0 | 0 | 0 | 8 |
| Chimie, Cosmétiques & Détergents | 8 | 0 | 0 | 0 | 8 |
| Textile, Habillement & Cuir | 8 | 0 | 0 | 0 | 8 |
| Métallurgie & Mécanique | 8 | 0 | 0 | 8 | 0 |
| Plastique & Caoutchouc | 8 | 0 | 0 | 0 | 8 |
| Électronique & Électricité | 8 | 0 | 0 | 0 | 8 |
| BTP & Matériaux de Construction | 8 | 0 | 0 | 0 | 8 |
| Médical & Pharmaceutique | 8 | 0 | 0 | 0 | 8 |
| Assemblage & Montage | 8 | 0 | 0 | 0 | 8 |
| Recyclage & Valorisation | 8 | 0 | 8 | 0 | 0 |

## Conclusions par filière

- **Recyclage & Valorisation — 8 avec réserves.** Lot344 consolide les huit pages Lot330. Contrôle rapporté : 17/17 rubriques structurelles, ressources images présentes, ancres internes non cassées; plusieurs galeries et postes illustrés. Les images sont illustratives/IA, non des photos constructeur; le logo maître, le rendu Edge manuel, la conformité éditoriale complète, le retour Dashboard direct et un BP Pro connecté ne sont pas démontrés. Verre 3,20 % accepté sans prétendre atteindre 6 %; DEEE 18,05 % conditionnel à 300 USD/t.
- **Métallurgie & Mécanique — 8 à corriger.** Le Lot385 prouve la présence des huit dossiers et des rubriques, avec impression/navigation statiquement contrôlées. Il relève l’absence du logo maître; son contrôle compte zéro image dans les sept pages actives et une seule dans la page Mobilier historique Lot229. Cela ne remet pas en cause les données financières sources; le contenu est à préserver en corrigeant uniquement l’intégration visuelle après nouvel ordre distinct.
- **Assemblage & Montage — 8 non vérifiables comme BP.** Les pièces datées du 15/11/2026 sont une qualification/étude industrielle et BOM, explicitement non BP final et sans calcul. Plusieurs candidats ne correspondent pas aux IDs du catalogue actif; l’audit n’injecte aucun candidat et ne réaffecte aucun ID.
- **Agroalimentaire, Chimie, Textile, Plastique hors Recyclage, Électronique & Électricité, BTP, Médical & Pharmaceutique — 56 non vérifiables.** La matrice racine contient des indicateurs et anciens statuts, mais les pages BP récentes et leurs pièces de configuration/résultat associées n’ont pas été retrouvées dans les fichiers accessibles avec l’archive auditée. Les anciens chiffres sont conservés dans une colonne distincte de la matrice, non présentés comme situation financière courante.

## Acquis conservés

Les huit configurations et résultats Lot352, les valeurs v107 du Recyclage attribuées aux derniers scénarios documentés Lot317/323/326, les pages et ressources présentes, les historiques associés au Mobilier et à la Chaudronnerie, les matrices 96-UP et l’intégralité des archives incluses sont restés inchangés. Les écarts connus sont dans le registre de réserves; aucun rapprochement contradictoire n’a été corrigé silencieusement.

Voir la matrice CSV et le registre des réserves pour la preuve UP par UP, les fichiers concernés et les résultats A1 sourcés.
