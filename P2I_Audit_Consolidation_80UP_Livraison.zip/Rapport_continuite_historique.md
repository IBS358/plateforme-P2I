# Rapport de continuité historique — audit des 80 UP

Date du contrôle : 19 novembre 2026. Travail en lecture seule. Aucun BP reconstruit, aucune simulation lancée, aucun prix/volume/configuration modifié.

## Sources et version retenue

| Périmètre | Pièce la plus récente utilisable pour le présent audit | Ce qu’elle prouve | Limites / continuité préservée |
|---|---|---|---|
| Archive technique principale | `P2I_Lot385_Metallurgie_Mecanique_Edge.zip` (SHA-256 dans manifeste) | Racine 96 UP, matrices 96 lignes, lots historiques inclus, pages Lot352 et contrôles avant/après. | Ne contient pas les pages BP consolidées récentes des huit autres filières cibles. |
| Recyclage & Valorisation (8 UP) | ZIP Lot344 persistant, pages Lot330; données Lot317/Synthèse v107; rapprochement avec rapport Lot344 | Huit pages, 17 rubriques structurelles, contrôles d’images/ancres, configuration et résultats A1 directement liés au scénario. | Valeurs indicatives conservées; verre 3,20 %; DEEE conditionnel; images illustratives; logo maître et rendu visuel Edge à réserver. |
| Métallurgie & Mécanique (8 UP) | `LOT352/SIMULATIONS_V107_LOT352.json`, `LOT385_CONTROLE_AVANT_APRES.json`, matrice Lot385 et rapport Lot384 | Huit scénarios v107 Lot352; pages 17 rubriques; navigation impression documentée; différences de périmètre avec les résultats historiques signalées. | 7 pages actives sans image; logo original absent; Mobilier renvoie à Lot229; produits/prix historiques différents ne sont pas substitués. |
| Chaudronnerie — historique distinct | Lot126/CSV historique référencé par Lot384; Lot372; Lot381 | Lot384 conserve le RN historique 86 857,27 USD / 19,24 % pour cuves 1 000 L à un autre périmètre; Lot372 donne une variante historique distincte; Lot381 porte `TRAVAIL_NON_PUBLIABLE`. | Lot352 actif : scénario cuves distinct et déficitaire. La comparaison est une rupture de périmètre, pas une autorisation de substitution. |
| Assemblage & Montage (8 UP) | Étude et qualification persistantes datées 15/11/2026; Lot136 complet comme archive complète retrouvée | Étude industrielle/NOM/BOM récente, pas BP fini ni calcul v107; rapport déclare aucun calcul et identifiants en conflit pour plusieurs candidats. | Aucun nouveau BP ni calcul attribué aux huit candidats; catalogue et IDs restent ceux du Lot136 en attente d’arbitrage. |
| Sept autres filières cibles (56 UP) | Matrices historiques dans Lot385 et lots anciens inclus | Identifiants, rubriques déclarées et anciennes valeurs RN traçables. | Dernière page BP/config/résultats v107 liés à chaque configuration non retrouvés dans les pièces accessibles durant cet audit; pas de statut de conformité induit. |

## Règle de rapprochement financier

Les tableaux utilisent les nombres stockés dans les fichiers source. Aucune somme, marge, résultat ou trésorerie n’a été recalculé. Pour le Lot352, les valeurs sont directement extraites de `SIMULATIONS_V107_LOT352.json`; pour le recyclage elles proviennent de `LOT317/SYNTHESE_V107.csv pour plastique/papier/métaux, LOT323/SYNTHESE_SCENARIOS.csv pour compost/verre/pneus/huiles, et Lot325/326 pour DEEE; Lot330/Lot344 identifient les versions récentes. Les résultats de l’ancienne matrice racine apparaissent séparément comme `RN A1 ancienne matrice`, jamais comme résultats courants.

Pour les sept UP métallurgie autres que chaudronnerie, les résultats Lot126 identifiés par Lot384 (configuration historique) restent distincts des scénarios actifs Lot352. Pour chaudronnerie, le résultat actif déficitaire Lot352 reste séparé du Lot372 et du fichier Lot381 marqué non publiable. Le Mobilier lot229 n’est pas présenté comme calcul actif du lot352.

## Verdict global

Sur 80 UP : **0 CONFORME**, **8 CONFORME AVEC RÉSERVES**, **8 À CORRIGER**, **64 NON VÉRIFIABLE**. Ce décompte mesure la preuve disponible dans les archives consultées et n’efface aucun travail antérieur. Les 64 dossiers ne sont pas déclarés inachevés : leur dernière version complète n’a pas pu être attachée à une preuve exploitable dans le corpus accessible pour ce rapport.
